package mathexp

import (
	"math"
	"time"

	"github.com/grafana/grafana-plugin-sdk-go/data"
)

// Common Test Constructor Utils and Types
type tp struct {
	t time.Time
	f *float64
}

func makeSeries(name string, labels data.Labels, points ...tp) Series {
	newSeries := NewSeries(name, labels, len(points))
	for idx, p := range points {
		newSeries.SetPoint(idx, p.t, p.f)
	}
	return newSeries
}

func makeNumber(name string, labels data.Labels, f *float64) Number {
	newNumber := NewNumber(name, labels)
	newNumber.SetValue(f)
	return newNumber
}

func unixTimePointer(sec, nsec int64) *time.Time {
	t := time.Unix(sec, nsec)
	return &t
}

func resultValuesNoErr(v ...Value) Results {
	return Results{
		Values: v,
		Error:  nil,
	}
}

var aSeries = Vars{
	"A": resultValuesNoErr(
		makeSeries("temp", nil, tp{
			time.Unix(5, 0), new(2.),
		}, tp{
			time.Unix(10, 0), new(1.),
		}),
	),
}

var aSeriesbNumber = Vars{
	"A": resultValuesNoErr(
		makeSeries("temp", nil, tp{
			time.Unix(5, 0), new(2.),
		}, tp{
			time.Unix(10, 0), new(1.),
		}),
	),
	"B": resultValuesNoErr(
		makeNumber("volt", data.Labels{"id": "1"}, new(7.)),
	),
}

var twoSeriesSets = Vars{
	"A": resultValuesNoErr(
		makeSeries("temp", data.Labels{"sensor": "a", "turbine": "1"}, tp{
			time.Unix(5, 0), new(6.),
		}, tp{
			time.Unix(10, 0), new(8.),
		}),
		makeSeries("temp", data.Labels{"sensor": "b", "turbine": "1"}, tp{
			time.Unix(5, 0), new(10.),
		}, tp{
			time.Unix(10, 0), new(16.),
		}),
	),
	"B": resultValuesNoErr(
		makeSeries("efficiency", data.Labels{"turbine": "1"}, tp{
			time.Unix(5, 0), new(.5),
		}, tp{
			time.Unix(10, 0), new(.2),
		}),
	),
}

// NaN is just to make the calls a little cleaner, the one
// call is not for any sort of equality side effect in tests.
// note: cmp.Equal must be used to test Equality for NaNs.
var NaN = new(math.NaN())
