use std::sync::Arc;
use std::time::{SystemTime, SystemTimeError, UNIX_EPOCH};

use async_trait::async_trait;
use chroma_error::{ChromaError, ErrorCodes};
use chroma_log::Log;
use chroma_system::{Operator, OperatorType};
use chroma_types::{Chunk, CollectionUuid, DatabaseName, LogRecord};
use thiserror::Error;
use tracing::Instrument;

use crate::execution::operators::fragment_fetch::{
    FragmentFetchError, FragmentFetcher, FragmentPointer,
};

/// The `FetchLogOperator` fetches logs from the log service.
///
/// Two strategies are supported, selected by `fragment_fetcher`:
///
/// 1. **gRPC pull** (default, when `fragment_fetcher` is `None`): `ScoutLogs` +
///    chunked concurrent `PullLogs` calls.
/// 2. **Pointer fetch** (when `fragment_fetcher` is `Some`):
///    `ScoutLogFragments` returns fragment pointers, then the embedded
///    `FragmentFetcher` reads parquet data directly from object storage.
///
/// # Parameters
/// - `log_client`: The log service reader
/// - `batch_size`: The maximum number of logs to fetch by `log_client` at a time
/// - `start_log_offset_id`: The offset id of the first log to read
/// - `maximum_fetch_count`: The maximum number of logs to fetch in total
/// - `collection_uuid`: The uuid of the collection where the fetched logs should belong
/// - `fetch_log_concurrency`: The maximum number of concurrent log fetch requests
/// - `fragment_fetcher`: When `Some`, use ScoutLogFragments + direct storage reads
///
/// # Inputs
/// - No input is required
///
/// # Outputs
/// - The contiguous chunk of logs belong to the collection with `collection_uuid`
///   starting from `start_log_offset_id`. At most `maximum_fetch_count` number of logs
///   will be fetched
///
/// # Usage
/// It should be run at the start of an orchestrator to get the latest data of a collection
#[derive(Clone, Debug)]
pub struct FetchLogOperator {
    pub log_client: Log,
    pub batch_size: u32,
    pub start_log_offset_id: u64,
    pub maximum_fetch_count: Option<u32>,
    pub collection_uuid: CollectionUuid,
    pub tenant: String,
    pub database_name: DatabaseName,
    pub fetch_log_concurrency: usize,
    pub fragment_fetcher: Option<Arc<FragmentFetcher>>,
    /// Exclusive upper bound on log offsets. When present, the operator uses
    /// this as the ceiling and skips its own scout call.
    pub log_upper_bound_offset: Option<u64>,
}

type FetchLogInput = ();

pub type FetchLogOutput = Chunk<LogRecord>;

#[derive(Error, Debug)]
pub enum FetchLogError {
    #[error("Error when pulling log: {0}")]
    PullLog(#[from] Box<dyn ChromaError>),
    #[error("Error when capturing system time: {0}")]
    SystemTime(#[from] SystemTimeError),
    #[error("Error dereferencing fragment pointer: {0}")]
    FragmentFetch(#[from] FragmentFetchError),
}

impl ChromaError for FetchLogError {
    fn code(&self) -> ErrorCodes {
        match self {
            FetchLogError::PullLog(e) => e.code(),
            FetchLogError::SystemTime(_) => ErrorCodes::Internal,
            FetchLogError::FragmentFetch(e) => e.code(),
        }
    }
}

impl FetchLogOperator {
    /// Fetch logs via the existing ScoutLogs + PullLogs gRPC path.
    #[tracing::instrument(skip(self))]
    async fn run_grpc_pull(&self) -> Result<FetchLogOutput, FetchLogError> {
        let mut log_client = self.log_client.clone();
        let mut limit_offset = if let Some(log_upper_bound_offset) = self.log_upper_bound_offset {
            log_upper_bound_offset
        } else {
            log_client
                .scout_logs(
                    &self.tenant,
                    self.database_name.clone(),
                    self.collection_uuid,
                    self.start_log_offset_id,
                )
                .await
                .inspect_err(|err| {
                    tracing::error!("could not pull logs: {err:?}");
                })?
        };
        let mut fetched = Vec::new();
        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH)?.as_nanos() as i64;

        if let Some(maximum_fetch_count) = self.maximum_fetch_count {
            limit_offset = std::cmp::min(
                limit_offset,
                self.start_log_offset_id + maximum_fetch_count as u64,
            );
        }

        let window_size: usize = self.batch_size as usize;
        let ranges = (self.start_log_offset_id..limit_offset)
            .step_by(window_size)
            .map(|x| (x, std::cmp::min(x + window_size as u64, limit_offset)))
            .collect::<Vec<_>>();
        let sema = Arc::new(tokio::sync::Semaphore::new(self.fetch_log_concurrency));
        let batch_readers = ranges
            .into_iter()
            .map(|(start, limit)| {
                let mut log_client = log_client.clone();
                let collection_uuid = self.collection_uuid;
                let database_name = self.database_name.clone();
                let num_records = (limit - start) as i32;
                let start = start as i64;
                let sema = Arc::clone(&sema);
                async move {
                    let _permit = sema.acquire().await.unwrap();
                    log_client
                        .read(
                            &self.tenant,
                            database_name,
                            collection_uuid,
                            start,
                            num_records,
                            Some(timestamp),
                        )
                        .await
                }
            })
            .collect::<Vec<_>>();
        let batches = futures::future::join_all(batch_readers).await;
        for batch in batches {
            match batch {
                Ok(batch) => fetched.extend(batch),
                Err(err) => {
                    return Err(FetchLogError::PullLog(Box::new(err)));
                }
            }
        }
        fetched.sort_by_key(|f| f.log_offset);
        Ok(Chunk::new(fetched.into()))
    }

    /// Fetch logs via ScoutLogFragments + direct object storage reads.
    #[tracing::instrument(skip(self))]
    async fn run_pointer_fetch(&self) -> Result<FetchLogOutput, FetchLogError> {
        let fragment_fetcher =
            self.fragment_fetcher
                .as_ref()
                .ok_or(FetchLogError::FragmentFetch(
                    FragmentFetchError::NotConfigured,
                ))?;

        let mut log_client = self.log_client.clone();
        let response = log_client
            .scout_log_fragments(
                self.database_name.clone(),
                self.collection_uuid,
                self.start_log_offset_id,
            )
            .instrument(
                tracing::info_span!("scout_log_fragments", collection_id = %self.collection_uuid, start_log_offset = self.start_log_offset_id),
            )
            .await?;

        let mut limit_offset = self
            .log_upper_bound_offset
            .unwrap_or(response.first_uninserted_record_offset);
        if let Some(maximum_fetch_count) = self.maximum_fetch_count {
            limit_offset = std::cmp::min(
                limit_offset,
                self.start_log_offset_id + maximum_fetch_count as u64,
            );
        }

        let pointers: Vec<FragmentPointer> = response
            .fragments
            .into_iter()
            .map(FragmentPointer::from)
            .collect();

        let fetched = fragment_fetcher
            .fetch_records(
                &pointers,
                self.start_log_offset_id,
                limit_offset,
                self.fetch_log_concurrency,
            )
            .await?;

        Ok(Chunk::new(fetched.into()))
    }
}

#[async_trait]
impl Operator<FetchLogInput, FetchLogOutput> for FetchLogOperator {
    type Error = FetchLogError;

    fn get_type(&self) -> OperatorType {
        OperatorType::IO
    }

    async fn run(&self, _: &FetchLogInput) -> Result<FetchLogOutput, FetchLogError> {
        tracing::debug!(
            batch_size = self.batch_size,
            start_log_offset_id = self.start_log_offset_id,
            maximum_fetch_count = self.maximum_fetch_count,
            collection_uuid = ?self.collection_uuid.0,
            use_fragment_fetch = self.fragment_fetcher.is_some(),
            "[{}]",
            self.get_name(),
        );

        if self.fragment_fetcher.is_some() {
            self.run_pointer_fetch().await
        } else {
            self.run_grpc_pull().await
        }
    }
}

#[cfg(test)]
mod tests {
    use chroma_log::{
        in_memory_log::{InMemoryLog, InternalLogRecord},
        test::{upsert_generator, LogGenerator},
    };
    use chroma_system::Operator;
    use chroma_types::CollectionUuid;

    use crate::execution::operators::fetch_log::FetchLogOperator;

    use super::Log;

    fn setup_in_memory_log() -> (CollectionUuid, Log) {
        let collection_id = CollectionUuid::new();
        let mut in_memory_log = InMemoryLog::new();
        upsert_generator
            .generate_vec(0..10)
            .into_iter()
            .for_each(|log| {
                in_memory_log.add_log(
                    collection_id,
                    InternalLogRecord {
                        collection_id,
                        log_offset: log.log_offset,
                        log_ts: log.log_offset,
                        record: log,
                    },
                )
            });
        (collection_id, Log::InMemory(in_memory_log))
    }

    #[tokio::test]
    async fn test_pull_all() {
        let (collection_uuid, log_client) = setup_in_memory_log();

        let fetch_log_operator = FetchLogOperator {
            log_client,
            batch_size: 2,
            start_log_offset_id: 0,
            maximum_fetch_count: None,
            collection_uuid,
            tenant: "test-tenant".to_string(),
            database_name: chroma_types::DatabaseName::new("test-db").unwrap(),
            fetch_log_concurrency: 10,
            fragment_fetcher: None,
            log_upper_bound_offset: None,
        };

        let logs = fetch_log_operator
            .run(&())
            .await
            .expect("Fetch log operator should not fail");

        assert_eq!(logs.len(), 10);
        logs.iter()
            .map(|(log, _)| log)
            .zip(0..10)
            .for_each(|(log, offset)| assert_eq!(log.log_offset, offset));
    }

    #[tokio::test]
    async fn test_pull_range() {
        let (collection_uuid, log_client) = setup_in_memory_log();

        let fetch_log_operator = FetchLogOperator {
            log_client,
            batch_size: 2,
            start_log_offset_id: 3,
            maximum_fetch_count: Some(3),
            collection_uuid,
            tenant: "test-tenant".to_string(),
            database_name: chroma_types::DatabaseName::new("test-db").unwrap(),
            fetch_log_concurrency: 10,
            fragment_fetcher: None,
            log_upper_bound_offset: None,
        };

        let logs = fetch_log_operator
            .run(&())
            .await
            .expect("FetchLogOperator should not fail");

        assert_eq!(logs.len(), 3);
        logs.iter()
            .map(|(log, _)| log)
            .zip(3..6)
            .for_each(|(log, offset)| assert_eq!(log.log_offset, offset));
    }

    #[tokio::test]
    async fn test_pull_with_upper_bound_offset() {
        let (collection_uuid, log_client) = setup_in_memory_log();

        let fetch_log_operator = FetchLogOperator {
            log_client,
            batch_size: 2,
            start_log_offset_id: 0,
            maximum_fetch_count: None,
            collection_uuid,
            tenant: "test-tenant".to_string(),
            database_name: chroma_types::DatabaseName::new("test-db").unwrap(),
            fetch_log_concurrency: 10,
            fragment_fetcher: None,
            log_upper_bound_offset: Some(5),
        };

        let logs = fetch_log_operator
            .run(&())
            .await
            .expect("FetchLogOperator should not fail");

        assert_eq!(logs.len(), 5);
        logs.iter()
            .map(|(log, _)| log)
            .zip(0..5)
            .for_each(|(log, offset)| assert_eq!(log.log_offset, offset));
    }

    #[tokio::test]
    async fn test_upper_bound_offset_with_start_offset() {
        let (collection_uuid, log_client) = setup_in_memory_log();

        let fetch_log_operator = FetchLogOperator {
            log_client,
            batch_size: 2,
            start_log_offset_id: 3,
            maximum_fetch_count: None,
            collection_uuid,
            tenant: "test-tenant".to_string(),
            database_name: chroma_types::DatabaseName::new("test-db").unwrap(),
            fetch_log_concurrency: 10,
            fragment_fetcher: None,
            log_upper_bound_offset: Some(7),
        };

        let logs = fetch_log_operator
            .run(&())
            .await
            .expect("FetchLogOperator should not fail");

        assert_eq!(logs.len(), 4);
        logs.iter()
            .map(|(log, _)| log)
            .zip(3..7)
            .for_each(|(log, offset)| assert_eq!(log.log_offset, offset));
    }
}
