use async_trait::async_trait;
use chroma_error::ChromaError;
use chroma_sysdb::sysdb::SysDb;
use chroma_system::{Operator, OperatorType};
use chroma_types::{
    AttachedFunction, AttachedFunctionConversionError, AttachedFunctionUuid, CollectionUuid,
    ListAttachedFunctionsError,
};
use thiserror::Error;

/// The `GetAttachedFunctionOperator` lists attached functions for a collection.
/// If no functions are found, it returns an empty result (not an error) to allow the orchestrator
/// to handle the case gracefully.
#[derive(Clone, Debug)]
pub struct GetAttachedFunctionOperator {
    pub sysdb: SysDb,
    pub collection_id: CollectionUuid,
}

impl GetAttachedFunctionOperator {
    pub fn new(sysdb: SysDb, collection_id: CollectionUuid) -> Self {
        Self {
            sysdb,
            collection_id,
        }
    }
}

#[derive(Debug)]
pub struct GetAttachedFunctionInput {
    pub collection_id: CollectionUuid,
    pub attached_function_id: Option<AttachedFunctionUuid>,
}

#[derive(Debug)]
pub struct GetAttachedFunctionOutput {
    pub attached_functions: Vec<AttachedFunction>,
}

#[derive(Debug, Error)]
pub enum GetAttachedFunctionOperatorError {
    #[error("Failed to list attached functions: {0}")]
    ListFunctions(#[from] ListAttachedFunctionsError),
    #[error("Failed to convert attached function proto")]
    ConversionError(#[from] AttachedFunctionConversionError),
    #[error("No attached function found")]
    NoAttachedFunctionFound,
}

#[derive(Debug, Error)]
pub enum GetAttachedFunctionError {
    #[error("Failed to list attached functions: {0}")]
    ListFunctions(#[from] ListAttachedFunctionsError),
    #[error("Failed to convert attached function proto")]
    ConversionError(#[from] AttachedFunctionConversionError),
}

impl ChromaError for GetAttachedFunctionError {
    fn code(&self) -> chroma_error::ErrorCodes {
        match self {
            GetAttachedFunctionError::ListFunctions(e) => e.code(),
            GetAttachedFunctionError::ConversionError(_) => chroma_error::ErrorCodes::Internal,
        }
    }

    fn should_trace_error(&self) -> bool {
        match self {
            GetAttachedFunctionError::ListFunctions(e) => e.should_trace_error(),
            GetAttachedFunctionError::ConversionError(_) => true,
        }
    }
}

impl ChromaError for GetAttachedFunctionOperatorError {
    fn code(&self) -> chroma_error::ErrorCodes {
        match self {
            GetAttachedFunctionOperatorError::ListFunctions(e) => e.code(),
            GetAttachedFunctionOperatorError::ConversionError(_) => {
                chroma_error::ErrorCodes::Internal
            }
            GetAttachedFunctionOperatorError::NoAttachedFunctionFound => {
                chroma_error::ErrorCodes::NotFound
            }
        }
    }

    fn should_trace_error(&self) -> bool {
        match self {
            GetAttachedFunctionOperatorError::ListFunctions(e) => e.should_trace_error(),
            GetAttachedFunctionOperatorError::ConversionError(_) => true,
            GetAttachedFunctionOperatorError::NoAttachedFunctionFound => false,
        }
    }
}

#[async_trait]
impl Operator<GetAttachedFunctionInput, GetAttachedFunctionOutput> for GetAttachedFunctionOperator {
    type Error = GetAttachedFunctionOperatorError;

    fn get_type(&self) -> OperatorType {
        OperatorType::IO
    }

    async fn run(
        &self,
        input: &GetAttachedFunctionInput,
    ) -> Result<GetAttachedFunctionOutput, GetAttachedFunctionOperatorError> {
        tracing::trace!(
            "[{}]: Collection ID {}",
            self.get_name(),
            input.collection_id.0
        );

        let attached_functions = self
            .sysdb
            .clone()
            .list_attached_functions(input.collection_id)
            .await?;

        if attached_functions.is_empty() {
            tracing::info!(
                "[{}]: No attached functions found for collection {}",
                self.get_name(),
                input.collection_id.0
            );
            return Ok(GetAttachedFunctionOutput {
                attached_functions: Vec::new(),
            });
        }

        let attached_functions = attached_functions
            .into_iter()
            .map(AttachedFunction::try_from)
            .collect::<Result<Vec<_>, _>>()
            .map_err(GetAttachedFunctionOperatorError::ConversionError)?;

        let attached_functions = match input.attached_function_id {
            Some(attached_function_id) => vec![attached_functions
                .into_iter()
                .find(|attached_function| attached_function.id == attached_function_id)
                .ok_or(GetAttachedFunctionOperatorError::NoAttachedFunctionFound)?],
            None => attached_functions,
        };

        tracing::info!(
            "[{}]: Found {} attached function(s) for collection {}",
            self.get_name(),
            attached_functions.len(),
            input.collection_id.0
        );

        Ok(GetAttachedFunctionOutput { attached_functions })
    }
}
