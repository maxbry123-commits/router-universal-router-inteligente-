############################ Copyrights and license ############################
#                                                                              #
# Copyright 2012 Vincent Jacques <vincent@vincent-jacques.net>                 #
# Copyright 2012 Zearin <zearin@gonk.net>                                      #
# Copyright 2013 Vincent Jacques <vincent@vincent-jacques.net>                 #
# Copyright 2014 Vincent Jacques <vincent@vincent-jacques.net>                 #
# Copyright 2016 Jannis Gebauer <ja.geb@me.com>                                #
# Copyright 2016 Peter Buckley <dx-pbuckley@users.noreply.github.com>          #
# Copyright 2018 sfdye <tsfdye@gmail.com>                                      #
# Copyright 2019 Steve Kowalik <steven@wedontsleep.org>                        #
# Copyright 2019 TechnicalPirate <35609336+TechnicalPirate@users.noreply.github.com>#
# Copyright 2019 Wan Liuyang <tsfdye@gmail.com>                                #
# Copyright 2020 Steve Kowalik <steven@wedontsleep.org>                        #
# Copyright 2023 Enrico Minack <github@enrico.minack.dev>                      #
# Copyright 2023 Jirka Borovec <6035284+Borda@users.noreply.github.com>        #
# Copyright 2025 Cristiano Salerno <119511125+csalerno-asml@users.noreply.github.com>#
# Copyright 2025 Enrico Minack <github@enrico.minack.dev>                      #
# Copyright 2026 Laura Lacort Zimmermann <81427562+laurazimrn@users.noreply.github.com>#
#                                                                              #
# This file is part of PyGithub.                                               #
# http://pygithub.readthedocs.io/                                              #
#                                                                              #
# PyGithub is free software: you can redistribute it and/or modify it under    #
# the terms of the GNU Lesser General Public License as published by the Free  #
# Software Foundation, either version 3 of the License, or (at your option)    #
# any later version.                                                           #
#                                                                              #
# PyGithub is distributed in the hope that it will be useful, but WITHOUT ANY  #
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS    #
# FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more #
# details.                                                                     #
#                                                                              #
# You should have received a copy of the GNU Lesser General Public License     #
# along with PyGithub. If not, see <http://www.gnu.org/licenses/>.             #
#                                                                              #
################################################################################

from __future__ import annotations

from github import InputGitTreeElement

from . import Framework


class GitRef(Framework.TestCase):
    def setUp(self):
        super().setUp()
        self.ref = self.g.get_user().get_repo("PyGithub").get_git_ref("heads/BranchCreatedByPyGithub")

    def testAttributes(self):
        self.assertIsNone(self.ref.node_id)
        self.assertEqual(self.ref.object.sha, "1292bf0e22c796e91cc3d6e24b544aece8c21f2a")
        self.assertEqual(self.ref.object.type, "commit")
        self.assertEqual(
            self.ref.object.url,
            "https://api.github.com/repos/jacquev6/PyGithub/git/commits/1292bf0e22c796e91cc3d6e24b544aece8c21f2a",
        )
        self.assertEqual(self.ref.ref, "ref/heads/BranchCreatedByPyGithub")
        self.assertEqual(
            self.ref.url,
            "https://api.github.com/repos/jacquev6/PyGithub/git/ref/heads/BranchCreatedByPyGithub",
        )

        self.assertEqual(repr(self.ref), 'GitRef(ref="ref/heads/BranchCreatedByPyGithub")')
        self.assertEqual(
            repr(self.ref.object),
            'GitObject(sha="1292bf0e22c796e91cc3d6e24b544aece8c21f2a")',
        )

    def testLazyAttributes(self):
        ref = self.g.withLazy(True).get_repo("lazy/repo").get_git_ref("refs/heads/main")
        self.assertEqual(str(ref), 'GitRef(ref="refs/heads/main")')
        self.assertEqual(ref.ref, "refs/heads/main")
        self.assertEqual(ref.url, "/repos/lazy/repo/git/ref/refs/heads/main")

    def testEdit(self):
        self.ref.edit("04cde900a0775b51f762735637bd30de392a2793")

    def testEditWithForce(self):
        self.ref.edit("4303c5b90e2216d927155e9609436ccb8984c495", force=True)

    def testExample(self):
        repo = self.g.get_repo("EnricoMi/PyGithub")
        branch = "commit-with-multiple-files"

        files_to_commit = {
            "path/to/file_one.txt": "content of file one",
            "path/to/file_two.txt": "content of file two",
        }

        ref = repo.get_git_ref(f"heads/{branch}")
        base_tree = repo.get_git_tree(ref.object.sha)

        element_list = [
            InputGitTreeElement(path=path, mode="100644", type="blob", content=content)
            for path, content in files_to_commit.items()
        ]

        tree = repo.create_git_tree(element_list, base_tree)
        parent = repo.get_git_commit(ref.object.sha)
        commit = repo.create_git_commit("Add multiple files in one commit", tree, [parent])
        ref.edit(commit.sha)

    def testDelete(self):
        self.ref.delete()
