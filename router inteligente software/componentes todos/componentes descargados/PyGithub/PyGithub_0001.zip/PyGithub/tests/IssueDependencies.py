############################ Copyrights and license ############################
#                                                                              #
# Copyright 2021 Claire Johns <42869556+johnsc1@users.noreply.github.com>      #
# Copyright 2023 Enrico Minack <github@enrico.minack.dev>                      #
# Copyright 2025 Enrico Minack <github@enrico.minack.dev>                      #
# Copyright 2026 James Geiger <james-geiger@users.noreply.github.com>          #
# Copyright 2026 Nayak <omk.nyk2729@gmail.com>                                 #
#                                                                              #
# This file is part of PyGithub.                                               #
# http://pygithub.readthedocs.io/                                              #
#                                                                              #
# PyGithub is free software: you can redistribute it and/or modify it under    #
# the terms of the GNU Lesser General Public License as published by the Free  #
# Software Foundation, either version 3 of the License, or (at your option)    #
# any later version.                                                           #
#                                                                              #
# PyGithub is distributed in the hope that it will be useful, but WITHOUT ANY  #
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS    #
# FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more #
# details.                                                                     #
#                                                                              #
# You should have received a copy of the GNU Lesser General Public License     #
# along with PyGithub. If not, see <http://www.gnu.org/licenses/>.             #
#                                                                              #
################################################################################

from __future__ import annotations

from . import Framework


class IssueDependencies(Framework.TestCase):
    def setUp(self):
        super().setUp()
        self.repo = self.g.withLazy(True).get_repo("EnricoMi/PyGithub")
        self.issue = self.repo.get_issue(24).complete()
        self.blocking_issue = self.repo.get_issue(13).complete()

    def testAddBlockedBy(self):
        self.assertNotIn(self.blocking_issue, list(self.issue.get_blocked_by()))
        self.issue.add_blocked_by(self.blocking_issue)
        self.assertIn(self.blocking_issue, list(self.issue.get_blocked_by()))

    def testRemoveBlockedBy(self):
        self.assertIn(self.blocking_issue, list(self.issue.get_blocked_by()))
        self.issue.remove_blocked_by(self.blocking_issue)
        self.assertNotIn(self.blocking_issue, list(self.issue.get_blocked_by()))
