// Protocol definitions and validation for various LLM APIs
// This module provides a structured approach to handling different API protocols

pub mod spec;
pub mod validation;
pub mod worker_spec;
