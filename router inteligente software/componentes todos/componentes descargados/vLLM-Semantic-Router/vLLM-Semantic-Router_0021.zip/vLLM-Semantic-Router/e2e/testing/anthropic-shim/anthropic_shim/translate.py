"""Pure translation helpers used by the proxy.

The functions here are deliberately framework-free so they can be
exercised by unit tests without spinning up a server or a model.

Three concerns are handled:

1. ``join_system_array`` flattens a Messages-API ``system`` array of
   ``TextBlockParam`` entries into a single newline-separated string.
   llama-server otherwise concatenates the text fields with no
   separator, which destroys word boundaries.
2. ``join_tool_result_content`` does the same for the ``content`` array
   of a ``tool_result`` block.
3. ``apply_cache_usage`` post-processes a Messages response and
   synthesises ``cache_creation_input_tokens`` /
   ``cache_read_input_tokens`` based on whether the inbound request
   carried ``cache_control`` markers and whether this session has seen
   the same request-body prefix before.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


def _is_text_block(block: Any) -> bool:
    return (
        isinstance(block, dict)
        and block.get("type") == "text"
        and isinstance(block.get("text"), str)
    )


def join_system_array(body: dict[str, Any]) -> dict[str, Any]:
    """Collapse ``system`` array into a single newline-joined string.

    Mutates and returns ``body``. No-op when ``system`` is missing or
    already a string. Non-text blocks are silently dropped (the
    Messages API permits only text blocks in ``system`` today).
    """
    system = body.get("system")
    if not isinstance(system, list):
        return body
    texts = [block["text"] for block in system if _is_text_block(block)]
    body["system"] = "\n".join(texts)
    return body


def join_tool_result_content(body: dict[str, Any]) -> dict[str, Any]:
    """Collapse every ``tool_result.content`` array into a single string.

    Walks all message blocks and rewrites ``tool_result`` entries whose
    ``content`` is an array of text blocks. Non-array contents
    (already a string, or absent) are left untouched. Non-text array
    entries are skipped, matching llama-server's expectation that
    ``tool_result.content`` carries only text.
    """
    messages = body.get("messages")
    if not isinstance(messages, list):
        return body
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue
            tr_content = block.get("content")
            if not isinstance(tr_content, list):
                continue
            texts = [item["text"] for item in tr_content if _is_text_block(item)]
            block["content"] = "\n".join(texts)
    return body


def anthropic_to_openai(body: dict[str, Any]) -> dict[str, Any]:
    """Translate the Messages subset used by E2E into chat completions."""
    translated: dict[str, Any] = {
        "model": body.get("model"),
        "messages": [],
    }
    system = body.get("system")
    if isinstance(system, str) and system:
        translated["messages"].append({"role": "system", "content": system})
    for message in body.get("messages") or []:
        if not isinstance(message, dict):
            continue
        translated["messages"].append(
            {
                "role": message.get("role"),
                "content": _openai_message_content(message.get("content")),
            }
        )
    field_map = {
        "max_tokens": "max_tokens",
        "temperature": "temperature",
        "top_p": "top_p",
        "stream": "stream",
        "stop_sequences": "stop",
    }
    for source, target in field_map.items():
        if source in body:
            translated[target] = body[source]
    output_config = body.get("output_config")
    output_format = (
        output_config.get("format") if isinstance(output_config, dict) else None
    )
    if isinstance(output_format, dict) and output_format.get("type") == "json_schema":
        translated["response_format"] = {
            "type": "json_schema",
            "json_schema": {
                "name": "structured_output",
                "strict": True,
                "schema": output_format.get("schema"),
            },
        }
    if translated.get("stream"):
        translated["stream_options"] = {"include_usage": True}
    return translated


class OpenAIStreamToAnthropic:
    """Stateful adapter from chat-completions chunks to Messages events.

    The adapter emits the official Messages event order and defers terminal
    events until the OpenAI ``[DONE]`` sentinel (or upstream EOF), allowing a
    final usage-only chunk to contribute authoritative output accounting.
    """

    def __init__(self, request_body: dict[str, Any]) -> None:
        self._request_body = request_body
        self._started = False
        self._finished = False
        self._response_id = "msg_shim_stream"
        self._model = str(request_body.get("model") or "")
        self._finish_reason = "stop"
        self._output_tokens = 0

    def feed(self, payload: str) -> list[bytes]:
        if self._finished:
            return []
        if payload.strip() == "[DONE]":
            return self.finish()
        try:
            chunk = json.loads(payload)
        except json.JSONDecodeError:
            return []
        if not isinstance(chunk, dict):
            return []

        self._response_id = str(chunk.get("id") or self._response_id)
        self._model = str(chunk.get("model") or self._model)
        usage = chunk.get("usage")
        if isinstance(usage, dict):
            self._output_tokens = int(usage.get("completion_tokens") or 0)

        events = self._start_events()
        choices = chunk.get("choices")
        choice = choices[0] if isinstance(choices, list) and choices else None
        if not isinstance(choice, dict):
            return events
        finish_reason = choice.get("finish_reason")
        if isinstance(finish_reason, str) and finish_reason:
            self._finish_reason = finish_reason
        delta = choice.get("delta")
        if isinstance(delta, dict) and isinstance(delta.get("content"), str):
            text = delta["content"]
            if text:
                events.append(
                    _anthropic_sse(
                        "content_block_delta",
                        {
                            "type": "content_block_delta",
                            "index": 0,
                            "delta": {"type": "text_delta", "text": text},
                        },
                    )
                )
        return events

    def finish(self) -> list[bytes]:
        if self._finished:
            return []
        events = self._start_events()
        self._finished = True
        stop_reason = _anthropic_stop_reason(
            self._finish_reason,
            self._request_body.get("stop_sequences") or [],
        )
        stop_sequences = self._request_body.get("stop_sequences") or []
        matched_stop_sequence = (
            stop_sequences[0] if stop_reason == "stop_sequence" else None
        )
        events.extend(
            [
                _anthropic_sse(
                    "content_block_stop",
                    {"type": "content_block_stop", "index": 0},
                ),
                _anthropic_sse(
                    "message_delta",
                    {
                        "type": "message_delta",
                        "delta": {
                            "stop_reason": stop_reason,
                            "stop_sequence": matched_stop_sequence,
                        },
                        "usage": {"output_tokens": self._output_tokens},
                    },
                ),
                _anthropic_sse("message_stop", {"type": "message_stop"}),
            ]
        )
        return events

    def _start_events(self) -> list[bytes]:
        if self._started:
            return []
        self._started = True
        return [
            _anthropic_sse(
                "message_start",
                {
                    "type": "message_start",
                    "message": {
                        "id": self._response_id,
                        "type": "message",
                        "role": "assistant",
                        "model": self._model,
                        "content": [],
                        "stop_reason": None,
                        "stop_sequence": None,
                        "usage": {"input_tokens": 0, "output_tokens": 0},
                    },
                },
            ),
            _anthropic_sse(
                "content_block_start",
                {
                    "type": "content_block_start",
                    "index": 0,
                    "content_block": {"type": "text", "text": ""},
                },
            ),
        ]


def _anthropic_sse(event: str, payload: dict[str, Any]) -> bytes:
    return f"event: {event}\ndata: {json.dumps(payload, separators=(',', ':'))}\n\n".encode()


def _anthropic_stop_reason(finish_reason: str, stop_sequences: list[Any]) -> str:
    if finish_reason == "length":
        return "max_tokens"
    if finish_reason == "tool_calls":
        return "tool_use"
    if finish_reason == "stop" and stop_sequences:
        return "stop_sequence"
    return "end_turn"


def openai_to_anthropic(
    response: dict[str, Any], request_body: dict[str, Any]
) -> dict[str, Any]:
    """Translate a chat-completions response into Messages wire shape."""
    if response.get("type") == "message":
        return response
    choices = response.get("choices") or []
    choice = choices[0] if choices and isinstance(choices[0], dict) else {}
    message = choice.get("message") if isinstance(choice.get("message"), dict) else {}
    text = str(message.get("content") or "")
    finish_reason = str(choice.get("finish_reason") or "")
    stop_sequences = request_body.get("stop_sequences") or []
    stop_reason = _anthropic_stop_reason(finish_reason, stop_sequences)
    usage = response.get("usage") if isinstance(response.get("usage"), dict) else {}
    return {
        "id": response.get("id", "msg_shim"),
        "type": "message",
        "role": "assistant",
        "model": response.get("model") or request_body.get("model"),
        "content": [{"type": "text", "text": text}],
        "stop_reason": stop_reason,
        "stop_sequence": stop_sequences[0] if stop_reason == "stop_sequence" else None,
        "usage": {
            "input_tokens": int(usage.get("prompt_tokens") or 0),
            "output_tokens": int(usage.get("completion_tokens") or 0),
        },
    }


def _openai_message_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""
    return "\n".join(
        str(block.get("text") or "")
        for block in content
        if isinstance(block, dict) and block.get("type") == "text"
    )


def has_cache_control(body: dict[str, Any]) -> bool:
    """Return True when any block in the request carries a ``cache_control`` marker."""
    system = body.get("system")
    if isinstance(system, list):
        for block in system:
            if isinstance(block, dict) and "cache_control" in block:
                return True
    for message in body.get("messages", []) or []:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and "cache_control" in block:
                    return True
    for tool in body.get("tools", []) or []:
        if isinstance(tool, dict) and "cache_control" in tool:
            return True
    return False


def cache_prefix_hash(body: dict[str, Any]) -> str:
    """Hash the cacheable prefix of a request.

    Anthropic's prompt-cache contract keys on the request prefix up to
    and including the last block bearing ``cache_control``. The shim
    walks ``tools``, ``system``, then each message's ``content``
    blocks in order, and stops at the last marker. Everything past
    that marker (subsequent turns, the final user query) is treated as
    cache-irrelevant. The hash is opaque; only equality matters.
    """
    prefix_parts: list[Any] = []

    tool_prefix = _tools_prefix(body.get("tools") or [])
    if tool_prefix is not None:
        prefix_parts.append({"tools": tool_prefix})

    system = body.get("system")
    if _should_include_system(body, system, tool_prefix is not None):
        prefix_parts.append({"system": system})

    message_prefix = _messages_prefix(body.get("messages") or [])
    if message_prefix is not None:
        prefix_parts.append({"messages": message_prefix})

    digest = hashlib.sha256(
        json.dumps(prefix_parts, sort_keys=True, default=str).encode("utf-8")
    )
    return digest.hexdigest()


def _tools_prefix(tools: list[Any]) -> list[Any] | None:
    """Return tools up to and including the last cache_control marker, or None."""
    last_marker = -1
    for idx, tool in enumerate(tools):
        if isinstance(tool, dict) and "cache_control" in tool:
            last_marker = idx
    return tools[: last_marker + 1] if last_marker >= 0 else None


def _should_include_system(
    body: dict[str, Any], system: Any, tools_have_marker: bool
) -> bool:
    """The system block joins the prefix if any later cached block exists."""
    if system is None:
        return False
    if tools_have_marker:
        return True
    if isinstance(system, list) and any(
        isinstance(block, dict) and "cache_control" in block for block in system
    ):
        return True
    return _messages_have_marker(body)


def _messages_prefix(messages: list[Any]) -> list[Any] | None:
    """Return messages truncated to the last cache_control marker, or None."""
    cutoff_message = -1
    cutoff_block = -1
    for m_idx, message in enumerate(messages):
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for b_idx, block in enumerate(content):
            if isinstance(block, dict) and "cache_control" in block:
                cutoff_message = m_idx
                cutoff_block = b_idx
    if cutoff_message < 0:
        return None
    truncated: list[Any] = list(messages[:cutoff_message])
    last = messages[cutoff_message]
    if isinstance(last, dict) and isinstance(last.get("content"), list):
        partial = dict(last)
        partial["content"] = last["content"][: cutoff_block + 1]
        truncated.append(partial)
    else:
        truncated.append(last)
    return truncated


def _messages_have_marker(body: dict[str, Any]) -> bool:
    for message in body.get("messages") or []:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and "cache_control" in block:
                    return True
    return False


def apply_cache_usage(
    response: dict[str, Any],
    request_had_cache_control: bool,
    prefix_seen: bool,
) -> dict[str, Any]:
    """Populate ``cache_creation_input_tokens`` and ``cache_read_input_tokens``.

    Mutates and returns ``response``. The Anthropic contract says:
    on the first request with a given cache prefix, the whole input
    counts as a creation; on subsequent requests, the same input
    counts as a read. llama-server reports neither field today, so the
    shim fills them in from ``input_tokens``.
    """
    if not request_had_cache_control:
        return response
    usage = response.get("usage")
    if not isinstance(usage, dict):
        return response
    input_tokens = usage.get("input_tokens", 0)
    if prefix_seen:
        usage.setdefault("cache_creation_input_tokens", 0)
        usage["cache_read_input_tokens"] = input_tokens
    else:
        usage["cache_creation_input_tokens"] = input_tokens
        usage.setdefault("cache_read_input_tokens", 0)
    return response
