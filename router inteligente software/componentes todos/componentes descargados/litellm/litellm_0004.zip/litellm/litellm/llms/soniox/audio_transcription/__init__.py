"""Soniox audio transcription implementation."""
