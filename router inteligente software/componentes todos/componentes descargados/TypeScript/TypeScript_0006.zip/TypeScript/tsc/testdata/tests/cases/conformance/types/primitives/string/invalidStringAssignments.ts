// @target: es2015
var x = '';

var a: boolean = x;
var b: number = x;
var c: void = x;
var d: typeof undefined = x;

class C { foo: string; }
var e: C = x;

interface I { bar: string; }
var f: I = x;

var g: { baz: string } = 1;
var g2: { 0: number } = 1;

namespace M { export var x = 1; }
M = x;

function i<T>(a: T) {
    a = x;
}
i = x;

enum E { A }
var j: E = x;