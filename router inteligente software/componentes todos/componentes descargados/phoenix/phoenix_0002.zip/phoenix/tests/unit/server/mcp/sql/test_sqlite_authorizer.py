import logging
import sqlite3
from pathlib import Path
from typing import Any

import pytest
import sqlean

from phoenix.server.mcp.sql.execute import _Denial, _sqlite_authorizer


def test_sqlite_authorizer_denies_table_and_function(tmp_path: Path) -> None:
    db_path = tmp_path / "auth.db"
    conn_rw = sqlite3.connect(db_path)
    conn_rw.executescript("CREATE TABLE spans(id INTEGER); CREATE TABLE api_keys(secret TEXT);")
    conn_rw.close()

    ro = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    ro.set_authorizer(_sqlite_authorizer(frozenset({"spans"}), frozenset({"count"})))

    def denies(sql: str) -> bool:
        try:
            ro.execute(sql).fetchone()
        except sqlite3.Error:
            return True
        return False

    try:
        ro.execute("SELECT count(id) FROM spans").fetchone()
        # `api_keys` was created for this and then never queried, so the table
        # half of the name was untested: deleting the authorizer's table branch
        # left this green. It is the half that matters more -- a denied function
        # costs a query, a readable table costs the data in it.
        assert denies("SELECT secret FROM api_keys")
        assert denies("SELECT abs(id) FROM spans")
    finally:
        ro.close()


def test_cte_name_cannot_mask_a_forbidden_physical_table(tmp_path: Path) -> None:
    db_path = tmp_path / "auth.db"
    connection = sqlite3.connect(db_path)
    connection.executescript(
        "CREATE TABLE spans(id INTEGER); "
        "CREATE TABLE api_keys(secret TEXT); "
        "INSERT INTO api_keys VALUES('TOPSECRET');"
    )
    connection.set_authorizer(
        _sqlite_authorizer(
            frozenset({"spans"}), frozenset(), introduced_relations=frozenset({"api_keys"})
        )
    )
    try:
        with pytest.raises(sqlite3.Error):
            connection.execute(
                "WITH api_keys AS (SELECT secret FROM main.api_keys) SELECT secret FROM api_keys"
            ).fetchall()
    finally:
        connection.close()


def test_sqlite_authorizer_denies_state_changes_and_attached_databases(tmp_path: Path) -> None:
    """The engine backstop must hold if a non-SELECT bypasses admission."""
    db_path = tmp_path / "auth.db"
    conn_rw = sqlite3.connect(db_path)
    conn_rw.execute("CREATE TABLE spans(id INTEGER)")
    conn_rw.close()

    guarded = sqlite3.connect(db_path)
    guarded.set_authorizer(_sqlite_authorizer(frozenset({"spans"}), frozenset()))

    def denies(sql: str) -> bool:
        try:
            guarded.execute(sql)
        except sqlite3.Error:
            return True
        return False

    try:
        assert denies("ATTACH DATABASE ':memory:' AS evil")
        assert denies("DELETE FROM spans")
        authorizer = _sqlite_authorizer(frozenset({"spans"}), frozenset())
        assert (
            authorizer(sqlite3.SQLITE_CREATE_VTABLE, "virtual_spans", None, "main", None)
            == sqlite3.SQLITE_DENY
        )
        assert (
            authorizer(sqlite3.SQLITE_DROP_VTABLE, "virtual_spans", None, "main", None)
            == sqlite3.SQLITE_DENY
        )
        assert (
            authorizer(
                sqlite3.SQLITE_READ,
                "spans",
                "id",
                "evil",
                None,
            )
            == sqlite3.SQLITE_DENY
        )
    finally:
        guarded.close()


def test_denial_distinguishes_a_bypass_from_a_layering_defect(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """The two causes of a denial need different reactions, so they need different logs.

    A denied name that belongs to Phoenix's schema means admission let through a
    table it should have refused, which is the case this gate exists for. A
    denied name belonging to no table means the statement or its rewrites created
    a relation the gate did not know about, which refuses a query the caller was
    entitled to run.

    Logged identically, the second drowns the first. Over one measured session
    the table check fired eleven times and every hit was the second kind, which
    was invisible until the two were separated.
    """
    import sqlite3

    for table, expect_bypass in (("api_keys", True), ("some_cte_alias", False)):
        caplog.clear()
        with caplog.at_level(logging.ERROR):
            authorizer = _sqlite_authorizer(frozenset({"spans"}), frozenset())
            verdict = authorizer(sqlite3.SQLITE_READ, table, "col", "main", None)
        assert verdict == sqlite3.SQLITE_DENY
        logged = caplog.text
        assert ("admission bypass" in logged) is expect_bypass, (
            f"{table!r} was classified wrongly: {logged!r}"
        )
        assert ("layering defect" in logged) is not expect_bypass


@pytest.mark.parametrize(
    ("sql", "allowed"),
    [
        ("SELECT (SELECT count(*) FROM users)", False),
        ("SELECT (SELECT count(*) FROM sqlite_master)", False),
        ("SELECT (SELECT count(*) FROM sqlite_schema)", False),
        ("SELECT count(*) FROM projects", True),
        ("WITH t AS (SELECT id FROM projects GROUP BY id) SELECT count(*) FROM t", True),
    ],
    ids=[
        "count-forbidden-table",
        "count-catalog",
        "count-catalog-alias",
        "count-allowed-table",
        "count-materialised-cte",
    ],
)
def test_table_level_reads_are_judged_before_the_transient_accept(sql: str, allowed: bool) -> None:
    """`count(*)` names no column, so its read presents with no database attached.

    That is indistinguishable in shape from a materialised CTE, so an accept
    path for transient tables placed first returned OK before the catalog deny
    and before the allowlist check — and this gate stopped being a backstop for
    every count-shaped read. Admission refuses these independently, so nothing
    leaked; what was missing was the second layer, which the authorizer's own
    logging calls by name.

    The CTE case is here to keep the fix honest: reordering must not re-break
    the materialised-CTE reads that the transient accept was added for.
    """
    import sqlean

    conn = sqlean.connect(":memory:")
    try:
        conn.execute("CREATE TABLE users(id INTEGER)")
        conn.execute("INSERT INTO users VALUES(1)")
        conn.execute("CREATE TABLE projects(id INTEGER)")
        conn.execute("INSERT INTO projects VALUES(1)")
        conn.set_authorizer(
            _sqlite_authorizer(
                frozenset({"projects"}), frozenset({"count"}), None, frozenset({"t"})
            )
        )
        try:
            conn.execute(sql).fetchone()
            permitted = True
        except Exception:
            permitted = False
    finally:
        conn.close()
    assert permitted is allowed


def test_catalog_aliases_are_denied_on_table_level_reads() -> None:
    """A table-level read presents with no database name, matching a CTE.

    sqlite_schema and sqlite_stat1 are not sqlite_master and are not Phoenix
    tables, so they used to fall through to the transient accept.
    """
    authorizer = _sqlite_authorizer(frozenset({"spans"}), frozenset({"count"}))
    for table in ("sqlite_master", "sqlite_schema", "sqlite_temp_master", "sqlite_stat1"):
        assert authorizer(sqlite3.SQLITE_READ, table, "", None, None) == sqlite3.SQLITE_DENY
        assert authorizer(sqlite3.SQLITE_READ, table, "sql", "main", None) == sqlite3.SQLITE_DENY


class TestProvenance:
    """The authorizer decided on a table *name*, which the caller can choose.

    A read of an allowlisted table and a read through a database object merely
    named after one were the same event, because the fifth authorizer argument
    -- the view or trigger responsible for the access -- was discarded. See F2.
    """

    @staticmethod
    def _connection(denials: list[_Denial]) -> Any:
        connection = sqlean.connect(":memory:")
        connection.execute("CREATE TABLE spans (id INTEGER, secret TEXT)")
        connection.execute("INSERT INTO spans VALUES (1, 'hidden-value')")
        connection.execute("CREATE TEMP VIEW shadow AS SELECT id, secret FROM spans")
        connection.set_authorizer(
            _sqlite_authorizer(
                allow_tables=frozenset({"spans"}),
                allowed_functions=frozenset({"count"}),
                denials=denials,
                introduced_relations=frozenset({"t"}),
            )
        )
        return connection

    def test_a_direct_read_of_an_allowlisted_table_is_permitted(self) -> None:
        connection = self._connection([])
        try:
            assert connection.execute("SELECT secret FROM spans").fetchall() == [("hidden-value",)]
        finally:
            connection.close()

    def test_a_relation_the_statement_declared_is_permitted(self) -> None:
        """A CTE reports its own name as the provenance of the underlying read,
        so the rule has to admit the ones admission already saw."""
        connection = self._connection([])
        try:
            rows = connection.execute(
                "WITH t AS (SELECT id FROM spans) SELECT id FROM t"
            ).fetchall()
            assert rows == [(1,)]
        finally:
            connection.close()

    def test_a_read_through_an_undeclared_view_is_denied(self) -> None:
        """The object is in the database rather than the statement, so admission
        never approved it, and this callback cannot see what it selects."""
        denials: list[_Denial] = []
        connection = self._connection(denials)
        try:
            with pytest.raises(Exception):
                connection.execute("SELECT secret FROM shadow").fetchall()
        finally:
            connection.close()

        assert denials
        assert denials[-1].identifier == "shadow"
        assert "did not declare" in denials[-1].message
