"""Declarative regression cases for analytics SQL admission."""

from __future__ import annotations

from dataclasses import dataclass

from phoenix.db.helpers import SupportedSQLDialectName
from phoenix.server.mcp.sql.parse import AdmissionOutcome


@dataclass(frozen=True)
class AdmissionCase:
    sql: str
    expect: AdmissionOutcome
    note: str
    dialect: SupportedSQLDialectName = "postgresql"


CASES: tuple[AdmissionCase, ...] = (
    AdmissionCase(
        sql="SELECT id FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="simple select against an allowlisted table",
    ),
    AdmissionCase(
        sql="SELECT * FROM users",
        expect=AdmissionOutcome.RELATION_NOT_ALLOWED,
        note="relation absent from the manifest",
    ),
    AdmissionCase(
        sql="SELECT generate_series(1, 100000000000) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="set-returning function that SQLGlot models with a dedicated node class, so a check inspecting only generic call nodes misses it",
    ),
    AdmissionCase(
        sql="SELECT * FROM generate_series(1, 100000000000)",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="same function in table position; must be refused for being disallowed, not incidentally because the parser produced an empty table name",
    ),
    AdmissionCase(
        sql="SELECT * FROM unnest(ARRAY[1,2,3])",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="array unnest in table position, modelled with a dedicated node class",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans; DROP TABLE users",
        expect=AdmissionOutcome.MULTI_STATEMENT,
        note="two statements must be refused, never truncated to the first",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans /* /* */ WHERE 1=0 */",
        expect=AdmissionOutcome.ADMIT,
        note="nested comment must not survive into the rendered statement",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans /* /* */ ; DROP TABLE api_keys */",
        expect=AdmissionOutcome.ADMIT,
        note="comment payload carrying a second statement; rendering must strip comments rather than pass them through",
    ),
    AdmissionCase(
        sql="SELECT abs(id) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="allowlisted 2026-08-02: arithmetic on one value; bounded by its own input",
    ),
    AdmissionCase(
        sql="SELECT * INTO temp FROM spans",
        expect=AdmissionOutcome.NOT_READ_ONLY,
        note="SELECT INTO creates a table",
    ),
    AdmissionCase(
        sql="SELECT * FROM spans FOR UPDATE",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="row locking takes write locks",
    ),
    AdmissionCase(
        sql="WITH RECURSIVE spans(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM spans WHERE n<5) SELECT * FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="recursive CTE can loop unboundedly, and its name shadows an allowlisted table",
    ),
    AdmissionCase(
        sql="SELECT * FROM spans, LATERAL generate_series(1, 10) AS g(i)",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="lateral join reaches a set-returning function without it appearing in the select list",
    ),
    AdmissionCase(
        sql="COPY spans TO '/tmp/x'",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="bulk copy writes to the filesystem and is not a select",
    ),
    AdmissionCase(
        sql="SELECT lower(name) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="allowlisted 2026-08-02: case folding preserves length; cannot amplify",
    ),
    AdmissionCase(
        sql="SELECT substring(name, 1, 2) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="allowlisted 2026-08-02: substring only ever shortens its input",
    ),
    AdmissionCase(
        sql="SELECT repeat(name, 1000000000) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="repeat can allocate unbounded memory from a small statement",
    ),
    AdmissionCase(
        sql="SELECT md5(name) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="hash function with a dedicated node class",
    ),
    AdmissionCase(
        sql="WITH users AS (SELECT 1 AS id) SELECT id FROM users",
        expect=AdmissionOutcome.ADMIT,
        note="a CTE named after a denied table is a lexical symbol, not that table; over-eager scoping would wrongly refuse this",
    ),
    AdmissionCase(
        sql="SELECT * FROM users WHERE id IN (WITH users AS (SELECT 1 AS id) SELECT id FROM users)",
        expect=AdmissionOutcome.RELATION_NOT_ALLOWED,
        note="the inner CTE must not make the outer reference to the real denied table acceptable",
    ),
    AdmissionCase(
        sql="WITH x AS (SELECT * FROM users) SELECT * FROM x",
        expect=AdmissionOutcome.RELATION_NOT_ALLOWED,
        note="a denied table inside a CTE body is still a real relation",
    ),
    AdmissionCase(
        sql="SELECT count(*), max(end_time) FROM spans GROUP BY span_kind",
        expect=AdmissionOutcome.ADMIT,
        note="allowed aggregates",
    ),
    AdmissionCase(
        sql="SELECT row_number() OVER (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="allowed ranking function with a dedicated node class",
    ),
    AdmissionCase(
        sql="SELECT rank() OVER (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="allowed ranking function the parser models as a generic call, exercising the other branch of the function check",
    ),
    AdmissionCase(
        sql="SELECT ROUND(CAST((EXTRACT(EPOCH FROM end_time) - EXTRACT(EPOCH FROM start_time)) * 1000 AS NUMERIC), 1) AS latency_ms FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="latency expression from the teaching examples must survive admission",
    ),
    AdmissionCase(
        sql="SELECT s.id FROM spans AS s JOIN traces AS t ON s.trace_rowid = t.id",
        expect=AdmissionOutcome.ADMIT,
        note="aliased join across two allowlisted tables",
    ),
    AdmissionCase(
        sql="SELECT * FROM public.spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="caller-supplied schema qualification is refused; the server qualifies accepted relations itself after admission",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans WHERE 1=0 UNION SELECT id FROM users",
        expect=AdmissionOutcome.RELATION_NOT_ALLOWED,
        note="a denied table reached through a UNION branch is still a real relation, even when the other branch is allowlisted",
    ),
    AdmissionCase(
        sql="SELECT jsonb_each(attributes) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="allowed JSON unnest in the select list; admission accepts it, so anything that later refuses it is refusing a legitimate query",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans WHERE latency_ms > 100",
        expect=AdmissionOutcome.ADMIT,
        note="latency_ms is a derived column substituted after admission, so admission must not reject it as an unknown identifier",
    ),
    AdmissionCase(
        sql="SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="continuous percentile is allowed on Postgres, which has ordered-set aggregate syntax",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="the same statement is refused on SQLite, which has no WITHIN GROUP grammar; the parser builds the node anyway, so the class check must be dialect-aware",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT percentile(id, 50) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite reaches percentiles through a plain call from the bundled stats extension",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT percentile(id, 50) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="the SQLite spelling is not a Postgres function and must not be admitted there",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT percentile_disc(0.5) WITHIN GROUP (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="discrete percentile returns an actual data point rather than an interpolated one, has no SQLite counterpart, and stays denied until measured separately",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT mode() WITHIN GROUP (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="allowing one ordered-set aggregate must not admit the others",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT lag(id) OVER (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="offset window function; comparing a row to its neighbour is what makes a trend expressible",
    ),
    AdmissionCase(
        sql="SELECT lead(id) OVER (ORDER BY id) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="offset window function, forward direction",
    ),
    AdmissionCase(
        sql="SELECT group_concat(name) FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="string aggregation; the one admitted function that amplifies, bounded by the per-cell byte cap",
    ),
    AdmissionCase(
        sql="SELECT repeat(name, 1000000) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="disconfirming: adjacent to the admitted string functions but amplifies a small statement into a huge value",
    ),
    AdmissionCase(
        sql="SELECT printf('%.100000f', 1.0) FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="disconfirming: format strings can amplify without any large input",
    ),
    AdmissionCase(
        sql="SELECT date_trunc('hour', start_time) AS bucket FROM spans GROUP BY bucket",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="SQLite has no date_trunc; admitting it would defer a guaranteed failure to execution time",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT EXTRACT(epoch FROM start_time) AS seconds FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="SQLGlot parses EXTRACT for SQLite, but its FROM grammar is PostgreSQL-only",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT EXTRACT(epoch FROM start_time) AS seconds FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL supports the standard EXTRACT(field FROM value) grammar",
    ),
    AdmissionCase(
        sql="SELECT name ILIKE '%root%' FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL supports case-insensitive LIKE predicates",
    ),
    AdmissionCase(
        sql="SELECT name NOT ILIKE '%root%' FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL supports negated case-insensitive LIKE predicates",
    ),
    AdmissionCase(
        sql="SELECT name ILIKE '%root%' FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite has no ILIKE; rewrite to lower(name) LIKE lower('%root%') rather than refuse",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT name NOT ILIKE '%root%' FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="NOT ILIKE must keep the negation: lower(name) NOT LIKE lower(...)",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT name SIMILAR TO '%root%' FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL supports SQL-standard pattern predicates",
    ),
    AdmissionCase(
        sql="SELECT name SIMILAR TO '%root%' FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite has no SIMILAR TO grammar",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT strftime('%Y-%m-%d %H', start_time) AS bucket FROM spans GROUP BY bucket",
        expect=AdmissionOutcome.ADMIT,
        note="strftime is SQLite's hour bucketing and parses to TimeToStr, a class name the caller never writes",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT to_char(start_time, 'YYYY-MM') FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="to_char is PostgreSQL's format spelling and parses to the same TimeToStr class as SQLite strftime",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT name, COUNT(*) FROM spans GROUP BY ROLLUP(name)",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite parses ROLLUP but cannot execute it; refuse before opening the backend",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT DISTINCT ON (name) id FROM spans ORDER BY name, id",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL DISTINCT ON is kept; LIMIT applies to the distinct result",
    ),
    AdmissionCase(
        sql="SELECT DISTINCT ON (name) id FROM spans ORDER BY name, id",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLGlot transpiles DISTINCT ON on SQLite so the injected LIMIT applies before the distinct",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans WHERE id = ANY(SELECT id FROM traces)",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite has no ANY/ALL quantifiers; SQLGlot still builds the node",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans WHERE start_time = ANY(VALUES ('2026-01-01T10:30:00'))",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="ANY(VALUES) is a list of literals spelled as a quantifier; the parser wraps VALUES in a Subquery that the timestamp walk would otherwise skip",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT name, COUNT(*) FROM spans GROUP BY CUBE(name)",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite parses CUBE but cannot execute it; PostgreSQL remains covered by grammar tests",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT name, COUNT(*) FROM spans GROUP BY GROUPING SETS ((name), ())",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite parses GROUPING SETS but cannot execute it",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT gradient_start_color FROM projects",
        expect=AdmissionOutcome.ADMIT,
        note="a physical DDL column is admitted even though older manifest policy omitted it",
    ),
    AdmissionCase(
        sql="SELECT GRADIENT_START_COLOR FROM projects",
        expect=AdmissionOutcome.ADMIT,
        note="physical DDL columns remain queryable under ordinary identifier case folding",
    ),
    AdmissionCase(
        sql='SELECT "GRADIENT_START_COLOR" FROM projects',
        expect=AdmissionOutcome.COLUMN_NOT_ALLOWED,
        note="quoted PostgreSQL identifiers preserve case and do not name lowercase physical columns",
    ),
    AdmissionCase(
        sql="SELECT p FROM projects p",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a bare reference to a relation is the whole row, omitted columns included, and names no column so every per-column rule was inapplicable",
    ),
    AdmissionCase(
        sql="SELECT CAST(p AS TEXT) FROM projects p",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="the same row-valued reference inside a cast, which is how it was first found returning every column of the table",
    ),
    AdmissionCase(
        sql="SELECT (p).gradient_start_color FROM projects p",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="composite field access reaches a field of the row without producing a column node for it",
    ),
    AdmissionCase(
        sql="SELECT p.id FROM projects p JOIN (SELECT '#x' AS gradient_start_color) g USING (gradient_start_color)",
        expect=AdmissionOutcome.ADMIT,
        note="USING may name any physical DDL column",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM projects NATURAL JOIN traces",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="NATURAL JOIN leaves join keys implicit, so require ON",
    ),
    AdmissionCase(
        sql="SELECT (jsonb_each(attributes)).key FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="field access on a set-returning function's result is not the row-valued escape; a blanket refusal of composite access removed the idiom this surface's own plan-gate comment cites",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE (attributes #>> ('{session,id}'::text[])) IS NOT NULL",
        expect=AdmissionOutcome.ADMIT,
        note="an array of an allowed element type reaches nothing the element type does not; refusing it made the surface reject the index spelling it publishes",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE (attributes #>> '{session,id}'::text[]) IS NOT NULL",
        expect=AdmissionOutcome.ADMIT,
        note="a cast written bare after #>> binds to the path, the way PostgreSQL reads it, and is the form pg_get_indexdef publishes",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT CAST(attributes #>> '{session,id}' AS text[]) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="casting the extraction parses the extracted string as an array literal, a distinct operation and a distinct tree from casting the path",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT (attributes #>> '{session,id}')::text[] AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="casting the extracted value is unambiguous once parenthesised, and is a real operation: PostgreSQL parses the extracted string as an array literal",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT CAST('pg_authid' AS regclass) FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="object-identifier types consult the catalogs for any relation, role or function and never appear as a scanned relation, so the plan gate cannot see them; this is why cast targets are restricted at all",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="WITH x AS (SELECT 1 AS v) SELECT gradient_start_color FROM projects AS x, x",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a table aliased to a CTE's name is dropped from the scope map every later check reads, so it was skipped rather than refused",
    ),
    AdmissionCase(
        sql="WITH t AS (SELECT 1 AS v) SELECT n FROM (SELECT count(*) AS n FROM spans AS t) q",
        expect=AdmissionOutcome.ADMIT,
        note="the same names in different scopes are legal and unambiguous; the first version of that check refused this, and t is both the commonest CTE name and the commonest alias",
    ),
    AdmissionCase(
        sql="SELECT attributes ? 'session' AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="key existence, the first question anyone asks of a JSONB column; the operator form of a key-existence test; its refusal names the parser class jsonb_contains, which is not PostgreSQL's function for it",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT attributes @? '$.a' AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="JSON path existence; JSON path existence; sql_names() has no function spelling for an operator, so a refusal here names j_s_o_n_b_path_exists, which exists nowhere",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT attributes ?| ARRAY['a','b'] AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="the array constructor is part of this operator's spelling, so the operator is unusable unless exp.Array is admitted too",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_object_keys(attributes) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="set-returning, so it must be in UNNEST_FUNCTIONS as well as the anon allowlist or the plan gate refuses what admission passed",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_set(attributes, '{a}', '1') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="returns a modified copy bounded by its inputs; writes nothing, and removing a large member before it crosses the per-cell byte cap is the use that matters",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT json_array_length(attributes) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="json1 size function; the SQLite counterpart of jsonb_array_length, bounded by the document it reads",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT json_group_array(name) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="parses to a node class rather than a generic call, so it reaches the SQLite authorizer only by being named in SQLITE_AUTHORIZER_FUNCTIONS",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT json_set(attributes, '$.a', 1) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="the SQLite counterpart of jsonb_set; parses to a node class, so it reaches the authorizer only by being named in SQLITE_AUTHORIZER_FUNCTIONS",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT json_tree(attributes) AS v FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="table-valued like json_each, but without the table-valued handling that makes json_each work; admitting it would defer a guaranteed failure to execution",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT attributes ? 'session' AS v FROM spans",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="declared asymmetry: SQLite has no key-existence operator, so the question is asked with json_extract(...) IS NOT NULL or json_each; the refusal names the parser class jsonb_contains rather than the operator written",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT jsonb_agg(attributes) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="aggregation into one document; amplifies like group_concat and is bounded by the per-cell byte cap and the statement deadline",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT attributes #- '{a}' AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="path removal in operator form; output is smaller than input",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT json_remove(attributes, '$.a') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="the SQLite counterpart of the #- operator, parsed as a node class",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT no_such_column FROM spans",
        expect=AdmissionOutcome.COLUMN_NOT_ALLOWED,
        note="the column policy is an allowlist: a name the manifest does not offer is refused, not merely one on a hidden list",
    ),
    AdmissionCase(
        sql="SELECT latency_ms FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="a virtual column is advertised and not stored, so the allowlist must offer it despite its absence from the manifest columns",
    ),
    AdmissionCase(
        sql="SELECT key FROM spans, json_each(spans.attributes)",
        expect=AdmissionOutcome.ADMIT,
        note="a table-valued function offers names the manifest never declared, so an unqualified reference beside one cannot be attributed to a base table",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans LIMIT ALL",
        expect=AdmissionOutcome.ADMIT,
        note="LIMIT ALL means no numeric bound; SQLite parses ALL as a column, so the column check must not treat the keyword as spans.all",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT pg_catalog.current_user FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="schema-qualified special forms parse as columns, so the function allowlist never sees them; the unqualified spelling is already refused",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql='SELECT t.v FROM (SELECT 1 AS v) AS "T"',
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a quoted derived alias is a different identifier from its unquoted folding; table aliases already require that match",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql='SELECT "T".v FROM (SELECT 1 AS v) AS "T"',
        expect=AdmissionOutcome.ADMIT,
        note="the quoted qualifier names the quoted derived alias",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans WHERE id = ALL(ARRAY[1, 2])",
        expect=AdmissionOutcome.ADMIT,
        note="ALL(ARRAY[...]) parses as a function named all; ANY(ARRAY[...]) parses as a quantifier. Both are the same PostgreSQL construct",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans WHERE start_time = ALL(ARRAY['2026-01-01T10:30:00'])",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="ALL(ARRAY[...]) is the same comparison as ANY(ARRAY[...]); a naive time of day must be refused",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT pg_catalog.localtimestamp FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="same column-shaped special form as current_user; the unqualified spelling is refused as a function",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT public.spans.id FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="schema qualification on a column is the same escape as schema qualification on a table, which is already refused",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT foo.bar FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a qualifier that names no relation in the query is not a misspelling the engine will always reject -- PostgreSQL executes pg_catalog.current_user",
    ),
    AdmissionCase(
        sql="SELECT t.x FROM (SELECT 1 AS x) t",
        expect=AdmissionOutcome.ADMIT,
        note="a qualifier that names a derived relation in this scope is query-local, not a missing table",
    ),
    AdmissionCase(
        sql='SELECT "GRAPHQL_NODE_ID" FROM spans',
        expect=AdmissionOutcome.COLUMN_NOT_ALLOWED,
        note="virtual overlays follow the same quoting rules as physical columns; the advertised name is graphql_node_id",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql='SELECT "graphql_node_id" FROM spans',
        expect=AdmissionOutcome.ADMIT,
        note="quoting the advertised spelling is still that column",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT (SELECT COUNT(*) FROM spans s WHERE s.trace_rowid = t.id) FROM traces t",
        expect=AdmissionOutcome.ADMIT,
        note="a correlated subquery names an outer alias; refusing it as a missing qualifier made a legal statement look like a typo",
    ),
    AdmissionCase(
        sql=(
            "SELECT s.name, top.key AS k1, nested.key AS k2, COUNT(*) AS n "
            "FROM spans s "
            "CROSS JOIN LATERAL jsonb_each(s.attributes) AS top "
            "CROSS JOIN LATERAL jsonb_each("
            "CASE WHEN jsonb_typeof(top.value) = 'object' THEN top.value ELSE '{}'::jsonb END"
            ") AS nested "
            "GROUP BY s.name, top.key, nested.key"
        ),
        expect=AdmissionOutcome.ADMIT,
        note="a later LATERAL reads an earlier LATERAL's alias; that name lives on the parent SELECT scope as a Scope, not a Table",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT t.start_time FROM traces tr",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a qualifier that names a different alias than the one in scope is still missing after correlated names are accepted",
    ),
    AdmissionCase(
        sql="SELECT jsonb_extract_path(attributes, 'session') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="the jsonb spelling of a dynamic-key extract, and the form the rewrite emits when -> has a non-literal key",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_extract_path_text(attributes, 'session') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="the text-returning counterpart; SQLGlot renders jsonb ->> expr as json_extract_path_text, which takes json not jsonb",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE start_time >= '14:30:00'",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a clock time with no date is not an instant; PostgreSQL rejects it as invalid timestamptz input, so admission must refuse rather than wait for EXECUTION_ERROR",
    ),
    AdmissionCase(
        sql="SELECT s.span_id, t.trace_id FROM spans s JOIN traces t USING (latency_ms)",
        expect=AdmissionOutcome.ADMIT,
        note="latency_ms is a query-only overlay; USING is rewritten to an ON comparison so the overlay substitution can see it",
    ),
    AdmissionCase(
        sql="SELECT s.span_id, t.trace_id FROM spans s JOIN traces t USING (graphql_node_id)",
        expect=AdmissionOutcome.ADMIT,
        note="graphql_node_id USING is the same overlay shape and is rewritten to ON rather than refused",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE start_time >= 1719792000",
        expect=AdmissionOutcome.ADMIT,
        note="an unquoted integer compared to a timestamp is a unix epoch; rewrite it to a UTC instant rather than failing as timestamptz >= integer",
    ),
    AdmissionCase(
        sql=(
            "SELECT count(*) AS n FROM (SELECT start_time AS ts FROM spans) t "
            "WHERE ts >= '2026-07-02 12:00:00'"
        ),
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="aliasing a stored timestamp must not bypass the naive-literal offset rule",
    ),
    AdmissionCase(
        sql="SELECT json_type('{\"a\":1}')",
        expect=AdmissionOutcome.FUNCTION_NOT_ALLOWED,
        note="json_type is SQLite; PostgreSQL spells the same question jsonb_typeof",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT json_type('{\"a\":1}')",
        expect=AdmissionOutcome.ADMIT,
        note="json_type is native SQLite json1 and must remain admitted there",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT attributes @@ 'exists($.session.id)' AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL jsonb @@ jsonpath parses as MatchAgainst; refusing it as match_against names a MySQL function the caller never wrote",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT attributes #> ARRAY['session', 'id'] FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="#> ARRAY['a','b'] is the array-constructor spelling of the #> '{a,b}' path and reaches the same value, so it is admitted on the same terms",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT events -> 0 FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="integer jsonb accessor events -> 0 is valid PostgreSQL; JSONPathSubscript is the parser's model of that subscript",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql=(
            "SELECT status_code, span_kind, COUNT(*) FROM spans "
            "GROUP BY GROUPING SETS ((status_code), (span_kind), ()) LIMIT 20"
        ),
        expect=AdmissionOutcome.ADMIT,
        note="SQLGlot cannot parse GROUPING SETS with LIMIT attached; peel the clause, parse, and put it back so the engine still sees the caller's limit",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="WITH v(x) AS (VALUES (1), (2)) SELECT x FROM v",
        expect=AdmissionOutcome.ADMIT,
        note="SQLGlot rewrites CTE VALUES into SELECT * FROM (VALUES) AS _values; admission must not treat that invented star as a reason to refuse",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT id, name FROM projects UNION CORRESPONDING SELECT id, name FROM projects",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLGlot renders CORRESPONDING as UNION BY NAME, which PostgreSQL cannot parse; refuse at admission rather than generating invalid SQL",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_typeof(attributes -> 'llm') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="arrow inside a function call parses as a lambda; rebuild it as a parenthesised JSON accessor so jsonb_typeof receives jsonb",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="PostgreSQL accepts an empty select list; SQLAlchemy cannot stream a zero-column cursor, so refuse rather than admit-then-fail",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT s.span_id, t.trace_id FROM spans s JOIN traces t USING (id, latency_ms)",
        expect=AdmissionOutcome.ADMIT,
        note="mixed physical and virtual USING keys must all become ON; USING (id) ON (...) is not valid PostgreSQL",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_typeof(attributes -> 'llm' -> 'token_count') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="chained arrow inside a call parses as a lambda whose body is a JSONExtract; rebuild the chain so jsonb_typeof receives jsonb",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT CAST(id AS VARCHAR(10)) FROM projects",
        expect=AdmissionOutcome.ADMIT,
        note="parameterized VARCHAR/CHAR/DECIMAL parse as DataTypeParam; the target is still an allowed type",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT ROW(id, name) FROM projects",
        expect=AdmissionOutcome.ADMIT,
        note="ROW(a, b) is the same constructor as (a, b); rewrite the keyword form to a tuple rather than refusing it as an anonymous function",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT id, ROW_NUMBER() OVER (ORDER BY id) AS rn FROM projects QUALIFY rn = 1",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="PostgreSQL has no QUALIFY; name the subquery-and-window spelling rather than a generic construct refusal",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT COUNT(DISTINCT name) OVER () FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="PostgreSQL does not implement DISTINCT inside window functions; COUNT(DISTINCT name) without OVER is fine",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT x FROM spans AS t(x)",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a column list on a base-table alias does not rename physical columns and admits then fails; teach the subquery spelling",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="WITH v(x, y) AS (SELECT id FROM projects) SELECT x FROM v",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a CTE column list longer than the projection admits then fails in PostgreSQL; too few names is engine-authored",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE start_time >= 999999999999",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="an unreadable Unix epoch used to skip rewrite and fail as timestamptz >= bigint; refuse with the ISO spelling",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE start_time >= CAST(1719792000 AS bigint)",
        expect=AdmissionOutcome.ADMIT,
        note="unwrap-and-rewrite of CAST(epoch AS bigint) must replace the whole CAST, not leave CAST('<instant>' AS bigint)",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans JOIN traces USING ()",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="empty USING is dropped and becomes a cross join; PostgreSQL would reject USING ()",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT v FROM jsonb_array_elements(CAST('[1,2,3]' AS jsonb)) AS t(v)",
        expect=AdmissionOutcome.ADMIT,
        note="a column list on an SRF names the function's columns; the base-table alias-list refusal must not catch it",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE start_time >= '12/08/2026'",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="slash dates follow session DateStyle (MDY vs DMY) and silently swap day and month; require ISO",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT count(*) FROM spans WHERE start_time >= 1e9",
        expect=AdmissionOutcome.ADMIT,
        note="scientific epochs without a decimal point are still Unix instants; 1.e9 already rewrote",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT name, COUNT(*) FROM spans GROUP BY ROLLUP(name) LIMIT 5",
        expect=AdmissionOutcome.ADMIT,
        note="GROUPING SETS LIMIT recovery must also match ROLLUP( without a space before the parenthesis",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT ROW() AS r",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="empty ROW() renders as () which PostgreSQL rejects; same family as an empty SELECT list",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="WITH t(a, a) AS (SELECT 1, 2) SELECT a FROM t",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="duplicate names in a CTE column list admit then fail as an ambiguous column",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT id, ROW_NUMBER() FILTER (WHERE id > 0) OVER (ORDER BY id) AS rn FROM projects",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="FILTER is not implemented for ranking window functions; COUNT(*) FILTER OVER is fine",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY id) OVER () FROM projects",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="OVER is not supported for ordered-set aggregates; the non-window form is admitted",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT ROW(1, ROW(2, 3)) AS v",
        expect=AdmissionOutcome.ADMIT,
        note="nested ROW() is the same constructor as nested tuples; rebuild innermost first",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_typeof(events -> (0)) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="parenthesised integer arrow inside a call parses as a lambda whose body is a paren; rebuild as an array subscript",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql='SELECT CAST(65 AS "char")',
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note='parser folds quoted `"char"` to CHAR (bpchar); PostgreSQL\'s `"char"` is a 1-byte type',
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT CAST(id AS pg_catalog.varchar) FROM projects",
        expect=AdmissionOutcome.ADMIT,
        note="schema-qualified USERDEFINED unwraps to VARCHAR; pg_catalog.regclass stays refused",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT json_extract(attributes, '$.llm') FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="postgres json_extract on jsonb must rewrite to jsonb_extract_path, not json_extract_path",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT spans.id FROM spans JOIN LATERAL traces t ON t.id = spans.trace_rowid",
        expect=AdmissionOutcome.ADMIT,
        note="LATERAL on a base table is a regular join; PostgreSQL rejects LATERAL schema.traces AS t",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT id FROM spans ORDER BY id LIMIT 1 UNION SELECT id FROM traces",
        expect=AdmissionOutcome.ADMIT,
        note="PostgreSQL requires parentheses around a set-op operand that carries ORDER BY/LIMIT",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT status_code, COUNT(*) FROM spans GROUP BY ALL",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="GROUP BY ALL is DuckDB/Spark; PostgreSQL rejects it, and LIMIT injection makes the error worse",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT name, COUNT(*) FROM spans GROUP BY ROLLUP()",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="empty ROLLUP() is emitted as WITH ROLLUP, which PostgreSQL also rejects",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT name, COUNT(*) FROM spans GROUP BY CUBE()",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="empty CUBE() is emitted as WITH CUBE, which PostgreSQL also rejects",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="WITH t AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM t) SELECT n FROM t",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="recursive CTE without the RECURSIVE keyword used to be refused as an unknown table",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT GROUPING(name), COUNT(*) FROM spans GROUP BY GROUPING SETS ((name), ())",
        expect=AdmissionOutcome.ADMIT,
        note="GROUPING() is the companion to GROUPING SETS / ROLLUP / CUBE on PostgreSQL",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT ROW(1) AS r",
        expect=AdmissionOutcome.ADMIT,
        note="ROW(1) must stay the keyword form; a one-element Tuple renders as (1), a scalar",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT latency_ms FROM spans JOIN traces USING (latency_ms)",
        expect=AdmissionOutcome.ADMIT,
        note="USING coalesces the overlay; unqualified latency_ms is that coalesced column, not an ambiguity",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT (1,) AS r",
        expect=AdmissionOutcome.ADMIT,
        note="a one-element tuple renders as (1), a scalar; rebuild as ROW(1) so it stays a record",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT CAST(id AS pg_catalog.int4) FROM projects",
        expect=AdmissionOutcome.ADMIT,
        note="pg_catalog.int4 is INT; refusing USERDEFINED/INT4 rejected a type PostgreSQL accepts as int",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT jsonb_typeof(attributes ->> 'llm') FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="jsonb_typeof(text) does not exist; the text extractor is the same key as ->",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT spans.id FROM spans, LATERAL traces t",
        expect=AdmissionOutcome.ADMIT,
        note="comma LATERAL on a base table is a cross join; PostgreSQL rejects LATERAL schema.traces AS t",
        dialect="postgresql",
    ),
    AdmissionCase(
        sql="SELECT MIN(attributes -> '$.llm.token_count.total') AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="in-call arrow with a path literal is a JSON accessor, not a key named $.llm...",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT s.id FROM spans s, LATERAL (SELECT 1 AS v) z",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite has no LATERAL; a subquery in LATERAL used to admit then fail at the engine",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT key FROM spans, LATERAL json_each(attributes)",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite json_each does not need LATERAL; drop the keyword rather than refuse",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="(SELECT id FROM spans LIMIT 1) UNION ALL (SELECT id FROM traces LIMIT 1)",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite rejects parentheses around compound members; lift each into FROM (subquery)",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE start_time >= '2027'",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a quoted year is not a timestamp; SQLite would coerce it and match every row",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE start_time >= '20260723T000000Z'",
        expect=AdmissionOutcome.ADMIT,
        note="compact ISO-8601 basic form is a timestamp, not a string to compare as text",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT CAST('{\"a\":1}' AS JSON) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="CAST AS JSON has NUMERIC affinity on SQLite; rewrite to json() so a document stays a document",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT CAST('1 day' AS INTERVAL) AS v FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite has no interval type; the cast silently becomes a number",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql='SELECT "nope" FROM spans, json_each(attributes)',
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite treats a quoted unknown identifier as a string; json_each does not project nope",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT k FROM spans, json_each(attributes)",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="json_each projects key, not k; refusing names the columns it has",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT typeof(id) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="typeof is in the SQLite authorizer; admission used to refuse a function the engine runs",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT median(cumulative_error_count) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="sqlean stats median; the schema used to say it was unavailable while the authorizer permitted it",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE start_time < unixepoch('now')",
        expect=AdmissionOutcome.ADMIT,
        note="compare unixepoch(start_time) to unixepoch('now'); text < integer matches nothing",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT json_each.value FROM spans, json_each(attributes)",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite names an unaliased json_each after the function; json_each.value used to be refused as an unknown relation",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE name COLLATE NOCASE = 'old'",
        expect=AdmissionOutcome.ADMIT,
        note="COLLATE is a clause, not a function; it used to be refused as function collate",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE name COLLATE latin1 = 'old'",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite collations are BINARY, NOCASE, and RTRIM; a name it does not have is a refusal, not a function denial",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT * FROM spans INDEXED BY spans_start_time",
        expect=AdmissionOutcome.ADMIT,
        note="INDEXED BY is a hint, not the question; drop it rather than refuse",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT a FROM (VALUES (1, 2), (3, 4)) AS v(a, b)",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite cannot render named columns on a table alias; rewrite VALUES to a SELECT so the names survive",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT COUNT(*) FROM spans WHERE start_time < datetime('now')",
        expect=AdmissionOutcome.ADMIT,
        note="datetime() is second-resolution; wrap start_time the same way or text compare is wrong on the same second",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT id, name FROM spans UNION SELECT id FROM traces",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="unequal UNION widths used to admit then fail at the engine",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT CAST(start_time AS TIME) AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="CAST AS TIME as TEXT returns the full datetime; time() is the time-of-day constructor",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT start_time + INTERVAL '1 day' AS v FROM spans",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite has no INTERVAL; rewrite to datetime(start_time, '+1 days') rather than admit then fail near DAY",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT INTERVAL '1 day' AS v FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a bare INTERVAL is not a SQLite value; the additive form is rewritten, this one is refused",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT k FROM spans, json_each(attributes) AS t(k, v)",
        expect=AdmissionOutcome.ADMIT,
        note="SQLite cannot render json_each AS t(k, v); push the names onto the json_each columns",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT json_each(attributes) FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="json_each is table-valued; in the SELECT list SQLite has no such function",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT key FROM spans, json_each(attributes, 'session')",
        expect=AdmissionOutcome.ADMIT,
        note="json_each path without $ is a SQLite error; arrows already get $.session",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="WITH x(a) AS (SELECT id, name FROM projects) SELECT * FROM x",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="SQLite rejects a CTE column list shorter than the query; PostgreSQL keeps extra columns",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT * FROM (VALUES (1, 2)) AS t(a)",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="a too-short VALUES alias list used to drop the extra cells",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT attributes #>> '{a,b}' FROM spans",
        expect=AdmissionOutcome.UNSUPPORTED_SYNTAX,
        note="#>> must not admit then fail as function jsonb_extract_scalar",
        dialect="sqlite",
    ),
    AdmissionCase(
        sql="SELECT id FROM projects /* comment",
        expect=AdmissionOutcome.PARSE_ERROR,
        note="an unterminated comment used to crash the tool instead of a parse error",
        dialect="sqlite",
    ),
)
