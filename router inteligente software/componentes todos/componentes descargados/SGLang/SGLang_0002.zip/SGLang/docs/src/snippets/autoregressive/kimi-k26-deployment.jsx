export const KimiK26Deployment = () => {
  // Config mirrors sgl-cookbook src/components/autoregressive/KimiK26ConfigGenerator/index.js.
  //
  // INT4:
  //   H200/B300: tp=8
  //   GB300/AMD: tp=4
  //
  // NVFP4:
  //   B300: tp=8
  //   GB300: tp=4
  const options = {
    hardware: {
      name: 'hardware',
      title: 'Hardware Platform',
      items: [
        { id: 'h200', label: 'H200', default: true },
        { id: 'b300', label: 'B300', default: false },
        { id: 'gb300', label: 'GB300', default: false },
        { id: 'mi300x', label: 'MI300X', default: false },
        { id: 'mi325x', label: 'MI325X', default: false },
        { id: 'mi350x', label: 'MI350X', default: false },
        { id: 'mi355x', label: 'MI355X', default: false },
      ],
    },
    quantization: {
      name: 'quantization',
      title: 'Quantization',
      getDynamicItems: (values) => {
        const hw = values.hardware;
        const isBlackwell = ['b300', 'gb300'].includes(hw);
        return [
          { id: 'int4', label: 'INT4', subtitle: 'Base checkpoint', default: !isBlackwell },
          { id: 'nvfp4', label: 'NVFP4', subtitle: 'Blackwell FP4', default: isBlackwell, disabled: !isBlackwell, disabledReason: !isBlackwell ? 'NVFP4 only on NVIDIA Blackwell' : '' },
        ];
      },
    },
    reasoning: {
      name: 'reasoning',
      title: 'Reasoning Parser',
      items: [
        { id: 'disabled', label: 'Disabled', default: false },
        { id: 'enabled', label: 'Enabled', default: true },
      ],
    },
    toolcall: {
      name: 'toolcall',
      title: 'Tool Call Parser',
      items: [
        { id: 'disabled', label: 'Disabled', default: false },
        { id: 'enabled', label: 'Enabled', default: true },
      ],
    },
    dpattention: {
      name: 'dpattention',
      title: 'DP Attention',
      items: [
        { id: 'disabled', label: 'Disabled', subtitle: 'Low Latency', default: true },
        { id: 'enabled', label: 'Enabled', subtitle: 'High Throughput', default: false },
      ],
    },
    speculative: {
      name: 'speculative',
      title: 'Speculative Decoding',
      condition: (values) => !['mi300x', 'mi325x', 'mi350x', 'mi355x'].includes(values.hardware),
      items: [
        { id: 'disabled', label: 'Disabled', default: true },
        { id: 'enabled', label: 'Enabled', default: false },
      ],
    },
  };

  const modelConfigs = {
    h200: { tp: 8 },
    b300: { tp: 8 },
    gb300: { tp: 4 },
    mi300x: { tp: 4 },
    mi325x: { tp: 4 },
    mi350x: { tp: 4 },
    mi355x: { tp: 4 },
  };

  const nvfp4ModelConfigs = {
    b300: { tp: 8 },
    gb300: { tp: 4 },
  };

  const resolveItems = (option, values) =>
    typeof option.getDynamicItems === 'function' ? option.getDynamicItems(values) : option.items || [];

  const getInitialState = () => {
    const initialState = {};
    for (const [key, option] of Object.entries(options)) {
      const items = resolveItems(option, initialState);
      const def = items.find((item) => item.default && !item.disabled) || items.find((item) => !item.disabled) || items[0];
      initialState[key] = def.id;
    }
    return initialState;
  };

  const [values, setValues] = useState(getInitialState);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const checkDarkMode = () => {
      const html = document.documentElement;
      const isDarkMode =
        html.classList.contains('dark') ||
        html.getAttribute('data-theme') === 'dark' ||
        html.style.colorScheme === 'dark';
      setIsDark(isDarkMode);
    };

    checkDarkMode();
    const observer = new MutationObserver(checkDarkMode);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class', 'data-theme', 'style'],
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    setValues((prev) => {
      const next = { ...prev };
      for (const [key, option] of Object.entries(options)) {
        if (typeof option.condition === 'function' && !option.condition(next)) {
          const items = resolveItems(option, next);
          const fallback = items.find((item) => item.default && !item.disabled) || items.find((item) => !item.disabled);
          if (fallback) next[key] = fallback.id;
          continue;
        }
        if (typeof option.getDynamicItems !== 'function') continue;
        const items = option.getDynamicItems(next);
        const current = items.find((item) => item.id === next[key]);
        if (!current || current.disabled) {
          const fallback = items.find((item) => item.default && !item.disabled) || items.find((item) => !item.disabled);
          if (fallback) next[key] = fallback.id;
        }
      }
      return next;
    });
  }, [values.hardware]);

  const handleRadioChange = (optionName, value) => {
    setValues((prev) => ({ ...prev, [optionName]: value }));
  };

  const generateCommand = () => {
    const { hardware, quantization, reasoning, toolcall, dpattention, speculative } = values;
    const isAMD = hardware === 'mi300x' || hardware === 'mi325x' || hardware === 'mi350x' || hardware === 'mi355x';
    const isNVFP4 = quantization === 'nvfp4';
    const hwConfig = isNVFP4 ? nvfp4ModelConfigs[hardware] : modelConfigs[hardware];
    if (!hwConfig) return '# NVFP4 is only supported on NVIDIA Blackwell hardware.';
    if (speculative === 'enabled' && isAMD) {
      return '# Speculative Decoding for Kimi-K2.6 is only supported on NVIDIA GPUs (H200/B300/GB300)';
    }
    const tpValue = hwConfig.tp;
    const modelName = isNVFP4 ? 'nvidia/Kimi-K2.6-NVFP4' : 'moonshotai/Kimi-K2.6';

    let cmd = '';

    if (isAMD) {
      cmd += 'SGLANG_USE_AITER=1 SGLANG_ROCM_FUSED_DECODE_MLA=0 \\\n';
    }

    cmd += 'sglang serve \\\n';
    cmd += `  --model-path ${modelName}`;
    cmd += ` \\\n  --tp ${tpValue}`;
    if (isNVFP4) {
      cmd += ' \\\n  --quantization modelopt_fp4';
    }
    if (isAMD) {
      cmd += ' \\\n  --mem-fraction-static 0.8';
    }
    cmd += ' \\\n  --trust-remote-code';

    if (dpattention === 'enabled') {
      cmd += ` \\\n  --dp ${tpValue} \\\n  --enable-dp-attention`;
    }

    if (reasoning === 'enabled') {
      cmd += ' \\\n  --reasoning-parser kimi_k2';
    }

    if (toolcall === 'enabled') {
      cmd += ' \\\n  --tool-call-parser kimi_k2';
    }

    if (speculative === 'enabled') {
      cmd += ' \\\n  --speculative-algorithm EAGLE3';
      cmd += ' \\\n  --speculative-num-steps 3';
      cmd += ' \\\n  --speculative-eagle-topk 1';
      cmd += ' \\\n  --speculative-num-draft-tokens 4';
      cmd += ' \\\n  --speculative-draft-model-path lightseekorg/kimi-k2.6-eagle3.1-mla';
    }

    const usesTokenspeedMla = hardware === 'b300' || hardware === 'gb300';

    if (usesTokenspeedMla) {
      cmd += ' \\\n  --attention-backend tokenspeed_mla';
    }

    if (isAMD || usesTokenspeedMla) {
      cmd += ' \\\n  --kv-cache-dtype fp8_e4m3';
    }

    cmd += ' \\\n  --host 0.0.0.0 \\\n  --port 30000';
    return cmd;
  };

  const containerStyle = { maxWidth: '900px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '4px' };
  const cardStyle = { padding: '8px 12px', border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`, borderLeft: `3px solid ${isDark ? '#E85D4D' : '#D45D44'}`, borderRadius: '4px', display: 'flex', alignItems: 'center', gap: '12px', background: isDark ? '#1f2937' : '#fff' };
  const titleStyle = { fontSize: '13px', fontWeight: '600', minWidth: '140px', flexShrink: 0, color: isDark ? '#e5e7eb' : 'inherit' };
  const itemsStyle = { display: 'flex', rowGap: '2px', columnGap: '6px', flexWrap: 'wrap', alignItems: 'center', flex: 1 };
  const labelBaseStyle = { padding: '4px 10px', border: `1px solid ${isDark ? '#9ca3af' : '#d1d5db'}`, borderRadius: '3px', cursor: 'pointer', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontWeight: '500', fontSize: '13px', transition: 'all 0.2s', userSelect: 'none', minWidth: '45px', textAlign: 'center', flex: 1, background: isDark ? '#374151' : '#fff', color: isDark ? '#e5e7eb' : 'inherit' };
  const checkedStyle = { background: '#D45D44', color: 'white', borderColor: '#D45D44' };
  const disabledStyle = { cursor: 'not-allowed', opacity: 0.4 };
  const subtitleStyle = { display: 'block', fontSize: '9px', marginTop: '1px', lineHeight: '1.1', opacity: 0.7 };
  const commandDisplayStyle = { flex: 1, padding: '12px 16px', background: isDark ? '#111827' : '#f5f5f5', borderRadius: '6px', fontFamily: "'Menlo', 'Monaco', 'Courier New', monospace", fontSize: '12px', lineHeight: '1.5', color: isDark ? '#e5e7eb' : '#374151', whiteSpace: 'pre-wrap', overflowX: 'auto', margin: 0, border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}` };

  return (
    <div style={containerStyle} className="not-prose">
      {Object.entries(options).map(([key, option]) => {
        if (typeof option.condition === 'function' && !option.condition(values)) return null;
        const items = resolveItems(option, values);
        return (
          <div key={key} style={cardStyle}>
            <div style={titleStyle}>{option.title}</div>
            <div style={itemsStyle}>
              {items.map((item) => {
                const isChecked = values[option.name] === item.id;
                const isDisabled = !!item.disabled;
                return (
                  <label
                    key={item.id}
                    style={{ ...labelBaseStyle, ...(isChecked ? checkedStyle : {}), ...(isDisabled ? disabledStyle : {}) }}
                    title={item.disabledReason || ''}
                  >
                    <input
                      type="radio"
                      name={option.name}
                      value={item.id}
                      checked={isChecked}
                      disabled={isDisabled}
                      onChange={() => !isDisabled && handleRadioChange(option.name, item.id)}
                      style={{ display: 'none' }}
                    />
                    {item.label}
                    {item.subtitle && <small style={{ ...subtitleStyle, color: isChecked ? 'rgba(255,255,255,0.85)' : 'inherit' }}>{item.subtitle}</small>}
                  </label>
                );
              })}
            </div>
          </div>
        );
      })}
      <div style={cardStyle}>
        <div style={titleStyle}>Run this Command:</div>
        <pre style={commandDisplayStyle}>{generateCommand()}</pre>
      </div>
    </div>
  );
};
