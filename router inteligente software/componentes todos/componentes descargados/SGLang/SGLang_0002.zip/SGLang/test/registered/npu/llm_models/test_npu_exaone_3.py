import unittest

from sglang.test.ascend.gsm8k_ascend_mixin import GSM8KAscendMixin
from sglang.test.ascend.test_ascend_utils import EXAONE_3_5_7_8B_INSTRUCT_WEIGHTS_PATH
from sglang.test.ci.ci_register import register_npu_ci
from sglang.test.test_utils import CustomTestCase

register_npu_ci(est_time=400, suite="full-1-npu-a3", nightly=True)


class TestEXAONE(GSM8KAscendMixin, CustomTestCase):
    """Testcase: Verify that the inference accuracy of the LGAI-EXAONE/EXAONE-3.5-7.8B-Instruct model on the GSM8K dataset is no less than 0.8.

    [Test Category] Model
    [Test Target] LGAI-EXAONE/EXAONE-3.5-7.8B-Instruct
    """

    model = EXAONE_3_5_7_8B_INSTRUCT_WEIGHTS_PATH
    # Allow 1% tolerance for the accuracy threshold
    accuracy = round(0.8 * 0.99, 3)
    other_args = [
        "--trust-remote-code",
        "--mem-fraction-static",
        "0.8",
        "--attention-backend",
        "ascend",
        "--disable-cuda-graph",
        "--dtype",
        "bfloat16",
    ]


if __name__ == "__main__":
    unittest.main()
