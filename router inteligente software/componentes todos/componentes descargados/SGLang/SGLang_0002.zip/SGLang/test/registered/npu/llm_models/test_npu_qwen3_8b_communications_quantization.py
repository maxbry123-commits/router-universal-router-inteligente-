import unittest

from sglang.test.ascend.gsm8k_ascend_mixin import GSM8KAscendMixin
from sglang.test.ascend.test_ascend_utils import QWEN3_8B_WEIGHTS_PATH
from sglang.test.ci.ci_register import register_npu_ci
from sglang.test.test_utils import CustomTestCase

register_npu_ci(est_time=400, suite="full-2-npu-a3", nightly=True)


class TestQwen38BCommQuantization(GSM8KAscendMixin, CustomTestCase):
    """Testcase: Verify that the inference accuracy of the Qwen/Qwen3-8B model with TP communications quantization on the GSM8K dataset is no less than 0.85.

    [Test Category] Model
    [Test Target] Qwen/Qwen3-8B
    """

    model = QWEN3_8B_WEIGHTS_PATH
    accuracy = 0.85
    other_args = [
        "--trust-remote-code",
        "--mem-fraction-static",
        0.8,
        "--max-running-requests",
        32,
        "--attention-backend",
        "ascend",
        "--cuda-graph-max-bs-decode",
        32,
        "--tp-size",
        2,
        "--enable-quant-communications",
    ]


if __name__ == "__main__":
    unittest.main()
