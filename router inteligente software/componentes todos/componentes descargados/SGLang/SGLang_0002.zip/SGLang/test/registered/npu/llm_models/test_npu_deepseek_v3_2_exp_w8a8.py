import unittest

from sglang.test.ascend.gsm8k_ascend_mixin import GSM8KAscendMixin
from sglang.test.ascend.test_ascend_utils import DEEPSEEK_V3_2_EXP_W8A8_WEIGHTS_PATH
from sglang.test.ci.ci_register import register_npu_ci
from sglang.test.test_utils import CustomTestCase

register_npu_ci(est_time=400, suite="full-16-npu-a3", nightly=True)


class TestDeepSeekV32(GSM8KAscendMixin, CustomTestCase):
    """Testcase: Verify that the inference accuracy of the vllm-ascend/DeepSeek-V3.2-Exp-W8A8 model on the GSM8K dataset is no less than 0.5.

    [Test Category] Model
    [Test Target] vllm-ascend/DeepSeek-V3.2-Exp-W8A8
    """

    model = DEEPSEEK_V3_2_EXP_W8A8_WEIGHTS_PATH
    accuracy = 0.5
    timeout_for_server_launch = 3000
    other_args = [
        "--trust-remote-code",
        "--mem-fraction-static",
        "0.9",
        "--attention-backend",
        "ascend",
        "--disable-cuda-graph",
        "--tp-size",
        "16",
        "--quantization",
        "modelslim",
        "--disable-radix-cache",
    ]


if __name__ == "__main__":
    unittest.main()
