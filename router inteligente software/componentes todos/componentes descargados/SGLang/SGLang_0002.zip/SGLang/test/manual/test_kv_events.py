import time
import unittest

import requests
import zmq
from msgspec.msgpack import Decoder

from sglang.srt.disaggregation.kv_events import (
    AllBlocksCleared,
    BlockRemoved,
    BlockStored,
    KVEventBatch,
)
from sglang.srt.utils import kill_process_tree
from sglang.test.test_utils import (
    DEFAULT_MLA_MODEL_NAME_FOR_TEST,
    DEFAULT_SMALL_MODEL_NAME_FOR_TEST,
    DEFAULT_TIMEOUT_FOR_SERVER_LAUNCH,
    DEFAULT_URL_FOR_TEST,
    CustomTestCase,
    popen_launch_server,
)

QWEN3_30B_MODEL_PATH = "Qwen/Qwen3-30B-A3B-FP8"


class TestKvEvents(CustomTestCase):
    def test_kv_events_enabled(self):
        """Test that kv events are sent and received by subscriber data when enabled"""

        # Launch kv events subscriber
        decoder = Decoder(type=KVEventBatch)
        context = zmq.Context()
        sub = context.socket(zmq.SUB)
        sub.connect("tcp://localhost:5557")
        topic = "kv-events"
        sub.setsockopt_string(zmq.SUBSCRIBE, topic)

        # Launch sglang server
        process = popen_launch_server(
            DEFAULT_SMALL_MODEL_NAME_FOR_TEST,
            DEFAULT_URL_FOR_TEST,
            timeout=DEFAULT_TIMEOUT_FOR_SERVER_LAUNCH,
            other_args=[
                "--kv-events-config",
                '{"publisher": "zmq", "topic": "kv-events"}',
                "--max-total-tokens",
                32,
                "--cuda-graph-max-bs-decode",
                2,
                "--enable-dp-attention",
                "--dp-size",
                1,
            ],
        )

        try:
            # Make some requests to generate some metrics
            response = requests.get(f"{DEFAULT_URL_FOR_TEST}/health_generate")
            self.assertEqual(response.status_code, 200)

            response = requests.post(
                f"{DEFAULT_URL_FOR_TEST}/generate",
                json={
                    "text": "The capital of France is",
                    "sampling_params": {
                        "temperature": 0,
                        "max_new_tokens": 32,
                    },
                },
            )
            response = requests.post(
                f"{DEFAULT_URL_FOR_TEST}/generate",
                json={
                    "text": "The capital of Spain is",
                    "sampling_params": {
                        "temperature": 0,
                        "max_new_tokens": 32,
                    },
                },
            )

            # Get events
            events = []
            start = time.time()
            max_wait_s = 5
            min_events_expected = 5  # Expect at least some events

            while (
                len(events) < min_events_expected and (time.time() - start) < max_wait_s
            ):
                if sub.poll(timeout=100):  # 100ms timeout
                    _, seq_bytes, payload = sub.recv_multipart()
                    event_batch = decoder.decode(payload)
                    for event in event_batch.events:
                        events.append(event)

            # Verify we received events
            self.assertGreater(
                len(events), 0, "Should have received at least one KV cache event"
            )

            # Track which blocks were stored and removed
            stored_blocks = {}  # hash -> BlockStored event
            removed_hashes = set()

            # Validate event structure and relationships
            for event in events:
                self.assertIsInstance(
                    event,
                    (BlockStored, BlockRemoved, AllBlocksCleared),
                    f"Event should be a KV cache event, got {type(event)}",
                )

                if isinstance(event, BlockStored):
                    # Validate BlockStored structure
                    self.assertIsInstance(event.block_hashes, list)
                    self.assertGreater(
                        len(event.block_hashes),
                        0,
                        "Should have at least one block hash",
                    )
                    self.assertIsInstance(event.token_ids, list)
                    self.assertEqual(
                        len(event.token_ids),
                        event.block_size * len(event.block_hashes),
                        "token_ids should contain one block_size chunk per hash",
                    )
                    self.assertIsNone(
                        event.lora_id, "lora_id should be None for basic test"
                    )

                    # Store every block carried by this coalesced event.
                    for block_hash in event.block_hashes:
                        stored_blocks[block_hash] = event

                    # If parent_block_hash is set, verify it was stored earlier
                    if event.parent_block_hash is not None:
                        # Parent should either be in stored_blocks or could be from a previous request
                        pass  # Don't strictly enforce this as root blocks may have synthetic parents

                elif isinstance(event, BlockRemoved):
                    # Validate BlockRemoved structure
                    self.assertIsInstance(event.block_hashes, list)
                    self.assertGreater(
                        len(event.block_hashes),
                        0,
                        "Should have at least one removed block hash",
                    )
                    removed_hashes.update(event.block_hashes)

            # Verify we got both BlockStored and BlockRemoved events
            self.assertGreater(
                len(stored_blocks), 0, "Should have at least one BlockStored event"
            )
            self.assertTrue(
                any(
                    isinstance(event, BlockStored) and len(event.block_hashes) > 1
                    for event in events
                ),
                "Expected at least one coalesced BlockStored event",
            )
            # BlockRemoved events may not always occur in this short test, so just check if they do occur
            # that they reference previously stored blocks
            for removed_hash in removed_hashes:
                # It's OK if the removed block wasn't in our stored_blocks
                # (it could have been stored before we started listening)
                pass

        finally:
            sub.close()
            context.term()
            kill_process_tree(process.pid)

    def test_kv_events_attn_dp(self):
        """Test that kv events are properly tagged with DP rank in attention DP mode"""

        # Launch multiple subscribers for different DP ranks
        decoder = Decoder(type=KVEventBatch)
        context = zmq.Context()

        # Subscribe to both DP rank endpoints
        sub_dp0 = context.socket(zmq.SUB)
        sub_dp0.connect("tcp://localhost:5557")  # DP rank 0
        topic = "kv-events"
        sub_dp0.setsockopt_string(zmq.SUBSCRIBE, topic)

        sub_dp1 = context.socket(zmq.SUB)
        sub_dp1.connect("tcp://localhost:5558")  # DP rank 1 (offset by rank)
        sub_dp1.setsockopt_string(zmq.SUBSCRIBE, topic)

        # Launch sglang server with DP attention enabled
        process = popen_launch_server(
            DEFAULT_MLA_MODEL_NAME_FOR_TEST,
            DEFAULT_URL_FOR_TEST,
            timeout=DEFAULT_TIMEOUT_FOR_SERVER_LAUNCH,
            other_args=[
                "--kv-events-config",
                '{"publisher": "zmq", "topic": "kv-events"}',
                "--max-total-tokens",
                64,
                "--cuda-graph-max-bs-decode",
                4,
                "--enable-dp-attention",
                "--dp-size",
                2,
                "--tp-size",
                2,
            ],
        )

        try:
            # Make requests to generate events
            response = requests.get(f"{DEFAULT_URL_FOR_TEST}/health_generate")
            self.assertEqual(response.status_code, 200)

            # Send multiple requests to trigger events from both DP ranks
            for i in range(4):
                response = requests.post(
                    f"{DEFAULT_URL_FOR_TEST}/generate",
                    json={
                        "text": f"Request {i}: The capital of country {i} is",
                        "sampling_params": {
                            "temperature": 0,
                            "max_new_tokens": 16,
                        },
                    },
                )

            # Collect events from both DP ranks
            events_dp0 = []
            events_dp1 = []
            start = time.time()
            max_wait_s = 10
            min_events_per_rank = 3  # Expect at least a few events from each rank

            while (time.time() - start) < max_wait_s and (
                len(events_dp0) < min_events_per_rank
                or len(events_dp1) < min_events_per_rank
            ):
                # Check DP rank 0
                if sub_dp0.poll(timeout=100):  # 100ms timeout
                    _, seq_bytes, payload = sub_dp0.recv_multipart()
                    event_batch = decoder.decode(payload)
                    print(
                        f"DP Rank 0 - EventBatch: ts={event_batch.ts}, attn_dp_rank={event_batch.attn_dp_rank}"
                    )
                    self.assertEqual(
                        event_batch.attn_dp_rank,
                        0,
                        "DP rank 0 events should have attn_dp_rank=0",
                    )
                    for event in event_batch.events:
                        print(f"  DP0 - {event}")
                        events_dp0.append(event)

                # Check DP rank 1
                if sub_dp1.poll(timeout=100):  # 100ms timeout
                    _, seq_bytes, payload = sub_dp1.recv_multipart()
                    event_batch = decoder.decode(payload)
                    print(
                        f"DP Rank 1 - EventBatch: ts={event_batch.ts}, attn_dp_rank={event_batch.attn_dp_rank}"
                    )
                    self.assertEqual(
                        event_batch.attn_dp_rank,
                        1,
                        "DP rank 1 events should have attn_dp_rank=1",
                    )
                    for event in event_batch.events:
                        print(f"  DP1 - {event}")
                        events_dp1.append(event)

            # Verify we got events from both DP ranks
            print(f"Collected {len(events_dp0)} events from DP rank 0")
            print(f"Collected {len(events_dp1)} events from DP rank 1")

            self.assertGreaterEqual(
                len(events_dp0),
                min_events_per_rank,
                f"Expected at least {min_events_per_rank} events from DP rank 0",
            )
            self.assertGreaterEqual(
                len(events_dp1),
                min_events_per_rank,
                f"Expected at least {min_events_per_rank} events from DP rank 1",
            )

            # Verify event types are as expected
            for events in [events_dp0, events_dp1]:
                for event in events:
                    self.assertIsInstance(
                        event,
                        (BlockStored, BlockRemoved, AllBlocksCleared),
                        f"Event should be a KV cache event, got {type(event)}",
                    )

        finally:
            sub_dp0.close()
            sub_dp1.close()
            context.term()
            kill_process_tree(process.pid)

    def test_kv_events_attn_cp_single_stream_per_dp_rank(self):
        """Test that CP replicas do not publish duplicate KV events for one DP rank."""

        decoder = Decoder(type=KVEventBatch)
        context = zmq.Context()

        sub_dp0 = context.socket(zmq.SUB)
        sub_dp0.connect("tcp://localhost:5557")
        topic = "kv-events"
        sub_dp0.setsockopt_string(zmq.SUBSCRIBE, topic)

        # There is only one DP rank in this test, so CP must not create another stream.
        sub_unexpected = context.socket(zmq.SUB)
        sub_unexpected.connect("tcp://localhost:5558")
        sub_unexpected.setsockopt_string(zmq.SUBSCRIBE, topic)

        process = popen_launch_server(
            QWEN3_30B_MODEL_PATH,
            DEFAULT_URL_FOR_TEST,
            timeout=DEFAULT_TIMEOUT_FOR_SERVER_LAUNCH,
            other_args=[
                "--kv-events-config",
                '{"publisher": "zmq", "topic": "kv-events"}',
                "--tp-size",
                2,
                "--attn-cp-size",
                2,
                "--moe-dp-size",
                2,
                "--enable-prefill-cp",
                "--cp-strategy",
                "zigzag",
                "--trust-remote-code",
                "--max-total-tokens",
                4096,
                "--max-running-requests",
                4,
                "--disable-cuda-graph",
                "--cuda-graph-max-bs-decode",
                4,
                "--model-loader-extra-config",
                '{"enable_multithread_load": true, "num_threads": 64}',
            ],
        )

        try:
            response = requests.get(f"{DEFAULT_URL_FOR_TEST}/health_generate")
            self.assertEqual(response.status_code, 200)

            for i in range(4):
                response = requests.post(
                    f"{DEFAULT_URL_FOR_TEST}/generate",
                    json={
                        "text": (
                            f"KV event context parallelism request {i}: "
                            "write a concise fact about distributed inference."
                        ),
                        "sampling_params": {
                            "temperature": 0,
                            "max_new_tokens": 16,
                        },
                    },
                )
                self.assertEqual(response.status_code, 200)

            batches = []
            stored_hashes = set()
            duplicate_hashes = set()
            unexpected_batches = []
            start = time.time()
            max_wait_s = 15
            min_stored_blocks = 3

            while (time.time() - start) < max_wait_s and (
                len(stored_hashes) < min_stored_blocks
            ):
                if sub_dp0.poll(timeout=100):
                    _, seq_bytes, payload = sub_dp0.recv_multipart()
                    event_batch = decoder.decode(payload)
                    print(
                        f"DP Rank 0 - EventBatch: ts={event_batch.ts}, "
                        f"attn_dp_rank={event_batch.attn_dp_rank}"
                    )
                    self.assertEqual(
                        event_batch.attn_dp_rank,
                        0,
                        "CP mode with one DP rank should publish events as attn_dp_rank=0",
                    )
                    batches.append(event_batch)

                    for event in event_batch.events:
                        print(f"  DP0 - {event}")
                        self.assertIsInstance(
                            event,
                            (BlockStored, BlockRemoved, AllBlocksCleared),
                            f"Event should be a KV cache event, got {type(event)}",
                        )
                        if isinstance(event, BlockStored):
                            for block_hash in event.block_hashes:
                                if block_hash in stored_hashes:
                                    duplicate_hashes.add(block_hash)
                                stored_hashes.add(block_hash)

                if sub_unexpected.poll(timeout=0):
                    _, seq_bytes, payload = sub_unexpected.recv_multipart()
                    unexpected_batches.append(decoder.decode(payload))

            self.assertGreater(
                len(batches), 0, "Should have received KV cache event batches"
            )
            self.assertGreaterEqual(
                len(stored_hashes),
                min_stored_blocks,
                f"Expected at least {min_stored_blocks} stored KV blocks",
            )
            self.assertEqual(
                unexpected_batches,
                [],
                "CP ranks within one DP rank should not create a second KV event stream",
            )
            self.assertEqual(
                duplicate_hashes,
                set(),
                "CP ranks should not publish duplicate BlockStored events for replicated KV blocks",
            )

        finally:
            sub_dp0.close()
            sub_unexpected.close()
            context.term()
            kill_process_tree(process.pid)


if __name__ == "__main__":
    unittest.main()
