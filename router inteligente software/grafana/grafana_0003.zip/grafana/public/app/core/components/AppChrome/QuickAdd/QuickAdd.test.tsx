import { useBooleanFlagValue } from '@openfeature/react-sdk';
import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { render } from 'test/test-utils';

import { type DataSourceInstanceListItem, type NavModelItem } from '@grafana/data';
import { config, reportInteraction } from '@grafana/runtime';
import { useDataSourceInstanceList } from '@grafana/runtime/unstable';
import { setTestFlags } from '@grafana/test-utils/unstable';
import { contextSrv } from 'app/core/services/context_srv';
import { NewDashboardLibraryInteractions } from 'app/features/dashboard/dashgrid/DashboardLibrary/analytics/main';
import { CONTENT_KINDS, SOURCE_ENTRY_POINTS } from 'app/features/dashboard/dashgrid/DashboardLibrary/constants';
import { getDashboardTemplatesTab } from 'app/features/dashboard/dashgrid/DashboardLibrary/enterprise-components/DashboardTemplatesTabExtension';
import { DashboardLibraryInteractions } from 'app/features/dashboard/dashgrid/DashboardLibrary/interactions';
import { useDashboardGenerationAvailable } from 'app/features/dashboard-prompt/useDashboardGenerationAvailable';
import { configureStore } from 'app/store/configureStore';
import { AccessControlAction } from 'app/types/accessControl';

import { QuickAdd } from './QuickAdd';

jest.mock(
  'app/features/dashboard/dashgrid/DashboardLibrary/enterprise-components/DashboardTemplatesTabExtension',
  () => ({
    getDashboardTemplatesTab: jest.fn(() => null),
  })
);

const mockGetDashboardTemplatesTab = jest.mocked(getDashboardTemplatesTab);

const defaultTestDataSource = {
  name: 'Test Data Source',
  uid: 'test-data-source-uid',
  type: 'grafana-testdata-datasource',
} as DataSourceInstanceListItem;

jest.mock('@grafana/runtime', () => {
  return {
    ...jest.requireActual('@grafana/runtime'),
    reportInteraction: jest.fn(),
  };
});

jest.mock('@grafana/runtime/unstable', () => ({
  ...jest.requireActual('@grafana/runtime/unstable'),
  useDataSourceInstanceList: jest.fn(() => ({ isLoading: false, items: [] })),
}));

const mockUseDataSourceInstanceList = jest.mocked(useDataSourceInstanceList);

jest.mock('@openfeature/react-sdk', () => ({
  ...jest.requireActual('@openfeature/react-sdk'),
  useBooleanFlagValue: jest.fn(),
}));

jest.mock('app/features/dashboard/dashgrid/DashboardLibrary/analytics/main', () => ({
  NewDashboardLibraryInteractions: { entryPointClicked: jest.fn() },
}));

jest.mock('app/features/dashboard/dashgrid/DashboardLibrary/interactions', () => ({
  DashboardLibraryInteractions: { entryPointClicked: jest.fn() },
}));

jest.mock('app/features/dashboard-prompt/useDashboardGenerationAvailable', () => ({
  useDashboardGenerationAvailable: jest.fn(),
}));

// Stub the lazy-loaded modal: this suite covers QuickAdd's wiring, not the prompt itself.
jest.mock('app/features/dashboard-prompt/GenerateDashboardModal', () => ({
  GenerateDashboardModal: ({ onDismiss }: { onDismiss: () => void }) => (
    <div data-testid="generate-dashboard-modal">
      <button onClick={onDismiss}>Close prompt</button>
    </div>
  ),
}));

const useBooleanFlagValueMock = jest.mocked(useBooleanFlagValue);
const mockUseDashboardGenerationAvailable = jest.mocked(useDashboardGenerationAvailable);

const dashboardsNavItem: NavModelItem = {
  text: 'Dashboards',
  id: 'dashboards/browse',
  url: '/dashboards',
  children: [
    { text: 'New dashboard', id: 'dashboards/new', url: '/dashboard/new', isCreateAction: true },
    { text: 'Import dashboard', id: 'dashboards/import', url: '/dashboard/import', isCreateAction: true },
    { text: 'Browse', id: 'dashboards-browse', url: '/dashboards' },
  ],
};

const alertingNavItem: NavModelItem = {
  text: 'Alerting',
  id: 'alerting',
  url: '/alerting',
  children: [{ text: 'New alert rule', id: 'alert', url: '/alerting/new', isCreateAction: true }],
};

const setup = (navBarTree?: NavModelItem[]) => {
  const tree: NavModelItem[] = navBarTree ?? [
    dashboardsNavItem,
    alertingNavItem,
    // Synthetic top-level create action — not in production navtree today, but exercises the ungrouped code path
    {
      text: 'New import',
      id: 'standalone-import',
      url: '/import',
      isCreateAction: true,
    },
  ];
  const store = configureStore({ navBarTree: tree });
  return render(<QuickAdd />, { store });
};

describe('QuickAdd', () => {
  const originalDashboardTemplates = config.featureToggles.dashboardTemplates;

  beforeAll(() => {
    jest.spyOn(window, 'matchMedia').mockImplementation(
      () =>
        ({
          addEventListener: jest.fn(),
          removeEventListener: jest.fn(),
          matches: true,
        }) as unknown as MediaQueryList
    );
  });

  beforeEach(() => {
    jest.clearAllMocks();
    // analyticsFramework defaults to enabled in production
    useBooleanFlagValueMock.mockReturnValue(true);
    config.featureToggles.dashboardTemplates = false;
    mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
    mockGetDashboardTemplatesTab.mockReturnValue(null);
    setTestFlags({ 'grafana.customDashboardTemplates': false });
    mockUseDashboardGenerationAvailable.mockReturnValue(false);
  });

  afterEach(() => {
    config.featureToggles.dashboardTemplates = originalDashboardTemplates;
  });

  it('renders a `New` button', () => {
    setup();
    expect(screen.getByRole('button', { name: 'New' })).toBeInTheDocument();
  });

  it('renders nothing when the navtree has no create actions', () => {
    setup([{ text: 'Dashboards', id: 'dashboards/browse', url: '/dashboards' }]);
    expect(screen.queryByRole('button', { name: 'New' })).not.toBeInTheDocument();
  });

  it('shows isCreateAction options when clicked', async () => {
    setup();
    await userEvent.click(screen.getByRole('button', { name: 'New' }));
    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New alert rule' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New import' })).toBeInTheDocument();
  });

  it('reports interaction when a menu item is clicked', async () => {
    const errorSpy = jest.spyOn(console, 'error').mockImplementation();
    setup();
    await userEvent.click(screen.getByRole('button', { name: 'New' }));
    await userEvent.click(screen.getByRole('menuitem', { name: 'New dashboard' }));

    expect(reportInteraction).toHaveBeenCalledWith('grafana_menu_item_clicked', {
      url: '/dashboard/new',
      from: 'quickadd',
    });
    errorSpy.mockRestore();
  });

  it('renders items under their correct group', async () => {
    setup();
    await userEvent.click(screen.getByRole('button', { name: 'New' }));

    const dashboardGroup = screen.getByRole('group', { name: 'Dashboards' });
    expect(within(dashboardGroup).getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(within(dashboardGroup).getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();

    const alertingGroup = screen.getByRole('group', { name: 'Alerting' });
    expect(within(alertingGroup).getByRole('menuitem', { name: 'New alert rule' })).toBeInTheDocument();
  });

  it('renders ungrouped items without a group header', async () => {
    setup();
    await userEvent.click(screen.getByRole('button', { name: 'New' }));

    const importItem = screen.getByRole('menuitem', { name: 'New import' });
    expect(importItem).toBeInTheDocument();

    const allGroups = screen.getAllByRole('group');
    const ungroupedGroup = allGroups.find(
      (group) => !group.hasAttribute('aria-labelledby') && !group.hasAttribute('aria-label')
    );
    expect(ungroupedGroup).toBeDefined();
    expect(within(ungroupedGroup!).getByRole('menuitem', { name: 'New import' })).toBeInTheDocument();
  });

  describe('Use template button', () => {
    let originalPermissions: typeof contextSrv.user.permissions;

    beforeEach(() => {
      config.featureToggles.dashboardTemplates = true;
      // Reset to defaults: a test datasource is available, custom templates are off.
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [defaultTestDataSource] });
      mockGetDashboardTemplatesTab.mockReturnValue(null);
      setTestFlags({ 'grafana.customDashboardTemplates': false });
      // Custom templates require dashboardtemplates:read; grant it by default (grafana-provisioned
      // templates don't depend on it), and revoke it in the read-gating case.
      originalPermissions = contextSrv.user.permissions;
      contextSrv.user.permissions = { [AccessControlAction.DashboardTemplatesRead]: true };
    });

    afterEach(() => {
      contextSrv.user.permissions = originalPermissions;
    });

    it('shows a `Use template` button when the feature flag is enabled and a test data source exists', async () => {
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.getByRole('menuitem', { name: 'Use template' })).toBeInTheDocument();
    });

    it('does not show a `Use template` button when there is no dashboard group', async () => {
      setup([alertingNavItem]);
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Use template' })).not.toBeInTheDocument();
    });

    it('does not show a `Use template` button when neither templates feature is enabled', async () => {
      config.featureToggles.dashboardTemplates = false;
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
      mockGetDashboardTemplatesTab.mockReturnValue(null);
      setTestFlags({ 'grafana.customDashboardTemplates': false });
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Use template' })).not.toBeInTheDocument();
    });

    it('does not show a `Use template` button when the dashboardTemplates flag is on but there are no test data sources', async () => {
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Use template' })).not.toBeInTheDocument();
    });

    it('shows a `Use template` button when only custom templates are enabled, even without a test datasource', async () => {
      config.featureToggles.dashboardTemplates = false;
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
      mockGetDashboardTemplatesTab.mockReturnValue(() => null);
      setTestFlags({ 'grafana.customDashboardTemplates': true });

      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.getByRole('menuitem', { name: 'Use template' })).toBeInTheDocument();
    });

    it('does not show a `Use template` button for custom-only templates without dashboardtemplates:read', async () => {
      config.featureToggles.dashboardTemplates = false;
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
      mockGetDashboardTemplatesTab.mockReturnValue(() => null);
      setTestFlags({ 'grafana.customDashboardTemplates': true });
      contextSrv.user.permissions = {};

      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Use template' })).not.toBeInTheDocument();
    });

    it('redirects the user to the dashboard from template page when the button is clicked', async () => {
      setup();

      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      const link = screen.getByRole('menuitem', { name: 'Use template' });
      expect(link).toHaveAttribute('href', '/dashboards?templateDashboards=true&source=quickAdd');
    });

    it('reports the new analytics framework interaction when clicked and the framework is enabled', async () => {
      // Clicking the menu item navigates via its href, which jsdom logs as unimplemented
      const errorSpy = jest.spyOn(console, 'error').mockImplementation();
      useBooleanFlagValueMock.mockReturnValue(true);
      setup();

      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      await userEvent.click(screen.getByRole('menuitem', { name: 'Use template' }));

      expect(NewDashboardLibraryInteractions.entryPointClicked).toHaveBeenCalledWith({
        entryPoint: SOURCE_ENTRY_POINTS.QUICK_ADD_BUTTON,
        contentKind: CONTENT_KINDS.TEMPLATE_DASHBOARD,
        contentKinds: [CONTENT_KINDS.TEMPLATE_DASHBOARD],
      });
      expect(DashboardLibraryInteractions.entryPointClicked).not.toHaveBeenCalled();
      errorSpy.mockRestore();
    });

    it('reports the legacy interaction when clicked and the analytics framework is disabled', async () => {
      // Clicking the menu item navigates via its href, which jsdom logs as unimplemented
      const errorSpy = jest.spyOn(console, 'error').mockImplementation();
      useBooleanFlagValueMock.mockReturnValue(false);
      setup();

      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      await userEvent.click(screen.getByRole('menuitem', { name: 'Use template' }));

      expect(DashboardLibraryInteractions.entryPointClicked).toHaveBeenCalledWith({
        entryPoint: SOURCE_ENTRY_POINTS.QUICK_ADD_BUTTON,
        contentKind: CONTENT_KINDS.TEMPLATE_DASHBOARD,
        contentKinds: [CONTENT_KINDS.TEMPLATE_DASHBOARD],
      });
      expect(NewDashboardLibraryInteractions.entryPointClicked).not.toHaveBeenCalled();
      errorSpy.mockRestore();
    });
  });

  describe('Generate dashboard button', () => {
    let originalPermissions: typeof contextSrv.user.permissions;

    beforeEach(() => {
      mockUseDashboardGenerationAvailable.mockReturnValue(true);
      originalPermissions = contextSrv.user.permissions;
      contextSrv.user.permissions = { [AccessControlAction.DashboardsCreate]: true };
    });

    afterEach(() => {
      contextSrv.user.permissions = originalPermissions;
    });

    it('shows a `Generate dashboard` item directly after `New dashboard`', async () => {
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));

      const dashboardGroup = screen.getByRole('group', { name: 'Dashboards' });
      const items = within(dashboardGroup)
        .getAllByRole('menuitem')
        .map((item) => item.textContent);
      expect(items).toEqual(['New dashboard', 'Generate dashboard', 'Import dashboard']);
    });

    it('opens the prompt when the item is clicked, and closes it again on dismiss', async () => {
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByTestId('generate-dashboard-modal')).not.toBeInTheDocument();

      await userEvent.click(screen.getByRole('menuitem', { name: 'Generate dashboard' }));
      expect(await screen.findByTestId('generate-dashboard-modal')).toBeInTheDocument();

      await userEvent.click(screen.getByRole('button', { name: 'Close prompt' }));
      expect(screen.queryByTestId('generate-dashboard-modal')).not.toBeInTheDocument();
    });

    it('does not show the item when dashboard generation is unavailable', async () => {
      mockUseDashboardGenerationAvailable.mockReturnValue(false);
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Generate dashboard' })).not.toBeInTheDocument();
    });

    it('does not show the item without dashboard create permission', async () => {
      contextSrv.user.permissions = {};
      setup();
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Generate dashboard' })).not.toBeInTheDocument();
    });

    it('does not show the item when there is no dashboard group to insert it into', async () => {
      setup([alertingNavItem]);
      await userEvent.click(screen.getByRole('button', { name: 'New' }));
      expect(screen.queryByRole('menuitem', { name: 'Generate dashboard' })).not.toBeInTheDocument();
    });
  });
});
