import { css } from '@emotion/css';
import Skeleton from 'react-loading-skeleton';

import { type GrafanaTheme2 } from '@grafana/data';
import { t, Trans } from '@grafana/i18n';
import { Button, Card, LinkButton, ModalsController, Stack, useStyles2 } from '@grafana/ui';
import { attachSkeleton, type SkeletonComponent } from '@grafana/ui/unstable';
import { DashNavButton } from 'app/features/dashboard/components/DashNav/DashNavButton';
import { ManagedBadge } from 'app/features/provisioning/components/ManagedBadge';
import {
  getManagerIdentity,
  getManagerKind,
  getSourcePath,
  isManaged,
} from 'app/features/provisioning/utils/managedResource';

import { type Playlist } from '../../api/clients/playlist/v1';

import { ShareModal } from './ShareModal';
import { useCanWritePlaylists } from './utils';

interface Props {
  setStartPlaylist: (playlistItem: Playlist) => void;
  setPlaylistToDelete: (playlistItem: Playlist) => void;
  playlist: Playlist;
}

const PlaylistCardComponent = ({ playlist, setStartPlaylist, setPlaylistToDelete }: Props) => {
  const canWrite = useCanWritePlaylists();
  return (
    <Card noMargin>
      <Card.Heading>
        <Stack direction="row" gap={1} alignItems="center" wrap>
          {playlist.spec?.title}
          {isManaged(playlist) && (
            <ManagedBadge
              managerKind={getManagerKind(playlist)}
              name={getManagerIdentity(playlist)}
              repositoryName={getManagerIdentity(playlist)}
              sourcePath={getSourcePath(playlist)}
            />
          )}
        </Stack>
      </Card.Heading>
      <Card.Actions>
        <Button variant="secondary" icon="play" onClick={() => setStartPlaylist(playlist)}>
          <Trans i18nKey="playlist-page.card.start">Start playlist</Trans>
        </Button>
        {canWrite && (
          <LinkButton key="edit" variant="secondary" href={`/playlists/edit/${playlist.metadata?.name}`} icon="cog">
            <Trans i18nKey="playlist-page.card.edit">Edit playlist</Trans>
          </LinkButton>
        )}
        {canWrite && (
          <Button disabled={false} onClick={() => setPlaylistToDelete(playlist)} icon="trash-alt" variant="destructive">
            <Trans i18nKey="playlist-page.card.delete">Delete playlist</Trans>
          </Button>
        )}
      </Card.Actions>
      <Card.SecondaryActions>
        <ModalsController key="button-share">
          {({ showModal, hideModal }) => (
            <DashNavButton
              tooltip={t('playlist-page.card.tooltip', 'Share playlist')}
              icon="share-alt"
              iconSize="lg"
              onClick={() => {
                showModal(ShareModal, {
                  playlistUid: playlist.metadata?.name ?? '',
                  onDismiss: hideModal,
                });
              }}
            />
          )}
        </ModalsController>
      </Card.SecondaryActions>
    </Card>
  );
};

const PlaylistCardSkeleton: SkeletonComponent = ({ rootProps }) => {
  const skeletonStyles = useStyles2(getSkeletonStyles);
  const canWrite = useCanWritePlaylists();
  return (
    <Card noMargin {...rootProps}>
      <Card.Heading>
        <Skeleton width={140} />
      </Card.Heading>
      <Card.Actions>
        <Stack direction="row" wrap="wrap">
          <Skeleton containerClassName={skeletonStyles.button} width={142} height={32} />
          {canWrite && (
            <>
              <Skeleton containerClassName={skeletonStyles.button} width={135} height={32} />
              <Skeleton containerClassName={skeletonStyles.button} width={153} height={32} />
            </>
          )}
        </Stack>
      </Card.Actions>
    </Card>
  );
};

export const PlaylistCard = attachSkeleton(PlaylistCardComponent, PlaylistCardSkeleton);

function getSkeletonStyles(theme: GrafanaTheme2) {
  return {
    button: css({
      lineHeight: 1,
    }),
  };
}
