import { type RoleDto } from 'app/api/clients/legacy';

/**
 * UserPermission is a map storing permissions in a form of
 * {
 *   action: true;
 * }
 */
export type UserPermission = Record<string, boolean>;

// Permission actions
export enum AccessControlAction {
  UsersRead = 'users:read',
  UsersWrite = 'users:write',
  UsersAuthTokenList = 'users.authtoken:read',
  UsersAuthTokenUpdate = 'users.authtoken:write',
  UsersPasswordUpdate = 'users.password:write',
  UsersDelete = 'users:delete',
  UsersCreate = 'users:create',
  UsersEnable = 'users:enable',
  UsersDisable = 'users:disable',
  UsersPermissionsUpdate = 'users.permissions:write',
  UsersLogout = 'users:logout',
  UsersQuotasList = 'users.quotas:read',
  UsersQuotasUpdate = 'users.quotas:write',

  ServiceAccountsRead = 'serviceaccounts:read',
  ServiceAccountsCreate = 'serviceaccounts:create',
  ServiceAccountsWrite = 'serviceaccounts:write',
  ServiceAccountsDelete = 'serviceaccounts:delete',
  ServiceAccountsPermissionsRead = 'serviceaccounts.permissions:read',
  ServiceAccountsPermissionsWrite = 'serviceaccounts.permissions:write',

  OrgsRead = 'orgs:read',
  OrgsPreferencesRead = 'orgs.preferences:read',
  OrgsWrite = 'orgs:write',
  OrgsPreferencesWrite = 'orgs.preferences:write',
  OrgsCreate = 'orgs:create',
  OrgsDelete = 'orgs:delete',
  OrgUsersRead = 'org.users:read',
  OrgUsersAdd = 'org.users:add',
  OrgUsersRemove = 'org.users:remove',
  OrgUsersWrite = 'org.users:write',

  LDAPUsersRead = 'ldap.user:read',
  LDAPUsersSync = 'ldap.user:sync',
  LDAPStatusRead = 'ldap.status:read',

  DataSourcesExplore = 'datasources:explore',
  DataSourcesRead = 'datasources:read',
  DataSourcesCreate = 'datasources:create',
  DataSourcesWrite = 'datasources:write',
  DataSourcesDelete = 'datasources:delete',
  DataSourcesPermissionsRead = 'datasources.permissions:read',
  DataSourcesCachingRead = 'datasources.caching:read',
  DataSourcesInsightsRead = 'datasources.insights:read',

  ActionServerStatsRead = 'server.stats:read',

  ActionTeamsCreate = 'teams:create',
  ActionTeamsDelete = 'teams:delete',
  ActionTeamsRead = 'teams:read',
  ActionTeamsWrite = 'teams:write',
  ActionTeamsPermissionsRead = 'teams.permissions:read',
  ActionTeamsPermissionsWrite = 'teams.permissions:write',

  ActionRolesList = 'roles:read',
  ActionTeamsRolesList = 'teams.roles:read',
  ActionTeamsRolesAdd = 'teams.roles:add',
  ActionTeamsRolesRemove = 'teams.roles:remove',
  ActionUserRolesList = 'users.roles:read',
  ActionUserRolesAdd = 'users.roles:add',
  ActionUserRolesRemove = 'users.roles:remove',

  DashboardsRead = 'dashboards:read',
  DashboardsWrite = 'dashboards:write',
  DashboardsDelete = 'dashboards:delete',
  DashboardsCreate = 'dashboards:create',
  DashboardTemplatesRead = 'dashboardtemplates:read',
  DashboardTemplatesWrite = 'dashboardtemplates:write',
  DashboardsPermissionsRead = 'dashboards.permissions:read',
  DashboardsPermissionsWrite = 'dashboards.permissions:write',
  DashboardsPublicWrite = 'dashboards.public:write',
  SnapshotsCreate = 'snapshots:create',
  SnapshotsDelete = 'snapshots:delete',
  SnapshotsRead = 'snapshots:read',

  FoldersRead = 'folders:read',
  FoldersWrite = 'folders:write',
  FoldersDelete = 'folders:delete',
  FoldersCreate = 'folders:create',
  FoldersPermissionsRead = 'folders.permissions:read',
  FoldersPermissionsWrite = 'folders.permissions:write',

  PlaylistsRead = 'playlists:read',
  PlaylistsWrite = 'playlists:write',

  VariablesCreate = 'variables:create',
  VariablesRead = 'variables:read',
  VariablesWrite = 'variables:write',
  VariablesDelete = 'variables:delete',

  // Support bundle actions
  ActionSupportBundlesCreate = 'support.bundles:create',
  ActionSupportBundlesRead = 'support.bundles:read',
  ActionSupportBundlesDelete = 'support.bundles:delete',

  // Alerting rules
  AlertingRuleCreate = 'alert.rules:create',
  AlertingRuleRead = 'alert.rules:read',
  AlertingRuleUpdate = 'alert.rules:write',
  AlertingRuleDelete = 'alert.rules:delete',

  // Alerting instances (+silences)
  AlertingInstanceCreate = 'alert.instances:create',
  AlertingInstanceUpdate = 'alert.instances:write',
  AlertingInstanceRead = 'alert.instances:read',

  // Alerting silences
  AlertingSilenceCreate = 'alert.silences:create',
  AlertingSilenceUpdate = 'alert.silences:write',
  AlertingSilenceRead = 'alert.silences:read',

  // Alerting Notification policies
  AlertingNotificationsRead = 'alert.notifications:read',
  AlertingNotificationsWrite = 'alert.notifications:write',

  // External alerting rule actions.
  AlertingRuleExternalWrite = 'alert.rules.external:write',
  AlertingRuleExternalRead = 'alert.rules.external:read',

  // External alerting instances actions.
  AlertingInstancesExternalWrite = 'alert.instances.external:write',
  AlertingInstancesExternalRead = 'alert.instances.external:read',

  // External alerting notifications actions.
  AlertingNotificationsExternalWrite = 'alert.notifications.external:write',
  AlertingNotificationsExternalRead = 'alert.notifications.external:read',

  // Alerting provisioning actions
  AlertingProvisioningReadSecrets = 'alert.provisioning.secrets:read',
  AlertingProvisioningRead = 'alert.provisioning:read',
  AlertingProvisioningWrite = 'alert.provisioning:write',
  AlertingRulesProvisioningRead = 'alert.rules.provisioning:read',
  AlertingRulesProvisioningWrite = 'alert.rules.provisioning:write',
  AlertingNotificationsProvisioningRead = 'alert.notifications.provisioning:read',
  AlertingNotificationsProvisioningWrite = 'alert.notifications.provisioning:write',
  AlertingProvisioningSetStatus = 'alert.provisioning.provenance:write',

  // Alerting receivers actions
  AlertingReceiversPermissionsRead = 'receivers.permissions:read',
  AlertingReceiversPermissionsWrite = 'receivers.permissions:write',
  AlertingReceiversCreate = 'alert.notifications.receivers:create',
  AlertingReceiversWrite = 'alert.notifications.receivers:write',
  AlertingReceiversRead = 'alert.notifications.receivers:read',
  AlertingReceiversDelete = 'alert.notifications.receivers:delete',
  /** @deprecated Use AlertingReceiversTestCreate instead */
  AlertingReceiversTest = 'alert.notifications.receivers:test',
  AlertingReceiversTestCreate = 'alert.notifications.receivers.test:create',
  AlertingReceiversUpdateProtected = 'alert.notifications.receivers.protected:write',

  // Legacy Alerting routes actions
  AlertingRoutesRead = 'alert.notifications.routes:read',
  AlertingRoutesWrite = 'alert.notifications.routes:write',

  // Alerting notifications config actions (new, scoped per-resource)
  ActionAlertingNotificationsConfigRead = 'notifications.alerting.grafana.app/configs:get',

  // Alerting managed routes actions (new, scoped per-resource)
  ActionAlertingManagedRoutesRead = 'notifications.alerting.grafana.app/routingtrees:get',
  ActionAlertingManagedRoutesWrite = 'notifications.alerting.grafana.app/routingtrees:update',
  ActionAlertingManagedRoutesCreate = 'notifications.alerting.grafana.app/routingtrees:create',
  ActionAlertingManagedRoutesDelete = 'notifications.alerting.grafana.app/routingtrees:delete',

  // Alerting time intervals actions
  AlertingTimeIntervalsRead = 'alert.notifications.time-intervals:read',
  AlertingTimeIntervalsWrite = 'alert.notifications.time-intervals:write',
  AlertingTimeIntervalsDelete = 'alert.notifications.time-intervals:delete',

  // Alerting templates actions
  AlertingTemplatesRead = 'alert.notifications.templates:read',
  AlertingTemplatesWrite = 'alert.notifications.templates:write',
  AlertingTemplatesDelete = 'alert.notifications.templates:delete',
  AlertingNotificationsTemplatesTest = 'alert.notifications.templates.test:write',

  // Alerting inhibition rules actions
  AlertingInhibitionRulesRead = 'alert.notifications.inhibition-rules:read',
  AlertingInhibitionRulesWrite = 'alert.notifications.inhibition-rules:write',
  AlertingInhibitionRulesDelete = 'alert.notifications.inhibition-rules:delete',

  // Alerting enrichments actions
  AlertingEnrichmentsRead = 'alert.enrichments:read',
  AlertingEnrichmentsWrite = 'alert.enrichments:write',

  PluginsInstall = 'plugins:install',
  PluginsWrite = 'plugins:write',
  PluginsAppAccess = 'plugins.app:access',

  // Settings
  SettingsRead = 'settings:read',
  SettingsWrite = 'settings:write',

  // GroupSync
  GroupSyncMappingsRead = 'groupsync.mappings:read',
  GroupSyncMappingsWrite = 'groupsync.mappings:write',

  // Migration Assistant
  MigrationAssistantMigrate = 'migrationassistant:migrate',

  // Saved Queries
  QueriesRead = 'queries:read',
  QueriesWrite = 'queries:write',

  // Provisioning
  ProvisioningRepositoriesRead = 'provisioning.repositories:read',
  ProvisioningRepositoriesWrite = 'provisioning.repositories:write',
  ProvisioningConnectionsCreate = 'provisioning.connections:create',
  ProvisioningConnectionsWrite = 'provisioning.connections:write',
}

export interface Role extends RoleDto {
  filteredDisplayName: string; // name to be shown in filtered role list
}
