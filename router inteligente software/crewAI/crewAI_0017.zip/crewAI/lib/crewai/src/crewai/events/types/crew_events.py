from typing import TYPE_CHECKING, Any, Literal

from crewai.events.base_events import BaseEvent


if TYPE_CHECKING:
    from crewai.crew import Crew
else:
    Crew = Any


class CrewBaseEvent(BaseEvent):
    """Base class for crew events with fingerprint handling"""

    crew_name: str | None
    crew: Crew | None = None

    def __init__(self, **data: Any) -> None:
        super().__init__(**data)
        self._set_crew_fingerprint()

    def _set_crew_fingerprint(self) -> None:
        if self.crew is not None and self.crew.fingerprint:
            self.source_fingerprint = self.crew.fingerprint.uuid_str
            self.source_type = "crew"
            if self.crew.fingerprint.metadata:
                self.fingerprint_metadata = self.crew.fingerprint.metadata

    def to_json(self, exclude: set[str] | None = None) -> Any:
        if exclude is None:
            exclude = set()
        exclude.add("crew")
        return super().to_json(exclude=exclude)


class CrewKickoffStartedEvent(CrewBaseEvent):
    """Event emitted when a crew starts execution"""

    inputs: dict[str, Any] | None
    type: Literal["crew_kickoff_started"] = "crew_kickoff_started"


class CrewKickoffCompletedEvent(CrewBaseEvent):
    """Event emitted when a crew completes execution"""

    output: Any
    type: Literal["crew_kickoff_completed"] = "crew_kickoff_completed"
    total_tokens: int = 0


class CrewKickoffFailedEvent(CrewBaseEvent):
    """Event emitted when a crew fails to complete execution"""

    error: str
    type: Literal["crew_kickoff_failed"] = "crew_kickoff_failed"


class CrewTrainStartedEvent(CrewBaseEvent):
    """Event emitted when a crew starts training"""

    n_iterations: int
    filename: str
    inputs: dict[str, Any] | None
    type: Literal["crew_train_started"] = "crew_train_started"


class CrewTrainCompletedEvent(CrewBaseEvent):
    """Event emitted when a crew completes training"""

    n_iterations: int
    filename: str
    type: Literal["crew_train_completed"] = "crew_train_completed"


class CrewTrainFailedEvent(CrewBaseEvent):
    """Event emitted when a crew fails to complete training"""

    error: str
    type: Literal["crew_train_failed"] = "crew_train_failed"


class CrewTestStartedEvent(CrewBaseEvent):
    """Event emitted when a crew starts testing"""

    n_iterations: int
    eval_llm: str | Any | None
    inputs: dict[str, Any] | None
    type: Literal["crew_test_started"] = "crew_test_started"


class CrewTestCompletedEvent(CrewBaseEvent):
    """Event emitted when a crew completes testing"""

    type: Literal["crew_test_completed"] = "crew_test_completed"


class CrewTestFailedEvent(CrewBaseEvent):
    """Event emitted when a crew fails to complete testing"""

    error: str
    type: Literal["crew_test_failed"] = "crew_test_failed"


class CrewTestResultEvent(CrewBaseEvent):
    """Event emitted when a crew test result is available"""

    quality: float
    execution_duration: float
    model: str
    type: Literal["crew_test_result"] = "crew_test_result"
