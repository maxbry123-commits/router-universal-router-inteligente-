from collections.abc import Callable
from inspect import getsource
from typing import Any, Literal

from crewai.events.base_events import BaseEvent


class LLMGuardrailBaseEvent(BaseEvent):
    task_id: str | None = None
    task_name: str | None = None
    from_task: Any | None = None
    from_agent: Any | None = None
    agent_role: str | None = None
    agent_id: str | None = None
    guardrail_type: str | None = None
    guardrail_name: str | None = None

    def __init__(self, **data: Any) -> None:
        super().__init__(**data)
        self._set_agent_params(data)
        self._set_task_params(data)


class LLMGuardrailStartedEvent(LLMGuardrailBaseEvent):
    """Event emitted when a guardrail task starts

    Attributes:
        guardrail: The guardrail callable or LLMGuardrail instance
        retry_count: The number of times the guardrail has been retried
    """

    type: Literal["llm_guardrail_started"] = "llm_guardrail_started"
    guardrail: str | Callable[..., Any]
    retry_count: int

    def __init__(self, **data: Any) -> None:
        from crewai.tasks.hallucination_guardrail import HallucinationGuardrail
        from crewai.tasks.llm_guardrail import LLMGuardrail

        super().__init__(**data)

        if isinstance(self.guardrail, HallucinationGuardrail):
            self.guardrail_type = "hallucination"
            self.guardrail_name = self.guardrail.description.strip()
            self.guardrail = self.guardrail.description.strip()
        elif isinstance(self.guardrail, LLMGuardrail):
            self.guardrail_type = "llm"
            self.guardrail_name = self.guardrail.description.strip()
            self.guardrail = self.guardrail.description.strip()
        elif callable(self.guardrail):
            self.guardrail_type = "function"
            self.guardrail_name = getattr(self.guardrail, "__name__", None)
            self.guardrail = getsource(self.guardrail).strip()


class LLMGuardrailCompletedEvent(LLMGuardrailBaseEvent):
    """Event emitted when a guardrail task completes

    Attributes:
        success: Whether the guardrail validation passed
        result: The validation result
        error: Error message if validation failed
        retry_count: The number of times the guardrail has been retried
    """

    type: Literal["llm_guardrail_completed"] = "llm_guardrail_completed"
    success: bool
    result: Any
    error: str | None = None
    retry_count: int
