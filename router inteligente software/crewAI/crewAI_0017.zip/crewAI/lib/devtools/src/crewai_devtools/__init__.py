"""CrewAI development tools."""

__version__ = "1.15.18"
