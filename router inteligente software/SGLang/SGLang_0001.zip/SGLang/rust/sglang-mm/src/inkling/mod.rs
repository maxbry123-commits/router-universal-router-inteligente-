use std::sync::OnceLock;

use crate::common;
use crate::common::par;
use half::bf16;

const MEAN: [f32; 3] = [
    0.48145466f64 as f32,
    0.4578275f64 as f32,
    0.40821073f64 as f32,
];
const STD: [f32; 3] = [
    0.26862954f64 as f32,
    0.2613026f64 as f32,
    0.2757771f64 as f32,
];
const INV255: f32 = (1.0f64 / 255.0f64) as f32;
const PAD_RAW: f32 = (-1.0f64 / 255.0f64) as f32;

#[inline]
fn pad_bits() -> [u16; 3] {
    core::array::from_fn(|c| bf16::from_f32((PAD_RAW - MEAN[c]) / STD[c]).to_bits())
}

fn luts() -> &'static [[u16; 256]; 3] {
    static LUTS: OnceLock<[[u16; 256]; 3]> = OnceLock::new();
    LUTS.get_or_init(|| {
        core::array::from_fn(|c| {
            core::array::from_fn(|v| {
                let raw = v as u8 as f32 * INV255;
                bf16::from_f32((raw - MEAN[c]) / STD[c]).to_bits()
            })
        })
    })
}

#[inline]
pub fn grid(h: usize, w: usize, ps: usize) -> (usize, usize) {
    (h.div_ceil(ps), w / ps + 1)
}

fn patchify_into(arr: &[u8], h: usize, w: usize, ps: usize, out: &mut [u16]) {
    let (_nph, npw) = grid(h, w, ps);
    let pad = pad_bits();
    let lut = luts();
    let patch_elems = ps * ps * 3;
    let row_elems = npw * patch_elems;

    let body = |(i, row): (usize, &mut [u16])| {
        let y_base = i * ps;
        for j in 0..npw {
            let x_base = j * ps;
            let chunk = &mut row[j * patch_elems..(j + 1) * patch_elems];
            for y in 0..ps {
                let iy = y_base + y;
                if iy >= h {
                    for x in 0..ps {
                        let o = (y * ps + x) * 3;
                        chunk[o..o + 3].copy_from_slice(&pad);
                    }
                    continue;
                }
                let n_real = if x_base < w { (w - x_base).min(ps) } else { 0 };
                let src = (iy * w + x_base) * 3;
                for x in 0..n_real {
                    let o = (y * ps + x) * 3;
                    let p = src + x * 3;
                    chunk[o] = lut[0][arr[p] as usize];
                    chunk[o + 1] = lut[1][arr[p + 1] as usize];
                    chunk[o + 2] = lut[2][arr[p + 2] as usize];
                }
                for x in n_real..ps {
                    let o = (y * ps + x) * 3;
                    chunk[o..o + 3].copy_from_slice(&pad);
                }
            }
        }
    };

    par::for_chunks_mut(out, row_elems, |index, chunk| body((index, chunk)));
}

fn patchify_alloc(arr: &[u8], h: usize, w: usize, ps: usize) -> Vec<u16> {
    let (nph, npw) = grid(h, w, ps);
    let mut out = vec![0u16; nph * npw * ps * ps * 3];
    patchify_into(arr, h, w, ps, &mut out);
    out
}

/// Struct implementing ImageProcessorSpec for Inkling.
pub struct InklingProcessor;

impl crate::registry::ImageProcessorSpec for InklingProcessor {
    fn name(&self) -> &'static str {
        "inkling"
    }

    fn preprocess_batch(
        &self,
        datas: &[Vec<u8>],
        patch_size: usize,
        rescale_frac: Option<f64>,
        rescale_cap: Option<i64>,
    ) -> Result<Vec<(usize, usize, Vec<u16>, u64)>, String> {
        if patch_size == 0 {
            return Err("patch_size must be greater than zero".into());
        }
        par::try_map(datas, |data| {
            let hash = common::content_hash_u64(data);
            let (rgb, h, w) = common::decode_rescale(data, rescale_frac, rescale_cap)?;
            Ok((h, w, patchify_alloc(&rgb, h, w, patch_size), hash))
        })
    }
}

// --- Python bindings (feature-gated: absent from the pure-Rust rlib) ---

#[cfg(feature = "python")]
mod python {
    use numpy::{IntoPyArray, PyArray1, PyReadonlyArray3, PyUntypedArrayMethods};
    use pyo3::exceptions::PyValueError;
    use pyo3::prelude::*;

    use super::patchify_alloc;
    use crate::common;
    use crate::common::par;

    /// `(height, width, patches_as_u16_bits)` for one decoded image.
    type Patches = (usize, usize, Vec<u16>);
    /// [`Patches`] plus the image content hash.
    type HashedPatches = (usize, usize, Vec<u16>, u64);
    /// [`Patches`] with the patch data as a numpy array bound to `'py`.
    type PyPatches<'py> = (usize, usize, Bound<'py, PyArray1<u16>>);
    /// [`PyPatches`] plus the image content hash.
    type PyHashedPatches<'py> = (usize, usize, Bound<'py, PyArray1<u16>>, u64);

    fn check_ps(ps: usize) -> PyResult<()> {
        if ps == 0 {
            return Err(PyValueError::new_err(
                "patch_size must be greater than zero",
            ));
        }
        Ok(())
    }

    #[pyfunction]
    fn patchify_rgb<'py>(
        py: Python<'py>,
        arr: PyReadonlyArray3<'py, u8>,
        patch_size: usize,
    ) -> PyResult<Bound<'py, PyArray1<u16>>> {
        check_ps(patch_size)?;
        let shape = arr.shape();
        let (h, w, c) = (shape[0], shape[1], shape[2]);
        if c != 3 {
            return Err(PyValueError::new_err(format!(
                "expected HWC RGB array with 3 channels, got {c}"
            )));
        }
        let data = arr
            .as_slice()
            .map_err(|_| PyValueError::new_err("array must be C-contiguous"))?
            .to_vec();
        let out = py.detach(move || patchify_alloc(&data, h, w, patch_size));
        Ok(out.into_pyarray(py))
    }

    #[pyfunction]
    #[pyo3(signature = (data, patch_size, rescale_frac=None, rescale_cap=None))]
    fn decode_patchify<'py>(
        py: Python<'py>,
        data: Vec<u8>,
        patch_size: usize,
        rescale_frac: Option<f64>,
        rescale_cap: Option<i64>,
    ) -> PyResult<(usize, usize, Bound<'py, PyArray1<u16>>)> {
        check_ps(patch_size)?;
        let (h, w, out) = py
            .detach(move || {
                let (rgb, h, w) = common::decode_rescale(&data, rescale_frac, rescale_cap)?;
                Ok::<_, String>((h, w, patchify_alloc(&rgb, h, w, patch_size)))
            })
            .map_err(PyValueError::new_err)?;
        Ok((h, w, out.into_pyarray(py)))
    }

    #[pyfunction]
    #[pyo3(signature = (datas, patch_size, rescale_frac=None, rescale_cap=None))]
    fn decode_patchify_batch<'py>(
        py: Python<'py>,
        datas: Vec<Vec<u8>>,
        patch_size: usize,
        rescale_frac: Option<f64>,
        rescale_cap: Option<i64>,
    ) -> PyResult<Vec<PyPatches<'py>>> {
        check_ps(patch_size)?;
        let results: Vec<Patches> = py
            .detach(move || {
                par::try_map(&datas, |data| -> Result<Patches, String> {
                    let (rgb, h, w) = common::decode_rescale(data, rescale_frac, rescale_cap)?;
                    Ok((h, w, patchify_alloc(&rgb, h, w, patch_size)))
                })
            })
            .map_err(PyValueError::new_err)?;
        results
            .into_iter()
            .map(|(h, w, v)| Ok((h, w, v.into_pyarray(py))))
            .collect()
    }

    #[pyfunction]
    #[pyo3(signature = (datas, patch_size, rescale_frac=None, rescale_cap=None))]
    fn preprocess_images<'py>(
        py: Python<'py>,
        datas: Vec<Vec<u8>>,
        patch_size: usize,
        rescale_frac: Option<f64>,
        rescale_cap: Option<i64>,
    ) -> PyResult<Vec<PyHashedPatches<'py>>> {
        check_ps(patch_size)?;
        let results: Vec<HashedPatches> = py
            .detach(move || {
                par::try_map(&datas, |data| -> Result<HashedPatches, String> {
                    let hash = common::content_hash_u64(data);
                    let (rgb, h, w) = common::decode_rescale(data, rescale_frac, rescale_cap)?;
                    Ok((h, w, patchify_alloc(&rgb, h, w, patch_size), hash))
                })
            })
            .map_err(PyValueError::new_err)?;
        results
            .into_iter()
            .map(|(h, w, v, hash)| Ok((h, w, v.into_pyarray(py), hash)))
            .collect()
    }

    #[pyfunction]
    #[pyo3(signature = (arr, raw_bytes, patch_size, rescale_frac=None, rescale_cap=None))]
    fn rescale_patchify_hash<'py>(
        py: Python<'py>,
        arr: PyReadonlyArray3<'py, u8>,
        raw_bytes: &[u8],
        patch_size: usize,
        rescale_frac: Option<f64>,
        rescale_cap: Option<i64>,
    ) -> PyResult<(usize, usize, Bound<'py, PyArray1<u16>>, u64)> {
        check_ps(patch_size)?;
        let shape = arr.shape();
        let (h, w, c) = (shape[0], shape[1], shape[2]);
        if c != 3 {
            return Err(PyValueError::new_err(format!(
                "expected HWC RGB array with 3 channels, got {c}"
            )));
        }
        let hash = common::content_hash_u64(raw_bytes);
        let rgb = arr
            .as_slice()
            .map_err(|_| PyValueError::new_err("array must be C-contiguous"))?
            .to_vec();
        let (oh, ow, out) = py.detach(move || {
            let (tw, th) = common::resize::scaled_dims(w, h, rescale_frac, rescale_cap);
            let (rgb, h, w) = if (tw, th) != (w, h) {
                (
                    common::resize::resize_lanczos_rgb(&rgb, h, w, th, tw),
                    th,
                    tw,
                )
            } else {
                (rgb, h, w)
            };
            (h, w, patchify_alloc(&rgb, h, w, patch_size))
        });
        Ok((oh, ow, out.into_pyarray(py), hash))
    }

    pub fn register(parent: &Bound<'_, PyModule>) -> PyResult<()> {
        let m = PyModule::new(parent.py(), "inkling")?;
        m.add_function(wrap_pyfunction!(patchify_rgb, &m)?)?;
        m.add_function(wrap_pyfunction!(decode_patchify, &m)?)?;
        m.add_function(wrap_pyfunction!(decode_patchify_batch, &m)?)?;
        m.add_function(wrap_pyfunction!(preprocess_images, &m)?)?;
        m.add_function(wrap_pyfunction!(rescale_patchify_hash, &m)?)?;
        parent.add_submodule(&m)?;
        Ok(())
    }
}

#[cfg(feature = "python")]
pub use python::register;
