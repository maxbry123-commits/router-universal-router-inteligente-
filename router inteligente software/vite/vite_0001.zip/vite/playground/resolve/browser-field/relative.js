import rc from './ext'
import re from './ext-index/index.js'
import rd from './ext.js'
import rf from './no-ext-index/index.js' // no substitution

/* eslint-disable import-x/no-duplicates */
import ra from './no-ext'
import rb from './no-ext.js' // no substitution

export { ra, rb, rc, rd, re, rf }
