import { expect, test } from 'vitest'
import { findAssetFile, isBuild, listAssets, page } from '~utils'
import { port } from './serve'

const url = `http://localhost:${port}`

test('should work when inlined', async () => {
  await page.goto(`${url}/static-light`)
  expect(await page.textContent('.static-light')).toMatch('42')
})

test('should work when output', async () => {
  await page.goto(`${url}/static-heavy`)
  expect(await page.textContent('.static-heavy')).toMatch('24')
})

test.runIf(isBuild)('should not contain wasm file when inlined', async () => {
  const assets = await listAssets()
  const lightWasm = assets.find((f) => /^light-[^-]+\.wasm$/.test(f))
  expect(lightWasm).toBeUndefined()

  const staticLight = await findAssetFile(/^static-light-.+\.js$/)
  expect(staticLight).toContain('data:application/wasm;base64,')
})

test.runIf(isBuild)(
  'should contain and reference wasm file when output',
  async () => {
    const assets = await listAssets()
    const heavyWasm = assets.find((f) => /heavy-.+\.wasm$/.test(f))
    expect(heavyWasm).toBeDefined()

    const staticHeavy = await findAssetFile(/^static-heavy-.+\.js$/)
    expect(staticHeavy).toContain(heavyWasm)
    expect(staticHeavy).not.toContain('data:application/wasm;base64,')
  },
)

test('direct wasm import', async () => {
  await page.goto(`${url}/direct-add`)
  expect(await page.textContent('.direct-add')).toMatch('3')
})

test.runIf(isBuild)(
  'direct wasm import should contain and reference wasm file',
  async () => {
    const assets = listAssets()
    const addWasm = assets.find((f) => /add-.+\.wasm$/.test(f))
    expect(addWasm).toBeDefined()

    const directAdd = findAssetFile(/^direct-add-.+\.js$/)
    expect(directAdd).toContain(addWasm)
    expect(directAdd).not.toContain('data:application/wasm;base64,')
  },
)

test('direct wasm import with wasm imports', async () => {
  await page.goto(`${url}/direct-light`)
  expect(await page.textContent('.direct-light')).toMatch('42')
})
