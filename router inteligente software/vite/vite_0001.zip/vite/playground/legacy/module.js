export const module = 'module'
