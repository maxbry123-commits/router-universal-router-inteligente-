document.querySelector('main').innerHTML = '👋'
