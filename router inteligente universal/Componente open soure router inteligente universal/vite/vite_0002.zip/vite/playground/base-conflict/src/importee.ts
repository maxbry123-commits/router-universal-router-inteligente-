export default 'absolute import'
