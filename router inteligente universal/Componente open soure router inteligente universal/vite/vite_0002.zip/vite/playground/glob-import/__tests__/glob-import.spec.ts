import { readdir } from 'node:fs/promises'
import path from 'node:path'
import { expect, test } from 'vitest'
import {
  addFile,
  editFile,
  findAssetFile,
  isBuild,
  isBundledDev,
  page,
  removeFile,
} from '~utils'

const filteredResult = {
  './alias.js': {
    default: 'hi',
  },
  './foo.js': {
    msg: 'foo',
  },
  "./quote'.js": {
    msg: 'single-quote',
  },
}

const json = {
  msg: 'baz',
  default: {
    msg: 'baz',
  },
}

const globWithAlias = {
  '/dir/alias.js': {
    default: 'hi',
  },
}

const allResult = {
  // JSON file should be properly transformed
  '/dir/alias.js': {
    default: 'hi',
  },
  '/dir/baz.json': json,
  '/dir/foo.css': {},
  '/dir/foo.js': {
    msg: 'foo',
  },
  '/dir/index.js': isBuild
    ? {
        modules: filteredResult,
        globWithAlias,
      }
    : {
        globWithAlias,
        modules: filteredResult,
      },
  '/dir/nested/bar.js': {
    modules: {
      '../baz.json': json,
    },
    msg: 'bar',
  },
  "/dir/quote'.js": {
    msg: 'single-quote',
  },
}

const nodeModulesResult = {
  '/dir/node_modules/hoge.js': { msg: 'hoge' },
}

const rawResult = {
  '/dir/baz.json': {
    msg: 'baz',
  },
}

const relativeRawResult = {
  './dir/baz.json': {
    msg: 'baz',
  },
}

const baseRawResult = {
  './baz.json': {
    msg: 'baz',
  },
}

test('should work', async () => {
  await expect
    .poll(async () => JSON.parse(await page.textContent('.result')))
    .toStrictEqual(allResult)
  await expect
    .poll(async () => JSON.parse(await page.textContent('.result-eager')))
    .toStrictEqual(allResult)
  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.result-node_modules')),
    )
    .toStrictEqual(nodeModulesResult)
})

test('import glob raw', async () => {
  expect(await page.textContent('.globraw')).toBe(
    JSON.stringify(rawResult, null, 2),
  )
})

test('import property access', async () => {
  expect(await page.textContent('.property-access')).toBe(
    JSON.stringify(rawResult['/dir/baz.json'], null, 2),
  )
})

test('import relative glob raw', async () => {
  expect(await page.textContent('.relative-glob-raw')).toBe(
    JSON.stringify(relativeRawResult, null, 2),
  )
})

test('unassigned import processes', async () => {
  expect(await page.textContent('.side-effect-result')).toBe(
    'Hello from side effect',
  )
})

test('import glob in package', async () => {
  expect(await page.textContent('.in-package')).toBe(
    JSON.stringify(['/pkg-pages/foo.js']),
  )
})

if (!isBuild) {
  test.skipIf(isBundledDev)('hmr for adding/removing files', async () => {
    const resultElement = page.locator('.result')

    addFile('root/dir/a.js', '')
    await expect
      .poll(async () => {
        const actualAdd = await resultElement.textContent()
        return JSON.parse(actualAdd)
      })
      .toStrictEqual({
        '/dir/a.js': {},
        ...allResult,
        '/dir/index.js': {
          ...allResult['/dir/index.js'],
          modules: {
            './a.js': {},
            ...allResult['/dir/index.js'].modules,
          },
        },
      })

    // edit the added file
    editFile('root/dir/a.js', () => 'export const msg ="a"')
    await expect
      .poll(async () => {
        const actualEdit = await resultElement.textContent()
        return JSON.parse(actualEdit)
      })
      .toStrictEqual({
        '/dir/a.js': {
          msg: 'a',
        },
        ...allResult,
        '/dir/index.js': {
          ...allResult['/dir/index.js'],
          modules: {
            './a.js': {
              msg: 'a',
            },
            ...allResult['/dir/index.js'].modules,
          },
        },
      })

    removeFile('root/dir/a.js')
    await expect
      .poll(async () => {
        const actualRemove = await resultElement.textContent()
        return JSON.parse(actualRemove)
      })
      .toStrictEqual(allResult)
  })

  test('no hmr for adding/removing files', async () => {
    let request = page.waitForResponse(/dir\/index\.js$/, { timeout: 200 })
    addFile('root/nohmr.js', '')
    let response = await request.catch(() => ({ status: () => -1 }))
    expect(response.status()).toBe(-1)

    request = page.waitForResponse(/dir\/index\.js$/, { timeout: 200 })
    removeFile('root/nohmr.js')
    response = await request.catch(() => ({ status: () => -1 }))
    expect(response.status()).toBe(-1)
  })

  test.skipIf(isBundledDev)(
    'hmr for adding/removing files in package',
    async () => {
      const resultElement = page.locator('.in-package')

      addFile('root/pkg-pages/bar.js', '// empty')
      await expect
        .poll(async () => JSON.parse(await resultElement.textContent()))
        .toStrictEqual(['/pkg-pages/foo.js', '/pkg-pages/bar.js'].sort())

      removeFile('root/pkg-pages/bar.js')
      await expect
        .poll(async () => JSON.parse(await resultElement.textContent()))
        .toStrictEqual(['/pkg-pages/foo.js'])
    },
  )

  test.skipIf(isBundledDev)(
    'hmr for adding/removing files with array patterns and exclusions',
    async () => {
      const resultElement = page.locator('.array-result')
      await expect
        .poll(async () => JSON.parse(await resultElement.textContent()))
        .toStrictEqual({
          './array-test-dir/included.js': 'included',
        })

      addFile('root/array-test-dir/new-file.js', 'export default "new"')
      await expect
        .poll(async () => JSON.parse(await resultElement.textContent()))
        .toStrictEqual({
          './array-test-dir/included.js': 'included',
          './array-test-dir/new-file.js': 'new',
        })

      removeFile('root/array-test-dir/new-file.js')
      await expect
        .poll(async () => JSON.parse(await resultElement.textContent()))
        .toStrictEqual({
          './array-test-dir/included.js': 'included',
        })
    },
  )
}

test('follow symlinks', async () => {
  await expect
    .poll(async () => JSON.parse(await page.textContent('.follow-symlinks')))
    .toStrictEqual({
      './follow-symlinks/linked/my-lib/components/a.js': 'a',
      './follow-symlinks/linked/my-lib/components/b.js': 'b',
    })
})

test('follow symlinks same reference', async () => {
  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.follow-symlinks-same-ref')),
    )
    .toStrictEqual({
      a: true,
      b: true,
    })
})

test('alias exclusion', async () => {
  await expect
    .poll(async () => JSON.parse(await page.textContent('.alias-exclusion')))
    .toSatisfy((keys: string[]) => {
      return keys.length > 0 && keys.every((k) => !k.includes('alias'))
    })
})

test('array pattern with exclusions', async () => {
  await expect
    .poll(async () => JSON.parse(await page.textContent('.array-result')))
    .toStrictEqual({
      './array-test-dir/included.js': 'included',
    })
})

// https://github.com/vitejs/vite/issues/22170
test('array pattern with sibling directories sharing a prefix', async () => {
  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.array-common-base-result')),
    )
    .toStrictEqual({
      '/array-common-base/pattern1/a.js': 'a',
      '/array-common-base/pattern2/b.js': 'b',
    })
})

test('tree-shake eager css', async () => {
  expect(await page.textContent('.no-tree-shake-eager-css-result')).toMatch(
    '.no-tree-shake-eager-css',
  )

  if (isBuild) {
    const content = findAssetFile(/index-[-\w]+\.js/, '../root/dist')
    expect(content).not.toMatch('.tree-shake-eager-css')
  }
})

test('escapes special chars in globs without mangling user supplied glob suffix', async () => {
  // the escape dir contains subdirectories where each has a name that needs escaping for glob safety
  // inside each of them is a glob.js that exports the result of a relative glob `./**/*.js`
  // and an alias glob `@escape_<dirname>_mod/**/*.js`. The matching aliases are generated in vite.config.ts
  // index.html has a script that loads all these glob.js files and prints the globs that returned the expected result
  // this test finally compares the printed output of index.js with the list of directories with special chars,
  // expecting that they all work
  const files = await readdir(
    path.join(import.meta.dirname, '..', 'root', 'escape'),
    {
      withFileTypes: true,
    },
  )
  const expectedNames = files
    .filter((f) => f.isDirectory())
    .map((f) => `/escape/${f.name}/glob.js`)
    .sort()
  await expect
    .poll(async () => {
      const text = await page.textContent('.escape-relative')
      return text.split('\n').sort()
    })
    .toEqual(expectedNames)
  await expect
    .poll(async () => {
      const text = await page.textContent('.escape-alias')
      return text.split('\n').sort()
    })
    .toEqual(expectedNames)
})

test('escape literal parenthesis in glob pattern', async () => {
  // https://github.com/vitejs/vite/issues/22166
  // Backslash-escaped parens must match literal "(" / ")" in both dev and build.
  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.escape-literal-parenthesis')),
    )
    .toStrictEqual(['/escape/(parenthesis)/mod/index.js'])
})

test('subpath imports', async () => {
  await expect
    .poll(async () => await page.textContent('.subpath-imports'))
    .toMatch('bar foo')
})

test('subpath imports (sub dir)', async () => {
  await expect
    .poll(async () => await page.textContent('.subpath-imports-sub-dir'))
    .toMatch('bar foo')
})

test('#alias imports', async () => {
  await expect
    .poll(async () => await page.textContent('.hash-alias-imports'))
    .toMatch('bar foo')
})

test('import base glob raw', async () => {
  await expect
    .poll(async () => await page.textContent('.result-base'))
    .toBe(JSON.stringify(baseRawResult, null, 2))
})

test('import.meta.glob and dynamic import vars transformations should be visible to post transform plugins', async () => {
  await expect
    .poll(async () => await page.textContent('.transform-visibility'))
    .toBe(
      JSON.stringify({ globTransformed: true, dynamicImportTransformed: true }),
    )
})

test('caseSensitiveMatch option', async () => {
  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.case-sensitive-true')),
    )
    .toStrictEqual(['./case-sensitive-dir/data-test.js'])

  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.case-sensitive-false')),
    )
    .toStrictEqual([
      './case-sensitive-dir/DATA-other.js',
      './case-sensitive-dir/data-test.js',
    ])
})
test('absolute base with files outside of root', async () => {
  await expect
    .poll(async () =>
      JSON.parse(await page.textContent('.absolute-base-outside-root')),
    )
    .toStrictEqual({
      '../external/x.js': 'hello from x',
      '../external/y.js': 'hello from y',
    })
})
