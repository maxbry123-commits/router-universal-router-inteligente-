export default 'DATA-OTHER'
