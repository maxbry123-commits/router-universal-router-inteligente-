export const depValue = 'initial'
