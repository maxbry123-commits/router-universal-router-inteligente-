exports.test = '[cjs ok]'
