self.constant = 'A classic'
