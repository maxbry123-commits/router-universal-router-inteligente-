export { default } from '@/imported'
