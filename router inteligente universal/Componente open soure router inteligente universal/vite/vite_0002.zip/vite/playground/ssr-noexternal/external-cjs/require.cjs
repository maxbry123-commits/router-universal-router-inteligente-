module.exports = 'foo'
