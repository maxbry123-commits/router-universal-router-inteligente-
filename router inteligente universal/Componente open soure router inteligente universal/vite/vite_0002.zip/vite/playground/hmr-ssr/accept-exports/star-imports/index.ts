import './star-imports.ts'
