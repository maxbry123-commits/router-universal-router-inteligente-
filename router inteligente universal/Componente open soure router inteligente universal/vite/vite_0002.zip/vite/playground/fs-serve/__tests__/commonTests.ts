import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import { setTimeout } from 'node:timers/promises'
import { pathToFileURL } from 'node:url'
import type { Page } from 'playwright-chromium'
import {
  afterEach,
  beforeAll,
  beforeEach,
  describe,
  expect,
  test,
} from 'vitest'
import WebSocket from 'ws'
import { browser, isServe, page, viteServer, viteTestUrl } from '~utils'
import { getWindows83ShortNameForDotEnv as getWindows83ShortNameForDotEnv } from '../root/windows83Filename'
import testJSON from '../safe.json'

const getViteTestIndexHtmlUrl = () => {
  const srcPrefix = viteTestUrl.endsWith('/') ? '' : '/'
  // NOTE: viteTestUrl is set lazily
  return viteTestUrl + srcPrefix + 'src/'
}

const safeJsonContent = fs.readFileSync(
  path.resolve(import.meta.dirname, '../safe.json'),
  'utf-8',
)
const stringified = JSON.stringify(testJSON)

beforeAll(async () => {
  await page.goto(getViteTestIndexHtmlUrl())
})

describe.runIf(isServe)('normal', () => {
  test('default import', async () => {
    await expect.poll(() => page.textContent('.full')).toBe(stringified)
  })

  test('named import', async () => {
    await expect.poll(() => page.textContent('.named')).toBe(testJSON.msg)
  })

  test('nested entry', async () => {
    await expect.poll(() => page.textContent('.nested-entry')).toBe('foobar')
  })

  test('virtual svg module', async () => {
    await expect.poll(() => page.textContent('.virtual-svg')).toMatch('<svg')
  })
})

describe.runIf(isServe)('matrix', () => {
  const dotEnvWindows83ShortName = getWindows83ShortNameForDotEnv()

  const variants = [
    { variantId: '', variantName: 'normal' },
    { variantId: '-fs', variantName: '/@fs/' },
  ] as const
  type VariantId = (typeof variants)[number]['variantId']
  const cases: Array<{
    name: string
    testId: string
    content: string | RegExp
    status: string | string[]
    disableVariants?: VariantId[]
    skip?: boolean
    isSPAFallback?: boolean
  }> = [
    {
      name: 'safe fetch',
      testId: 'safe',
      content: /KEY=safe/,
      status: '200',
    },
    {
      name: 'safe fetch with query',
      testId: 'safe-query',
      content: /KEY=safe/,
      status: '200',
    },
    {
      name: 'safe fetch in subdir',
      testId: 'safe-subdir',
      content: /KEY=safe/,
      status: '200',
    },
    {
      name: 'safe fetch with special characters',
      testId: 'safe-subdir-special-characters',
      content: /KEY=safe/,
      status: '200',
    },
    {
      name: 'safe fetch with special characters 2',
      testId: 'safe-subdir-special-characters2',
      content: safeJsonContent,
      status: '200',
    },
    {
      name: 'safe fetch imported',
      testId: 'safe-imported',
      content: safeJsonContent,
      status: '200',
      disableVariants: [''],
    },
    {
      name: 'safe fetch imported with query',
      testId: 'safe-imported-query',
      content: safeJsonContent,
      status: '200',
      disableVariants: [''],
    },

    {
      name: 'unsafe fetch',
      testId: 'unsafe',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe JSON fetch',
      testId: 'unsafe-json',
      content: /403 Restricted/,
      status: '403',
      disableVariants: [''],
    },
    {
      name: 'unsafe HTML fetch',
      testId: 'unsafe-html',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe HTML fetch outside root',
      testId: 'unsafe-html-outside-root',
      content: /403 Restricted/,
      status: '403',
      disableVariants: [''],
    },
    {
      name: 'unsafe fetch with special characters (#8498)',
      testId: 'unsafe-8498',
      content: '',
      status: '404',
    },
    {
      name: 'unsafe fetch with special characters 2 (#8498)',
      testId: 'unsafe-8498-2',
      content: '',
      status: '404',
    },
    {
      name: 'unsafe fetch import inline',
      testId: 'unsafe-import-inline',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe fetch raw query import',
      testId: 'unsafe-raw-query-import',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe fetch raw import raw outside root',
      testId: 'unsafe-raw-import-raw-outside-root',
      content: /403 Restricted/,
      status: '403',
      disableVariants: [''],
    },
    {
      name: 'unsafe fetch raw import raw outside root 1',
      testId: 'unsafe-raw-import-raw-outside-root1',
      content: /403 Restricted/,
      status: '403',
      disableVariants: [''],
    },
    {
      name: 'unsafe fetch raw import raw outside root 2',
      testId: 'unsafe-raw-import-raw-outside-root2',
      content: /403 Restricted/,
      status: '403',
      disableVariants: [''],
    },
    {
      name: 'unsafe fetch with ?url query',
      testId: 'unsafe-url',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe fetch ?.svg?import',
      testId: 'unsafe-query-dot-svg-import',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe fetch .svg?import',
      testId: 'unsafe-svg',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'unsafe fetch import inline wasm init',
      testId: 'unsafe-import-inline-wasm-init',
      content: /403 Restricted/,
      status: '403',
    },
    // It is 404 in `fs-serve/base` test, 403 in `fs-serve` test
    {
      name: 'unsafe fetch with relative path after query',
      testId: 'unsafe-relative-path-after-query',
      content: /403 Restricted|^$/,
      status: ['403', '404'],
      isSPAFallback: true,
    },
    {
      name: 'denied .env',
      testId: 'unsafe-dotenv',
      content: /403 Restricted/,
      status: '403',
    },
    // It is 403 in case insensitive system, 404 in others
    {
      name: 'denied env casing',
      testId: 'unsafe-dotenv-casing',
      content: /403 Restricted|^$/,
      status: ['403', '404'],
    },
    {
      name: 'denied .env with raw query',
      testId: 'unsafe-dotenv-raw',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'denied .env with url query',
      testId: 'unsafe-dotenv-url',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'denied .env with inline query',
      testId: 'unsafe-dotenv-inline',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'denied env with ?.svg?.wasm?init',
      testId: 'unsafe-dotenv-query-dot-svg-wasm-init',
      content: /403 Restricted/,
      status: '403',
    },
    {
      name: 'denied .env with import and raw query',
      testId: 'unsafe-dotenv-import-raw',
      content: /403 Restricted/,
      status: '403',
    },
    // On NTFS, it exposes a file's default data stream through the `::$DATA` suffix,
    // so `.env::$DATA` resolves to the same content as `.env`.
    // It is 404 on non-NTFS.
    {
      name: 'denied .env with NTFS ADS suffix',
      testId: 'unsafe-dotenv-ntfs-ads',
      content: /403 Restricted|^$/,
      status: ['403', '404'],
    },
    // On Windows, the files can be accessed through the 8.3 short name if the feature is enabled.
    // For example, if the short name for `.env` is `ENV~1`, it can be accessed as `ENV~1`.
    {
      name: 'denied .env with 8.3 short name',
      testId: 'unsafe-dotenv-83-short-name',
      content: /403 Restricted/,
      status: '403',
      skip: dotEnvWindows83ShortName === undefined, // skip if 8.3 short name is not available
    },
  ]

  for (const {
    name,
    testId,
    content,
    status,
    disableVariants,
    skip,
    isSPAFallback,
  } of cases) {
    for (const { variantId, variantName } of variants) {
      if (disableVariants?.includes(variantId)) {
        continue
      }

      test.concurrent(
        `${name} (${variantName})`,
        { skip },
        async ({ expect }) => {
          const baseSelector = `.fetch${variantId}-${testId}`
          const actualStatus = expect.poll(() =>
            page.textContent(`${baseSelector}-status`),
          )
          const actualContent = expect.poll(() =>
            page.textContent(`${baseSelector}-content`),
          )

          if (variantName === 'normal' && isSPAFallback) {
            await actualStatus.toBe('200')
            await actualContent.toContain(
              '<h1>FS Serve Matrix Test Summary</h1>',
            )
            return
          }

          if (typeof status === 'string') {
            await actualStatus.toBe(status)
          } else {
            await actualStatus.toBeOneOf(status)
          }

          if (typeof content === 'string') {
            await actualContent.toBe(content)
          } else {
            await actualContent.toMatch(content)
          }
        },
      )
    }
  }
})

describe('fetch', () => {
  test('serve with configured headers', async () => {
    const res = await fetch(viteTestUrl + '/src/')
    expect(res.headers.get('x-served-by')).toBe('vite')
  })
})

describe('cross origin', () => {
  const fetchStatusFromPage = async (page: Page, url: string) => {
    return await page.evaluate(async (url: string) => {
      try {
        const res = await globalThis.fetch(url)
        return res.status
      } catch {
        return -1
      }
    }, url)
  }

  const connectWebSocketFromPage = async (page: Page, url: string) => {
    return await page.evaluate(async (url: string) => {
      try {
        const ws = new globalThis.WebSocket(url, ['vite-hmr'])
        await new Promise<void>((resolve, reject) => {
          ws.addEventListener('open', () => {
            resolve()
            ws.close()
          })
          ws.addEventListener('error', () => {
            reject()
          })
        })
        return true
      } catch {
        return false
      }
    }, url)
  }

  const connectWebSocketFromServer = async (
    url: string,
    host: string,
    origin: string | undefined,
  ) => {
    try {
      const ws = new WebSocket(url, ['vite-hmr'], {
        headers: {
          Host: host,
          ...(origin ? { Origin: origin } : undefined),
        },
      })
      await new Promise<void>((resolve, reject) => {
        ws.addEventListener('open', () => {
          resolve()
          ws.close()
        })
        ws.addEventListener('error', () => {
          reject()
        })
      })
      return true
    } catch {
      return false
    }
  }

  describe('allowed for same origin', () => {
    beforeEach(async () => {
      await page.goto(getViteTestIndexHtmlUrl())
    })

    test('fetch HTML file', async () => {
      const status = await fetchStatusFromPage(page, viteTestUrl + '/src/')
      expect(status).toBe(200)
    })

    test.runIf(isServe)('fetch JS file', async () => {
      const status = await fetchStatusFromPage(
        page,
        viteTestUrl + '/src/code.js',
      )
      expect(status).toBe(200)
    })

    test.runIf(isServe)('connect WebSocket with valid token', async () => {
      const token = viteServer.config.webSocketToken
      const result = await connectWebSocketFromPage(
        page,
        `${viteTestUrl}?token=${token}`,
      )
      expect(result).toBe(true)
    })

    test('fetch with allowed hosts', async () => {
      const viteTestUrlUrl = new URL(viteTestUrl)
      const res = await fetch(viteTestUrl + '/src/index.html', {
        headers: { Host: viteTestUrlUrl.host },
      })
      expect(res.status).toBe(200)
    })

    test.runIf(isServe)(
      'connect WebSocket with valid token with allowed hosts',
      async () => {
        const viteTestUrlUrl = new URL(viteTestUrl)
        const token = viteServer.config.webSocketToken
        const result = await connectWebSocketFromServer(
          `${viteTestUrl}?token=${token}`,
          viteTestUrlUrl.host,
          viteTestUrlUrl.origin,
        )
        expect(result).toBe(true)
      },
    )

    test.runIf(isServe)(
      'connect WebSocket without a token without the origin header',
      async () => {
        const viteTestUrlUrl = new URL(viteTestUrl)
        const result = await connectWebSocketFromServer(
          viteTestUrl,
          viteTestUrlUrl.host,
          undefined,
        )
        expect(result).toBe(true)
      },
    )
  })

  describe('denied for different origin', async () => {
    let page2: Page
    beforeEach(async () => {
      page2 = await browser.newPage()
      // Serve the navigation locally so the tests don't depend on reaching the
      // public `vite.dev` site (flaky from CI runners).
      await page2.route('http://vite.dev/**', (route) =>
        route.fulfill({
          contentType: 'text/html',
          body: '<!doctype html><title>404</title>',
        }),
      )
      await page2.goto('http://vite.dev/404')
    })
    afterEach(async () => {
      await page2.close()
    })

    test('fetch HTML file', async () => {
      const status = await fetchStatusFromPage(page2, viteTestUrl + '/src/')
      expect(status).not.toBe(200)
    })

    test.runIf(isServe)('fetch JS file', async () => {
      const status = await fetchStatusFromPage(
        page2,
        viteTestUrl + '/src/code.js',
      )
      expect(status).not.toBe(200)
    })

    test.runIf(isServe)('connect WebSocket without token', async () => {
      const result = await connectWebSocketFromPage(page, viteTestUrl)
      expect(result).toBe(false)

      const result2 = await connectWebSocketFromPage(
        page,
        `${viteTestUrl}?token=`,
      )
      expect(result2).toBe(false)
    })

    test.runIf(isServe)('connect WebSocket with invalid token', async () => {
      const token = viteServer.config.webSocketToken
      const result = await connectWebSocketFromPage(
        page,
        `${viteTestUrl}?token=${'t'.repeat(token.length)}`,
      )
      expect(result).toBe(false)

      const result2 = await connectWebSocketFromPage(
        page,
        `${viteTestUrl}?token=${'t'.repeat(token.length)}t`, // different length
      )
      expect(result2).toBe(false)
    })

    test('fetch with non-allowed hosts', async () => {
      // NOTE: fetch cannot be used here as `fetch` sets the correct `Host` header
      const res = await new Promise<http.IncomingMessage>((resolve, reject) => {
        http
          .get(
            viteTestUrl + '/src/index.html',
            {
              headers: {
                Host: 'vite.dev',
              },
            },
            (res) => {
              resolve(res)
            },
          )
          .on('error', (e) => {
            reject(e)
          })
      })
      expect(res.statusCode).toBe(403)
    })

    test.runIf(isServe)(
      'connect WebSocket with valid token with non-allowed hosts',
      async () => {
        const token = viteServer.config.webSocketToken
        const result = await connectWebSocketFromServer(
          `${viteTestUrl}?token=${token}`,
          'vite.dev',
          'http://vite.dev',
        )
        expect(result).toBe(false)

        const result2 = await connectWebSocketFromServer(
          `${viteTestUrl}?token=${token}`,
          'vite.dev',
          undefined,
        )
        expect(result2).toBe(false)
      },
    )
  })
})

describe.runIf(isServe)('fetchModule via WebSocket', () => {
  const root = path.resolve(
    import.meta.dirname.replace('playground', 'playground-temp'),
    '..',
  )

  const fetchModuleViaWebSocket = async (filePath: string) => {
    const resolvedPath = path.resolve(root, filePath)
    const token = viteServer.config.webSocketToken
    const wsUrl = viteTestUrl.replace('http', 'ws')
    const ws = new WebSocket(`${wsUrl}?token=${token}`, ['vite-hmr'])

    try {
      return await Promise.race([
        new Promise<any>((resolve, reject) => {
          ws.on('open', () => {
            ws.send(
              JSON.stringify({
                type: 'custom',
                event: 'vite:invoke',
                data: {
                  name: 'fetchModule',
                  id: 'send:1',
                  data: [pathToFileURL(resolvedPath).href],
                },
              }),
            )
          })

          ws.on('message', (raw: Buffer) => {
            const parsed = JSON.parse(raw.toString())
            if (
              parsed.type === 'custom' &&
              parsed.event === 'vite:invoke' &&
              parsed.data?.id === 'response:1'
            ) {
              resolve(parsed.data.data)
            }
          })

          ws.on('error', (err) => {
            reject(err)
          })
        }),
        setTimeout(10_000).then(() =>
          Promise.reject(new Error('WebSocket response timed out')),
        ),
      ])
    } finally {
      ws.close()
    }
  }

  test('should not read files inside allowed directories as fetchModule is disabled', async () => {
    const result = await fetchModuleViaWebSocket('root/src/safe.txt?raw')
    expect(result.result).toBeUndefined()
    expect(result.error).toBeTruthy()
  })

  test('should not read files outside allowed directories', async () => {
    const result = await fetchModuleViaWebSocket('root/unsafe.txt?raw')
    expect(result.result).toBeUndefined()
    expect(result.error).toBeTruthy()
  })
})

describe.runIf(!isServe)('preview HTML', () => {
  test('unsafe HTML fetch', async () => {
    await expect
      .poll(() => page.textContent('.fetch-unsafe-html-status'))
      .toBe('404')
    await expect
      .poll(() => page.textContent('.fetch-unsafe-html-content'))
      .toBe('')
  })
})
