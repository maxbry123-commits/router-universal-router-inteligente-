export default 'browser.js'
