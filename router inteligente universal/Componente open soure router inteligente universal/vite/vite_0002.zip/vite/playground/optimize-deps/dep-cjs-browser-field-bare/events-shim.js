module.exports = {
  foo: 'foo',
}
