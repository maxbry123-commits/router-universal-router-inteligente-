from __future__ import annotations

from .dataset import resolve_ids
from .decorators import save_to_hub_args_decorator
from .distributed import all_gather, all_gather_padded, all_gather_with_grad, get_rank, get_world_size
from .environment import (
    check_package_availability,
    check_version_requirements,
    get_device_name,
    is_accelerate_available,
    is_datasets_available,
    is_dist_initialized,
    is_training_available,
)
from .file_io import disabled_tqdm, http_get, is_sentence_transformer_model, load_dir_path, load_file_path
from .hard_negatives import mine_hard_negatives
from .logging import LoggingHandler, install_logger
from .misc import (
    ORIGINAL_TRANSFORMER_MODELS,
    append_to_last_row,
    check_teacher_targets,
    disable_datasets_caching,
    disable_logging,
    fullname,
    import_from_string,
    import_module_class,
    similarity_fct_name,
)
from .quantization import quantize_embeddings
from .retrieval import (
    community_detection,
    information_retrieval,
    paraphrase_mining,
    paraphrase_mining_embeddings,
    semantic_search,
)
from .similarity import (
    SimilarityFunction,
    cos_sim,
    dot_score,
    euclidean_sim,
    manhattan_sim,
    maxsim,
    maxsim_pairwise,
    mean_maxsim,
    mean_maxsim_pairwise,
    pairwise_angle_sim,
    pairwise_cos_sim,
    pairwise_dot_score,
    pairwise_euclidean_sim,
    pairwise_manhattan_sim,
    pytorch_cos_sim,
)
from .tensor import (
    _convert_to_batch,
    _convert_to_batch_tensor,
    _convert_to_tensor,
    _move_tensors_to_cpu,
    batch_to_device,
    cat_padded_token_embeddings,
    compute_count_vector,
    normalize_embeddings,
    repad_flattened_features,
    select_max_active_dims,
    stack_padded_token_embeddings,
    to_scipy_coo,
    truncate_embeddings,
)

__all__ = [
    # From decorators.py
    "save_to_hub_args_decorator",
    # From distributed.py
    "all_gather",
    "all_gather_padded",
    "all_gather_with_grad",
    "get_rank",
    "get_world_size",
    # From environment.py
    "get_device_name",
    "check_package_availability",
    "check_version_requirements",
    "is_accelerate_available",
    "is_datasets_available",
    "is_dist_initialized",
    "is_training_available",
    # From file_io.py
    "is_sentence_transformer_model",
    "load_dir_path",
    "load_file_path",
    "http_get",
    "disabled_tqdm",
    # From logging.py
    "LoggingHandler",
    "install_logger",
    # From misc.py
    "fullname",
    "similarity_fct_name",
    "check_teacher_targets",
    "import_from_string",
    "import_module_class",
    "disable_datasets_caching",
    "disable_logging",
    "append_to_last_row",
    "ORIGINAL_TRANSFORMER_MODELS",
    # From retrieval.py
    "community_detection",
    "information_retrieval",
    "paraphrase_mining",
    "paraphrase_mining_embeddings",
    "semantic_search",
    # From quantization.py
    "quantize_embeddings",
    # From similarity.py
    "SimilarityFunction",
    "cos_sim",
    "dot_score",
    "euclidean_sim",
    "manhattan_sim",
    "maxsim",
    "maxsim_pairwise",
    "mean_maxsim",
    "mean_maxsim_pairwise",
    "pairwise_angle_sim",
    "pairwise_cos_sim",
    "pairwise_dot_score",
    "pairwise_euclidean_sim",
    "pairwise_manhattan_sim",
    "pytorch_cos_sim",
    # From tensor.py
    "_convert_to_batch",
    "_convert_to_batch_tensor",
    "_convert_to_tensor",
    "_move_tensors_to_cpu",
    "batch_to_device",
    "cat_padded_token_embeddings",
    "compute_count_vector",
    "normalize_embeddings",
    "repad_flattened_features",
    "select_max_active_dims",
    "stack_padded_token_embeddings",
    "to_scipy_coo",
    "truncate_embeddings",
    # From hard_negatives.py
    "mine_hard_negatives",
    # From dataset.py
    "resolve_ids",
]
