"""Tests for the V2 ``OpenTelemetryV2`` CustomLogger adapter.

Exercises the callback surface the existing call sites use: the LLM-call span
opened at the ``pre_call`` boundary and closed at async success/failure, service
hooks, proxy SERVER span lifecycle (start + setters), parent-context resolution
(ambient context), and Baggage promotion onto child spans.
"""

import asyncio
import contextlib
import os
from unittest.mock import patch
from datetime import datetime, timedelta, timezone

import pytest

pytest.importorskip("opentelemetry")

from opentelemetry import trace  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)
from opentelemetry.trace import SpanKind  # noqa: E402
from opentelemetry.trace.status import StatusCode  # noqa: E402

from litellm.integrations.otel import (  # noqa: E402
    GenAI,
    LiteLLM,
    OpenTelemetryV2Config,
)
from litellm.integrations.otel.plumbing import providers  # noqa: E402
from litellm.integrations.otel.plumbing.context import (  # noqa: E402
    reset_mcp_message_trace_carrier,
    reset_mcp_message_transport_span,
    set_mcp_message_trace_carrier,
    set_mcp_message_transport_span,
    set_request_root_span,
)
from litellm.integrations.otel.logger import OpenTelemetryV2  # noqa: E402
from litellm.integrations.otel.model.config import ExporterSpec  # noqa: E402
from litellm.integrations.otel.model.spans import (  # noqa: E402
    LITELLM_PROXY_REQUEST_SPAN_NAME,
    SpanRole,
)
from litellm.integrations.otel.model.utils import to_ns, to_seconds  # noqa: E402

# --------------------------------------------------------------------------- #
#  Fixtures
# --------------------------------------------------------------------------- #


@pytest.fixture(autouse=True)
def _reset_request_root_span():
    """Clear the request-root-span anchor around every test.

    In production each request runs in its own asyncio task whose context is a
    fresh copy, so the anchor never leaks between requests. The test process
    shares one context, so reset it explicitly to keep tests order-independent.
    """
    from litellm.integrations.otel.plumbing import context as _otel_context

    _otel_context._request_root_span.set(None)
    _otel_context._mcp_message_trace_carrier.set(None)
    _otel_context._mcp_message_transport_span.set(None)
    yield
    _otel_context._request_root_span.set(None)
    _otel_context._mcp_message_trace_carrier.set(None)
    _otel_context._mcp_message_transport_span.set(None)


def _payload(**overrides):
    payload = {
        "call_type": "acompletion",
        "custom_llm_provider": "openai",
        "model": "gpt-4o",
        "prompt_tokens": 10,
        "completion_tokens": 5,
        "total_tokens": 15,
        "stream": False,
        "model_parameters": {"temperature": 0.7, "max_tokens": 256},
        "response": {
            "id": "resp_1",
            "model": "gpt-4o-2024",
            "choices": [{"finish_reason": "stop"}],
        },
        "metadata": {
            "team_id": "t1",
            "team_alias": "team one",
            "user_api_key_hash": "hsh",
        },
        "api_base": "https://api.openai.com:443/v1",
        "status": "success",
        "litellm_call_id": "call_1",
        "response_cost": 0.002,
        "hidden_params": {},
    }
    payload.update(overrides)
    return payload


def _kwargs(payload=None):
    return {
        # ``litellm_call_id`` (here carried inside the payload) correlates the
        # pre_call boundary with the close callback — the carrier is keyed by it.
        "standard_logging_object": payload if payload is not None else _payload(),
        "litellm_params": {"metadata": {}},
    }


def _logger(legacy_compat=True, team_metadata_keys=None):
    cfg = OpenTelemetryV2Config(
        exporter="in_memory",
        legacy_compat=legacy_compat,
        baggage_team_metadata_keys=team_metadata_keys or [],
    )
    exporter = InMemorySpanExporter()
    tracer_provider = providers.build_tracer_provider(cfg, exporter=exporter)
    return OpenTelemetryV2(config=cfg, tracer_provider=tracer_provider), exporter


def _emit_llm(logger, kwargs=None, *, ambient=None, fail=False):
    """Drive the real boundary flow: open at ``pre_call`` then close at the async
    callback. ``ambient``, if given, is the span that is the active OTel context
    while ``pre_call`` runs (the server span) so the LLM span parents to it."""
    if kwargs is None:
        kwargs = _kwargs()
    payload = kwargs.get("standard_logging_object") or {}
    with (
        trace.use_span(ambient, end_on_exit=False)
        if ambient is not None
        else contextlib.nullcontext()
    ):
        logger.log_pre_api_call(model=payload.get("model"), messages=[], kwargs=kwargs)
    hook = logger.async_log_failure_event if fail else logger.async_log_success_event
    asyncio.run(hook(kwargs, None, None, None))
    return kwargs


# --------------------------------------------------------------------------- #
#  Time helpers
# --------------------------------------------------------------------------- #


def test_to_ns_handles_datetime_and_float():
    dt = datetime(2026, 5, 26, 12, 0, 0, tzinfo=timezone.utc)
    assert to_ns(dt) == int(dt.timestamp() * 1e9)
    assert to_ns(1.5) == 1_500_000_000
    assert to_ns(None) is None
    assert to_ns(True) is None  # bool is rejected — not a real epoch value


def test_to_seconds_parses_string_formats():
    assert to_seconds("2026-05-26 12:00:00.123") is not None
    assert to_seconds("2026-05-26 12:00:00") is not None
    assert to_seconds("nonsense") is None
    assert to_seconds(None) is None
    assert to_seconds(1.5) == 1.5


# --------------------------------------------------------------------------- #
#  LLM-call callbacks
# --------------------------------------------------------------------------- #


def test_async_log_success_event_emits_llm_call_span():
    logger, exporter = _logger()
    _emit_llm(logger)
    (span,) = exporter.get_finished_spans()
    assert span.name == "chat gpt-4o"
    assert span.kind is SpanKind.CLIENT
    assert span.attributes[GenAI.OPERATION_NAME] == "chat"
    assert span.attributes[GenAI.REQUEST_MODEL] == "gpt-4o"
    assert span.attributes[LiteLLM.CALL_ID] == "call_1"
    # Success leaves status UNSET (semconv default), not forced OK.
    assert span.status.status_code is StatusCode.UNSET


def test_streaming_span_carries_time_to_first_chunk():
    logger, exporter = _logger()
    kwargs = {
        **_kwargs(payload=_payload(stream=True)),
        "optional_params": {"stream": True},
        "api_call_start_time": datetime(2026, 5, 26, 12, 0, 0, tzinfo=timezone.utc),
        "completion_start_time": datetime(2026, 5, 26, 12, 0, 0, 750000, tzinfo=timezone.utc),
    }
    _emit_llm(logger, kwargs)
    (span,) = exporter.get_finished_spans()
    assert span.attributes[GenAI.RESPONSE_TIME_TO_FIRST_CHUNK] == pytest.approx(0.75)


def test_non_streaming_span_has_no_time_to_first_chunk():
    logger, exporter = _logger()
    kwargs = {
        **_kwargs(),
        "optional_params": {},
        "api_call_start_time": datetime(2026, 5, 26, 12, 0, 0, tzinfo=timezone.utc),
        "completion_start_time": datetime(2026, 5, 26, 12, 0, 5, tzinfo=timezone.utc),
    }
    _emit_llm(logger, kwargs)
    (span,) = exporter.get_finished_spans()
    assert GenAI.RESPONSE_TIME_TO_FIRST_CHUNK not in span.attributes


def test_streaming_span_without_timing_omits_time_to_first_chunk():
    logger, exporter = _logger()
    kwargs = {
        **_kwargs(payload=_payload(stream=True)),
        "optional_params": {"stream": True},
    }
    _emit_llm(logger, kwargs)
    (span,) = exporter.get_finished_spans()
    assert GenAI.RESPONSE_TIME_TO_FIRST_CHUNK not in span.attributes


def test_async_log_failure_event_marks_error_status():
    logger, exporter = _logger()
    payload = _payload(
        status="failure",
        error_information={"error_class": "RateLimitError", "error_message": "429"},
    )
    _emit_llm(logger, _kwargs(payload=payload), fail=True)
    (span,) = exporter.get_finished_spans()
    assert span.status.status_code is StatusCode.ERROR
    assert span.attributes["error.type"] == "RateLimitError"


def _logger_with_events(enable_events):
    from opentelemetry.sdk._logs.export import InMemoryLogExporter

    cfg = OpenTelemetryV2Config(exporter="in_memory", enable_events=enable_events)
    span_exporter = InMemorySpanExporter()
    tracer_provider = providers.build_tracer_provider(cfg, exporter=span_exporter)
    log_exporter = InMemoryLogExporter()
    logger_provider = providers.build_logger_provider(cfg, log_exporter=log_exporter)
    logger = OpenTelemetryV2(config=cfg, tracer_provider=tracer_provider, logger_provider=logger_provider)
    return logger, span_exporter, log_exporter


def test_enable_events_records_operation_exception_through_failure_callback():
    """With ``enable_events`` on, a real failure callback records the GenAI
    ``gen_ai.client.operation.exception`` log event, carrying the traceback from
    the standard logging payload and correlated to the LLM-call span."""
    from litellm.integrations.otel.model.semconv import ExceptionEvent, GenAIEvent

    logger, span_exporter, log_exporter = _logger_with_events(enable_events=True)
    payload = _payload(
        status="failure",
        error_information={
            "error_class": "RateLimitError",
            "error_message": "429 rate limited",
            "traceback": "Traceback (most recent call last) ...",
        },
    )
    _emit_llm(logger, _kwargs(payload=payload), fail=True)

    (span,) = span_exporter.get_finished_spans()
    (log,) = log_exporter.get_finished_logs()
    record = log.log_record
    assert record.attributes["event.name"] == GenAIEvent.OPERATION_EXCEPTION
    assert record.attributes[ExceptionEvent.TYPE] == "RateLimitError"
    assert record.attributes[ExceptionEvent.MESSAGE] == "429 rate limited"
    assert record.attributes[ExceptionEvent.STACKTRACE] == "Traceback (most recent call last) ..."
    assert record.trace_id == span.context.trace_id
    assert record.span_id == span.context.span_id


def test_events_off_by_default_records_no_log_event_on_failure():
    """``enable_events`` defaults to off: even with a logs pipeline injected, a
    failure records only the span-side error surface, no log event."""
    logger, span_exporter, log_exporter = _logger_with_events(enable_events=False)
    payload = _payload(
        status="failure",
        error_information={"error_class": "RateLimitError", "error_message": "429"},
    )
    _emit_llm(logger, _kwargs(payload=payload), fail=True)

    assert len(span_exporter.get_finished_spans()) == 1
    assert log_exporter.get_finished_logs() == ()
    assert OpenTelemetryV2Config(exporter="in_memory").enable_events is False


def test_sync_log_event_is_noop():
    """V2 closes the span async-only; the sync callback runs out-of-context, so
    it no-ops (the span stays open on the carrier until the async callback)."""
    logger, exporter = _logger()
    kwargs = _kwargs()
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    logger.log_success_event(kwargs, None, None, None)
    logger.log_failure_event(kwargs, None, None, None)
    assert exporter.get_finished_spans() == ()


def test_missing_standard_logging_object_is_noop():
    """No carrier (``pre_call`` never ran) → the callback emits nothing."""
    logger, exporter = _logger()
    asyncio.run(
        logger.async_log_success_event({"litellm_params": {}}, None, None, None)
    )
    assert exporter.get_finished_spans() == ()


def test_no_span_when_pre_call_never_ran():
    """A request rejected before the upstream call — at the auth/budget gate, or
    blocked by a pre-call guardrail — never reaches ``pre_call``, so there is no
    carrier and the failure log produces no phantom CLIENT span. This replaces the
    old post-hoc heuristics: "did pre_call run?" is the only signal needed."""
    logger, exporter = _logger()
    payload = _payload(
        status="failure",
        error_information={"error_class": "ProxyException", "error_code": "401"},
    )
    # No log_pre_api_call: the call never started.
    asyncio.run(
        logger.async_log_failure_event(_kwargs(payload=payload), None, None, None)
    )
    assert exporter.get_finished_spans() == ()  # no phantom LLM span


def test_real_llm_failure_still_emitted():
    """A genuine LLM failure: ``pre_call`` ran (the call was attempted), so the
    CLIENT span is opened at the boundary and closed ERROR."""
    logger, exporter = _logger()
    payload = _payload(
        status="failure",
        error_information={"error_class": "RateLimitError", "error_code": "429"},
    )
    _emit_llm(logger, _kwargs(payload=payload), fail=True)
    (span,) = exporter.get_finished_spans()
    assert span.name == "chat gpt-4o"
    assert span.status.status_code is StatusCode.ERROR


def test_provider_auth_failure_span_carries_stack_trace():
    """Regression for LIT-6163: a 401 the provider returned is not an expected
    client error, so the error span built from the real failure payload keeps
    ``litellm.provider.error.stack_trace`` alongside code and llm_provider."""
    from litellm.exceptions import AuthenticationError
    from litellm.litellm_core_utils.litellm_logging import StandardLoggingPayloadSetup

    try:
        raise AuthenticationError(
            message="AnthropicException - API key is invalid.", llm_provider="anthropic", model="claude-haiku-4-5"
        )
    except AuthenticationError as caught:
        error_information = StandardLoggingPayloadSetup.get_error_information(caught)
    logger, exporter = _logger()
    payload = _payload(status="failure", custom_llm_provider="anthropic", error_information=error_information)
    _emit_llm(logger, _kwargs(payload=payload), fail=True)
    (span,) = exporter.get_finished_spans()
    assert span.status.status_code is StatusCode.ERROR
    assert span.attributes["error.type"] == "AuthenticationError"
    assert span.attributes["litellm.provider.error.code"] == "401"
    assert span.attributes["litellm.provider.error.llm_provider"] == "anthropic"
    assert "test_otel_v2_logger" in span.attributes["litellm.provider.error.stack_trace"]


def test_unmapped_provider_auth_failure_span_carries_stack_trace():
    """Regression for LIT-6163 on /v1/messages: that route logs the provider's
    raw exception (no llm_provider), and its error span keeps the stack trace."""
    from litellm.litellm_core_utils.litellm_logging import StandardLoggingPayloadSetup
    from litellm.llms.anthropic.common_utils import AnthropicError

    try:
        raise AnthropicError(status_code=401, message='{"type":"authentication_error","message":"API key is invalid."}')
    except AnthropicError as caught:
        error_information = StandardLoggingPayloadSetup.get_error_information(caught)
    logger, exporter = _logger()
    payload = _payload(status="failure", custom_llm_provider="anthropic", error_information=error_information)
    _emit_llm(logger, _kwargs(payload=payload), fail=True)
    (span,) = exporter.get_finished_spans()
    assert span.status.status_code is StatusCode.ERROR
    assert span.attributes["error.type"] == "AnthropicError"
    assert span.attributes["litellm.provider.error.code"] == "401"
    assert "test_otel_v2_logger" in span.attributes["litellm.provider.error.stack_trace"]


def test_idempotent_on_repeat_callback():
    """The carrier is the dedup: once the async callback closes the span and
    clears the carrier, a second callback firing emits nothing."""
    logger, exporter = _logger()
    kwargs = _kwargs()
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    assert len(exporter.get_finished_spans()) == 1


def test_evicted_carrier_completed_call_emits_one_deferred_span():
    """Eviction over the concurrency budget drops only the boundary carrier, not
    the call. When an evicted call later closes as a real completed call
    (``upstream_started``, payload present) it still emits exactly one span
    through the deferred branch, and a second close for the same id dedups. Only
    an evicted call that never closes goes unexported."""
    logger, exporter = _logger()
    kwargs = {**_kwargs(), "api_call_start_time": datetime(2026, 5, 26, 12, 0, 0, tzinfo=timezone.utc)}
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    assert "call_1" in logger._open_llm_calls

    # Evict exactly as ``_store_open_call`` does over budget: drop the oldest
    # carrier and release its routed provider.
    _, evicted = logger._open_llm_calls.popitem(last=False)
    logger._release_carrier(evicted)
    assert not logger._open_llm_calls
    assert exporter.get_finished_spans() == ()  # the evicted boundary span is never exported

    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    spans = exporter.get_finished_spans()
    assert len(spans) == 1, "the evicted call's real close re-emits one deferred span, not zero"
    assert spans[0].name == "chat gpt-4o"
    assert spans[0].attributes[LiteLLM.CALL_ID] == "call_1"

    # Success-then-failure on one logging object: the deferred branch dedups by id.
    asyncio.run(logger.async_log_failure_event(kwargs, None, None, None))
    assert len(exporter.get_finished_spans()) == 1, "second close for the same id must not duplicate"


# --------------------------------------------------------------------------- #
#  MCP tool-call spans
# --------------------------------------------------------------------------- #


def _mcp_payload(**overrides):
    payload = {
        "call_type": "call_mcp_tool",
        "status": "success",
        "litellm_call_id": "mcp_1",
        "response_cost": 0.01,
        "metadata": {
            "user_api_key_team_id": "t1",
            "mcp_tool_call_metadata": {
                "name": "get_weather",
                "arguments": {"city": "Paris"},
                "result": {"temp_c": 21},
                "mcp_server_name": "weather-mcp",
                "mcp_server_resource": "https://weather.example.com",
                "mcp_session_id": "sess-abc123",
            },
        },
        "hidden_params": {},
    }
    payload.update(overrides)
    return payload


def _logger_capturing():
    from litellm.integrations.otel.model.config import CaptureMessageContent

    cfg = OpenTelemetryV2Config(
        exporter="in_memory",
        legacy_compat=False,
        capture_message_content=CaptureMessageContent.SPAN_ONLY,
    )
    exporter = InMemorySpanExporter()
    tracer_provider = providers.build_tracer_provider(cfg, exporter=exporter)
    return OpenTelemetryV2(config=cfg, tracer_provider=tracer_provider), exporter


def test_mcp_tool_call_emits_client_span():
    """A closed MCP tool call becomes a CLIENT span named ``tools/call {tool}``,
    carrying the MCP semconv method/operation and the vendor server name."""
    logger, exporter = _logger()
    kwargs = {"standard_logging_object": _mcp_payload()}
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    (span,) = exporter.get_finished_spans()
    assert span.name == "tools/call get_weather"
    assert span.kind is SpanKind.CLIENT
    assert span.attributes["mcp.method.name"] == "tools/call"
    assert span.attributes["mcp.session.id"] == "sess-abc123"
    assert span.attributes[GenAI.OPERATION_NAME] == "execute_tool"
    assert span.attributes["gen_ai.tool.name"] == "get_weather"
    assert span.attributes[LiteLLM.MCP_SERVER_NAME] == "weather-mcp"
    assert span.attributes[LiteLLM.CALL_ID] == "mcp_1"
    assert span.status.status_code is StatusCode.UNSET
    # Tool I/O is content: withheld while capture is off (the default).
    assert "gen_ai.tool.call.arguments" not in span.attributes
    assert "gen_ai.tool.call.result" not in span.attributes


def test_mcp_tool_call_stateless_omits_session_id():
    """A stateless MCP call carries no ``mcp-session-id``, so the span must omit
    ``mcp.session.id`` rather than stamping an empty or ``None`` value."""
    logger, exporter = _logger()
    payload = _mcp_payload()
    del payload["metadata"]["mcp_tool_call_metadata"]["mcp_session_id"]
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": payload}, None, None, None
        )
    )
    (span,) = exporter.get_finished_spans()
    assert "mcp.session.id" not in span.attributes
    assert span.attributes["mcp.method.name"] == "tools/call"


def test_mcp_tool_call_is_not_logged_as_llm_call():
    """The MCP branch must short-circuit the LLM-call path: even if ``pre_call``
    opened a stray carrier for this id, the result is one MCP span, never an LLM
    ``chat`` span."""
    logger, exporter = _logger()
    kwargs = {"standard_logging_object": _mcp_payload()}
    logger.log_pre_api_call(model="MCP: get_weather", messages=[], kwargs=kwargs)
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    (span,) = exporter.get_finished_spans()
    assert span.attributes["mcp.method.name"] == "tools/call"
    assert "gen_ai.request.model" not in span.attributes


def test_mcp_tool_call_captures_io_when_enabled():
    logger, exporter = _logger_capturing()
    kwargs = {"standard_logging_object": _mcp_payload()}
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    (span,) = exporter.get_finished_spans()
    assert '"Paris"' in span.attributes["gen_ai.tool.call.arguments"]
    assert "21" in span.attributes["gen_ai.tool.call.result"]


def test_mcp_tool_call_failure_marks_error():
    logger, exporter = _logger()
    payload = _mcp_payload(
        status="failure",
        error_information={"error_class": "MCPError", "error_message": "upstream 500"},
    )
    asyncio.run(
        logger.async_log_failure_event(
            {"standard_logging_object": payload}, None, None, None
        )
    )
    (span,) = exporter.get_finished_spans()
    assert span.name == "tools/call get_weather"
    assert span.status.status_code is StatusCode.ERROR
    assert span.attributes["error.type"] == "MCPError"
    assert span.attributes["rpc.system"] == "jsonrpc"
    assert span.attributes["server.address"] == "weather.example.com"


def test_mcp_tool_call_deduped_on_repeat():
    logger, exporter = _logger()
    kwargs = {"standard_logging_object": _mcp_payload()}
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    assert len(exporter.get_finished_spans()) == 1


def test_mcp_tool_call_metadata_read_from_nested_metadata_not_top_level():
    """``mcp_tool_call_metadata`` lives under ``StandardLoggingPayload.metadata``;
    a top-level copy (the pre-fix shape the reader used to look at) must be ignored
    so the reader can't silently regress to producing an empty ``tools/call`` span
    with no session id, tool name, or server name."""
    logger, exporter = _logger()
    payload = _mcp_payload()
    # Move the real metadata to the top level only, mirroring the old buggy read
    # location. ``call_type`` still classifies this as an MCP call, so the span is
    # emitted, but none of its fields are reachable from the wrong nesting level.
    payload["mcp_tool_call_metadata"] = payload["metadata"].pop(
        "mcp_tool_call_metadata"
    )
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": payload}, None, None, None
        )
    )
    (span,) = exporter.get_finished_spans()
    assert span.name == "tools/call"
    assert "mcp.session.id" not in span.attributes
    assert "gen_ai.tool.name" not in span.attributes
    assert LiteLLM.MCP_SERVER_NAME not in span.attributes


def _mcp_list_payload(**overrides):
    payload = {
        "call_type": "list_mcp_tools",
        "status": "success",
        "litellm_call_id": "mcp_list_1",
        "metadata": {
            "user_api_key_team_id": "t1",
            "spend_logs_metadata": {"mcp_operation": "list_tools"},
        },
        "hidden_params": {},
    }
    payload.update(overrides)
    return payload


def test_mcp_list_tools_emits_client_span():
    """An MCP ``tools/list`` discovery call becomes a CLIENT span named ``tools/list``,
    carrying only the MCP method and the call id. Per the GenAI MCP semconv the list
    span omits ``gen_ai.operation.name`` and ``gen_ai.tool.name`` (tool-call-only) and
    ``mcp.session.id`` (the list path threads no session id), so a naive reuse of the
    tool-call mapper would wrongly stamp them, and the pre-fix code emitted no span at
    all for a ``list_mcp_tools`` payload."""
    logger, exporter = _logger()
    kwargs = {"standard_logging_object": _mcp_list_payload()}
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    (span,) = exporter.get_finished_spans()
    assert span.name == "tools/list"
    assert span.kind is SpanKind.CLIENT
    assert span.attributes["mcp.method.name"] == "tools/list"
    assert span.attributes[LiteLLM.CALL_ID] == "mcp_list_1"
    assert span.status.status_code is StatusCode.UNSET
    # Bug-killers: no span pre-fix (empty exporter -> the unpack above raises), and a
    # tool-call-shaped fix would leak execute_tool / tool name / session id here.
    assert GenAI.OPERATION_NAME not in span.attributes
    assert "gen_ai.tool.name" not in span.attributes
    assert "mcp.session.id" not in span.attributes


_MCP_SPAN_CASES = [
    (_mcp_payload, "tools/call get_weather"),
    (_mcp_list_payload, "tools/list"),
]


def test_mcp_tool_call_names_its_rpc_system_and_upstream():
    """A tool-call span names the RPC system, and always alongside the upstream it called.

    A CLIENT span holding none of the ``rpc.*``/``http.*``/``db.*``/``messaging.*``
    families is unclassifiable, so a backend deriving a span type from them has nothing
    to derive from: Elastic APM indexed these spans as ``span.type=unknown`` with no
    ``span.subtype`` at all, and its span-links API then rejected the whole trace with
    ``Missing required fields (span.subtype)``.

    The two assertions are one invariant, not two. Naming the RPC system makes a
    consumer treat the span as a downstream dependency and key that dependency off
    ``server.address``/``server.port``; emitting the first without the second names the
    dependency ``:0``, which is worse than leaving the span unclassified.
    """
    logger, exporter = _logger()
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": _mcp_payload()}, None, None, None
        )
    )
    (span,) = exporter.get_finished_spans()
    assert span.attributes["rpc.system"] == "jsonrpc"
    assert span.attributes["server.address"] == "weather.example.com"
    assert span.attributes["server.port"] == 443


@pytest.mark.parametrize(
    "resource",
    [None, "mcp://weather.example.com", "ws://weather.example.com"],
    ids=["no-resource", "scheme-with-no-default-port", "ws-scheme"],
)
def test_mcp_tool_call_omits_rpc_system_without_a_complete_upstream(resource):
    """A tool call drops the RPC system unless the full destination resolved.

    ``mcp_server_resource`` is absent whenever the tool name resolves to no registered
    server, and it is ``None`` for a transport with no host to log at all (stdio). A
    host-bearing scheme outside the HTTP(S) default-port map resolves an address but no
    port, and the ``url`` field is not scheme-validated, so that state is reachable from
    config. Each case names the dependency ``:0`` or ``host:0`` if ``rpc.system`` ships
    on its own, so the pairing is enforced here rather than left to the extractors
    happening to agree.
    """
    logger, exporter = _logger()
    payload = _mcp_payload()
    if resource is None:
        del payload["metadata"]["mcp_tool_call_metadata"]["mcp_server_resource"]
    else:
        payload["metadata"]["mcp_tool_call_metadata"]["mcp_server_resource"] = resource
    asyncio.run(
        logger.async_log_success_event({"standard_logging_object": payload}, None, None, None)
    )
    (span,) = exporter.get_finished_spans()
    assert "rpc.system" not in span.attributes
    assert "server.port" not in span.attributes
    assert span.attributes["mcp.method.name"] == "tools/call"


def test_mcp_list_tools_omits_rpc_system_without_an_upstream():
    """The discovery span carries no upstream identity, so it must not claim to be RPC.

    ``tools/list`` reaches the callbacks with no ``mcp_tool_call_metadata``, so there is
    no ``server.address`` to attach and a listing can span several upstreams anyway.
    Naming ``rpc.system`` here would buy a ``span.subtype`` at the cost of a bogus ``:0``
    dependency node in every consumer that aggregates on it.
    """
    logger, exporter = _logger()
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": _mcp_list_payload()}, None, None, None
        )
    )
    (span,) = exporter.get_finished_spans()
    assert "rpc.system" not in span.attributes
    assert "server.address" not in span.attributes


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_nests_under_transport_without_propagated_context(
    make_payload, span_name
):
    """Almost no MCP client implements SEP-414, so ``params._meta`` normally carries
    no trace context. Rooting the span there split one tool call into two traces
    joined only by a link, which is how it surfaced in APM: the ``POST`` transaction
    and the ``tools/call`` span shared no ``trace_id``. With no remote parent to
    honor the span nests under the transport span instead, and records no link since
    the transport is now the real parent."""
    logger, exporter = _logger()
    transport = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(transport)
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": make_payload()}, None, None, None
        )
    )
    transport.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    assert span.parent is not None
    assert span.parent.span_id == transport.get_span_context().span_id
    assert span.context.trace_id == transport.get_span_context().trace_id
    assert span.links == ()


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_nests_under_this_messages_transport_not_the_session_opener(
    make_payload, span_name
):
    """A *stateful* streamable-HTTP session runs every message on the single task
    spawned by that session's ``initialize`` POST, so the ``_request_root_span``
    ContextVar the ASGI request task writes is frozen at ``initialize`` inside the
    handler and never sees the later ``tools/call`` POST. Nesting on that anchor
    would hang every tool call of the session off the first request's (already
    ended) span, rendering skewed at the session's start. The gateway resolves the
    current message's transport on the request task and publishes it, so the span
    parents to the POST that actually carried this message."""
    logger, exporter = _logger()
    session_opener = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    this_message = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )

    async def session_task():
        token = set_mcp_message_transport_span(this_message)
        try:
            await logger.async_log_success_event(
                {"standard_logging_object": make_payload()}, None, None, None
            )
        finally:
            reset_mcp_message_transport_span(token)

    async def initialize_request():
        # The anchor the session task inherits is the one ``initialize`` left behind;
        # spawning here reproduces the SDK's session task, which outlives this request.
        set_request_root_span(session_opener)
        await asyncio.create_task(session_task())

    asyncio.run(initialize_request())
    session_opener.end()
    this_message.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    assert span.parent is not None
    assert span.parent.span_id == this_message.get_span_context().span_id
    assert span.context.trace_id == this_message.get_span_context().trace_id
    assert span.parent.span_id != session_opener.get_span_context().span_id
    assert span.context.trace_id != session_opener.get_span_context().trace_id


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_roots_without_transport_or_propagated_context(
    make_payload, span_name
):
    """With neither a remote parent nor a transport span there is nothing to nest
    under, so the span legitimately starts its own root trace with no links."""
    logger, exporter = _logger()
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": make_payload()}, None, None, None
        )
    )
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    assert span.parent is None
    assert span.links == ()


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_links_propagated_meta_trace_context_and_nests_under_transport(
    make_payload, span_name
):
    """When the client propagates W3C trace context in the request's
    ``params._meta`` (SEP-414), the MCP span still nests under the gateway's own
    transport span — one renderable trace — and records the client's context as a
    span *link*. Parenting to the remote context instead would root the span in a
    trace whose root span never reaches the gateway's tracing backend, leaving the
    span unreachable from the trace view."""
    logger, exporter = _logger()
    transport = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(transport)
    token = set_mcp_message_trace_carrier(
        {"traceparent": "00-11111111111111111111111111111111-2222222222222222-01"}
    )
    try:
        asyncio.run(
            logger.async_log_success_event(
                {"standard_logging_object": make_payload()}, None, None, None
            )
        )
    finally:
        reset_mcp_message_trace_carrier(token)
    transport.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    assert span.parent is not None
    assert span.parent.span_id == transport.get_span_context().span_id
    assert span.context.trace_id == transport.get_span_context().trace_id
    assert [link.context.trace_id for link in span.links] == [
        0x11111111111111111111111111111111
    ]
    assert [link.context.span_id for link in span.links] == [0x2222222222222222]


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_without_transport_roots_and_links_propagated_context(
    make_payload, span_name
):
    """With no transport span at all there is nothing of the gateway's to anchor
    to, so the span starts its own root trace — and the client context stays a
    span link there too, so the event keeps one shape everywhere."""
    logger, exporter = _logger()
    token = set_mcp_message_trace_carrier(
        {"traceparent": "00-11111111111111111111111111111111-2222222222222222-01"}
    )
    try:
        asyncio.run(
            logger.async_log_success_event(
                {"standard_logging_object": make_payload()}, None, None, None
            )
        )
    finally:
        reset_mcp_message_trace_carrier(token)
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    assert span.parent is None
    assert span.context.trace_id != 0x11111111111111111111111111111111
    assert [link.context.span_id for link in span.links] == [0x2222222222222222]


def test_mcp_span_links_unsampled_client_traceparent():
    """A client traceparent with the sampled flag off ('-00') still yields a valid
    remote context, so the link is recorded; the span's own recording follows the
    transport's sampling decision, never the client's flag."""
    logger, exporter = _logger()
    transport = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(transport)
    token = set_mcp_message_trace_carrier(
        {"traceparent": "00-11111111111111111111111111111111-2222222222222222-00"}
    )
    try:
        asyncio.run(
            logger.async_log_success_event(
                {"standard_logging_object": _mcp_list_payload()}, None, None, None
            )
        )
    finally:
        reset_mcp_message_trace_carrier(token)
    transport.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == "tools/list")
    assert span.parent is not None
    assert span.parent.span_id == transport.get_span_context().span_id
    assert [link.context.span_id for link in span.links] == [0x2222222222222222]


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_ignores_client_supplied_baggage(make_payload, span_name):
    """The MCP span must NOT honor W3C Baggage from the client's ``params._meta``.

    ``params._meta`` is caller-controlled and the baggage processor stamps
    allowlisted baggage keys onto every span, so extracting remote baggage would
    let a client spoof a span's identity (e.g. ``litellm.team.id``). The propagator
    extracts trace context only, so the spoofed keys never reach the span while the
    legitimate traceparent parenting still works."""
    logger, exporter = _logger()
    transport = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(transport)
    token = set_mcp_message_trace_carrier(
        {
            "traceparent": "00-11111111111111111111111111111111-2222222222222222-01",
            "baggage": "litellm.team.id=spoofed-team,litellm.metadata.user_api_key_user_id=attacker",
        }
    )
    try:
        asyncio.run(
            logger.async_log_success_event(
                {"standard_logging_object": make_payload()}, None, None, None
            )
        )
    finally:
        reset_mcp_message_trace_carrier(token)
    transport.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    # Trace context still honored (as a link): proves the carrier was processed,
    # not dropped wholesale.
    assert [link.context.span_id for link in span.links] == [0x2222222222222222]
    assert span.parent is not None
    assert span.parent.span_id == transport.get_span_context().span_id
    # Identity is the authenticated payload's team, never the client's spoofed value.
    assert span.attributes[LiteLLM.TEAM_ID] == "t1"
    assert "litellm.metadata.user_api_key_user_id" not in span.attributes


@pytest.mark.parametrize("make_payload, span_name", _MCP_SPAN_CASES)
def test_mcp_span_carries_authenticated_identity(make_payload, span_name):
    """An MCP span is labeled with the authenticated request's identity (team/key),
    seeded from the parsed payload like the LLM-call span. Without this seeding the
    span — parented to an empty remote context — would carry no team/key attribute at
    all, so it couldn't be attributed or filtered by team in the traces backend."""
    logger, exporter = _logger()
    asyncio.run(
        logger.async_log_success_event(
            {"standard_logging_object": make_payload()}, None, None, None
        )
    )
    span = next(s for s in exporter.get_finished_spans() if s.name == span_name)
    assert span.attributes[LiteLLM.TEAM_ID] == "t1"


def test_mcp_span_malformed_traceparent_nests_under_transport():
    """A malformed traceparent in ``params._meta`` must not crash or parent to a
    bogus span: the propagator ignores it, leaving no remote parent, so the span
    falls back to nesting under the transport span rather than starting a
    disconnected root trace."""
    logger, exporter = _logger()
    transport = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(transport)
    token = set_mcp_message_trace_carrier({"traceparent": "not-a-valid-traceparent"})
    try:
        asyncio.run(
            logger.async_log_success_event(
                {"standard_logging_object": _mcp_list_payload()}, None, None, None
            )
        )
    finally:
        reset_mcp_message_trace_carrier(token)
    transport.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == "tools/list")
    assert span.parent is not None
    assert span.parent.span_id == transport.get_span_context().span_id
    assert span.links == ()


def test_mcp_span_with_propagated_context_nests_under_this_messages_transport():
    """With client context propagated, the span must still anchor to the POST
    carrying this message, not the stale session anchor — otherwise the tool call
    is attributed to whichever request opened the session."""
    logger, exporter = _logger()
    session_opener = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    this_message = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(session_opener)
    trace_token = set_mcp_message_trace_carrier(
        {"traceparent": "00-11111111111111111111111111111111-2222222222222222-01"}
    )
    transport_token = set_mcp_message_transport_span(this_message)
    try:
        asyncio.run(
            logger.async_log_success_event(
                {"standard_logging_object": _mcp_list_payload()}, None, None, None
            )
        )
    finally:
        reset_mcp_message_transport_span(transport_token)
        reset_mcp_message_trace_carrier(trace_token)
    session_opener.end()
    this_message.end()
    span = next(s for s in exporter.get_finished_spans() if s.name == "tools/list")
    assert span.parent is not None
    assert span.parent.span_id == this_message.get_span_context().span_id
    assert span.context.trace_id == this_message.get_span_context().trace_id
    assert [link.context.span_id for link in span.links] == [0x2222222222222222]


def test_pre_call_idempotent_keeps_first_span():
    """A retried call may re-enter ``pre_call`` with the same call id; the first
    span (with the true start time) is kept, not replaced."""
    logger, _ = _logger()
    kwargs = _kwargs()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    with trace.use_span(server, end_on_exit=False):
        logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
        first = logger._open_llm_calls["call_1"]
        logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
        second = logger._open_llm_calls["call_1"]
    server.end()
    assert first is second  # not overwritten


# --------------------------------------------------------------------------- #
#  Parent resolution — ambient context at the boundary (no metadata threading)
# --------------------------------------------------------------------------- #


def test_llm_span_parents_to_ambient_server_span():
    """The span is opened at ``pre_call`` while the server span is the active
    context, so it nests under it natively (no ``litellm_parent_otel_span``)."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    _emit_llm(logger, ambient=server)
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    llm_span = by_name["chat gpt-4o"]
    assert llm_span.parent is not None
    assert llm_span.parent.span_id == server.get_span_context().span_id


def test_llm_span_is_root_without_ambient_server_span():
    """No server span at ``pre_call`` → creation is deferred and the span is a
    root of its own trace (the SDK / no-proxy path)."""
    logger, exporter = _logger()
    _emit_llm(logger)
    (span,) = exporter.get_finished_spans()
    assert span.parent is None  # standalone (no proxy server span) → root


# --------------------------------------------------------------------------- #
#  Explicit request-root-span anchor — request-level spans (LLM call, guardrail)
#  parent to the captured server span, NOT to whatever span is momentarily
#  active. Regression cover for the two ambient-only failure modes:
#    * auth: the LLM/guardrail span must not nest under the live ``auth`` span;
#    * pass-through: the span must not orphan when closed off the request task.
# --------------------------------------------------------------------------- #


def test_llm_span_anchors_to_root_even_inside_active_phase_span():
    """Bug 1: a synthetic error log can fire ``pre_call`` while the ``auth`` phase
    span is the *active* context. The LLM span must still parent to the request
    root (the server span), never to the auth span it happens to be nested in."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(server)
    kwargs = _kwargs()
    # ``auth`` phase span is the active span when pre_call + close run.
    with trace.use_span(server, end_on_exit=False):
        with logger.start_phase_span("auth /chat/completions"):
            logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
            asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    llm_span = by_name["chat gpt-4o"]
    auth_span = by_name["auth /chat/completions"]
    # Parented to the server root, NOT the auth span it was emitted inside.
    assert llm_span.parent.span_id == server.get_span_context().span_id
    assert llm_span.parent.span_id != auth_span.get_span_context().span_id


def test_live_llm_span_anchors_to_root_with_no_active_span():
    """Bug 2 (pass-through), live path: even with no span active at ``pre_call``,
    the anchor is a recordable parent, so the span opens live under the server root
    instead of orphaning — and the detached close just ends it, in the right
    trace."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(server)
    kwargs = _kwargs()
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    assert logger._open_llm_calls["call_1"].span is not None  # live, via anchor
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    llm_span = by_name["chat gpt-4o"]
    assert llm_span.parent.span_id == server.get_span_context().span_id
    assert llm_span.context.trace_id == server.get_span_context().trace_id


def test_deferred_llm_span_reads_anchor_at_close():
    """Bug 2, deferred path: when the anchor isn't visible at ``pre_call`` (a
    sync-only provider's thread-pool call) the span defers; the close — back on the
    request task, anchor visible — must parent it to the root, not orphan it."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    kwargs = _kwargs()
    # pre_call with NO anchor and no active span → deferred.
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    assert logger._open_llm_calls["call_1"].span is None  # deferred
    # Anchor becomes visible at close (worker copied the request task's context).
    set_request_root_span(server)
    asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    llm_span = by_name["chat gpt-4o"]
    assert llm_span.parent.span_id == server.get_span_context().span_id
    assert llm_span.context.trace_id == server.get_span_context().trace_id


def test_synthetic_error_log_produces_no_llm_span():
    """Bug 1 root cause: a proxy-gate error log (auth/rate-limit) fires ``pre_call``
    for a request that never reached a provider. Tagged with
    ``LITELLM_LOGGING_NO_UPSTREAM_LLM_CALL``, it must open no carrier and emit no
    LLM-call span — even though the failure callback also fires."""
    from litellm.constants import LITELLM_LOGGING_NO_UPSTREAM_LLM_CALL

    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(server)
    payload = _payload(
        status="failure",
        error_information={"error_class": "ProxyException", "error_code": "401"},
    )
    kwargs = _kwargs(payload=payload)
    kwargs[LITELLM_LOGGING_NO_UPSTREAM_LLM_CALL] = True
    with trace.use_span(server, end_on_exit=False):
        with logger.start_phase_span("auth /chat/completions"):
            logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
            assert "call_1" not in logger._open_llm_calls  # no carrier opened
            asyncio.run(logger.async_log_failure_event(kwargs, None, None, None))
    server.end()
    names = {s.name for s in exporter.get_finished_spans()}
    assert "chat gpt-4o" not in names  # no phantom LLM span
    assert "auth /chat/completions" in names  # auth span itself still recorded


def test_create_request_started_span_captures_anchor():
    """``create_litellm_proxy_request_started_span`` doubles as the anchor capture
    point: the active server span becomes the request root for later spans."""
    from litellm.integrations.otel.plumbing.context import request_root_span

    logger, _ = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    with trace.use_span(server, end_on_exit=False):
        returned = logger.create_litellm_proxy_request_started_span(
            start_time=datetime.now(), headers=None
        )
    server.end()
    assert returned.get_span_context().span_id == server.get_span_context().span_id
    assert (
        request_root_span().get_span_context().span_id
        == server.get_span_context().span_id
    )


def test_guardrail_span_anchors_to_root_inside_active_phase_span():
    """A guardrail emitted from a failure hook that runs inside the live ``auth``
    span must still be a sibling of the LLM call under the request root, not a
    child of auth."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(server)
    entry = {"guardrail_name": "my_guard", "guardrail_status": "success"}
    with trace.use_span(server, end_on_exit=False):
        with logger.start_phase_span("auth /chat/completions"):
            logger.emit_guardrail_span(entry)
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    guard = by_name["execute_guardrail my_guard"]
    auth_span = by_name["auth /chat/completions"]
    assert guard.parent.span_id == server.get_span_context().span_id
    assert guard.parent.span_id != auth_span.get_span_context().span_id


# --------------------------------------------------------------------------- #
#  LIT-4179 — proxy-level failures that never reach an LLM call must still stamp
#  the structured error.* attributes onto the request's spans, restoring the v1
#  behavior v2 dropped when it stopped subclassing ``OpenTelemetry``.
# --------------------------------------------------------------------------- #


def _proxy_exc(message, code):
    from litellm.proxy._types import ProxyException

    return ProxyException(message=message, type="bad_request_error", param=None, code=code)


def test_async_post_call_failure_hook_stamps_error_on_root_span():
    """PATH B: an endpoint-level failure (empty body rejected before dispatch)
    reaches ``async_post_call_failure_hook``; it must stamp error.* + an exception
    event on the anchored request root span."""
    from litellm.proxy._types import UserAPIKeyAuth

    logger, exporter = _logger()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    set_request_root_span(server)
    exc = _proxy_exc("litellm.BadRequestError: messages is required", 400)
    result = asyncio.run(
        logger.async_post_call_failure_hook(
            request_data={}, original_exception=exc, user_api_key_dict=UserAPIKeyAuth()
        )
    )
    server.end()
    assert result is None
    (span,) = exporter.get_finished_spans()
    assert span.attributes["error.type"] == "ProxyException"
    assert "messages is required" in span.attributes["error.message"]
    assert span.attributes["litellm.provider.error.code"] == "400"
    assert span.status.status_code is StatusCode.ERROR
    assert any(e.name == "exception" for e in span.events)


def test_async_post_call_failure_hook_falls_back_to_user_api_key_parent_span():
    """With no anchor set (a path that never captured the root), the hook must fall
    back to ``user_api_key_dict.parent_otel_span`` rather than dropping the error."""
    from litellm.proxy._types import UserAPIKeyAuth

    logger, exporter = _logger()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    asyncio.run(
        logger.async_post_call_failure_hook(
            request_data={},
            original_exception=_proxy_exc("boom", 401),
            user_api_key_dict=UserAPIKeyAuth(parent_otel_span=server),
        )
    )
    server.end()
    (span,) = exporter.get_finished_spans()
    assert span.attributes["error.type"] == "ProxyException"
    assert span.attributes["litellm.provider.error.code"] == "401"


def test_async_post_call_failure_hook_stamps_the_mcp_messages_own_transport():
    """A failed MCP tool call is handled on the session's task, where the request
    root anchor is still the request that opened the session — an ended span, so the
    SDK dropped the write and the POST that actually failed carried no error at all.
    The hook must stamp the transport the gateway published for this message."""
    from litellm.proxy._types import UserAPIKeyAuth

    logger, exporter = _logger()
    session_opener = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    this_message = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)

    async def session_task():
        token = set_mcp_message_transport_span(this_message)
        try:
            await logger.async_post_call_failure_hook(
                request_data={},
                original_exception=_proxy_exc("Authorization failed for tool 'x'", 403),
                user_api_key_dict=UserAPIKeyAuth(),
            )
        finally:
            reset_mcp_message_transport_span(token)

    async def initialize_request():
        set_request_root_span(session_opener)
        await asyncio.create_task(session_task())

    asyncio.run(initialize_request())
    session_opener.end()
    this_message.end()
    by_id = {s.context.span_id: s for s in exporter.get_finished_spans()}
    failed = by_id[this_message.get_span_context().span_id]
    opener = by_id[session_opener.get_span_context().span_id]
    assert failed.attributes["error.type"] == "ProxyException"
    assert failed.status.status_code is StatusCode.ERROR
    assert "error.type" not in opener.attributes
    assert opener.status.status_code is not StatusCode.ERROR


def test_mcp_message_transport_reanchors_request_level_spans():
    """Publishing the message's transport also re-anchors the request root, so
    everything else the message emits lands on the request that carried it. Without
    that, a guardrail run during a tool call — like the identity attributes seeded
    onto the server span — attaches to the request that opened the session."""
    logger, exporter = _logger()
    session_opener = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    this_message = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)

    async def session_task():
        token = set_mcp_message_transport_span(this_message)
        try:
            logger.emit_guardrail_span({"guardrail_name": "my_guard", "guardrail_status": "success"})
        finally:
            reset_mcp_message_transport_span(token)

    async def initialize_request():
        set_request_root_span(session_opener)
        await asyncio.create_task(session_task())

    asyncio.run(initialize_request())
    session_opener.end()
    this_message.end()
    guard = next(s for s in exporter.get_finished_spans() if s.name == "execute_guardrail my_guard")
    assert guard.parent.span_id == this_message.get_span_context().span_id
    assert guard.parent.span_id != session_opener.get_span_context().span_id


def test_async_post_call_failure_hook_skips_a_transport_that_already_answered():
    """The published transport is only writable while its request is open. A
    notification POST answers before the session task is done with the message, and
    writing to the finished span is a no-op the SDK logs and discards, so the hook
    must fall through to the anchor instead of aiming at it."""
    from litellm.proxy._types import UserAPIKeyAuth

    logger, exporter = _logger()
    anchor = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    answered = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    answered.end()
    set_request_root_span(anchor)
    token = set_mcp_message_transport_span(answered)
    try:
        asyncio.run(
            logger.async_post_call_failure_hook(
                request_data={},
                original_exception=_proxy_exc("boom", 403),
                user_api_key_dict=UserAPIKeyAuth(),
            )
        )
    finally:
        reset_mcp_message_transport_span(token)
    anchor.end()
    by_id = {s.context.span_id: s for s in exporter.get_finished_spans()}
    assert by_id[anchor.get_span_context().span_id].attributes["error.type"] == "ProxyException"
    assert "error.type" not in by_id[answered.get_span_context().span_id].attributes


def test_record_error_attributes_on_span_decorates_without_ending():
    """PATH A: a failure that dies before any LLM-call span (malformed body,
    validation) is stamped onto the instrumentor-owned SERVER span. The method must
    not end the span, and must pin error.code to the real response status (not the
    exception's own code).

    LIT-4780: the instrumentor never sees the exception (the proxy handler turns it
    into a JSONResponse), so nothing else marks the span as failed; the status and
    the exception event have to come from here or the trace shows the error message
    on an otherwise successful-looking request."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    logger.record_error_attributes_on_span(server, _proxy_exc("Invalid JSON body", 400), 422)
    assert server.is_recording()
    server.end()
    (span,) = exporter.get_finished_spans()
    assert span.attributes["error.type"] == "ProxyException"
    assert span.attributes["error.message"] == "Invalid JSON body"
    assert span.attributes["litellm.provider.error.code"] == "422"
    assert span.status.status_code is StatusCode.ERROR
    assert [e.name for e in span.events] == ["exception"]


def test_record_error_attributes_on_span_does_not_duplicate_an_already_stamped_error():
    """A failure that already went through ``async_post_call_failure_hook`` reaches
    the exception handler too; the second stamp must keep one exception event while
    still repinning error.code to the real response status."""
    from litellm.proxy._types import UserAPIKeyAuth

    logger, exporter = _logger()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    set_request_root_span(server)
    exc = _proxy_exc("Authentication Error, invalid key", 401)
    asyncio.run(
        logger.async_post_call_failure_hook(
            request_data={}, original_exception=exc, user_api_key_dict=UserAPIKeyAuth()
        )
    )
    logger.record_error_attributes_on_span(server, exc, 400)
    server.end()
    (span,) = exporter.get_finished_spans()
    assert [e.name for e in span.events] == ["exception"]
    assert span.attributes["litellm.provider.error.code"] == "400"
    assert span.status.status_code is StatusCode.ERROR


def test_record_error_attributes_on_span_ignores_below_400_and_missing_span():
    logger, _ = _logger()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    logger.record_error_attributes_on_span(None, _proxy_exc("boom", 400), 400)  # no span → no-op
    logger.record_error_attributes_on_span(server, None, 400)  # no exception → no-op
    server.end()
    assert "error.type" not in (server.attributes or {})


def test_start_phase_span_stamps_error_attributes_on_failure():
    """An ``auth`` phase span that dies (expired key) must carry the structured
    error.* attributes, not only the exception event ``use_span`` records."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    set_request_root_span(server)
    exc = _proxy_exc("Authentication Error, ExpiredToken", 401)
    with trace.use_span(server, end_on_exit=False):
        with contextlib.suppress(Exception):
            with logger.start_phase_span("auth /chat/completions"):
                raise exc
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    auth = by_name["auth /chat/completions"]
    assert auth.attributes["error.type"] == "ProxyException"
    assert "ExpiredToken" in auth.attributes["error.message"]
    assert auth.attributes["litellm.provider.error.code"] == "401"
    assert auth.status.status_code is StatusCode.ERROR
    assert any(e.name == "exception" for e in auth.events)


def test_start_phase_span_success_carries_no_error():
    logger, exporter = _logger()
    with logger.start_phase_span("auth /chat/completions"):
        pass
    (span,) = exporter.get_finished_spans()
    assert "error.type" not in span.attributes
    assert span.status.status_code is not StatusCode.ERROR


def test_real_logging_pre_call_opens_span_end_to_end():
    """Regression guard: a real ``LiteLLMLoggingObj.pre_call`` must fire
    ``log_pre_api_call`` on the V2 logger (via ``litellm.input_callback``), so the
    boundary span is opened and then closed by the success callback. If the logger
    is not wired into ``input_callback``, no span is produced at all."""
    import litellm
    from litellm.litellm_core_utils.litellm_logging import Logging

    logger, exporter = _logger()
    # Register exactly this logger as the (only) input callback pre_call iterates.
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(litellm, "input_callback", [logger], raising=False)
    try:
        logging_obj = Logging(
            model="gpt-4o",
            messages=[{"role": "user", "content": "hi"}],
            stream=False,
            call_type="acompletion",
            start_time=datetime.now(),
            litellm_call_id="call_e2e",
            function_id="fn",
        )
        # The wrapper always runs this before pre_call — it's what seeds
        # ``litellm_params`` and ``litellm_call_id`` into ``model_call_details``
        # (the call id is how the close callback correlates back to this span).
        logging_obj.update_environment_variables(
            litellm_params={"metadata": {}},
            optional_params={},
            model="gpt-4o",
        )
        # pre_call fires log_pre_api_call → opens the boundary span on the obj.
        logging_obj.pre_call(input="hi", api_key="sk-test")
        # The success callback closes it, reading the typed payload.
        logging_obj.model_call_details["standard_logging_object"] = _payload(
            litellm_call_id="call_e2e"
        )
        asyncio.run(
            logger.async_log_success_event(
                logging_obj.model_call_details, None, None, None
            )
        )
    finally:
        monkeypatch.undo()
    (span,) = exporter.get_finished_spans()
    assert span.name == "chat gpt-4o"


def test_deferred_span_parents_to_ambient_at_close():
    """When ``pre_call`` runs off the request task (a sync-only provider driven
    through a thread pool, where contextvars don't follow), no ambient parent is
    visible there, so span creation is deferred. The async callback — whose worker
    context was copied from the request task and so still carries the server span —
    then creates it parented to that server span, not as an orphan root."""
    logger, exporter = _logger()
    kwargs = _kwargs()
    # pre_call with NO ambient span (the thread-pool case) → deferred.
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    # The close callback runs with the (worker-copied) server span ambient.
    with trace.use_span(server, end_on_exit=False):
        asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    llm_span = by_name["chat gpt-4o"]
    assert llm_span.parent.span_id == server.get_span_context().span_id


# Inbound ``traceparent`` propagation is now the FastAPI instrumentor's job
# (see proxy_server's startup mount + ``test_otel_v2_mount``), not the logger's.


# --------------------------------------------------------------------------- #
#  Baggage promotion (LLM call writes identity into baggage so child spans
#  inherit team/key/model attrs).
# --------------------------------------------------------------------------- #


def test_baggage_identity_promoted_onto_llm_call():
    """On the deferred (SDK / no-proxy) path the callback seeds identity Baggage
    from the payload so the span is still labeled with team/key. (On the proxy
    boundary path identity rides in from auth-seeded ambient Baggage instead.)"""
    logger, exporter = _logger()
    _emit_llm(logger)
    (span,) = exporter.get_finished_spans()
    assert span.attributes[LiteLLM.TEAM_ID] == "t1"
    assert span.attributes[LiteLLM.TEAM_ALIAS] == "team one"
    assert span.attributes[GenAI.REQUEST_MODEL] == "gpt-4o"


class _Auth:
    """Stub matching the ``UserAPIKeyAuth`` fields the logger reads."""

    team_id = "t1"
    team_alias = "team one"
    team_metadata = {"tier": "gold", "cost_center": "42"}
    api_key = "hash1"
    user_id = "u1"
    org_id = None
    key_alias = "k1"
    end_user_id = None


def test_provider_model_and_team_metadata_on_real_boundary_flow():
    """End-to-end on the proxy boundary path (the gap a pure-emitter test misses):

    - ``litellm.team.metadata`` (filtered to the allowlisted sub-keys) is known
      at auth, so it rides identity Baggage seeded there onto EVERY span
      (server + LLM call).
    - ``litellm.provider.model`` is only known once routing picks a deployment
      (in the payload at close), AFTER the auth seed and AFTER the boundary span
      starts — so it can't ride Baggage. It's stamped directly on the LLM-call
      span by the mapper, and is absent from the server span (which starts first).
    """
    import json

    logger, exporter = _logger(team_metadata_keys=["tier", "cost_center"])
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    payload = _payload(
        hidden_params={"litellm_model_name": "azure/my-deployment"},
        metadata={
            "user_api_key_team_id": "t1",
            "user_api_key_team_alias": "team one",
            "user_api_key_hash": "hash1",
            "user_api_key_team_metadata": {"tier": "gold", "cost_center": "42"},
        },
    )
    kwargs = _kwargs(payload=payload)
    with trace.use_span(server, end_on_exit=False):
        # auth boundary: seed identity (provider model unknown here)
        logger.seed_request_identity(_Auth(), model="gpt-4o")
        # pre_call boundary opens the LLM span; success closes it from the payload
        logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
        asyncio.run(logger.async_log_success_event(kwargs, None, None, None))
    server.end()

    spans = {s.name: s for s in exporter.get_finished_spans()}
    llm = spans["chat gpt-4o"]
    srv = spans[LITELLM_PROXY_REQUEST_SPAN_NAME]
    # provider model: on the LLM call span, NOT the server span
    assert llm.attributes[LiteLLM.PROVIDER_MODEL] == "azure/my-deployment"
    assert LiteLLM.PROVIDER_MODEL not in srv.attributes
    # team metadata: on every span, JSON-serialized
    expected = {"tier": "gold", "cost_center": "42"}
    assert json.loads(llm.attributes[LiteLLM.TEAM_METADATA]) == expected
    assert json.loads(srv.attributes[LiteLLM.TEAM_METADATA]) == expected


def test_pre_call_hook_seeds_baggage_onto_server_and_child_spans():
    """The pre-call hook seeds identity Baggage in the request context so the
    server span (stamped directly) AND later child spans (service here, via the
    Baggage processor) carry identity — not just the LLM-call span."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )

    async def _flow():
        # pre-call seeds baggage + stamps the active server span
        await logger.async_pre_call_hook(
            _Auth(), None, {"model": "gpt-4o"}, "completion"
        )
        # a later service call (same task) must inherit the identity
        await logger.async_service_success_hook(
            payload=_ServicePayload("redis", "set"), parent_otel_span=server
        )

    with trace.use_span(server, end_on_exit=False):
        asyncio.run(_flow())
    server.end()

    spans = {s.name: s for s in exporter.get_finished_spans()}
    redis = spans["redis set"]
    assert redis.attributes[LiteLLM.TEAM_ID] == "t1"
    assert redis.attributes[LiteLLM.KEY_HASH] == "hash1"
    assert redis.attributes[f"{LiteLLM.METADATA_PREFIX}user_api_key_user_id"] == "u1"
    srv = spans[LITELLM_PROXY_REQUEST_SPAN_NAME]
    assert (
        srv.attributes[LiteLLM.TEAM_ID] == "t1"
    )  # stamped directly on the server span
    assert srv.attributes[f"{LiteLLM.METADATA_PREFIX}user_api_key_user_id"] == "u1"


# --------------------------------------------------------------------------- #
#  Service hooks (Phase 3)
# --------------------------------------------------------------------------- #


class _Service:
    """Stub matching ``ServiceTypes(str, Enum)``."""

    def __init__(self, value):
        self.value = value


class _ServicePayload:
    def __init__(self, service="redis", call_type="set", error=None):
        self.service = _Service(service)
        self.call_type = call_type
        self.error = error


def _service_parent(logger):
    """Helper: a live PROXY_REQUEST span to parent service spans under."""
    return logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )


def test_async_service_success_hook_emits_service_span():
    logger, exporter = _logger()
    parent = _service_parent(logger)
    try:
        asyncio.run(
            logger.async_service_success_hook(
                payload=_ServicePayload("redis", "set"),
                parent_otel_span=parent,
                event_metadata={"key1": "val1"},
            )
        )
    finally:
        parent.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    # Name disambiguates calls to the same service; redis is an outbound
    # datastore call, so it's a CLIENT span with db.* semconv.
    span = by_name["redis set"]
    assert span.kind is SpanKind.CLIENT
    assert span.attributes["db.system.name"] == "redis"
    assert span.attributes["db.operation.name"] == "set"
    assert span.attributes[LiteLLM.SERVICE_NAME] == "redis"
    assert span.attributes[LiteLLM.SERVICE_CALL_TYPE] == "set"
    # Canonical (V2) namespaced metadata key
    assert span.attributes[f"{LiteLLM.METADATA_PREFIX}key1"] == "val1"
    # V1 bare key (legacy dual-emit)
    assert span.attributes["key1"] == "val1"
    assert span.attributes["service"] == "redis"  # V1 bare key
    assert span.attributes["call_type"] == "set"  # V1 bare key
    # Success leaves status UNSET (semconv default), not forced OK.
    assert span.status.status_code is StatusCode.UNSET


def test_postgres_db_span_names_the_database_server_not_the_prisma_engine():
    """Prisma reaches Postgres over loopback, so without server.address the
    backend attributes the wait to localhost."""
    dsn = "postgresql://llmproxy:dbpassword9090@litellm-prod.abc123.us-east-1.rds.amazonaws.com:6432/litellm?schema=reporting"
    logger, exporter = _logger()
    parent = _service_parent(logger)
    try:
        with patch.dict(os.environ, {"DATABASE_URL": dsn}, clear=False):
            os.environ.pop("DATABASE_URL_READ_REPLICA", None)
            asyncio.run(
                logger.async_service_success_hook(
                    payload=_ServicePayload("postgres", "get_data"),
                    parent_otel_span=parent,
                )
            )
    finally:
        parent.end()
    span = {s.name: s for s in exporter.get_finished_spans()}["postgres get_data"]
    assert span.kind is SpanKind.CLIENT
    assert span.attributes["db.system.name"] == "postgresql"
    assert span.attributes["db.operation.name"] == "get_data"
    assert span.attributes["server.address"] == "litellm-prod.abc123.us-east-1.rds.amazonaws.com"
    assert span.attributes["server.port"] == 6432
    assert span.attributes["db.namespace"] == "litellm|reporting"
    assert span.attributes["db.system"] == "postgresql"
    exported = " ".join(str(value) for value in span.attributes.values())
    assert "dbpassword9090" not in exported
    assert "llmproxy" not in exported


def test_async_service_failure_hook_marks_error_status():
    logger, exporter = _logger()
    parent = _service_parent(logger)
    try:
        asyncio.run(
            logger.async_service_failure_hook(
                payload=_ServicePayload("postgres", "query"),
                error="boom",
                parent_otel_span=parent,
            )
        )
    finally:
        parent.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    span = by_name["postgres query"]
    assert span.kind is SpanKind.CLIENT
    assert span.attributes["db.system.name"] == "postgresql"
    assert span.status.status_code is StatusCode.ERROR
    # Without an explicit error_type from the payload, V2 stamps the fallback.
    assert span.attributes["error.type"] == "error"
    assert span.attributes[LiteLLM.SERVICE_NAME] == "postgres"


def test_async_service_failure_hook_preserves_payload_error_over_override():
    """When the payload itself carries an error, that takes precedence over the override."""
    logger, exporter = _logger()
    parent = _service_parent(logger)
    try:
        asyncio.run(
            logger.async_service_failure_hook(
                payload=_ServicePayload("postgres", "query", error="db-down"),
                error="override-only-used-when-payload-clean",
                parent_otel_span=parent,
            )
        )
    finally:
        parent.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    span = by_name["postgres query"]
    assert span.status.status_code is StatusCode.ERROR
    assert "db-down" in (span.status.description or "")


def test_metrics_only_ping_without_timing_or_parent_is_noop():
    """A success with no timing and no parent is a prometheus-only ping (the
    per-request ``self`` latency hook, in-memory queue gauges) — not a traceable
    operation, so no span is emitted."""
    logger, exporter = _logger()
    asyncio.run(
        logger.async_service_success_hook(
            payload=_ServicePayload(), parent_otel_span=None
        )
    )
    assert exporter.get_finished_spans() == ()


def test_background_service_call_with_timing_emits_root_span():
    """A background datastore call (no request → no parent) but with real timing
    still emits — as its own root trace — instead of being dropped."""
    logger, exporter = _logger()
    asyncio.run(
        logger.async_service_success_hook(
            payload=_ServicePayload("postgres", "query"),
            parent_otel_span=None,
            start_time=1.0,
            end_time=2.0,
        )
    )
    spans = exporter.get_finished_spans()
    assert [s.name for s in spans] == ["postgres query"]
    # No parent → it's a root span of its own trace.
    assert spans[0].parent is None
    assert spans[0].kind is SpanKind.CLIENT


def test_internal_service_call_is_internal_kind_without_db_attrs():
    """A genuine internal service (background job) is an INTERNAL span, no db.*."""
    logger, exporter = _logger()
    asyncio.run(
        logger.async_service_success_hook(
            payload=_ServicePayload("reset_budget_job", "reset_budget"),
            parent_otel_span=None,
            start_time=1.0,
            end_time=2.0,
        )
    )
    span = exporter.get_finished_spans()[0]
    assert span.name == "reset_budget_job reset_budget"
    assert span.kind is SpanKind.INTERNAL
    assert "db.system.name" not in span.attributes
    assert span.attributes[LiteLLM.SERVICE_NAME] == "reset_budget_job"


def test_metrics_only_services_emit_no_span():
    """self / router / proxy_pre_call / auth duplicate gen-AI spans or get a live
    phase span — they are metrics-only and must not produce a service span."""
    for service in ("self", "router", "proxy_pre_call", "auth"):
        logger, exporter = _logger()
        asyncio.run(
            logger.async_service_success_hook(
                payload=_ServicePayload(service, "x"),
                parent_otel_span=None,
                start_time=1.0,
                end_time=2.0,
            )
        )
        assert exporter.get_finished_spans() == (), f"{service} should emit no span"


def test_service_span_inherits_parent_when_provided():
    logger, exporter = _logger()
    parent = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    try:
        asyncio.run(
            logger.async_service_success_hook(
                payload=_ServicePayload(), parent_otel_span=parent
            )
        )
    finally:
        parent.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    assert (
        by_name["redis set"].parent.span_id
        == by_name[LITELLM_PROXY_REQUEST_SPAN_NAME].get_span_context().span_id
    )


def test_service_span_prefers_ambient_context_over_threaded_parent():
    """Service/DB spans parent to the active (ambient) span when there is one, so
    they nest under whatever phase is active (e.g. a DB lookup under the live
    ``auth`` span). The threaded ``parent_otel_span`` is only a fallback for when
    ambient has no live span (a background service call)."""
    logger, exporter = _logger()
    ambient = logger._emitter.start_span(SpanRole.LLM_CALL, "chat gpt-4o")
    threaded = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    try:
        with trace.use_span(ambient, end_on_exit=False):
            asyncio.run(
                logger.async_service_success_hook(
                    payload=_ServicePayload("redis", "get"),
                    parent_otel_span=threaded,
                )
            )
    finally:
        ambient.end()
        threaded.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    assert by_name["redis get"].parent.span_id == ambient.get_span_context().span_id


# --------------------------------------------------------------------------- #
#  Proxy SERVER span lifecycle
# --------------------------------------------------------------------------- #


def test_create_proxy_request_started_span_returns_ambient_span():
    """V2 doesn't create a server span (the instrumentor does), but it returns
    the active server span so the proxy can thread it as the service-span parent
    — service logging only fires the OTel hook when that parent is non-None."""
    logger, exporter = _logger()
    # No ambient recordable span → None (and creates nothing).
    assert (
        logger.create_litellm_proxy_request_started_span(
            start_time=datetime.now(timezone.utc), headers={"traceparent": "x"}
        )
        is None
    )
    assert exporter.get_finished_spans() == ()
    # With an active server span, return it (do NOT create a new one).
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    with trace.use_span(server, end_on_exit=False):
        got = logger.create_litellm_proxy_request_started_span(
            start_time=datetime.now(timezone.utc), headers=None
        )
    server.end()
    assert got is server


# --------------------------------------------------------------------------- #
#  Constructor / proxy global guard
# --------------------------------------------------------------------------- #


def test_constructor_accepts_v1_compatible_kwargs():
    """Mirrors V1's positional shape — config / callback_name / providers / **kwargs."""
    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)
    logger = OpenTelemetryV2(
        config=cfg,
        callback_name="otel",
        tracer_provider=tp,
        logger_provider=None,
        meter_provider=None,
        turn_off_message_logging=True,
    )
    assert logger.callback_name == "otel"
    assert logger.turn_off_message_logging is True
    assert logger.tracer is not None


def test_default_config_reads_env(monkeypatch):
    """No explicit config → reads env (exporter=console by default)."""
    monkeypatch.delenv("OTEL_EXPORTER", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_PROTOCOL", raising=False)
    logger = OpenTelemetryV2(
        tracer_provider=providers.build_tracer_provider(
            OpenTelemetryV2Config(exporter="in_memory")
        )
    )
    assert logger.config.exporter == "console"


def test_proxy_global_first_registered_wins(monkeypatch):
    """``_init_otel_logger_on_litellm_proxy`` claims the global only when empty."""
    proxy_server = pytest.importorskip("litellm.proxy.proxy_server")
    monkeypatch.setattr(proxy_server, "open_telemetry_logger", None, raising=False)
    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)

    first = OpenTelemetryV2(config=cfg, tracer_provider=tp)
    assert proxy_server.open_telemetry_logger is first

    second = OpenTelemetryV2(config=cfg, tracer_provider=tp)
    # Global still points at the first registration.
    assert proxy_server.open_telemetry_logger is first
    assert second is not first


def test_select_global_otel_v2_logger_reuses_existing_preset_logger():
    """The global-provider selection must reuse the logger the callback factory
    already built (e.g. an arize preset logger that folds the OTEL_* base exporter
    and its own exporter into one logger), not mint a second generic one.

    Regression for the orphan span: the startup publish used to search
    ``service_callback`` (which a preset logger does not always reach), miss the
    existing logger, and build a second generic ``OpenTelemetryV2`` whose provider
    became the OTel global. The server span then exported through that generic
    provider while the preset logger's gen-ai spans exported to the preset backend,
    so on that backend the LLM span had no parent. Selecting from the loggers the
    factory registered keeps one logger, one provider, one connected trace.
    """
    from litellm.integrations.otel.logger import select_global_otel_v2_logger

    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)
    preset_logger = OpenTelemetryV2(
        config=cfg, callback_name="arize", tracer_provider=tp
    )

    chosen = select_global_otel_v2_logger([object(), preset_logger, object()])
    assert chosen is preset_logger


def test_select_global_otel_v2_logger_prefers_registered_owner_over_list_scan():
    """Selection reuses the canonical owner the factory registered, not whatever
    the ``in_memory_loggers`` scan happens to reach first.

    The factory designates one logger as ``proxy_server.open_telemetry_logger`` the
    moment it builds the first one, and every other v2 path (guardrail, seed,
    phase spans) routes through that owner. With two presets configured, the list
    scan's "first ``OpenTelemetryV2``" is order-dependent and could disagree with
    that owner, publishing one backend's provider as the global while the rest of
    the v2 code emits through another. Passing the registered owner pins the global
    provider to the same logger the rest of the code already uses.
    """
    from litellm.integrations.otel.logger import select_global_otel_v2_logger

    cfg = OpenTelemetryV2Config(exporter="in_memory")
    owner = OpenTelemetryV2(
        config=cfg,
        callback_name="arize",
        tracer_provider=providers.build_tracer_provider(cfg),
    )
    other = OpenTelemetryV2(
        config=cfg,
        callback_name="langfuse_otel",
        tracer_provider=providers.build_tracer_provider(cfg),
    )

    chosen = select_global_otel_v2_logger([other, owner], registered=owner)
    assert chosen is owner


def test_select_global_otel_v2_logger_builds_one_when_none_registered():
    """With no logger registered, selection builds exactly one generic logger so
    the proxy still publishes a provider; it must not return ``None``."""
    from litellm.integrations.otel.logger import select_global_otel_v2_logger

    chosen = select_global_otel_v2_logger([])
    assert isinstance(chosen, OpenTelemetryV2)


def test_publish_global_otel_v2_provider_sets_selected_logger_provider():
    """The startup publish must set the OTel global provider to the *selected*
    logger's provider (the preset logger that owns every exporter), so the FastAPI
    server span and the gen-ai spans share one provider and one trace.

    Drives the publish step the proxy runs at startup, with the global-setter
    injected so no real global OTel state is mutated. Guards the wiring that a unit
    test would otherwise miss: that the published provider is the selected logger's,
    not some other.
    """
    from litellm.integrations.otel.logger import publish_global_otel_v2_provider

    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)
    preset_logger = OpenTelemetryV2(
        config=cfg, callback_name="arize", tracer_provider=tp
    )

    published = []
    chosen = publish_global_otel_v2_provider(
        [object(), preset_logger], published.append
    )

    assert chosen is preset_logger
    assert published == [preset_logger._tracer_provider]


def test_registers_into_litellm_service_callback(monkeypatch):
    """The logger must mutate ``litellm.service_callback`` in place. An empty
    list is falsy, so a ``getattr(..) or []`` would append to a throwaway local
    and service spans (Redis, …) would silently never fire on this logger.
    """
    import litellm

    pytest.importorskip("litellm.proxy.proxy_server")
    monkeypatch.setattr(litellm, "service_callback", [], raising=False)
    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)

    first = OpenTelemetryV2(config=cfg, tracer_provider=tp)
    assert first in litellm.service_callback

    # A second OTel logger sees one is already registered and does not duplicate.
    OpenTelemetryV2(config=cfg, tracer_provider=tp)
    otel_registrations = [
        cb
        for cb in litellm.service_callback
        if cb.__class__.__module__.startswith("litellm.integrations.otel")
    ]
    assert len(otel_registrations) == 1


def test_registers_into_litellm_input_callback(monkeypatch):
    """The logger must land in ``litellm.input_callback`` — the list
    ``Logging.pre_call`` iterates to fire ``log_pre_api_call``. Without this the
    boundary hook never runs and the gen-AI span is never opened (the span goes
    completely missing). Deduped like ``service_callback``.
    """
    import litellm

    pytest.importorskip("litellm.proxy.proxy_server")
    monkeypatch.setattr(litellm, "input_callback", [], raising=False)
    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)

    first = OpenTelemetryV2(config=cfg, tracer_provider=tp)
    assert first in litellm.input_callback

    OpenTelemetryV2(config=cfg, tracer_provider=tp)
    otel_registrations = [
        cb
        for cb in litellm.input_callback
        if cb.__class__.__module__.startswith("litellm.integrations.otel")
    ]
    assert len(otel_registrations) == 1


def test_registers_into_async_success_and_failure_callbacks(monkeypatch):
    """The logger must self-register into ``litellm._async_success_callback`` and
    ``litellm._async_failure_callback`` — the lists ``Logging.async_success_handler``
    / ``async_failure_handler`` iterate to fire ``async_log_success_event`` /
    ``async_log_failure_event``, where the boundary span is *closed*.

    ``input_callback`` opens the span; these lists close it. Relying only on the
    proxy's ``litellm.callbacks`` fan-out to populate them is not enough: a logger
    that reached litellm via ``service_callback`` / ``success_callback`` (or was
    created after the fan-out ran) is absent from ``litellm.callbacks``, so on a
    pass-through request (which never runs ``function_setup``) the span opens and is
    never ended — the gen-AI span leaks and never exports, while DB/service spans
    still show up. Self-registration here guarantees every open has a close.
    """
    import litellm

    pytest.importorskip("litellm.proxy.proxy_server")
    monkeypatch.setattr(litellm, "_async_success_callback", [], raising=False)
    monkeypatch.setattr(litellm, "_async_failure_callback", [], raising=False)
    cfg = OpenTelemetryV2Config(exporter="in_memory")
    tp = providers.build_tracer_provider(cfg)

    first = OpenTelemetryV2(config=cfg, tracer_provider=tp)
    assert first in litellm._async_success_callback
    assert first in litellm._async_failure_callback

    # Deduped — a second otel logger doesn't double up the close hook.
    OpenTelemetryV2(config=cfg, tracer_provider=tp)
    for callback_list in (
        litellm._async_success_callback,
        litellm._async_failure_callback,
    ):
        otel_registrations = [
            cb
            for cb in callback_list
            if cb.__class__.__module__.startswith("litellm.integrations.otel")
        ]
        assert len(otel_registrations) == 1


def test_boundary_span_closes_without_proxy_fanout(monkeypatch):
    """A span opened at ``pre_call`` is still closed and exported when the logger is
    registered ONLY via its own ``__init__`` (no ``litellm.callbacks`` fan-out, as
    happens for a logger configured through ``service_callback``) and the close runs
    through the real ``async_success_handler``.

    Self-registration must wire both ends: the open hook (``input_callback``) and the
    close hook (``_async_success_callback``). If only the open end were wired the span
    would leak — opened but never closed, never exported.
    """
    import litellm
    from litellm.litellm_core_utils.litellm_logging import Logging

    pytest.importorskip("litellm.proxy.proxy_server")
    monkeypatch.setattr(litellm, "input_callback", [], raising=False)
    monkeypatch.setattr(litellm, "_async_success_callback", [], raising=False)
    monkeypatch.setattr(litellm, "_async_failure_callback", [], raising=False)
    # Crucially: the logger is NOT in litellm.callbacks, so the proxy fan-out would
    # never reach it. Only __init__ self-registration wires the open + close hooks.
    monkeypatch.setattr(litellm, "callbacks", [], raising=False)

    logger, exporter = _logger()
    logging_obj = Logging(
        model="gpt-4o",
        messages=[{"role": "user", "content": "hi"}],
        stream=False,
        call_type="pass_through_endpoint",
        start_time=datetime.now(),
        litellm_call_id="pt_leak",
        function_id="fn",
    )
    logging_obj.update_environment_variables(
        litellm_params={"metadata": {}},
        optional_params={},
        model="gpt-4o",
    )
    logging_obj.model_call_details["litellm_call_id"] = "pt_leak"
    # pre_call opens the boundary span (logger is in input_callback).
    logging_obj.pre_call(input="hi", api_key="")
    assert "pt_leak" in logger._open_llm_calls
    # The close runs through the real async_success_handler, which iterates
    # _async_success_callback — where the logger self-registered.
    logging_obj.model_call_details["standard_logging_object"] = _payload(
        litellm_call_id="pt_leak"
    )
    asyncio.run(
        logging_obj.async_success_handler(
            result=None, start_time=datetime.now(), end_time=datetime.now()
        )
    )
    assert "pt_leak" not in logger._open_llm_calls  # carrier closed, not leaked
    (span,) = exporter.get_finished_spans()
    assert span.name == "chat gpt-4o"


# --------------------------------------------------------------------------- #
#  Guardrail span placement: request-level parent + real execution timestamps
# --------------------------------------------------------------------------- #


def _guardrail_entry(*, start, end):
    return {
        "guardrail_name": "openai-moderation",
        "guardrail_mode": "pre_call",
        "guardrail_status": "success",
        "start_time": start,
        "end_time": end,
        "duration": end - start,
    }


def test_guardrail_span_parents_to_ambient_server_span():
    """``emit_guardrail_span`` runs in the request task with the server span
    ambient, so with no explicit anchor set the guardrail span parents to it.
    (Auth already finished, so no phase span is active.)"""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    entry = _guardrail_entry(start=1000.0, end=1000.5)
    try:
        with trace.use_span(server, end_on_exit=False):
            logger.emit_guardrail_span(entry)
    finally:
        server.end()
    g = {s.name: s for s in exporter.get_finished_spans()}[
        "execute_guardrail openai-moderation"
    ]
    assert g.parent.span_id == server.get_span_context().span_id


def test_guardrail_span_uses_actual_execution_timestamps():
    """A pre_call guardrail's span carries its real start/end (from the logging
    entry), so it sorts before the LLM call instead of at emission time."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    entry = _guardrail_entry(start=1700.0, end=1700.25)
    try:
        with trace.use_span(server, end_on_exit=False):
            logger.emit_guardrail_span(entry)
    finally:
        server.end()
    g = {s.name: s for s in exporter.get_finished_spans()}[
        "execute_guardrail openai-moderation"
    ]
    assert g.start_time == to_ns(1700.0)
    assert g.end_time == to_ns(1700.25)


def test_emit_guardrail_span_anchors_to_root_not_ambient_phase_span():
    """With an explicit request-root anchor set, the guardrail span parents to it
    even while a phase span is the active OTel context — the anchor wins over
    ambient, so a guardrail emitted mid-``auth`` is a sibling of the LLM call, not
    a child of ``auth``."""
    logger, exporter = _logger()
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    set_request_root_span(server)
    entry = _guardrail_entry(start=2000.0, end=2000.1)
    with logger.start_phase_span("auth /chat/completions"):
        logger.emit_guardrail_span(entry)
    server.end()
    by_name = {s.name: s for s in exporter.get_finished_spans()}
    guard = by_name["execute_guardrail openai-moderation"]
    auth_span = by_name["auth /chat/completions"]
    assert guard.parent.span_id == server.get_span_context().span_id
    assert guard.parent.span_id != auth_span.get_span_context().span_id


def test_module_level_emit_guardrail_span_routes_to_registered_logger(monkeypatch):
    """The module-level entry point custom_guardrail calls routes the entry to the
    single registered v2 logger and emits exactly one span."""
    import litellm.integrations.otel.logger as otel_logger

    logger, exporter = _logger()
    monkeypatch.setattr(otel_logger, "_registered_v2_logger", lambda: logger)

    otel_logger.emit_guardrail_span(_guardrail_entry(start=3000.0, end=3000.2))

    names = [s.name for s in exporter.get_finished_spans()]
    assert names.count("execute_guardrail openai-moderation") == 1


def test_module_level_emit_guardrail_span_noop_without_registered_logger(monkeypatch):
    """No registered v2 logger (SDK path / OTel not configured) → emitting is a
    no-op rather than an error."""
    import litellm.integrations.otel.logger as otel_logger

    monkeypatch.setattr(otel_logger, "_registered_v2_logger", lambda: None)
    otel_logger.emit_guardrail_span(_guardrail_entry(start=1.0, end=2.0))


def test_module_level_emit_guardrail_span_swallows_emit_errors(monkeypatch):
    """Span emission is best-effort: a logger that raises must never propagate out
    of the guardrail-recording path and break guardrail evaluation."""
    import litellm.integrations.otel.logger as otel_logger

    class _Boom:
        def emit_guardrail_span(self, entry):
            raise RuntimeError("emit blew up")

    monkeypatch.setattr(otel_logger, "_registered_v2_logger", lambda: _Boom())
    otel_logger.emit_guardrail_span(_guardrail_entry(start=1.0, end=2.0))


# --------------------------------------------------------------------------- #
#  Metrics: invalid attribute-filter config is visible, not a silent no-op
# --------------------------------------------------------------------------- #


def _emitted_metric_names(reader) -> set:
    data = reader.get_metrics_data()
    if data is None:
        return set()
    return {
        m.name
        for rm in data.resource_metrics
        for sm in rm.scope_metrics
        for m in sm.metrics
        if any(m.data.data_points)
    }


def _metric_success_kwargs() -> dict:
    return {
        "model": "gpt-4o-mini",
        "call_type": "acompletion",
        "litellm_params": {"custom_llm_provider": "openai"},
        "optional_params": {},
        "response_cost": 0.001,
        "standard_logging_object": {"metadata": {}, "hidden_params": {}},
    }


def test_invalid_metric_filter_logged_once_records_nothing(caplog, monkeypatch):
    """An invalid ``callback_settings.otel.attributes`` (include_list + exclude_list
    both set) must make the operator-fixable config error visible once at ERROR and
    record no metrics — without raising out of the success path and without
    per-request log spam. Mirrors the v1 fix against the silent-no-op failure mode.
    """
    import logging

    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import InMemoryMetricReader

    import litellm

    monkeypatch.setattr(
        litellm,
        "callback_settings",
        {
            "otel": {
                "attributes": {
                    "include_list": ["gen_ai.system"],
                    "exclude_list": ["hidden_params"],
                }
            }
        },
        raising=False,
    )

    cfg = OpenTelemetryV2Config(exporter="in_memory", enable_metrics=True)
    reader = InMemoryMetricReader()
    logger = OpenTelemetryV2(
        config=cfg,
        callback_name="otel",
        tracer_provider=providers.build_tracer_provider(cfg),
        meter_provider=MeterProvider(metric_readers=[reader]),
    )

    start = datetime.now(timezone.utc)
    end = start + timedelta(seconds=1)
    response_obj = {"usage": {"prompt_tokens": 1, "completion_tokens": 1}}

    with caplog.at_level(logging.ERROR, logger="LiteLLM"):
        # Neither call may raise; the bad filter is caught in the logger.
        asyncio.run(
            logger.async_log_success_event(
                _metric_success_kwargs(), response_obj, start, end
            )
        )
        asyncio.run(
            logger.async_log_success_event(
                _metric_success_kwargs(), response_obj, start, end
            )
        )

    assert _emitted_metric_names(reader) == set()  # nothing recorded
    errors = [
        r
        for r in caplog.records
        if r.levelno == logging.ERROR and "metric filter" in r.getMessage()
    ]
    assert len(errors) == 1  # logged once, second bad record does not re-log


def test_valid_metric_filter_records_six_metrics(monkeypatch):
    """The happy path: with no attribute filter, a successful LLM call records all
    six GenAI histograms, and the token metric keeps its input/output split."""
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import InMemoryMetricReader

    import litellm

    monkeypatch.setattr(litellm, "callback_settings", {}, raising=False)

    cfg = OpenTelemetryV2Config(exporter="in_memory", enable_metrics=True)
    reader = InMemoryMetricReader()
    logger = OpenTelemetryV2(
        config=cfg,
        callback_name="otel",
        tracer_provider=providers.build_tracer_provider(cfg),
        meter_provider=MeterProvider(metric_readers=[reader]),
    )

    start = datetime.now(timezone.utc)
    end = start + timedelta(seconds=2)
    kwargs = _metric_success_kwargs()
    kwargs["api_call_start_time"] = start.timestamp()
    kwargs["completion_start_time"] = (start + timedelta(seconds=0.5)).timestamp()
    kwargs["end_time"] = end.timestamp()
    kwargs["optional_params"] = {"stream": True}
    response_obj = {"usage": {"prompt_tokens": 5, "completion_tokens": 7}}

    asyncio.run(logger.async_log_success_event(kwargs, response_obj, start, end))

    assert _emitted_metric_names(reader) == {
        "gen_ai.client.operation.duration",
        "gen_ai.client.token.usage",
        "gen_ai.usage.cost",
        "gen_ai.server.time_to_first_token",
        "gen_ai.server.time_per_output_token",
        "gen_ai.client.response.duration",
    }

    data = reader.get_metrics_data()
    token_types = {
        dp.attributes.get("gen_ai.token.type")
        for rm in data.resource_metrics
        for sm in rm.scope_metrics
        for m in sm.metrics
        if m.name == "gen_ai.client.token.usage"
        for dp in m.data.data_points
    }
    assert token_types == {"input", "output"}


def test_metrics_disabled_by_default_records_nothing(monkeypatch):
    """With ``enable_metrics`` off (the default), no meter is built and a success
    event records nothing — the default behavior must stay unchanged."""
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import InMemoryMetricReader

    import litellm

    monkeypatch.setattr(litellm, "callback_settings", {}, raising=False)

    cfg = OpenTelemetryV2Config(exporter="in_memory")  # enable_metrics defaults False
    reader = InMemoryMetricReader()
    logger = OpenTelemetryV2(
        config=cfg,
        callback_name="otel",
        tracer_provider=providers.build_tracer_provider(cfg),
        meter_provider=MeterProvider(metric_readers=[reader]),
    )
    assert logger._metrics_recorder is None

    start = datetime.now(timezone.utc)
    end = start + timedelta(seconds=1)
    asyncio.run(
        logger.async_log_success_event(
            _metric_success_kwargs(),
            {"usage": {"prompt_tokens": 1, "completion_tokens": 1}},
            start,
            end,
        )
    )
    assert _emitted_metric_names(reader) == set()


# --------------------------------------------------------------------------- #
#  Per-request Phoenix project routing (key/team auth metadata)
# --------------------------------------------------------------------------- #


def _phoenix_routing_logger(capture_kind):
    """A Phoenix-shaped logger whose owned exporter is a registered factory kind
    that captures the exporter built per routed header set, so the test can
    assert which destination each span actually exported through."""
    captured = {}

    def factory(spec):
        exporter = InMemorySpanExporter()
        captured[spec.headers] = exporter
        return exporter

    providers.register_exporter_factory(capture_kind, factory)
    cfg = OpenTelemetryV2Config(
        exporters=[
            ExporterSpec(
                kind=capture_kind,
                endpoint="http://phoenix:6006",
                headers="Authorization=Bearer phoenix-key",
                owner="arize_phoenix",
            )
        ]
    )
    default_exporter = InMemorySpanExporter()
    tracer_provider = providers.build_tracer_provider(cfg, exporter=default_exporter)
    logger = OpenTelemetryV2(
        config=cfg, callback_name="arize_phoenix", tracer_provider=tracer_provider
    )
    return logger, default_exporter, captured


def test_key_team_auth_metadata_routes_llm_span_to_phoenix_project():
    """The proxy stamps the key/team config into ``user_api_key_auth_metadata``;
    a ``phoenix_project_name`` there must route the LLM span through an exporter
    carrying the ``x-project-name`` header while keeping the preset's auth."""
    logger, default_exporter, captured = _phoenix_routing_logger("capture_route_a")
    auth_md = {"phoenix_project_name": "team-proj"}
    payload = _payload(metadata={"user_api_key_auth_metadata": auth_md})
    kwargs = {
        "standard_logging_object": payload,
        "litellm_params": {"metadata": {"user_api_key_auth_metadata": auth_md}},
    }
    _emit_llm(logger, kwargs)

    assert [s.name for s in default_exporter.get_finished_spans()] == []
    (headers,) = captured
    parsed = providers.parse_headers(headers)
    assert parsed["x-project-name"] == "team-proj"
    assert parsed["authorization"] == "Bearer phoenix-key"
    routed_spans = captured[headers].get_finished_spans()
    assert len(routed_spans) == 1
    assert routed_spans[0].parent is None  # own trace, so Phoenix can route it


def test_client_request_metadata_cannot_route_phoenix_project():
    """A bare ``phoenix_project_name`` in client request metadata (not the
    server-set ``user_api_key_auth_metadata``) must be ignored: the span stays
    on the default tracer and no routed exporter is ever built."""
    logger, default_exporter, captured = _phoenix_routing_logger("capture_route_b")
    payload = _payload(metadata={"phoenix_project_name": "attacker-project"})
    kwargs = {
        "standard_logging_object": payload,
        "litellm_params": {"metadata": {"phoenix_project_name": "attacker-project"}},
    }
    _emit_llm(logger, kwargs)

    assert captured == {}
    assert len(default_exporter.get_finished_spans()) == 1


def test_project_routing_resolves_at_pre_call_before_payload_exists():
    """Production ``pre_call`` runs before the standard logging payload exists,
    so the destination project must resolve from ``litellm_params`` alone — the
    span is created (and its exporter chosen) right there."""
    logger, default_exporter, captured = _phoenix_routing_logger("capture_route_c")
    auth_md = {"phoenix_project_name": "team-proj"}
    litellm_params = {"metadata": {"user_api_key_auth_metadata": auth_md}}
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    with trace.use_span(server, end_on_exit=False):
        logger.log_pre_api_call(
            model="gpt-4o",
            messages=[],
            kwargs={"litellm_call_id": "call_1", "litellm_params": litellm_params},
        )
    server.end()
    assert len(captured) == 1  # routed exporter already built at pre_call

    close_kwargs = {
        "standard_logging_object": _payload(
            metadata={"user_api_key_auth_metadata": auth_md}
        ),
        "litellm_params": litellm_params,
    }
    asyncio.run(logger.async_log_success_event(close_kwargs, None, None, None))

    (headers,) = captured
    (routed_span,) = captured[headers].get_finished_spans()
    assert routed_span.name == "chat gpt-4o"
    # Phoenix pins a whole trace to one project by its first-arriving span, so
    # the routed span must root its OWN trace, linked back to the request trace.
    assert routed_span.parent is None
    (link,) = routed_span.links
    assert link.context.span_id == server.get_span_context().span_id
    assert all(
        s.name != "chat gpt-4o" for s in default_exporter.get_finished_spans()
    )


def test_evicted_provider_still_exports_span_opened_before_eviction(monkeypatch):
    """LRU eviction while a routed span is still open must defer the provider
    shutdown: the span opened at ``pre_call`` closes at the later success
    callback and would otherwise be silently dropped instead of exported."""
    from litellm.integrations.otel.plumbing import routing as routing_mod

    monkeypatch.setattr(routing_mod, "_MAX_CACHED_PROVIDERS", 1)
    logger, _default_exporter, captured = _phoenix_routing_logger("capture_evict")
    md_a = {"user_api_key_auth_metadata": {"phoenix_project_name": "proj-a"}}
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    with trace.use_span(server, end_on_exit=False):
        logger.log_pre_api_call(
            model="gpt-4o",
            messages=[],
            kwargs={"litellm_call_id": "call_a", "litellm_params": {"metadata": md_a}},
        )

    # A second project's full call overflows the size-1 LRU and evicts proj-a's
    # provider while call_a's span is still open.
    md_b = {"user_api_key_auth_metadata": {"phoenix_project_name": "proj-b"}}
    _emit_llm(
        logger,
        {
            "standard_logging_object": _payload(litellm_call_id="call_b", metadata=md_b),
            "litellm_params": {"metadata": md_b},
        },
    )

    asyncio.run(
        logger.async_log_success_event(
            {
                "standard_logging_object": _payload(litellm_call_id="call_a", metadata=md_a),
                "litellm_params": {"metadata": md_a},
            },
            None,
            None,
            None,
        )
    )
    server.end()

    headers_a = next(h for h in captured if "proj-a" in h)
    assert [s.name for s in captured[headers_a].get_finished_spans()] == ["chat gpt-4o"]


def test_deferred_pre_call_does_not_churn_tenant_cache(monkeypatch):
    """Deferred ``pre_call`` must not create or LRU-touch a tenant provider.

    ``route_for`` used to run before the recordable-parent check, so a
    thread-pool ``pre_call`` that immediately released its hold still built a
    provider and could evict an idle one. Close re-routes when the span
    actually opens.
    """
    from litellm.integrations.otel.plumbing import routing as routing_mod

    monkeypatch.setattr(routing_mod, "_MAX_CACHED_PROVIDERS", 1)
    shut_down = []
    monkeypatch.setattr(routing_mod, "_shutdown_provider", lambda p: shut_down.append(p))
    logger, _default, captured = _phoenix_routing_logger("capture_deferred_churn")
    md_a = {"user_api_key_auth_metadata": {"phoenix_project_name": "proj-a"}}
    server = logger._emitter.start_span(
        SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME
    )
    with trace.use_span(server, end_on_exit=False):
        _emit_llm(
            logger,
            {
                "standard_logging_object": _payload(litellm_call_id="call_a", metadata=md_a),
                "litellm_params": {"metadata": md_a},
            },
            ambient=server,
        )
    assert len(logger._tenant_tracers._providers) == 1
    idle = next(iter(logger._tenant_tracers._providers.values()))
    assert shut_down == []

    md_b = {"user_api_key_auth_metadata": {"phoenix_project_name": "proj-b"}}
    deferred_kwargs = {
        "litellm_call_id": "call_b",
        "standard_logging_object": _payload(litellm_call_id="call_b", metadata=md_b),
        "litellm_params": {"metadata": md_b},
    }
    logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=deferred_kwargs)
    carrier = logger._open_llm_calls["call_b"]
    assert carrier.span is None
    assert carrier.provider is None
    assert list(logger._tenant_tracers._providers.values()) == [idle]
    assert shut_down == []
    assert captured and all("proj-b" not in headers for headers in captured)

    asyncio.run(logger.async_log_success_event(deferred_kwargs, None, None, None))
    server.end()
    headers_b = next(h for h in captured if "proj-b" in h)
    assert [s.name for s in captured[headers_b].get_finished_spans()] == ["chat gpt-4o"]


# --- New Relic team-scoped deferred emit + dedup (no pre_call carrier) --- #


def test_no_span_when_request_never_reached_upstream():
    """A request rejected before the upstream call — at the auth/budget gate, or
    blocked by a pre-call guardrail — carries the ``no upstream call`` marker
    (stamped in ``proxy/utils.py`` before its handlers fire), so the failure log
    produces no phantom CLIENT span even though a payload exists."""
    from litellm.constants import LITELLM_LOGGING_NO_UPSTREAM_LLM_CALL

    logger, exporter = _logger()
    payload = _payload(
        status="failure",
        error_information={"error_class": "ProxyException", "error_code": "401"},
    )
    kwargs = _kwargs(payload=payload)
    kwargs[LITELLM_LOGGING_NO_UPSTREAM_LLM_CALL] = True
    # No log_pre_api_call: the call never started.
    asyncio.run(logger.async_log_failure_event(kwargs, None, None, None))
    assert exporter.get_finished_spans() == ()  # no phantom LLM span


def test_success_without_pre_call_emits_deferred_span():
    """A team/key-scoped logger is registered as a success callback only, so
    ``pre_call`` never reaches it and no carrier exists. A completed call (it has
    its payload, no ``no upstream call`` marker) must still get its span — the
    deferred branch — or team-scoped destinations receive nothing at all."""
    logger, exporter = _logger()
    # No log_pre_api_call: this logger never receives the input hook. The
    # request-level provider-handoff stamp is present (pre_call ran globally).
    asyncio.run(
        logger.async_log_success_event({**_kwargs(), "api_call_start_time": 100.0}, None, 100.0, 101.5)
    )
    spans = exporter.get_finished_spans()
    assert len(spans) == 1
    assert spans[0].attributes.get("gen_ai.operation.name")
    # Start time comes from the callback's start_time, not a bogus zero.
    assert spans[0].start_time == 100_000_000_000
    assert spans[0].end_time == 101_500_000_000


def test_no_carrier_and_no_payload_is_noop():
    logger, exporter = _logger()
    asyncio.run(
        logger.async_log_success_event({"litellm_params": {}}, None, None, None)
    )
    assert exporter.get_finished_spans() == ()


def test_second_close_for_same_call_does_not_duplicate_span():
    """Success and failure can both fire on one logging object for the same call
    id. The first close pops the carrier and finishes the boundary span; the
    second must dedup against it, not fabricate a duplicate through the
    deferred branch."""
    logger, exporter = _logger()
    kwargs = {**_kwargs(), "api_call_start_time": 100.0}
    # Boundary open: the span is born at pre_call under a live server span and
    # closed via finish_span, which never passes through emit()'s dedup.
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    _emit_llm(logger, kwargs, ambient=server)
    server.end()
    llm_before = [s for s in exporter.get_finished_spans() if s.name.startswith("chat")]
    assert len(llm_before) == 1
    # Second close: carrier already popped, payload still present, handoff stamped.
    asyncio.run(logger.async_log_failure_event(kwargs, None, None, None))
    llm_after = [s for s in exporter.get_finished_spans() if s.name.startswith("chat")]
    assert len(llm_after) == 1


def test_failure_without_pre_call_emits_deferred_error_span():
    """A team-scoped logger registered as a failure callback only still gets an
    ERROR span for a real provider failure (payload present, no marker)."""
    from opentelemetry.trace import StatusCode

    logger, exporter = _logger()
    payload = _payload(
        status="failure",
        error_information={"error_class": "RateLimitError", "error_code": "429"},
    )
    asyncio.run(
        logger.async_log_failure_event(
            {**_kwargs(payload=payload), "api_call_start_time": 100.0}, None, None, None
        )
    )
    spans = exporter.get_finished_spans()
    assert len(spans) == 1
    assert spans[0].status.status_code == StatusCode.ERROR


def test_boundary_open_with_no_payload_ends_provisional_span():
    """Opened at pre_call but the payload never materialized: the boundary span
    is ended provisionally (no payload attributes) rather than leaked open."""
    logger, exporter = _logger()
    kwargs = _kwargs()
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    with trace.use_span(server, end_on_exit=False):
        logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    asyncio.run(
        logger.async_log_success_event(
            {**kwargs, "standard_logging_object": None, "litellm_call_id": "call_1"}, None, None, None
        )
    )
    server.end()
    llm_spans = [s for s in exporter.get_finished_spans() if s.name.startswith("chat")]
    assert len(llm_spans) == 1
    assert "gen_ai.usage.input_tokens" not in llm_spans[0].attributes


def test_failure_before_provider_handoff_emits_nothing():
    """A failure event whose request never handed off to a provider (router
    pre-call rejection, SDK error before the call, standalone guardrail run)
    has a payload but no ``api_call_start_time``; without a carrier it must not
    fabricate an LLM-call span."""
    logger, exporter = _logger()
    payload = _payload(
        status="failure",
        error_information={"error_class": "RateLimitError", "error_code": "429"},
    )
    asyncio.run(logger.async_log_failure_event(_kwargs(payload=payload), None, None, None))
    assert exporter.get_finished_spans() == ()


def test_provisional_close_then_payload_close_does_not_duplicate():
    """Streaming shape: the success close arrives with no assembled payload (the
    boundary span is ended provisionally), then the failure close arrives with a
    payload for the same call id. Exactly one exported span."""
    logger, exporter = _logger()
    kwargs = {**_kwargs(), "api_call_start_time": 100.0}
    payload = kwargs["standard_logging_object"]
    server = logger._emitter.start_span(SpanRole.PROXY_REQUEST, LITELLM_PROXY_REQUEST_SPAN_NAME)
    with trace.use_span(server, end_on_exit=False):
        logger.log_pre_api_call(model="gpt-4o", messages=[], kwargs=kwargs)
    asyncio.run(
        logger.async_log_success_event(
            {**kwargs, "standard_logging_object": None, "litellm_call_id": payload["litellm_call_id"]},
            None,
            None,
            None,
        )
    )
    asyncio.run(logger.async_log_failure_event(kwargs, None, None, None))
    server.end()
    llm_spans = [s for s in exporter.get_finished_spans() if s.name.startswith("chat")]
    assert len(llm_spans) == 1
