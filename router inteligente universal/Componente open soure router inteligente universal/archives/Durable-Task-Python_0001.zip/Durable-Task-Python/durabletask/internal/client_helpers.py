# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from __future__ import annotations

import logging
import uuid
from collections.abc import Sequence
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, TypeVar

from google.protobuf import duration_pb2, wrappers_pb2

import durabletask.internal.helpers as helpers
import durabletask.internal.orchestrator_service_pb2 as pb
import durabletask.internal.shared as shared
from durabletask import task
from durabletask.internal.grpc_interceptor import (
    DefaultAsyncClientInterceptorImpl,
    DefaultClientInterceptorImpl,
)

if TYPE_CHECKING:
    from durabletask.client import (
        EntityQuery,
        OrchestrationQuery,
        OrchestrationState,
        OrchestrationStatus,
    )
    from durabletask.entities import EntityInstanceId
    from durabletask.serialization import DataConverter

TInput = TypeVar('TInput')
TOutput = TypeVar('TOutput')


def _serialize(value: Any, data_converter: DataConverter | None) -> str | None:
    """Serialize ``value`` using the supplied converter, defaulting to the SDK's."""
    if data_converter is None:
        from durabletask.serialization import DEFAULT_DATA_CONVERTER
        data_converter = DEFAULT_DATA_CONVERTER
    return data_converter.serialize(value)


def prepare_sync_interceptors(
        metadata: list[tuple[str, str]] | None,
        interceptors: Sequence[shared.ClientInterceptor] | None
) -> list[shared.ClientInterceptor] | None:
    """Prepare the list of sync gRPC interceptors, adding a metadata interceptor if needed."""
    result: list[shared.ClientInterceptor] | None = None
    if interceptors is not None:
        result = list(interceptors)
        if metadata is not None:
            result.append(DefaultClientInterceptorImpl(metadata))
    elif metadata is not None:
        result = [DefaultClientInterceptorImpl(metadata)]
    return result


def prepare_async_interceptors(
        metadata: list[tuple[str, str]] | None,
        interceptors: Sequence[shared.AsyncClientInterceptor] | None
) -> list[shared.AsyncClientInterceptor] | None:
    """Prepare the list of async gRPC interceptors, adding a metadata interceptor if needed."""
    result: list[shared.AsyncClientInterceptor] | None = None
    if interceptors is not None:
        result = list(interceptors)
        if metadata is not None:
            result.append(DefaultAsyncClientInterceptorImpl(metadata))
    elif metadata is not None:
        result = [DefaultAsyncClientInterceptorImpl(metadata)]
    return result


def build_schedule_new_orchestration_req(
        orchestrator: task.Orchestrator[TInput, TOutput] | str, *,
        input: TInput | None,
        instance_id: str | None,
        start_at: datetime | None,
        reuse_id_policy: pb.OrchestrationIdReusePolicy | None,
        tags: dict[str, str] | None,
        version: str | None,
        data_converter: DataConverter) -> pb.CreateInstanceRequest:
    """Build a CreateInstanceRequest for scheduling a new orchestration."""
    name = orchestrator if isinstance(orchestrator, str) else task.get_name(orchestrator)
    return pb.CreateInstanceRequest(
        name=name,
        instanceId=instance_id if instance_id else uuid.uuid4().hex,
        input=helpers.get_string_value(data_converter.serialize(input)),
        scheduledStartTimestamp=helpers.new_timestamp(start_at) if start_at else None,
        version=helpers.get_string_value(version),
        orchestrationIdReusePolicy=reuse_id_policy,
        tags=tags
    )


def build_query_instances_req(
        orchestration_query: OrchestrationQuery,
        continuation_token: wrappers_pb2.StringValue | None) -> pb.QueryInstancesRequest:
    """Build a QueryInstancesRequest from an OrchestrationQuery."""
    return pb.QueryInstancesRequest(
        query=pb.InstanceQuery(
            runtimeStatus=[status.value for status in orchestration_query.runtime_status] if orchestration_query.runtime_status else None,
            createdTimeFrom=helpers.new_timestamp(orchestration_query.created_time_from) if orchestration_query.created_time_from else None,
            createdTimeTo=helpers.new_timestamp(orchestration_query.created_time_to) if orchestration_query.created_time_to else None,
            instanceIdPrefix=helpers.get_string_value(orchestration_query.instance_id_prefix),
            maxInstanceCount=orchestration_query.max_instance_count,
            fetchInputsAndOutputs=orchestration_query.fetch_inputs_and_outputs,
            continuationToken=continuation_token
        )
    )


def build_purge_by_filter_req(
        created_time_from: datetime | None,
        created_time_to: datetime | None,
        runtime_status: list[OrchestrationStatus] | None,
        recursive: bool,
        timeout: timedelta | None = None) -> pb.PurgeInstancesRequest:
    """Build a PurgeInstancesRequest for purging orchestrations by filter."""
    if timeout is not None and timeout <= timedelta():
        raise ValueError("timeout must be greater than zero.")

    purge_filter = pb.PurgeInstanceFilter(
        createdTimeFrom=helpers.new_timestamp(created_time_from) if created_time_from else None,
        createdTimeTo=helpers.new_timestamp(created_time_to) if created_time_to else None,
        runtimeStatus=[status.value for status in runtime_status] if runtime_status else None
    )
    if timeout is not None:
        timeout_duration = duration_pb2.Duration()
        timeout_duration.FromTimedelta(timeout)
        purge_filter.timeout.CopyFrom(timeout_duration)

    return pb.PurgeInstancesRequest(
        purgeInstanceFilter=purge_filter,
        recursive=recursive
    )


def build_query_entities_req(
        entity_query: EntityQuery,
        continuation_token: wrappers_pb2.StringValue | None) -> pb.QueryEntitiesRequest:
    """Build a QueryEntitiesRequest from an EntityQuery."""
    return pb.QueryEntitiesRequest(
        query=pb.EntityQuery(
            instanceIdStartsWith=helpers.get_string_value(entity_query.instance_id_starts_with),
            lastModifiedFrom=helpers.new_timestamp(entity_query.last_modified_from) if entity_query.last_modified_from else None,
            lastModifiedTo=helpers.new_timestamp(entity_query.last_modified_to) if entity_query.last_modified_to else None,
            includeState=entity_query.include_state,
            includeTransient=entity_query.include_transient,
            pageSize=helpers.get_int_value(entity_query.page_size),
            continuationToken=continuation_token
        )
    )


def check_continuation_token(
        resp_token: wrappers_pb2.StringValue | None,
        prev_token: wrappers_pb2.StringValue | None,
        logger: logging.Logger) -> bool:
    """Check if a continuation token indicates more pages. Returns True to continue, False to stop."""
    if resp_token and resp_token.value and resp_token.value != "0":
        logger.info(f"Received continuation token with value {resp_token.value}, fetching next page...")
        if prev_token and prev_token.value and prev_token.value == resp_token.value:
            logger.warning(f"Received the same continuation token value {resp_token.value} again, stopping to avoid infinite loop.")
            return False
        return True
    return False


def log_completion_state(
        logger: logging.Logger,
        instance_id: str,
        state: OrchestrationState | None) -> None:
    """Log the final state of a completed orchestration."""
    if not state:
        return
    # Compare against proto constants to avoid circular imports with client.py
    status_val = state.runtime_status.value
    if status_val == pb.ORCHESTRATION_STATUS_FAILED and state.failure_details is not None:
        details = state.failure_details
        logger.info(f"Instance '{instance_id}' failed: [{details.error_type}] {details.message}")
    elif status_val == pb.ORCHESTRATION_STATUS_TERMINATED:
        logger.info(f"Instance '{instance_id}' was terminated.")
    elif status_val == pb.ORCHESTRATION_STATUS_COMPLETED:
        logger.info(f"Instance '{instance_id}' completed.")


def build_raise_event_req(
        instance_id: str,
        event_name: str,
        data: Any | None = None,
        data_converter: DataConverter | None = None) -> pb.RaiseEventRequest:
    """Build a RaiseEventRequest for raising an orchestration event."""
    return pb.RaiseEventRequest(
        instanceId=instance_id,
        name=event_name,
        input=helpers.get_string_value(_serialize(data, data_converter))
    )


def build_terminate_req(
        instance_id: str,
        output: Any | None = None,
        recursive: bool = True,
        data_converter: DataConverter | None = None) -> pb.TerminateRequest:
    """Build a TerminateRequest for terminating an orchestration."""
    return pb.TerminateRequest(
        instanceId=instance_id,
        output=helpers.get_string_value(_serialize(output, data_converter)),
        recursive=recursive
    )


def build_signal_entity_req(
        entity_instance_id: EntityInstanceId,
        operation_name: str,
        input: Any | None = None,
        signal_time: datetime | None = None,
        data_converter: DataConverter | None = None) -> pb.SignalEntityRequest:
    """Build a SignalEntityRequest for signaling an entity."""
    scheduled_time = helpers.new_timestamp(signal_time) if signal_time is not None else None
    return pb.SignalEntityRequest(
        instanceId=str(entity_instance_id),
        name=operation_name,
        input=helpers.get_string_value(_serialize(input, data_converter)),
        requestId=str(uuid.uuid4()),
        scheduledTime=scheduled_time,
        parentTraceContext=None,
        requestTime=helpers.new_timestamp(datetime.now(timezone.utc))
    )
