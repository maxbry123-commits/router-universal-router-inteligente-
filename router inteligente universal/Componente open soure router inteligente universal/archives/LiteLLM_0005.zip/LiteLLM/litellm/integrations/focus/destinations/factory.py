"""Factory helpers for Focus export destinations."""

from __future__ import annotations

import os
from typing import Any, Final

from .base import FocusDestination
from .gcs_destination import FocusGCSDestination
from .mavvrik_destination import FocusMavvrikDestination
from .s3_destination import FocusS3Destination
from .vantage_destination import FocusVantageDestination


class FocusDestinationFactory:
    """Builds destination instances based on provider/config settings."""

    @staticmethod
    def create(
        *,
        provider: str,
        prefix: str,
        config: dict[str, Any] | None = None,
    ) -> FocusDestination:
        """Return a destination implementation for the requested provider."""
        provider_lower: Final = provider.lower()
        normalized_config = FocusDestinationFactory._resolve_config(provider=provider_lower, overrides=config or {})
        if provider_lower == "s3":
            return FocusS3Destination(prefix=prefix, config=normalized_config)
        if provider_lower == "vantage":
            return FocusVantageDestination(prefix=prefix, config=normalized_config)
        if provider_lower == "gcs":
            return FocusGCSDestination(prefix=prefix, config=normalized_config)
        if provider_lower == "mavvrik":
            return FocusMavvrikDestination(prefix=prefix, config=normalized_config)
        raise NotImplementedError(f"Provider '{provider}' not supported for Focus export")

    @staticmethod
    def _resolve_config(
        *,
        provider: str,
        overrides: dict[str, Any],
    ) -> dict[str, Any]:
        if provider == "s3":
            resolved = {
                "bucket_name": overrides.get("bucket_name") or os.getenv("FOCUS_S3_BUCKET_NAME"),
                "region_name": overrides.get("region_name") or os.getenv("FOCUS_S3_REGION_NAME"),
                "endpoint_url": overrides.get("endpoint_url") or os.getenv("FOCUS_S3_ENDPOINT_URL"),
                "aws_access_key_id": overrides.get("aws_access_key_id") or os.getenv("FOCUS_S3_ACCESS_KEY"),
                "aws_secret_access_key": overrides.get("aws_secret_access_key") or os.getenv("FOCUS_S3_SECRET_KEY"),
                "aws_session_token": overrides.get("aws_session_token") or os.getenv("FOCUS_S3_SESSION_TOKEN"),
            }
            if not resolved.get("bucket_name"):
                raise ValueError("FOCUS_S3_BUCKET_NAME must be provided for S3 exports")
            return {k: v for k, v in resolved.items() if v is not None}
        if provider == "vantage":
            resolved = {
                "api_key": overrides.get("api_key") or os.getenv("VANTAGE_API_KEY"),
                "integration_token": overrides.get("integration_token") or os.getenv("VANTAGE_INTEGRATION_TOKEN"),
                "base_url": overrides.get("base_url") or os.getenv("VANTAGE_BASE_URL", "https://api.vantage.sh"),
            }
            if not resolved.get("api_key"):
                raise ValueError("VANTAGE_API_KEY must be provided for Vantage exports")
            if not resolved.get("integration_token"):
                raise ValueError("VANTAGE_INTEGRATION_TOKEN must be provided for Vantage exports")
            return {k: v for k, v in resolved.items() if v is not None}
        if provider == "gcs":
            resolved = {
                "bucket_name": overrides.get("bucket_name") or os.getenv("FOCUS_GCS_BUCKET_NAME"),
                "service_account_json": overrides.get("service_account_json")
                or os.getenv("FOCUS_GCS_PATH_SERVICE_ACCOUNT"),
            }
            if not resolved.get("bucket_name"):
                raise ValueError("FOCUS_GCS_BUCKET_NAME must be provided for GCS exports")
            return {k: v for k, v in resolved.items() if v is not None}
        if provider == "mavvrik":
            resolved = {
                "api_key": overrides.get("api_key") or os.getenv("MAVVRIK_API_KEY"),
                "api_endpoint": overrides.get("api_endpoint") or os.getenv("MAVVRIK_API_ENDPOINT"),
                "connection_id": overrides.get("connection_id") or os.getenv("MAVVRIK_CONNECTION_ID"),
            }
            return {k: v for k, v in resolved.items() if v is not None}
        raise NotImplementedError(f"Provider '{provider}' not supported for Focus export configuration")
