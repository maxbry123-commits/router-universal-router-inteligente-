"""Rubrik LiteLLM Plugin for prompt/response moderation and batch logging."""

import asyncio
import os
import random
import time
import uuid
from collections import Counter
from collections.abc import Awaitable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal, Optional, Protocol, TypedDict, overload

import httpx
from typing_extensions import Never, ReadOnly, Required

from litellm._logging import verbose_logger
from litellm.integrations.custom_batch_logger import CustomBatchLogger
from litellm.integrations.custom_guardrail import (
    CustomGuardrail,
    ModifyResponseException,
)
from litellm.litellm_core_utils.core_helpers import safe_deep_copy
from litellm.litellm_core_utils.model_param_helper import ModelParamHelper
from litellm.litellm_core_utils.prompt_templates.common_utils import (
    convert_content_list_to_str,
)
from litellm.llms.custom_httpx.http_handler import (
    get_async_httpx_client,
    httpxSpecialProvider,
)
from litellm.types.guardrails import GuardrailEventHooks
from litellm.types.llms.openai import AllMessageValues, ChatCompletionToolCallChunk
from litellm.types.utils import (
    ChatCompletionMessageToolCall,
    Function,
    GenericGuardrailAPIInputs,
    StandardLoggingPayload,
    StandardLoggingUserAPIKeyMetadata,
)

if TYPE_CHECKING:
    from litellm.litellm_core_utils.litellm_logging import (
        Logging as LiteLLMLoggingObj,
    )
    from litellm.proxy._types import UserAPIKeyAuth

_WEBHOOK_PATH_RESPONSE_MODERATION: Final = "/v1/after_completion/openai/v1"
_WEBHOOK_PATH_PROMPT_MODERATION: Final = "/v1/before_prompt/openai/v1"
_WEBHOOK_PATH_LOGGING_BATCH: Final = "/v1/litellm/batch"
_MAX_QUEUE_SIZE: Final = 10_000
_DROP_WARNING_INTERVAL_SECONDS: Final = 60.0
_EMPTY_MAPPING: Final[Mapping[str, Never]] = MappingProxyType({})


class _ModerationToolCall(TypedDict, total=False):
    id: ReadOnly[Required[str]]


class _ModerationMessage(TypedDict, total=False):
    content: ReadOnly[str | None]
    tool_calls: ReadOnly[Sequence[_ModerationToolCall] | None]


class _ModerationChoice(TypedDict, total=False):
    message: ReadOnly[_ModerationMessage | None]


class _ModerationResponse(TypedDict, total=False):
    choices: ReadOnly[Sequence[_ModerationChoice]]


class _LogEventKwargs(TypedDict, total=False):
    standard_logging_object: ReadOnly[Required[StandardLoggingPayload]]
    litellm_call_id: ReadOnly[str]


class _HasCallId(Protocol):
    def get(self, key: Literal["litellm_call_id"], /) -> str | None: ...


class _HasModelAttr(Protocol):
    model: str | None


class _ResponseSource(Protocol):
    def get(self, key: Literal["response"], /) -> "_HasModelAttr | None": ...


class _ModelSource(Protocol):
    def get(self, key: Literal["model"], default: str, /) -> str: ...


class _FallbackSource(Protocol):
    @overload
    def get(self, key: Literal["start_time"], /) -> datetime | None: ...
    @overload
    def get(self, key: str, /) -> object | None: ...


class _RequestContextSource(Protocol):
    @overload
    def get(self, key: Literal["optional_params"], /) -> Mapping[str, object] | None: ...
    @overload
    def get(self, key: str, /) -> object | None: ...
    def __contains__(self, key: object, /) -> bool: ...
    def __getitem__(self, key: str, /) -> object: ...


class _ToolCallLike(Protocol):
    id: str | None
    type: str | None
    function: Function


class _ModerationSourceToolCall(TypedDict, total=False):
    function: ReadOnly[Mapping[str, object] | None]


class _ModerationSourceMessage(TypedDict, total=False):
    role: ReadOnly[str]
    function_call: ReadOnly[Mapping[str, object] | None]
    tool_calls: ReadOnly[Sequence[_ModerationSourceToolCall | None] | None]


class _FlattenedModerationMessage(TypedDict):
    role: ReadOnly[str | None]
    content: ReadOnly[str]


class _CorrelatablePayload(TypedDict):
    id: str  # writable-ok: _apply_correlation_id overwrites the provider id on a deep-copied payload


class _SystemPromptCarrier(TypedDict, total=False):
    messages: object  # writable-ok: _prepend_system_prompt rebinds messages on the copied payload by design


class _BlockFailurePayload(TypedDict, total=False):
    id: object  # writable-ok: correlation id is pinned after copying the base payload
    model: ReadOnly[object]
    model_group: ReadOnly[object]
    model_id: ReadOnly[str]
    model_parameters: ReadOnly[object]
    startTime: ReadOnly[float | None]
    endTime: ReadOnly[float | None]
    completionStartTime: ReadOnly[float | None]
    messages: object  # writable-ok: passed to _prepend_system_prompt, which rebinds messages
    metadata: ReadOnly[StandardLoggingUserAPIKeyMetadata]
    response: str  # writable-ok: block failure text replaces the copied response
    status: ReadOnly[str]


class _MalformedToolBlockingResponseError(Exception):
    """Raised when the response moderation service returns a structurally invalid
    response (e.g. empty ``choices``).

    Distinct from transient network/HTTP errors so callers can surface a
    louder, misconfiguration-style log instead of treating it as a routine
    fail-open.
    """


@dataclass
class BlockedResponseResult:
    """Returned by _extract_response_block when the response was blocked
    (response text replaced, or at least one tool call removed)."""

    explanation: str


class RubrikLogger(CustomGuardrail, CustomBatchLogger):
    def __init__(
        self,
        api_key: str | None = None,
        api_base: str | None = None,
        **kwargs,
    ):
        self.flush_lock = asyncio.Lock()
        kwargs.setdefault("guardrail_name", "rubrik")
        # `initialize_guardrail` always passes these kwargs explicitly, with
        # value `None` when the user omits `mode` / `default_on` from the
        # guardrail config. Follow the standard litellm convention: omitted
        # resolves to False (off by default, user must opt in explicitly).
        kwargs["event_hook"] = kwargs.get("event_hook") or GuardrailEventHooks.post_call
        if kwargs.get("default_on") is None:
            kwargs["default_on"] = False
        super().__init__(
            flush_lock=self.flush_lock,
            supported_event_hooks=list(self.get_supported_event_hooks()),
            **kwargs,
        )

        verbose_logger.debug("initializing rubrik logger")

        # Defining ``apply_guardrail`` routes streaming responses through
        # litellm's ``unified_guardrail.async_post_call_streaming_iterator_hook``.
        # By default that hook samples intermediate chunks
        # (``streaming_sampling_rate``, default 5) and also moderates at
        # end-of-stream, so a streamed response costs ~ceil(N/5)+1 Rubrik
        # webhook round-trips. litellm reads this attribute via
        # ``getattr(guardrail, "streaming_end_of_stream_only", False)``; when
        # True it yields chunks unprocessed and only moderates the fully
        # assembled response once at end of stream.
        self.streaming_end_of_stream_only = True

        # ``streaming_end_of_stream_only`` is detect-only: it releases every
        # chunk to the client *before* moderating, so a block can only append a
        # trailing message -- the original content has already been delivered.
        # ``streaming_buffer_until_moderated`` (litellm >= BerriAI/litellm#31389)
        # withholds all chunks until end-of-stream moderation passes, then
        # releases the original response (clean) or only the block message
        # (blocked). On older litellm this attribute is ignored and we fall
        # back to the detect-only behavior above.
        self.streaming_buffer_until_moderated = True

        self._parse_sampling_rate()

        self.key = api_key or os.getenv("RUBRIK_API_KEY")
        if not self.key:
            verbose_logger.warning("Rubrik: No API key configured. Requests will be unauthenticated.")

        self._parse_batch_size()

        # Cap the in-memory retry queue so a Rubrik webhook outage cannot let
        # authenticated traffic accumulate prompt/response payloads until the
        # proxy runs out of memory. Once the cap is reached, oldest events are
        # dropped to make room for fresh ones (drop-oldest backpressure).
        self.max_queue_size = _MAX_QUEUE_SIZE
        self._dropped_since_warning = 0
        self._last_drop_warning_time = 0.0

        _webhook_url = api_base or os.getenv("RUBRIK_WEBHOOK_URL")
        if not _webhook_url:
            raise ValueError("Rubrik webhook URL not configured. Set RUBRIK_WEBHOOK_URL or pass api_base.")

        _webhook_url = _webhook_url.rstrip("/").removesuffix("/v1")
        self._setup_clients(_webhook_url)

        self._headers: Mapping[str, str] = MappingProxyType(
            {"Content-Type": "application/json", "Authorization": f"Bearer {self.key}"}
            if self.key
            else {"Content-Type": "application/json"}
        )

        self._periodic_flush_task: asyncio.Task[None] | None = self._start_periodic_flush_task()

    @classmethod
    def get_supported_event_hooks(cls) -> list[GuardrailEventHooks]:
        """Return the guardrail event hooks this integration supports.

        Prompt moderation (``pre_call``) evaluates the user's message before
        the LLM is called. Response moderation (``post_call``) evaluates the
        assistant's reply and tool calls after the LLM returns.
        """
        return [GuardrailEventHooks.pre_call, GuardrailEventHooks.post_call]

    def _parse_sampling_rate(self) -> None:
        self.sampling_rate = 1.0
        rbrk_sampling_rate: Final = os.getenv("RUBRIK_SAMPLING_RATE")
        if rbrk_sampling_rate is not None:
            try:
                parsed_rate: Final = float(rbrk_sampling_rate.strip())
                self.sampling_rate = max(0.0, min(1.0, parsed_rate))
                if parsed_rate != self.sampling_rate:
                    verbose_logger.warning("RUBRIK_SAMPLING_RATE=%s clamped to %s", parsed_rate, self.sampling_rate)
            except ValueError:
                verbose_logger.warning("Invalid RUBRIK_SAMPLING_RATE: %r, using 1.0", rbrk_sampling_rate)

    def _parse_batch_size(self) -> None:
        _batch_size: Final = os.getenv("RUBRIK_BATCH_SIZE")
        if _batch_size:
            try:
                parsed_size: Final = int(_batch_size)
                if parsed_size <= 0:
                    verbose_logger.warning("RUBRIK_BATCH_SIZE=%r must be > 0, using default", _batch_size)
                else:
                    self.batch_size = parsed_size
            except ValueError:
                verbose_logger.warning("Invalid RUBRIK_BATCH_SIZE: %r, using default", _batch_size)

    def _setup_clients(self, webhook_url: str) -> None:
        self.response_moderation_endpoint = f"{webhook_url}{_WEBHOOK_PATH_RESPONSE_MODERATION}"
        self.prompt_moderation_endpoint = f"{webhook_url}{_WEBHOOK_PATH_PROMPT_MODERATION}"
        self.logging_endpoint = f"{webhook_url}{_WEBHOOK_PATH_LOGGING_BATCH}"

        self.async_httpx_client = get_async_httpx_client(llm_provider=httpxSpecialProvider.LoggingCallback)

        self.moderation_client = get_async_httpx_client(
            llm_provider=httpxSpecialProvider.LoggingCallback,
            params={"timeout": httpx.Timeout(5.0, connect=2.0)},
        )

    def _start_periodic_flush_task(self) -> asyncio.Task[None] | None:
        """Start the periodic flush task only when an event loop is already running."""
        try:
            loop: Final = asyncio.get_running_loop()
        except RuntimeError:
            return None
        return loop.create_task(self.periodic_flush())

    def _ensure_periodic_flush_task(self) -> None:
        if self._periodic_flush_task is None or self._periodic_flush_task.done():
            self._periodic_flush_task = self._start_periodic_flush_task()

    async def aclose(self):
        """Cancel the periodic flush task.

        ``moderation_client`` and ``async_httpx_client`` are shared objects
        from LiteLLM's global HTTP-client cache (``get_async_httpx_client``
        uses the same cache key for all instances with equal parameters).
        Closing them here would close the shared connection pool for every
        other logger instance; let LiteLLM manage their lifecycle instead.
        """
        task: Final[asyncio.Task[None] | None] = getattr(self, "_periodic_flush_task", None)
        if task is not None:
            task.cancel()

    # -- Guardrail hook --------------------------------------------------------

    async def apply_guardrail(
        self,
        inputs: GenericGuardrailAPIInputs,
        request_data: dict,
        input_type: Literal["request", "response"],
        logging_obj: Optional["LiteLLMLoggingObj"] = None,
    ) -> GenericGuardrailAPIInputs:
        """Moderate prompts (request) and responses (response); fail-open.

        - ``request``: evaluate the prompt via the before_prompt webhook and
          block disallowed prompts before the model is called.
        - ``response``: evaluate the assistant's response text and tool calls
          via the after_completion webhook and block on a policy violation.

        litellm's guardrail-translation layer normalizes Anthropic and OpenAI
        requests/responses into ``inputs`` before this runs, so a single code
        path covers both wire formats. The configured guardrail ``mode``
        selects which surface(s) run.
        """
        if input_type == "request":
            return await self._guarded(
                self._moderate_prompt(inputs, request_data, logging_obj),
                inputs,
                "Prompt moderation",
            )
        if input_type == "response":
            return await self._guarded(
                self._moderate_response(inputs, request_data, logging_obj),
                inputs,
                "Response moderation",
            )
        return inputs

    @staticmethod
    async def _guarded(
        coro: Awaitable[GenericGuardrailAPIInputs],
        inputs: GenericGuardrailAPIInputs,
        label: str,
    ) -> GenericGuardrailAPIInputs:
        """Await a moderation coroutine fail-open: re-raise an intentional
        block, log at critical for malformed service responses, and swallow
        any other error returning ``inputs`` unchanged."""
        try:
            return await coro
        except ModifyResponseException:
            raise
        except _MalformedToolBlockingResponseError as e:
            # The service responded but the payload was structurally invalid,
            # which usually indicates a misconfigured webhook or a breaking
            # change in its response format. Log loudly so operators notice
            # their moderation policy is not actually being enforced.
            verbose_logger.critical(
                "Response moderation service returned a malformed response: %s. "
                "Requests are NOT being checked -- verify the webhook "
                "configuration. Returning original inputs unchanged.",
                e,
                exc_info=True,
            )
            return inputs
        except Exception as e:
            verbose_logger.error(
                "%s hook failed: %s. Returning original inputs unchanged.",
                label,
                e,
                exc_info=True,
            )
            return inputs

    async def _moderate_response(
        self,
        inputs: GenericGuardrailAPIInputs,
        request_data: dict,
        logging_obj: Optional["LiteLLMLoggingObj"],
    ) -> GenericGuardrailAPIInputs:
        """Send response text + tool calls to the after_completion webhook and
        raise if either the response text or any tool call is blocked."""
        tool_calls: Final = inputs.get("tool_calls")
        texts: Final = inputs.get("texts")
        if not tool_calls and not texts:
            return inputs

        message_tool_calls: Final = self._normalize_tool_calls(tool_calls or ())
        sent_content: Final = self._join_texts(texts)

        call_details = getattr(logging_obj, "model_call_details", _EMPTY_MAPPING) if logging_obj else _EMPTY_MAPPING
        if logging_obj and not call_details:
            verbose_logger.warning(
                "Rubrik: logging_obj present but model_call_details is empty -- request context will be missing"
            )

        # The moderation payload's ``id`` becomes the tool-blocking log's
        # correlation key (the S3 filename), so it must match the failure
        # (response) log written for the same blocked request. Both use
        # ``litellm_call_id`` -- see ``_correlation_id``.
        request_id: Final = self._correlation_id(call_details, request_data)

        response_data: Final = self._build_response_moderation_payload(message_tool_calls, sent_content, request_id)
        req_data: Final = self._extract_request_data(call_details, request_data)

        service_response: Final = await self._post_to_response_moderation_endpoint(response_data, req_data)
        blocked: Final = self._extract_response_block(service_response, message_tool_calls, sent_content)

        if blocked:
            model: Final = self._resolve_model(request_data, call_details)
            self._stash_block_context(logging_obj, request_data)
            raise ModifyResponseException(
                message=blocked.explanation,
                model=model,
                request_data=request_data,
                guardrail_name=self.guardrail_name,
            )

        return inputs

    async def _moderate_prompt(
        self,
        inputs: GenericGuardrailAPIInputs,
        request_data: dict,
        logging_obj: Optional["LiteLLMLoggingObj"],
    ) -> GenericGuardrailAPIInputs:
        """Send the (normalized) prompt to the before_prompt webhook and raise
        if the prompt is blocked."""
        messages = inputs.get("structured_messages")
        if not messages:
            # For non-chat request types (e.g. /v1/completions), litellm
            # supplies the prompt as ``texts`` with no structured_messages.
            # Synthesise a user-message so the webhook can evaluate the prompt.
            texts: Final = inputs.get("texts")
            if texts:
                joined: Final = "\n".join(t for t in texts if t)
                if joined:
                    messages = [{"role": "user", "content": joined}]
        if not messages:
            return inputs

        payload: Final = self._build_prompt_moderation_payload(inputs, request_data)
        service_response: Final = await self._post_to_prompt_moderation_endpoint(payload)
        refusal: Final = self._extract_prompt_refusal(service_response)
        if refusal is None:
            return inputs

        model: Final = inputs.get("model") or request_data.get("model") or "unknown"
        self._stash_block_context(logging_obj, request_data)
        raise ModifyResponseException(
            message=refusal,
            model=model,
            request_data=request_data,
            guardrail_name=self.guardrail_name,
        )

    @staticmethod
    def _stash_block_context(
        logging_obj: Optional["LiteLLMLoggingObj"],
        request_data: dict[str, object],
    ) -> None:
        """Stash signals so the deferred success-event skips this request and
        ``async_post_call_failure_hook`` can build the failure payload.

        - Sets a flag on ``logging_obj.model_call_details`` so the deferred
          success-event handler short-circuits.
        - Stashes a reference to ``logging_obj`` on ``request_data`` under a
          custom key. ``ProxyLogging.post_call_failure_hook`` pops only
          ``litellm_logging_obj`` before iterating callbacks, so this key
          survives.

        When ``logging_obj`` is ``None`` the success-event has no way to
        observe the block (the flag has nowhere to live), so we log an error
        instead of silently dropping the signal.
        """
        if logging_obj is None:
            verbose_logger.error(
                "Rubrik: moderation block fired with logging_obj=None for "
                "litellm_call_id=%s; "
                "cannot suppress success event or attach failure payload.",
                request_data.get("litellm_call_id"),
            )
            request_data["_rubrik_logging_obj"] = None
            return
        logging_obj.model_call_details["_rubrik_blocked"] = True
        request_data["_rubrik_logging_obj"] = logging_obj

    @staticmethod
    def _normalize_tool_calls(
        tool_calls: Sequence[ChatCompletionToolCallChunk | ChatCompletionMessageToolCall | _ToolCallLike],
    ) -> tuple[ChatCompletionMessageToolCall, ...]:
        """Convert tool_calls from inputs to ChatCompletionMessageToolCall objects."""
        return tuple(RubrikLogger._normalize_tool_call(tc) for tc in tool_calls)

    @staticmethod
    def _normalize_tool_call(
        tc: ChatCompletionToolCallChunk | ChatCompletionMessageToolCall | _ToolCallLike,
    ) -> ChatCompletionMessageToolCall:
        if isinstance(tc, ChatCompletionMessageToolCall):
            return tc
        if isinstance(tc, dict):
            func: Final = tc.get("function") or _EMPTY_MAPPING
            return ChatCompletionMessageToolCall(
                id=tc.get("id", ""),
                type=tc.get("type", "function"),
                function=Function(
                    name=func.get("name", ""),
                    arguments=func.get("arguments", ""),
                ),
            )
        if hasattr(tc, "id") and hasattr(tc, "function"):
            return ChatCompletionMessageToolCall(
                id=tc.id or "",
                type=getattr(tc, "type", None) or "function",
                function=tc.function,
            )
        raise TypeError(f"Cannot normalize tool_call of type {type(tc).__name__}: {tc!r}")

    @staticmethod
    def _join_texts(texts: Sequence[str] | None) -> str:
        """Join response text segments into the single content string the
        webhook evaluates. Empty when there is no assistant text."""
        if not texts:
            return ""
        return "\n".join(t for t in texts if t)

    @staticmethod
    def _build_response_moderation_payload(
        tool_calls: Sequence[ChatCompletionMessageToolCall],
        content: str,
        request_id: str | None,
    ) -> Mapping[str, object]:
        """Build an OpenAI ChatCompletion-format dict (assistant text + tool
        calls) for the after_completion webhook.

        ``content`` is sent so the webhook can moderate the response text;
        ``None`` when the assistant produced no text (tool-call-only response).
        """
        message: Final[Mapping[str, object]] = {
            "role": "assistant",
            "content": content or None,
            **(
                {"tool_calls": tuple(tc.model_dump(exclude_none=True) for tc in tool_calls)}
                if tool_calls
                else _EMPTY_MAPPING
            ),
        }
        return {
            "id": request_id or f"chatcmpl-{uuid.uuid4()}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": "",
            "choices": [
                {
                    "index": 0,
                    "message": message,
                    "finish_reason": "tool_calls" if tool_calls else "stop",
                }
            ],
        }

    @staticmethod
    def _flatten_messages_for_moderation(
        messages: Sequence[AllMessageValues | None] | None,
    ) -> tuple[_FlattenedModerationMessage, ...]:
        """Collapse each message's content to a plain string for the webhook.

        litellm normalizes Anthropic ``/v1/messages`` requests to OpenAI shape,
        but a turn sent as content-parts (``[{"type": "text", ...}]``) stays a
        list. The before_prompt webhook reads ``content`` as a string and drops
        non-string content, so we flatten text parts here (images skipped, per
        ``convert_content_list_to_str``) -- otherwise block-content prompts
        would pass through unmoderated. Builds a new list; never mutates the
        shared ``structured_messages``.
        """
        return tuple(
            {
                "role": message.get("role"),
                "content": "\n".join(p for p in RubrikLogger._moderation_text_parts(message) if p),
            }
            for message in messages or ()
            if isinstance(message, dict)
        )

    @staticmethod
    def _moderation_text_parts(message: _ModerationSourceMessage) -> tuple[str, ...]:
        """Every attacker-controlled text segment of a message: its content plus
        the arguments of any tool call or deprecated function call."""
        fc: Final = message.get("function_call")
        return (
            # Base text content (flattens Anthropic content-part arrays)
            convert_content_list_to_str(message),  # pyright: ignore[reportArgumentType]  # dict[str,Any] is AllMessageValues at runtime
            *(
                str((tc.get("function") or _EMPTY_MAPPING).get("arguments") or "")
                for tc in message.get("tool_calls") or ()
                if isinstance(tc, dict)
            ),
            str((fc.get("arguments") if isinstance(fc, dict) else None) or ""),
        )

    @staticmethod
    def _build_prompt_moderation_payload(
        inputs: GenericGuardrailAPIInputs,
        request_data: Mapping[str, object],
    ) -> Mapping[str, object]:
        """Build the bare OpenAI request the before_prompt webhook consumes.

        Unlike the after_completion envelope, this endpoint takes a raw OpenAI
        chat-completions request. ``structured_messages`` is litellm's
        OpenAI-normalized view of the prompt, so this works for Anthropic
        ``/v1/messages`` requests too. Optional fields are sent only when
        present so the payload stays clean.
        """
        tools: Final = inputs.get("tools")
        user: Final = request_data.get("user")
        # Fall back to litellm_call_id, the stable cross-provider join key the
        # response/tool path uses (see _correlation_id). LiteLLM does not
        # populate request_data["correlation_key"]; it carries litellm_call_id.
        # The before_prompt webhook skips the *_prompt_moderation.json S3 write
        # when correlation_key is empty, so without this the block fires but no
        # log is ever written. An explicit correlation_key still wins.
        correlation_key: Final = request_data.get("correlation_key") or request_data.get("litellm_call_id")
        return {
            "model": inputs.get("model") or request_data.get("model") or "",
            "messages": RubrikLogger._flatten_messages_for_moderation(inputs.get("structured_messages")),
            **({"tools": tools} if tools is not None else _EMPTY_MAPPING),
            **({"user": user} if user else _EMPTY_MAPPING),
            **({"correlation_key": correlation_key} if correlation_key else _EMPTY_MAPPING),
        }

    @staticmethod
    def _extract_request_data(
        call_details: _RequestContextSource,
        request_data: _RequestContextSource | None,
    ) -> Mapping[str, object]:
        """Extract original request data from model_call_details for the
        response moderation service envelope.

        Includes the agent's declared ``tools`` (OpenAI-format) when available
        so the webhook's hallucination evaluator can compare returned tool calls
        against the declared tool list.
        """
        if not call_details and not request_data:
            return _EMPTY_MAPPING
        call_details = call_details or _EMPTY_MAPPING
        request_data = request_data or _EMPTY_MAPPING
        optional_params: Final = call_details.get("optional_params") or _EMPTY_MAPPING

        # Use ``in`` rather than truthy ``or`` so an explicit empty list
        # (caller declared the agent has NO tools) is forwarded as-is.
        # The response moderation service uses that signal to flag tool-call
        # hallucinations -- ``or`` would mask it by falling through to
        # optional_params.
        if "tools" in request_data:
            tools = request_data["tools"]
        else:
            tools = optional_params.get("tools")

        # The response moderation service consumes only messages/model/tools.
        # Don't forward proxy_server_request -- in litellm >=1.83 its ``body``
        # snapshot carries a UserAPIKeyAuth instance that breaks json.dumps,
        # silently fail-opening the guardrail.
        return {
            "messages": call_details.get("messages"),
            "model": call_details.get("model"),
            "tools": tools,
        }

    @staticmethod
    def _sanitize_proxy_server_request(proxy_server_request: Mapping[str, object] | str | None) -> object:
        """Allowlist only routing fields (``url``, ``method``) when forwarding
        ``proxy_server_request`` to an external webhook, dropping inbound
        ``headers`` (Authorization, Cookie, x-api-key, ...) and the raw
        request ``body`` so proxy credentials are not exfiltrated."""
        if not isinstance(proxy_server_request, dict):
            return proxy_server_request
        return {key: proxy_server_request[key] for key in ("url", "method") if key in proxy_server_request}

    @staticmethod
    def _resolve_model(request_data: _ResponseSource, call_details: _ModelSource) -> str:
        """Get the model name for the ModifyResponseException."""
        response: Final = request_data.get("response")
        if response and hasattr(response, "model"):
            return response.model or "unknown"
        return call_details.get("model", "unknown")

    # -- Logging hooks ---------------------------------------------------------

    @staticmethod
    def _correlation_id(
        call_details: _HasCallId | _LogEventKwargs, request_data: _HasCallId | None = None
    ) -> str | None:
        """The id that joins a blocked request's two S3 logs by filename: the
        moderation (``_blocking``) log and the failure (response) log.

        Always ``litellm_call_id``. It is assigned at request start and is
        present identically in both the guardrail path (``model_call_details``
        / ``request_data``) and the failure-hook path. Unlike ``response.id``
        or ``standard_logging_object["id"]`` it is immune to the race where a
        block fires before the response/logging object is populated, so the
        two logs correlate for every provider (OpenAI and Anthropic alike).
        """
        return call_details.get("litellm_call_id") or (request_data or _EMPTY_MAPPING).get("litellm_call_id")

    @classmethod
    def _apply_correlation_id(cls, payload: _CorrelatablePayload, source: _HasCallId | _LogEventKwargs) -> None:
        """Pin ``payload["id"]`` to ``litellm_call_id`` in place so this log
        shares its S3 filename id with the moderation (``_blocking``) and
        failure logs for the same request -- for every provider.

        ``standard_logging_object["id"]`` is the provider response id
        (``response_obj.get("id", litellm_call_id)``), a ``chatcmpl-*`` value
        for OpenAI, which would not correlate. ``litellm_call_id`` is assigned
        at request start and is identical across all log paths. Falls back to
        the existing id when ``litellm_call_id`` is somehow absent rather than
        writing a null filename key.

        ``source`` may be ``model_call_details`` directly or a ``kwargs`` dict
        that aliases it -- same shape either way.
        """
        correlated: Final = cls._correlation_id(source)
        if correlated:
            payload["id"] = correlated

    @staticmethod
    def _prepend_system_prompt(payload: _SystemPromptCarrier, source: Mapping[str, object]) -> None:
        """Prepend ``source["system"]`` onto ``payload["messages"]``.

        Builds a NEW messages list rather than mutating ``payload["messages"]``
        in place. The fallback branch of ``_prepare_block_failure_payload``
        aliases ``call_details["messages"]`` directly, so an in-place
        ``list.insert(0, ...)`` would mutate the shared source dict.

        No-op if no system prompt is present. Tolerates list/dict/str
        message shapes; on unexpected shape, leaves payload alone.
        """
        system_prompt: Final = source.get("system")
        if not system_prompt:
            return
        try:
            system_scaffold: Final = {"role": "system", "content": system_prompt}
            messages: Final = payload.get("messages")
            if isinstance(messages, list):
                payload["messages"] = (system_scaffold, *messages)
            elif isinstance(messages, (dict, str)):
                payload["messages"] = (system_scaffold, messages)
        except Exception as e:
            verbose_logger.warning(
                "Rubrik: failed to prepend system prompt: %s",
                e,
                exc_info=True,
            )

    async def _prepare_log_payload(self, kwargs: _LogEventKwargs, event_type: str) -> StandardLoggingPayload | None:
        """Shared logic for success logging (sampled)."""
        if random.random() > self.sampling_rate:
            verbose_logger.debug("Skipping Rubrik %s logging (sampling_rate=%s)", event_type, self.sampling_rate)
            return None

        # Deep-copy so mutations don't affect other callbacks sharing this object
        standard_logging_payload: Final[StandardLoggingPayload] = safe_deep_copy(kwargs["standard_logging_object"])

        self._apply_correlation_id(standard_logging_payload, kwargs)
        self._prepend_system_prompt(standard_logging_payload, kwargs)  # pyright: ignore[reportArgumentType]  # StandardLoggingPayload is dict[str,Any] at runtime

        return standard_logging_payload

    async def _append_and_maybe_flush(self, payload: Mapping[str, object]) -> None:
        self._ensure_periodic_flush_task()
        self.log_queue.append(payload)
        self._enforce_max_queue_size()
        if len(self.log_queue) >= self.batch_size:
            await self.flush_queue()

    def _enforce_max_queue_size(self) -> None:
        overflow: Final = len(self.log_queue) - self.max_queue_size
        if overflow <= 0:
            return
        del self.log_queue[:overflow]
        self._dropped_since_warning += overflow
        now: Final = time.time()
        if now - self._last_drop_warning_time >= _DROP_WARNING_INTERVAL_SECONDS:
            verbose_logger.warning(
                "Rubrik: log queue exceeded max_queue_size=%s; dropped %s "
                "oldest events since the last warning. The Rubrik webhook may "
                "be unhealthy or undersized for current traffic.",
                self.max_queue_size,
                self._dropped_since_warning,
            )
            self._dropped_since_warning = 0
            self._last_drop_warning_time = now

    async def _enqueue_log_event(self, kwargs: _LogEventKwargs, event_type: str):
        try:
            payload: Final = await self._prepare_log_payload(kwargs, event_type)
            if payload is None:
                return
            await self._append_and_maybe_flush(payload)
        except Exception as e:
            verbose_logger.error(
                "Rubrik %s logging hook failed: %s. Skipping logging for this event.",
                event_type,
                e,
                exc_info=True,
            )

    async def async_log_success_event(self, kwargs, response_obj, start_time, end_time):
        # Blocked requests are logged via async_post_call_failure_hook;
        # skip here to avoid double-logging the pre-block response.
        if kwargs.get("_rubrik_blocked"):
            verbose_logger.debug(
                "Rubrik: skipping success event for blocked request litellm_call_id=%s",
                kwargs.get("litellm_call_id"),
            )
            return
        await self._enqueue_log_event(kwargs, "success")

    async def async_log_failure_event(self, kwargs, response_obj, start_time, end_time):
        # Log regular LLM failures (timeouts, upstream errors, etc.) to Rubrik.
        # NOTE: ``ModifyResponseException`` blocks are NOT routed here; they
        # bypass ``Logging.async_failure_handler`` entirely and reach
        # ``async_post_call_failure_hook`` instead. So there is no risk of
        # double-logging a block through this path.
        await self._enqueue_log_event(kwargs, "failure")

    async def async_post_call_failure_hook(
        self,
        request_data: dict,
        original_exception: Exception,
        user_api_key_dict: "UserAPIKeyAuth",
        traceback_str: str | None = None,
    ) -> None:
        """Log blocked requests signalled via ``ModifyResponseException``
        (prompt blocks, response/tool blocks, streaming blocks).

        Carries the stashed ``_rubrik_logging_obj``. For every other
        exception we no-op; LiteLLM's standard failure plumbing handles those.
        """
        if not isinstance(original_exception, ModifyResponseException):
            return

        # Guard by guardrail_name so that when multiple Rubrik instances are
        # registered, only the instance that raised the block handles it.
        # The failure hook is called for every registered callback; without
        # this check the first instance pops the stash and the originating
        # instance finds None and silently skips logging.
        if getattr(original_exception, "guardrail_name", None) != self.guardrail_name:
            return

        logging_obj: Final = request_data.pop("_rubrik_logging_obj", None)
        if logging_obj is None:
            # Legitimate when a non-Rubrik guardrail raised the block;
            # problematic if Rubrik did and the stash was lost (e.g.
            # ``_stash_block_context`` ran with ``logging_obj=None``). Either
            # way we cannot build the payload.
            verbose_logger.warning(
                "Rubrik: block exception without stashed logging_obj. "
                "litellm_call_id=%s, "
                "model=%s, "
                "user_id=%s, "
                "raising_guardrail=%s",
                request_data.get("litellm_call_id"),
                request_data.get("model"),
                user_api_key_dict.user_id,
                getattr(original_exception, "guardrail_name", None),
            )
            return

        call_id: Final[str | None] = None
        await self._build_and_enqueue_block_event(logging_obj, original_exception, call_id, user_api_key_dict)

    async def _build_and_enqueue_block_event(
        self,
        logging_obj: "LiteLLMLoggingObj",
        exception: "ModifyResponseException",
        call_id: str | None,
        user_api_key_dict: "UserAPIKeyAuth",
    ) -> None:
        try:
            call_details: Final = logging_obj.model_call_details
            # Do NOT pop "_rubrik_blocked" here. The deferred success-handler
            # task may still be iterating callbacks, and popping mid-iteration
            # (between two awaited callback invocations) would cause this
            # plugin's success-event callback to read the flag as absent and
            # log the pre-block response -- the exact bug this hook exists to
            # prevent. The flag dies with model_call_details when the request
            # completes; there's nothing to clean up.
            call_id = call_details.get("litellm_call_id")
            payload: Final = self._prepare_block_failure_payload(logging_obj, exception, user_api_key_dict)
        except (AttributeError, ImportError, KeyError, TypeError) as e:
            verbose_logger.error(
                "Rubrik: failed to build blocked-tool payload for litellm_call_id=%s: %s. Event will NOT be logged.",
                call_id,
                e,
                exc_info=True,
            )
            return

        try:
            await self._append_and_maybe_flush(payload)
        except Exception as e:
            verbose_logger.error(
                "Rubrik: failed to enqueue blocked-tool event for litellm_call_id=%s: %s.",
                call_id,
                e,
                exc_info=True,
            )

    def _prepare_block_failure_payload(
        self,
        logging_obj: "LiteLLMLoggingObj",
        exception: "ModifyResponseException",
        user_api_key_dict: "UserAPIKeyAuth",
    ) -> _BlockFailurePayload:
        """Build a failure-style payload using the exception text as response.

        Blocked-tool events are security-relevant and **bypass sampling**:
        every block is logged.

        A non-streaming block always takes the fallback, and not because of a
        race: registering a post_call guardrail sets ``_defer_async_logging``,
        which parks the success handler that would have written
        ``standard_logging_object``, and ``_flush_deferred_async_logging``
        returns early once an exception was raised. Streaming requests never set
        that flag, so a streamed block can arrive with the object already
        populated; the branch below covers it and wins over the fallback.

        For prompt blocks the LLM is never called, so ``standard_logging_object``
        is never populated. The fallback therefore must carry enough fields to
        pass the log processor's ``LogEntry`` schema (``BaseLogEntry`` requires
        ``metadata``, ``model_id``, ``model_group``, ``model_parameters``,
        ``startTime``, ``endTime``, and ``completionStartTime``). Without a
        parseable payload the log processor discards the entry with a parse
        error and no session is created, so prompt-moderation violations are
        silently dropped even though the ``_prompt_moderation.json`` forensic
        log is written correctly.

        Field sourcing for the fallback path:
        - ``model`` / ``model_group``: ``call_details["model"]`` -- this is the
          model-group name (e.g. "gpt-4o") set by the proxy before the guardrail
          fires. The router writes ``metadata["model_group"]`` only inside
          ``acompletion()``, which hasn't run yet for a prompt block.
        - ``model_id``: not available before the LLM returns hidden_params;
          defaults to empty string.
        - caller identity: ``_caller_metadata`` off the ``user_api_key_dict``
          the failure hook is handed. The enriched litellm metadata lives under
          ``call_details["litellm_params"]["metadata"]``, never at the top
          level, so the previous top-level read resolved to an empty string for
          every block.
        - time fields: ``call_details["start_time"]`` reused for all three;
          end/completion times are meaningless for a prompt block.
        """
        call_details: Final = logging_obj.model_call_details
        exception_text: Final = f"{type(exception).__name__}: {exception.message}"

        base: Final[StandardLoggingPayload | None] = call_details.get("standard_logging_object")
        if base is not None:
            payload: _BlockFailurePayload = self._copy_block_payload_base(base)
        else:
            verbose_logger.debug(
                "Rubrik: standard_logging_object not yet on model_call_details "
                "for litellm_call_id=%s; "
                "using best-effort fallback payload.",
                call_details.get("litellm_call_id"),
            )
            payload = self._build_fallback_payload(call_details, user_api_key_dict)

        payload["response"] = exception_text

        # Pin the correlation key to litellm_call_id so this failure log shares
        # its S3 filename id with the moderation (``_blocking``) log for the
        # same request. The copied ``standard_logging_object["id"]`` is
        # ``response_obj.get("id", litellm_call_id)`` -- a provider ``chatcmpl-*``
        # value for OpenAI -- which would not correlate; overwrite it.
        payload["id"] = self._correlation_id(call_details) or f"chatcmpl-{uuid.uuid4()}"
        self._prepend_system_prompt(payload, call_details)

        return payload

    @staticmethod
    def _copy_block_payload_base(base: StandardLoggingPayload) -> _BlockFailurePayload:
        return safe_deep_copy(base)

    @staticmethod
    def _caller_metadata(user_api_key_dict: "UserAPIKeyAuth") -> StandardLoggingUserAPIKeyMetadata:
        """Identify the caller whose request was blocked.

        Uses the same mapper the success path and the proxy spend logger use, so
        a block log and a success log agree on the caller key set.

        The import is deferred because ``litellm/integrations/`` is SDK-side
        while the mapper lives under ``proxy/``: ``rubrik.py`` is imported during
        guardrail discovery and must not pull proxy-only dependencies into its
        import chain. It is unguarded because the only dispatcher of this hook,
        ``ProxyLogging.post_call_failure_hook``, already imports fastapi at
        module scope, so there is no path where this hook runs and the mapper is
        missing.
        """
        from litellm.proxy.litellm_pre_call_utils import LiteLLMProxyRequestSetup

        return LiteLLMProxyRequestSetup.get_sanitized_user_information_from_key(user_api_key_dict)

    @classmethod
    def _build_fallback_payload(
        cls,
        call_details: _FallbackSource,
        user_api_key_dict: "UserAPIKeyAuth",
    ) -> _BlockFailurePayload:
        # Convert datetime to a Unix float so json.dumps can serialize it.
        # httpx's json= parameter uses stdlib json.dumps with no custom encoder.
        _raw_start: Final = call_details.get("start_time")
        _start: Final = _raw_start.timestamp() if _raw_start is not None else None
        return {
            "id": call_details.get("litellm_call_id"),
            "model": call_details.get("model") or "",
            # model_group is set by the router inside acompletion(), which
            # hasn't run for a prompt block; use the model name instead.
            "model_group": call_details.get("model") or "",
            # model_id comes from response.hidden_params -- unavailable here.
            "model_id": "",
            "model_parameters": ModelParamHelper.get_standard_logging_model_parameters(
                call_details.get("optional_params") or _EMPTY_MAPPING  # pyright: ignore[reportArgumentType]  # helper only reads the mapping
            ),
            "startTime": _start,
            "endTime": _start,
            "completionStartTime": _start,
            "messages": call_details.get("messages") or (),
            "metadata": cls._caller_metadata(user_api_key_dict),
            "status": "failure",
        }

    # -- Batch logging ---------------------------------------------------------

    async def _log_batch_to_rubrik(self, data):
        # NOTE: this method intentionally re-raises on failure so flush_queue
        # can preserve the unsent events for the next flush attempt instead of
        # silently dropping them.
        try:
            response: Final = await self.async_httpx_client.post(
                url=self.logging_endpoint,
                json=data,
                headers=dict(self._headers),
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            verbose_logger.exception("Rubrik HTTP Error: %s - %s", e.response.status_code, e.response.text)
            raise
        except Exception:
            verbose_logger.exception("Rubrik Layer Error")
            raise

    async def async_send_batch(self):
        """Handles sending batches of responses to Rubrik.

        Note: the canonical flush path is :meth:`flush_queue`, which takes a
        single snapshot used for both sending and queue draining. This method
        is kept for direct callers / tests; it intentionally does NOT remove
        events from the queue.
        """
        if not self.log_queue:
            return

        await self._log_batch_to_rubrik(
            data=self.log_queue,
        )

    async def flush_queue(self):
        """Snapshot, send, and drain in one consistent step.

        Overrides the base implementation so the same snapshot drives both
        the HTTP send and the queue truncation. This avoids the subtle
        coupling where the base class captures ``len(self.log_queue)``
        separately from the snapshot taken inside ``async_send_batch``,
        which could otherwise drift in a future refactor and cause
        duplicate deliveries to Rubrik.
        """
        if self.flush_lock is None:
            return

        async with self.flush_lock:
            if not self.log_queue:
                return
            snapshot: Final = list(self.log_queue)
            verbose_logger.debug("Rubrik: Flushing batch of %s events", len(snapshot))
            try:
                await self._log_batch_to_rubrik(data=snapshot)
            except Exception:
                # Already logged with traceback inside _log_batch_to_rubrik.
                # Preserve the in-flight events for retry on the next flush.
                return
            del self.log_queue[: len(snapshot)]
            self.last_flush_time = time.time()

    # -- Webhook services ------------------------------------------------------

    async def _post_json(self, endpoint: str, payload: Mapping[str, object], service_name: str) -> _ModerationResponse:
        """POST ``payload`` to a Rubrik webhook and return its dict response.

        Raises:
            Exception: If the service is unavailable or returns an error.
            TypeError: If the response JSON is not a dict.
        """
        verbose_logger.debug("Sending request to %s: %s", service_name, endpoint)
        http_response: Final = await self.moderation_client.post(
            endpoint,
            json=dict(payload),
            headers=dict(self._headers),
        )
        http_response.raise_for_status()
        result: Final[_ModerationResponse | None] = http_response.json()
        if not isinstance(result, dict):
            raise TypeError(
                f"{service_name} returned non-dict JSON "
                f"({type(result).__name__}); expected OpenAI chat completion "
                "shape or empty object."
            )
        return result

    async def _post_to_response_moderation_endpoint(
        self,
        response_data: Mapping[str, object],
        request_data: Mapping[str, object],
    ) -> _ModerationResponse:
        """Post the ``{request, response}`` envelope to the after_completion
        webhook and return its (possibly rewritten) response.

        Args:
            response_data: The OpenAI-formatted response payload to send.
            request_data: Original LLM request data to include alongside
                the response for additional context. Empty dict if unavailable.
        """
        envelope: Final = {"request": request_data, "response": response_data}
        return await self._post_json(
            self.response_moderation_endpoint,
            envelope,
            "Response moderation service",
        )

    async def _post_to_prompt_moderation_endpoint(self, payload: Mapping[str, object]) -> _ModerationResponse:
        """Post a bare OpenAI request to the before_prompt webhook.

        Returns ``{}`` (passthrough) or a synthetic chat.completion (block).
        """
        return await self._post_json(self.prompt_moderation_endpoint, payload, "Prompt moderation service")

    @staticmethod
    def _extract_prompt_refusal(service_response: _ModerationResponse) -> str | None:
        """Return the refusal text when the prompt was blocked, else None.

        The before_prompt webhook returns ``{}`` (passthrough) or a synthetic
        chat.completion whose ``choices[0].message.content`` is the refusal
        explanation.
        """
        choices: Final = service_response.get("choices")
        if not choices:
            return None
        message: Final = choices[0].get("message") or _EMPTY_MAPPING
        content: Final = message.get("content")
        return content or "Request blocked by policy."

    @staticmethod
    def _extract_response_block(
        service_response: _ModerationResponse,
        all_tool_calls: Sequence[ChatCompletionMessageToolCall],
        sent_content: str,
    ) -> BlockedResponseResult | None:
        """Detect whether the webhook moderated the response text or tool calls.

        The after_completion webhook rewrites the response in place with no
        explicit "blocked" flag, so we infer a block by diffing what we sent
        against what came back:

        - Tool block: a tool call we sent is absent from the returned (allowed)
          set.
        - Text block: the returned content was REPLACED wholesale (a text
          violation), as opposed to having a tool-block explanation APPENDED to
          the original content. We tell them apart with ``startswith``, which
          mirrors the webhook's own append-vs-replace behavior.

        Returns None when nothing was moderated. A text block supersedes a tool
        block (mirroring the webhook, which drops tool calls on a text block).

        Expects service_response in OpenAI chat completion format:
            {"choices": [{"message": {"tool_calls": [...], "content": "..."}}]}
        """
        choices: Final = service_response.get("choices") or ()
        if not choices:
            raise _MalformedToolBlockingResponseError("Response moderation service returned empty response")

        message: Final = choices[0].get("message") or _EMPTY_MAPPING
        returned_tool_calls: Final = message.get("tool_calls") or ()
        returned_content: Final = message.get("content") or ""

        # Use Counter so duplicate IDs are handled correctly: if the model
        # emits two calls with the same ID (one allowed, one prohibited) and
        # the service returns only the allowed one, a set-based check would
        # miss the block. Counter preserves multiplicity.
        returned_id_counts: Final[Counter[str]] = Counter(tc["id"] for tc in returned_tool_calls if tc.get("id"))
        required_id_counts: Final[Counter[str]] = Counter(tc.id for tc in all_tool_calls if tc.id)
        # Cardinality check catches ID-less tool calls (not counted in
        # required_id_counts because tc.id is falsy); Counter check catches
        # duplicate-ID attacks where one occurrence is silently removed.
        tools_blocked: Final = len(returned_tool_calls) < len(all_tool_calls) or not all(
            returned_id_counts.get(tc_id, 0) >= count for tc_id, count in required_id_counts.items()
        )

        # The webhook either replaces content wholesale (text block) or appends
        # a tool-block explanation to the original text. ``appended`` tells the
        # two apart, and is reused below to recover just the explanation. A text
        # block requires there to have been assistant text to block.
        # Use the documented ``\n\n`` separator to distinguish a tool-block
        # append from a text replacement that shares the original as a prefix.
        # Without the separator, a replacement like "Hello, blocked." where the
        # original was "Hello" would be classified as an append (not a text
        # block) and silently pass through to the client.
        appended: Final = bool(sent_content) and returned_content.startswith(f"{sent_content}\n\n")
        text_blocked: Final = bool(sent_content) and returned_content != sent_content and not appended

        if text_blocked:
            return BlockedResponseResult(explanation=returned_content or "Response blocked by policy.")

        if tools_blocked:
            if appended:
                # Recover just the appended explanation: drop the original text
                # and the leading separator the webhook inserted before it.
                explanation = returned_content[len(sent_content) :].lstrip("\n")
            else:
                explanation = returned_content
            return BlockedResponseResult(explanation=explanation or "Tool call blocked by policy.")

        return None
