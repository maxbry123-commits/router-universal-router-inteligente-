"""
Utils used for litellm.transcription() and litellm.atranscription()
"""

import hashlib
import os
from dataclasses import dataclass
from typing import Final

from litellm.types.files import (
    AUDIO_FILE_TYPES,
    FILE_EXTENSIONS,
    FILE_MIME_TYPES,
    FileType,
    get_file_mime_type_from_extension,
)
from litellm.types.utils import FileTypes


@dataclass
class ProcessedAudioFile:
    """
    Processed audio file data.

    Attributes:
        file_content: The binary content of the audio file
        filename: The filename (extracted or generated)
        content_type: The MIME type of the audio file
    """

    file_content: bytes
    filename: str
    content_type: str


def process_audio_file(audio_file: FileTypes) -> ProcessedAudioFile:
    """
    Common utility function to process audio files for audio transcription APIs.

    Handles various input types:
    - File paths (str, os.PathLike)
    - Raw bytes/bytearray
    - Tuples (filename, content, optional content_type)
    - File-like objects with read() method

    Args:
        audio_file: The audio file input in various formats

    Returns:
        ProcessedAudioFile: Structured data with file content, filename, and content type

    Raises:
        ValueError: If audio_file type is unsupported or content cannot be extracted
    """
    file_content = None
    filename = None

    if isinstance(audio_file, (bytes, bytearray)):
        # Raw bytes
        filename = "audio.wav"
        file_content = bytes(audio_file)
    elif isinstance(audio_file, str):
        # Bare strings are rejected — see extract_file_data for the same
        # rationale: in a proxy request handler the string is
        # attacker-controlled, and opening it as a path is an arbitrary
        # file read.
        raise ValueError(
            "process_audio_file does not accept bare str inputs. Pass bytes, "
            "an open file handle, a (filename, content) tuple, or a "
            "pathlib.Path."
        )
    elif isinstance(audio_file, os.PathLike):
        # File path or PathLike — PathLike is a Python-level type that
        # HTTP form values can't fabricate.
        file_path: Final = str(audio_file)
        with open(file_path, "rb") as f:
            file_content = f.read()
        filename = file_path.split("/")[-1]
    elif isinstance(audio_file, tuple):
        # Tuple format: (filename, content, content_type) or (filename, content)
        if len(audio_file) >= 2:
            filename = audio_file[0] or "audio.wav"
            content: Final = audio_file[1]
            if isinstance(content, (bytes, bytearray)):
                file_content = bytes(content)
            elif isinstance(content, str):
                raise ValueError(
                    "process_audio_file does not accept bare str tuple "
                    "contents. Pass bytes, an open file handle, or a "
                    "pathlib.Path."
                )
            elif isinstance(content, os.PathLike):
                # PathLike: SDK convenience for local-file uploads.
                with open(str(content), "rb") as f:
                    file_content = f.read()
            elif hasattr(content, "read"):
                # File-like object
                file_content = content.read()
                if hasattr(content, "seek"):
                    content.seek(0)
            else:
                raise ValueError(f"Unsupported content type in tuple: {type(content)}")
        else:
            raise ValueError("Tuple must have at least 2 elements: (filename, content)")
    elif hasattr(audio_file, "read") and not isinstance(audio_file, (str, bytes, bytearray, tuple, os.PathLike)):
        # File-like object (IO) - check this after all other types
        filename = getattr(audio_file, "name", "audio.wav")
        file_content = audio_file.read()
        # Reset file pointer if possible
        if hasattr(audio_file, "seek"):
            audio_file.seek(0)
    else:
        raise ValueError(f"Unsupported audio_file type: {type(audio_file)}")

    if file_content is None:
        raise ValueError("Could not extract file content from audio_file")

    # Determine content type using LiteLLM's file type utilities
    content_type = "audio/wav"  # Default fallback
    if filename:
        try:
            # Extract extension from filename
            extension: Final = filename.split(".")[-1].lower() if "." in filename else "wav"
            content_type = get_file_mime_type_from_extension(extension)
        except ValueError:
            # If extension is not recognized, fallback to audio/wav
            content_type = "audio/wav"

    return ProcessedAudioFile(file_content=file_content, filename=filename, content_type=content_type)


BARE_ISO_639_1_TO_BCP47: Final = {
    "en": "en-US",
    "es": "es-ES",
    "de": "de-DE",
    "fr": "fr-FR",
    "it": "it-IT",
    "pt": "pt-BR",
    "ja": "ja-JP",
    "ko": "ko-KR",
    "zh": "zh-CN",
    "ru": "ru-RU",
    "hi": "hi-IN",
    "ar": "ar-SA",
}


def normalize_transcription_language_to_bcp47(language: str) -> str:
    """
    OpenAI's transcription `language` param accepts bare ISO-639-1 codes like
    ``en``; speech APIs such as Google Speech-to-Text and NVIDIA Riva require
    BCP-47 like ``en-US``. Map the most common bare codes and pass through
    anything already region-qualified (or unknown, for a clear provider error).
    """
    if "-" in language:
        return language
    return BARE_ISO_639_1_TO_BCP47.get(language.lower(), language)


def get_audio_file_name(file_obj: FileTypes) -> str:
    """
    Safely get the name of a file-like object or return its string representation.

    Args:
        file_obj (Any): A file-like object or any other object.

    Returns:
        str: The name of the file if available, otherwise a string representation of the object.
    """
    if hasattr(file_obj, "name"):
        return getattr(file_obj, "name")
    elif hasattr(file_obj, "__str__"):
        return str(file_obj)
    else:
        return repr(file_obj)


def get_audio_file_content_hash(file_obj: FileTypes) -> str:
    """
    Compute SHA-256 hash of audio file content for cache keys.
    Falls back to filename hash if content extraction fails.
    """
    file_content: bytes | None = None
    fallback_filename: str | None = None

    if isinstance(file_obj, tuple):
        if len(file_obj) < 2:
            fallback_filename = str(file_obj[0]) if len(file_obj) > 0 else None
            file_content_obj = None
        else:
            fallback_filename = str(file_obj[0]) if file_obj[0] is not None else None
            file_content_obj = file_obj[1]
    else:
        file_content_obj = file_obj
        fallback_filename = get_audio_file_name(file_obj)

    try:
        if isinstance(file_content_obj, (bytes, bytearray)):
            file_content = bytes(file_content_obj)
        elif isinstance(file_content_obj, str):
            # Bare strings are not treated as file paths in this helper —
            # the cache-key path is reached from request handlers where the
            # value is attacker-controlled. Fall back to hashing the string
            # itself rather than opening it.
            fallback_filename = file_content_obj
            file_content = None
        elif isinstance(file_content_obj, os.PathLike):
            try:
                with open(str(file_content_obj), "rb") as f:
                    file_content = f.read()
                if fallback_filename is None:
                    fallback_filename = str(file_content_obj)
            except OSError:
                fallback_filename = str(file_content_obj)
                file_content = None
        elif file_content_obj is not None and hasattr(file_content_obj, "read"):
            try:
                current_position: Final = file_content_obj.tell() if hasattr(file_content_obj, "tell") else None
                if hasattr(file_content_obj, "seek"):
                    file_content_obj.seek(0)
                file_content = file_content_obj.read()
                if current_position is not None and hasattr(file_content_obj, "seek"):
                    file_content_obj.seek(current_position)
            except (OSError, AttributeError):
                file_content = None
        else:
            file_content = None
    except Exception:
        file_content = None

    if file_content is not None and isinstance(file_content, bytes):
        try:
            hash_object = hashlib.sha256(file_content)
            return hash_object.hexdigest()
        except Exception:
            pass

    if fallback_filename:
        hash_object = hashlib.sha256(fallback_filename.encode("utf-8"))
        return hash_object.hexdigest()

    file_obj_str: Final = str(file_obj)
    hash_object = hashlib.sha256(file_obj_str.encode("utf-8"))
    return hash_object.hexdigest()


def get_audio_file_for_health_check() -> FileTypes:
    """
    Get an audio file for health check

    Returns the content of `audio_health_check.wav` in the same directory as this file
    """
    pwd: Final = os.path.dirname(os.path.realpath(__file__))
    file_path: Final = os.path.join(pwd, "audio_health_check.wav")
    return open(file_path, "rb")


def calculate_request_duration(file: FileTypes) -> float | None:
    """
    Calculate audio duration from file content.

    Args:
        file: The audio file (can be file path, bytes, or file-like object)

    Returns:
        Duration in seconds, or None if extraction fails or soundfile is not available
    """
    try:
        import soundfile as sf
    except ImportError:
        # soundfile not available, cannot extract duration
        return None

    try:
        import io

        # Handle different file input types
        file_content: bytes | None = None

        if isinstance(file, (bytes, bytearray)):
            # Raw bytes
            file_content = bytes(file)
        elif isinstance(file, str):
            # Bare strings are rejected — see extract_file_data.
            raise ValueError(
                "calculate_request_duration does not accept bare str inputs. "
                "Pass bytes, an open file handle, a (filename, content) "
                "tuple, or a pathlib.Path."
            )
        elif isinstance(file, os.PathLike):
            # File path (PathLike): SDK convenience.
            with open(str(file), "rb") as f:
                file_content = f.read()
        elif isinstance(file, tuple):
            # Tuple format: (filename, content, optional content_type)
            if len(file) >= 2:
                content: Final = file[1]
                if isinstance(content, bytes):
                    file_content = content
                elif hasattr(content, "read") and not isinstance(content, (str, os.PathLike)):
                    # File-like object in tuple
                    current_pos: Final = getattr(content, "tell", lambda: None)()
                    # Seek to start to ensure we read the entire content
                    if hasattr(content, "seek"):
                        content.seek(0)
                    file_content = content.read()
                    if current_pos is not None and hasattr(content, "seek"):
                        content.seek(current_pos)
        elif hasattr(file, "read") and not isinstance(file, tuple):
            # File-like object (including BytesIO)
            current_position: Final = file.tell() if hasattr(file, "tell") else None
            # Seek to start to ensure we read the entire content
            if hasattr(file, "seek"):
                file.seek(0)
            file_content = file.read()
            # Reset file position if possible
            if current_position is not None and hasattr(file, "seek"):
                file.seek(current_position)

        if file_content is None or not isinstance(file_content, bytes):
            return None

        # Extract duration using soundfile
        file_object: Final = io.BytesIO(file_content)
        with sf.SoundFile(file_object) as audio:
            duration: Final = len(audio) / audio.samplerate
            return duration

    except Exception:
        # Silently fail if duration extraction fails
        return None


DEFAULT_SPEECH_MEDIA_TYPE: Final = "audio/mpeg"


def _speech_media_type_for_response_format(response_format: str) -> str | None:
    file_type: Final = next(
        (candidate for candidate, extensions in FILE_EXTENSIONS.items() if response_format.lower() in extensions),
        None,
    )
    if file_type is None or file_type not in AUDIO_FILE_TYPES:
        return None
    return FILE_MIME_TYPES[file_type]


def resolve_speech_media_type(upstream_content_type: str | None, response_format: str | None) -> str:
    upstream_media_type: Final = (upstream_content_type or "").split(";", 1)[0].strip().lower()
    if upstream_media_type.startswith("audio/"):
        return upstream_media_type
    requested_media_type: Final = (
        None if response_format is None else _speech_media_type_for_response_format(response_format)
    )
    return requested_media_type or DEFAULT_SPEECH_MEDIA_TYPE


_OGG_OPUS_HEAD_WINDOW: Final = 64
_ADTS_SYNC_AND_LAYER_MASK: Final = 0xF6
_ADTS_SYNC_AND_LAYER: Final = 0xF0
_ADTS_SAMPLE_RATE_INDEX_LIMIT: Final = 13
_MPEG_SYNC_MASK: Final = 0xE0
_MPEG_LAYER_MASK: Final = 0x06
_MPEG_RESERVED_VERSION: Final = 0x01
_MPEG_INVALID_BITRATE_INDEX: Final = 0x0F
_MPEG_RESERVED_SAMPLE_RATE_INDEX: Final = 0x03


def _adts_aac_frame_media_type(header: bytes) -> str | None:
    sample_rate_index: Final = (header[2] >> 2) & 0x0F
    return FILE_MIME_TYPES[FileType.AAC] if sample_rate_index < _ADTS_SAMPLE_RATE_INDEX_LIMIT else None


def _mpeg_audio_frame_media_type(header: bytes) -> str | None:
    version: Final = (header[1] >> 3) & 0x03
    layer: Final = header[1] & _MPEG_LAYER_MASK
    bitrate_index: Final = header[2] >> 4
    sample_rate_index: Final = (header[2] >> 2) & 0x03
    if (
        (header[1] & _MPEG_SYNC_MASK) != _MPEG_SYNC_MASK
        or version == _MPEG_RESERVED_VERSION
        or layer == 0
        or bitrate_index == _MPEG_INVALID_BITRATE_INDEX
        or sample_rate_index == _MPEG_RESERVED_SAMPLE_RATE_INDEX
    ):
        return None
    return FILE_MIME_TYPES[FileType.MP3]


def speech_media_type_from_audio_bytes(audio: bytes) -> str | None:
    if audio[:4] == b"RIFF" and audio[8:12] == b"WAVE":
        return FILE_MIME_TYPES[FileType.WAV]
    if audio[:4] == b"fLaC":
        return FILE_MIME_TYPES[FileType.FLAC]
    if audio[:4] == b"OggS":
        is_opus: Final = b"OpusHead" in audio[:_OGG_OPUS_HEAD_WINDOW]
        return FILE_MIME_TYPES[FileType.OPUS if is_opus else FileType.OGG]
    if audio[:3] == b"ID3":
        return FILE_MIME_TYPES[FileType.MP3]
    if len(audio) < 3 or audio[0] != 0xFF:
        return None
    if (audio[1] & _ADTS_SYNC_AND_LAYER_MASK) == _ADTS_SYNC_AND_LAYER:
        return _adts_aac_frame_media_type(audio)
    return _mpeg_audio_frame_media_type(audio)
