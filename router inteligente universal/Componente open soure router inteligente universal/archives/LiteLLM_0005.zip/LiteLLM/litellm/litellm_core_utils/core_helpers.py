# What is this?
## Helper utilities
import copy
from collections.abc import Iterable, Mapping
from typing import TYPE_CHECKING, Any, Final, Literal

import httpx

from litellm._logging import verbose_logger
from litellm.types.llms.openai import AllMessageValues, OpenAIChatCompletionFinishReason

if TYPE_CHECKING:
    from opentelemetry.trace import Span as _Span

    from litellm.types.utils import ModelResponseStream

    Span = _Span | Any
else:
    Span = Any


def safe_divide_seconds(seconds: float, denominator: float, default: float | None = None) -> float | None:
    """
    Safely divide seconds by denominator, handling zero division.

    Args:
        seconds: Time duration in seconds
        denominator: The divisor (e.g., number of tokens)
        default: Value to return if division by zero (defaults to None)

    Returns:
        The result of the division as a float (seconds per unit), or default if denominator is zero
    """
    if denominator <= 0:
        return default

    return float(seconds / denominator)


def safe_divide(
    numerator: float,
    denominator: float,
    default: float = 0,
) -> int | float:
    """
    Safely divide two numbers, returning a default value if denominator is zero.

    Args:
        numerator: The number to divide
        denominator: The number to divide by
        default: Value to return if denominator is zero (defaults to 0)

    Returns:
        The result of numerator/denominator, or default if denominator is zero
    """
    if denominator == 0:
        return default
    return numerator / denominator


def _is_litellm_limit_rejection(exception: BaseException) -> bool:
    from litellm.exceptions import RateLimitErrorCategory

    litellm_limit_categories: Final = frozenset(
        (RateLimitErrorCategory.LITELLM_RATE_LIMIT.value, RateLimitErrorCategory.LITELLM_BATCH_RATE_LIMIT.value)
    )
    return getattr(exception, "category", None) in litellm_limit_categories


def _is_proxy_rejection(exception: BaseException) -> bool:
    if _is_litellm_limit_rejection(exception):
        return True
    try:
        from starlette.exceptions import HTTPException
    except ImportError:
        return False
    return isinstance(exception, HTTPException)


def _is_provider_originated(exception: BaseException) -> bool:
    if _is_proxy_rejection(exception):
        return False
    if getattr(exception, "llm_provider", None):
        return True
    from litellm.llms.base_llm.chat.transformation import BaseLLMException

    return isinstance(exception, BaseLLMException)


def is_expected_client_error(exception: BaseException | None) -> bool:
    """
    True when the proxy itself rejected the request with an HTTP 4xx before any
    provider call (bad key, budget, unknown model, guardrail). A 4xx returned by
    a provider is an upstream or deployment problem, so it is never an expected
    client error and keeps its traceback: a mapped litellm exception carries
    ``llm_provider``, and the raw ``BaseLLMException`` that provider handlers
    raise before mapping (the /v1/messages route surfaces it as-is) is one too.
    The proxy's own limiters raise ``HTTPException`` subclasses that also carry
    an ``llm_provider``, so any ``HTTPException`` stays a proxy rejection, and
    so does any exception whose unified rate-limit ``category`` names litellm's
    own limiter (``BudgetExceededError`` is a plain ``Exception`` that the auth
    handler decorates with the requested model's provider).

    ProxyException stores the status on .code (as a str), HTTPException and
    litellm exceptions on .status_code.
    """
    if exception is None:
        return False
    if _is_provider_originated(exception):
        return False
    code: Final[object] = getattr(exception, "code", None)
    status_code: Final[object] = code if code is not None else getattr(exception, "status_code", None)
    if status_code is None or isinstance(status_code, bool):
        return False
    try:
        status: Final = int(str(status_code))
    except ValueError:
        return False
    return 400 <= status < 500


def coerce_token_limit(value: object) -> int | None:
    """
    Coerce a max_input_tokens / max_output_tokens value to an int, treating a
    malformed value as absent.

    A deployment's model_info is registered into litellm.model_cost verbatim, so a
    config value like "128,000" or "" reaches the /v1/models listing uncoerced from
    both the router index and the cost map. Returning None omits that one limit
    instead of failing the whole listing.

    Args:
        value: The raw configured or cost-map value

    Returns:
        The value as an int, or None if it is missing or not a usable number.
        Bools are rejected because True/False is never a meaningful token limit.
    """
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, (str, float)):
        try:
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return None
    return None


_FINISH_REASON_MAP: Final[dict[str, OpenAIChatCompletionFinishReason]] = {
    # Anthropic
    "stop_sequence": "stop",
    "end_turn": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "refusal": "content_filter",
    "compaction": "length",
    # Cohere
    "COMPLETE": "stop",
    "ERROR_TOXIC": "content_filter",
    "ERROR": "stop",
    # HuggingFace / Together AI
    "eos_token": "stop",
    "eos": "stop",
    # Gemini / Vertex AI
    "STOP": "stop",
    "MAX_TOKENS": "length",
    "SAFETY": "content_filter",
    "RECITATION": "content_filter",
    "FINISH_REASON_UNSPECIFIED": "stop",
    "MALFORMED_FUNCTION_CALL": "stop",
    "LANGUAGE": "content_filter",
    "OTHER": "content_filter",
    "BLOCKLIST": "content_filter",
    "PROHIBITED_CONTENT": "content_filter",
    "SPII": "content_filter",
    "IMAGE_SAFETY": "content_filter",
    "IMAGE_PROHIBITED_CONTENT": "content_filter",
    "TOO_MANY_TOOL_CALLS": "stop",
    "MALFORMED_RESPONSE": "stop",
    # Zhipu GLM
    "network_error": "stop",
    "sensitive": "content_filter",
    # Bedrock
    "guardrail_intervened": "content_filter",
    # OpenAI passthrough
    "stop": "stop",
    "length": "length",
    "tool_calls": "tool_calls",
    "function_call": "function_call",
    "content_filter": "content_filter",
    # Anthropic Sonnet 4
    "content_filtered": "content_filter",
    # Generic error passthrough (OpenRouter and other OpenAI-compatible providers
    # emit lowercase "error" when a provider fails mid-stream)
    "error": "stop",
}


def map_finish_reason(finish_reason: str) -> OpenAIChatCompletionFinishReason:
    mapped: Final = _FINISH_REASON_MAP.get(finish_reason)
    if mapped is None:
        verbose_logger.warning("Unmapped finish_reason '%s', defaulting to 'stop'", finish_reason)
        return "stop"
    return mapped


def remove_index_from_tool_calls(
    messages: list[AllMessageValues] | None,
):
    if messages is not None:
        for message in messages:
            _tool_calls = message.get("tool_calls")
            if _tool_calls is not None and isinstance(_tool_calls, list):
                for tool_call in _tool_calls:
                    if isinstance(tool_call, dict) and "index" in tool_call:  # Type guard to ensure it's a dict
                        tool_call.pop("index", None)


def remove_items_at_indices(items: list[Any] | None, indices: Iterable[int]) -> None:
    """Remove items from a list in-place by index"""
    if items is None:
        return
    for index in sorted(set(indices), reverse=True):
        if 0 <= index < len(items):
            items.pop(index)


def add_missing_spend_metadata_to_litellm_metadata(litellm_metadata: dict, metadata: dict) -> dict:
    """
    Helper to get litellm metadata for spend tracking

    PATCH for issue where both `litellm_metadata` and `metadata` are present in the kwargs
    and user_api_key values are in 'metadata'.
    """
    potential_spend_tracking_metadata_substring: Final = "user_api_key"
    for key, value in metadata.items():
        if potential_spend_tracking_metadata_substring in key:
            litellm_metadata[key] = value
    return litellm_metadata


def get_metadata_variable_name_from_kwargs(
    kwargs: Mapping[str, object],
) -> Literal["metadata", "litellm_metadata"]:
    """
    Helper to return what the "metadata" field should be called in the request data

    - New endpoints return `litellm_metadata`
    - Old endpoints return `metadata`

    Context:
    - LiteLLM used `metadata` as an internal field for storing metadata
    - OpenAI then started using this field for their metadata
    - LiteLLM is now moving to using `litellm_metadata` for our metadata
    """
    return "litellm_metadata" if "litellm_metadata" in kwargs else "metadata"


def get_or_create_metadata_bucket(
    request_data: dict,
) -> tuple[Literal["metadata", "litellm_metadata"], dict]:
    """
    Return the proxy-internal metadata bucket for this request, creating it if absent.

    Batch/file routes store proxy state in ``litellm_metadata`` so the OpenAI
    ``metadata`` field can remain provider-safe (string values only). Every writer and
    reader of proxy-internal metadata resolves the bucket through here, so a caller that
    supplies its own ``metadata`` field cannot split them across two dicts.
    """
    metadata_key: Final = get_metadata_variable_name_from_kwargs(request_data)
    metadata_bucket = request_data.get(metadata_key)
    if not isinstance(metadata_bucket, dict):
        metadata_bucket = {}
        request_data[metadata_key] = metadata_bucket
    return metadata_key, metadata_bucket


def get_litellm_metadata_from_kwargs(kwargs: dict):
    """
    Helper to get litellm metadata from all litellm request kwargs

    Return `litellm_metadata` if it exists, otherwise return `metadata`
    """
    litellm_params: Final = kwargs.get("litellm_params", {})
    if litellm_params:
        metadata: Final = litellm_params.get("metadata", {})
        litellm_metadata = litellm_params.get("litellm_metadata", {})
        if litellm_metadata and metadata:
            litellm_metadata = add_missing_spend_metadata_to_litellm_metadata(litellm_metadata, metadata)
        if litellm_metadata:
            return litellm_metadata
        elif metadata:
            return metadata

    return {}


def reconstruct_model_name(
    model_name: str,
    custom_llm_provider: str | None,
    metadata: dict,
) -> str:
    """Reconstruct full model name with provider prefix for logging."""
    # Check if deployment model name from router metadata is available (has original prefix)
    deployment_model_name: Final = metadata.get("deployment")
    if deployment_model_name and "/" in deployment_model_name:
        # Use the deployment model name which preserves the original provider prefix
        return deployment_model_name
    elif custom_llm_provider and model_name and "/" not in model_name:
        # Only add prefix for Bedrock (not for direct Anthropic API)
        # This ensures Bedrock models get the prefix while direct Anthropic models don't
        if custom_llm_provider == "bedrock":
            return f"{custom_llm_provider}/{model_name}"
    return model_name


# Helper functions used for OTEL logging
def _get_parent_otel_span_from_kwargs(
    kwargs: dict | None = None,
) -> Span | None:
    try:
        if kwargs is None:
            return None
        litellm_params: Final = kwargs.get("litellm_params")
        _metadata: Final = kwargs.get("metadata") or {}
        if "litellm_parent_otel_span" in _metadata:
            return _metadata["litellm_parent_otel_span"]
        elif (
            litellm_params is not None
            and litellm_params.get("metadata") is not None
            and "litellm_parent_otel_span" in litellm_params.get("metadata", {})
        ):
            return litellm_params["metadata"]["litellm_parent_otel_span"]
        elif "litellm_parent_otel_span" in kwargs:
            return kwargs["litellm_parent_otel_span"]
        return None
    except Exception as e:
        verbose_logger.exception("Error in _get_parent_otel_span_from_kwargs: " + str(e))
        return None


def process_response_headers(
    response_headers: httpx.Headers | dict,
    preserve_litellm_internal_headers: bool = False,
) -> dict:
    """
    `preserve_litellm_internal_headers` must only be True when the input is a
    LiteLLM-owned dict (e.g. `_hidden_params["additional_headers"]` that has
    already been through one round of processing).  For raw upstream provider
    headers — whether passed as `httpx.Headers` or a plain dict — it must
    remain False, otherwise a malicious provider returning `x-litellm-*` could
    spoof LiteLLM-internal markers (e.g. `x-litellm-attempted-fallbacks`).

    When the input is an `httpx.Headers` object the flag is always treated as
    False regardless of what the caller requested, because `httpx.Headers` is
    always a raw provider response and can never be LiteLLM-owned.
    """
    from litellm.types.utils import OPENAI_RESPONSE_HEADERS

    # Raw httpx.Headers objects come directly from provider HTTP responses and
    # must never be treated as LiteLLM-owned, regardless of caller intent.
    _preserve: Final = preserve_litellm_internal_headers and isinstance(response_headers, dict)

    openai_headers: Final = {}
    processed_headers: Final = {}
    additional_headers = {}

    for k, v in response_headers.items():
        if k in OPENAI_RESPONSE_HEADERS:  # return openai-compatible headers
            openai_headers[k] = v
        if k.startswith("llm_provider-"):  # return raw provider headers (incl. openai-compatible ones)
            processed_headers[k] = v
        elif _preserve and k.startswith("x-litellm-"):
            # LiteLLM's own internal headers (e.g. x-litellm-attempted-fallbacks,
            # x-litellm-model-group) are not LLM provider headers and must not be
            # prefixed. Downstream consumers (proxy override, callers checking
            # whether a fallback happened) look up the bare key.
            processed_headers[k] = v
        else:
            additional_headers["{}-{}".format("llm_provider", k)] = v

    additional_headers = {
        **openai_headers,
        **processed_headers,
        **additional_headers,
    }
    return additional_headers


def preserve_upstream_non_openai_attributes(
    model_response: "ModelResponseStream", original_chunk: "ModelResponseStream"
):
    """
    Preserve non-OpenAI attributes from the original chunk.
    """
    # Access model_fields on the class, not the instance, to avoid Pydantic 2.11+ deprecation warnings
    expected_keys: Final = set(type(model_response).model_fields.keys()).union({"usage"})
    for key, value in original_chunk.model_dump().items():
        if key not in expected_keys:
            setattr(model_response, key, value)


def safe_deep_copy(data):
    """
    Safe Deep Copy

    The LiteLLM request may contain objects that cannot be pickled/deep-copied
    (e.g., tracing spans, locks, clients).

    This helper deep-copies each top-level key independently; on failure keeps
    original ref
    """
    import copy

    import litellm

    if litellm.safe_memory_mode is True:
        return data

    litellm_parent_otel_span: Any | None = None
    # Step 1: Remove the litellm_parent_otel_span
    litellm_parent_otel_span = None
    if isinstance(data, dict):
        # remove litellm_parent_otel_span since this is not picklable
        if "metadata" in data and "litellm_parent_otel_span" in data["metadata"]:
            litellm_parent_otel_span = data["metadata"].pop("litellm_parent_otel_span")
            data["metadata"]["litellm_parent_otel_span"] = "placeholder"
        if "litellm_metadata" in data and "litellm_parent_otel_span" in data["litellm_metadata"]:
            litellm_parent_otel_span = data["litellm_metadata"].pop("litellm_parent_otel_span")
            data["litellm_metadata"]["litellm_parent_otel_span"] = "placeholder"

    # Step 2: Per-key deepcopy with fallback
    if isinstance(data, dict):
        new_data = {}
        for k, v in data.items():
            try:
                new_data[k] = copy.deepcopy(v)
            except Exception:
                new_data[k] = v
    else:
        try:
            new_data = copy.deepcopy(data)
        except Exception:
            new_data = data

    # Step 3: re-add the litellm_parent_otel_span after doing a deep copy
    if isinstance(data, dict) and litellm_parent_otel_span is not None:
        if "metadata" in data and "litellm_parent_otel_span" in data["metadata"]:
            data["metadata"]["litellm_parent_otel_span"] = litellm_parent_otel_span
        if "litellm_metadata" in data and "litellm_parent_otel_span" in data["litellm_metadata"]:
            data["litellm_metadata"]["litellm_parent_otel_span"] = litellm_parent_otel_span
    return new_data


def independent_snapshot(
    data: dict,  # mutable-ok: caller-defined request-payload shape
) -> dict:  # mutable-ok: caller-defined request-payload shape
    """
    A copy of ``data`` whose top-level keys are deep-copied independently
    where possible -- always attempted, regardless of
    ``litellm.safe_memory_mode``. Unlike ``safe_deep_copy``, which can return
    the *original* object outright under that mode (defeating any isolation
    guarantee for every key, not just the ones that need it), this never
    skips copying wholesale.

    Real proxy requests carry ``data["litellm_logging_obj"]`` (a ``Logging``
    instance nesting a live OTel span with a real lock) by the time
    ``pre_call_hook`` runs, which can never be deep-copied. Any individual
    key that fails to deep-copy falls back to sharing its original
    reference, same crash tolerance as ``safe_deep_copy``'s own per-key
    fallback; callers needing true isolation (e.g. a guardrail's
    ``scan_raw_request`` snapshot) only depend on the keys that are plain,
    cleanly-copyable structures (``messages``/``input``,
    ``metadata``/``litellm_metadata``).
    """
    sanitized: Final = {
        key: (
            {  # mutable-ok: same request-payload shape as data
                inner_key: ("placeholder" if inner_key == "litellm_parent_otel_span" else inner_value)
                for inner_key, inner_value in value.items()
            }
            if key in ("metadata", "litellm_metadata") and isinstance(value, dict)
            else value
        )
        for key, value in data.items()
    }

    def _copied_value(key: str, sanitized_value: object) -> object:
        try:
            copied_value: Final = copy.deepcopy(sanitized_value)
        except Exception:  # noqa: BLE001  # any unpicklable value falls back to the original reference for this key only
            return data.get(key)
        original_value: Final = data.get(key)
        if (
            key in ("metadata", "litellm_metadata")
            and isinstance(copied_value, dict)
            and isinstance(original_value, dict)
            and "litellm_parent_otel_span" in original_value
        ):
            return {  # mutable-ok: same request-payload shape as data
                **copied_value,
                "litellm_parent_otel_span": original_value["litellm_parent_otel_span"],
            }
        return copied_value

    return {  # mutable-ok: same request-payload shape as data
        key: _copied_value(key, value) for key, value in sanitized.items()
    }


def filter_exceptions_from_params(data: Any, max_depth: int = 20) -> Any:
    """
    Recursively filter out Exception objects and callable objects from dicts/lists.

    This is a defensive utility to prevent deepcopy failures when exception objects
    are accidentally stored in parameter dictionaries (e.g., optional_params).
    Also filters callable objects (functions) to prevent JSON serialization errors.
    Exceptions and callables should not be stored in params - this function removes them.

    Args:
        data: The data structure to filter (dict, list, or any other type)
        max_depth: Maximum recursion depth to prevent infinite loops

    Returns:
        Filtered data structure with Exception and callable objects removed, or None if the
        entire input was an Exception or callable
    """
    if max_depth <= 0:
        return data

    # Skip exception objects
    if isinstance(data, Exception):
        return None
    # Skip callable objects (functions, methods, lambdas) but not classes (type objects)
    if callable(data) and not isinstance(data, type):
        return None
    # Skip known non-serializable object types (Logging, Router, etc.)
    obj_type_name: Final = type(data).__name__
    if obj_type_name in ["Logging", "LiteLLMLoggingObj", "Router"]:
        return None

    if isinstance(data, dict):
        result: Final[dict[str, Any]] = {}
        for k, v in data.items():
            # Skip exception and callable values
            if isinstance(v, Exception) or (callable(v) and not isinstance(v, type)):
                continue
            try:
                filtered = filter_exceptions_from_params(v, max_depth - 1)
                if filtered is not None:
                    result[k] = filtered
            except Exception:
                # Skip values that cause errors during filtering
                continue
        return result
    elif isinstance(data, list):
        result_list: Final[list[Any]] = []
        for item in data:
            # Skip exception and callable items
            if isinstance(item, Exception) or (callable(item) and not isinstance(item, type)):
                continue
            try:
                filtered = filter_exceptions_from_params(item, max_depth - 1)
                if filtered is not None:
                    result_list.append(filtered)
            except Exception:
                # Skip items that cause errors during filtering
                continue
        return result_list
    else:
        return data


def filter_internal_params(data: dict, additional_internal_params: set | None = None) -> dict:
    """
    Filter out LiteLLM internal parameters that shouldn't be sent to provider APIs.

    This removes internal/MCP-related parameters that are used by LiteLLM internally
    but should not be included in API requests to providers.

    Args:
        data: Dictionary of parameters to filter
        additional_internal_params: Optional set of additional internal parameter names to filter

    Returns:
        Filtered dictionary with internal parameters removed
    """
    if not isinstance(data, dict):
        return data

    # Known internal parameters that should never be sent to provider APIs
    internal_params: Final = {
        "skip_mcp_handler",
        "mcp_handler_context",
        "_skip_mcp_handler",
    }

    # Add any additional internal params if provided
    if additional_internal_params:
        internal_params.update(additional_internal_params)

    # Filter out internal parameters
    return {k: v for k, v in data.items() if k not in internal_params}


def redact_nested_match_and_regex_keys(
    payload: dict | list[Any] | str | None,
) -> dict | list[Any] | str | None:
    """
    Deep-copy `payload` and replace every `match` / `regex` string field with
    "[REDACTED]" anywhere in nested dict/list structures.

    Used for guardrail spend/compliance logging so raw spans are not persisted.
    """
    if payload is None or isinstance(payload, str):
        return payload
    try:
        redacted: Final[dict | list[Any] | str | None] = copy.deepcopy(payload)
    except Exception:
        return payload

    # Iterative traversal; `seen` guards against cyclic refs preserved by deepcopy.
    try:
        seen: Final[set] = set()
        stack: Final[list[Any]] = [redacted]
        while stack:
            node = stack.pop()
            node_id = id(node)
            if node_id in seen:
                continue
            seen.add(node_id)
            if isinstance(node, dict):
                if "match" in node:
                    node["match"] = "[REDACTED]"
                if "regex" in node:
                    node["regex"] = "[REDACTED]"
                stack.extend(node.values())
            elif isinstance(node, list):
                stack.extend(node)
    except Exception:
        return payload
    return redacted
