from collections.abc import Mapping, Sequence
from datetime import datetime
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, Literal

import httpx
from httpx._types import RequestFiles
from typing_extensions import ReadOnly, TypedDict

import litellm
from litellm.constants import RUNWAYML_DEFAULT_API_VERSION
from litellm.litellm_core_utils.url_utils import encode_url_path_segment
from litellm.llms.base_llm.chat.transformation import BaseLLMException
from litellm.llms.base_llm.videos.transformation import BaseVideoConfig
from litellm.llms.custom_httpx.http_handler import (
    AsyncHTTPHandler,
    HTTPHandler,
    _get_httpx_client,
    get_async_httpx_client,
)
from litellm.secret_managers.main import get_secret_str
from litellm.types.router import GenericLiteLLMParams
from litellm.types.videos.main import VideoCreateOptionalRequestParams, VideoObject
from litellm.types.videos.utils import (
    encode_video_id_with_provider,
    extract_original_video_id,
)

if TYPE_CHECKING:
    from litellm.litellm_core_utils.litellm_logging import Logging as _LiteLLMLoggingObj

    LiteLLMLoggingObj = _LiteLLMLoggingObj
else:
    LiteLLMLoggingObj = Any


class RunwayMLError(BaseLLMException):
    pass


class _RunwayTaskResponse(TypedDict, total=False):
    id: ReadOnly[str]
    status: ReadOnly[str]
    createdAt: ReadOnly[str]
    completedAt: ReadOnly[str]
    output: ReadOnly[Sequence[str] | str]
    failureCode: ReadOnly[str]
    failure: ReadOnly[str]
    progress: ReadOnly[float]
    estimatedCost: ReadOnly[Mapping[str, float]]


class _VideoObjectData(TypedDict, extra_items=object):
    id: ReadOnly[str]
    object: ReadOnly[Literal["video"]]
    status: ReadOnly[str]
    created_at: ReadOnly[int]


def _parse_runway_task_response(raw_response: httpx.Response) -> _RunwayTaskResponse:
    response_data: Final[_RunwayTaskResponse] = raw_response.json()
    return response_data


_USD_PER_CREDIT: Final = 0.01

_RESOLUTION_AREA_TIERS: Final[tuple[tuple[int, str], ...]] = (
    (600_000, "480p"),
    (1_500_000, "720p"),
    (4_000_000, "1080p"),
)


def _ratio_to_resolution(ratio: object) -> str | None:
    if not isinstance(ratio, str) or ":" not in ratio:
        return None
    width_str, _, height_str = ratio.partition(":")
    if not (width_str.isdigit() and height_str.isdigit()):
        return None
    area: Final = int(width_str) * int(height_str)
    return next((label for threshold, label in _RESOLUTION_AREA_TIERS if area < threshold), "4k")


def _duration_seconds(seconds: str | None) -> float | None:
    if not seconds:
        return None
    try:
        return float(seconds)
    except ValueError:
        return None


def _estimated_cost_usd(response_data: _RunwayTaskResponse) -> float | None:
    estimated_cost: Final = response_data.get("estimatedCost")
    if not isinstance(estimated_cost, Mapping):
        return None
    credits: Final = estimated_cost.get("credits")
    if not isinstance(credits, (int, float)):
        return None
    return float(credits) * _USD_PER_CREDIT


def _progress_percent(progress: float) -> int:
    return min(100, max(0, round(float(progress) * 100)))


class RunwayMLVideoConfig(BaseVideoConfig):
    """
    Configuration class for RunwayML video generation.

    RunwayML uses a task-based API where:
    1. POST /v1/text_to_video, /v1/image_to_video, or /v1/video_to_video creates a task
    2. The task returns immediately with a task ID
    3. Client must poll or wait for task completion
    """

    def __init__(self):
        super().__init__()

    @staticmethod
    def _parse_task_response(raw_response: httpx.Response) -> _RunwayTaskResponse:
        return raw_response.json()

    def get_supported_openai_params(self, model: str) -> list:
        """
        Get the list of supported OpenAI parameters for video generation.
        Maps OpenAI params to RunwayML equivalents:
        - prompt -> promptText
        - input_reference -> promptImage
        - size -> ratio (e.g., "1280x720" -> "1280:720")
        - seconds -> duration
        """
        return [
            "model",
            "prompt",
            "input_reference",
            "seconds",
            "size",
            "user",
            "extra_headers",
        ]

    def map_openai_params(
        self,
        video_create_optional_params: VideoCreateOptionalRequestParams,
        model: str,
        drop_params: bool,
    ) -> dict[str, object]:
        """
        Map OpenAI parameters to RunwayML format.

        Mappings:
        - prompt -> promptText
        - input_reference -> promptImage
        - size -> ratio (convert "WIDTHxHEIGHT" to "WIDTH:HEIGHT")
        - seconds -> duration (convert to integer)
        """
        supported_openai_params: Final = self.get_supported_openai_params(model)
        return {
            **self._prompt_image_param(video_create_optional_params),
            **self._ratio_param(video_create_optional_params),
            **self._duration_param(video_create_optional_params),
            **{key: value for key, value in video_create_optional_params.items() if key not in supported_openai_params},
        }

    @staticmethod
    def _prompt_image_param(video_create_optional_params: VideoCreateOptionalRequestParams) -> Mapping[str, object]:
        # Handle input_reference parameter - map to promptImage
        if "input_reference" in video_create_optional_params:
            return {"promptImage": video_create_optional_params["input_reference"]}
        return {}

    @staticmethod
    def _ratio_param(video_create_optional_params: VideoCreateOptionalRequestParams) -> Mapping[str, str]:
        # Handle size parameter - convert "1280x720" to "1280:720"
        if "size" in video_create_optional_params:
            size: Final = video_create_optional_params["size"]
            if isinstance(size, str) and "x" in size:
                return {"ratio": size.replace("x", ":")}
        return {}

    @staticmethod
    def _duration_param(video_create_optional_params: VideoCreateOptionalRequestParams) -> Mapping[str, int]:
        # Handle seconds parameter - convert to integer
        if "seconds" in video_create_optional_params:
            seconds: Final = video_create_optional_params["seconds"]
            if seconds is not None:
                try:
                    return {"duration": int(float(seconds)) if isinstance(seconds, str) else int(seconds)}
                except (ValueError, TypeError):
                    # If conversion fails, use default duration
                    pass
        return {}

    def validate_environment(
        self,
        headers: dict,
        model: str,
        api_key: str | None = None,
        litellm_params: GenericLiteLLMParams | None = None,
    ) -> dict:
        """
        Validate environment and set up authentication headers.
        RunwayML uses Bearer token authentication via RUNWAYML_API_SECRET.
        """
        # Use api_key from litellm_params if available, otherwise fall back to other sources
        if litellm_params and litellm_params.api_key:
            api_key = api_key or litellm_params.api_key

        api_key = (
            api_key or litellm.api_key or get_secret_str("RUNWAYML_API_SECRET") or get_secret_str("RUNWAYML_API_KEY")
        )

        if api_key is None:
            raise ValueError(
                "RunwayML API key is required. Set RUNWAYML_API_SECRET environment variable or pass api_key parameter."
            )

        headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "X-Runway-Version": RUNWAYML_DEFAULT_API_VERSION,
                "Content-Type": "application/json",
            }
        )
        return headers

    def get_complete_url(
        self,
        model: str,
        api_base: str | None,
        litellm_params: dict,
    ) -> str:
        """
        Get the base URL for RunwayML API.
        The specific endpoint path will be added in the transform methods.
        """
        if api_base is None:
            api_base = "https://api.dev.runwayml.com/v1"

        return api_base.rstrip("/")

    def transform_video_create_request(
        self,
        model: str,
        prompt: str,
        api_base: str,
        video_create_optional_request_params: dict[str, object],
        litellm_params: GenericLiteLLMParams,
        headers: dict,
    ) -> tuple[dict, RequestFiles, str]:
        """
        Transform the video creation request for RunwayML API.

        RunwayML has three generation endpoints discriminated by which input is
        present, and each request body rejects unknown fields:
        - /text_to_video: promptText only (rejects promptImage)
        - /image_to_video: promptImage (+ optional promptText)
        - /video_to_video: promptVideo or videoUri (rejects promptImage)
        """
        merged_params: Final = MappingProxyType(
            {
                "model": model,
                "promptText": prompt,
                **video_create_optional_request_params,
            }
        )

        endpoint: Final = self._select_generation_endpoint(merged_params)

        request_data: Final[dict[str, object]] = {
            key: value for key, value in merged_params.items() if endpoint == "image_to_video" or key != "promptImage"
        }

        files_list: Final[RequestFiles] = []

        return request_data, files_list, f"{api_base}/{endpoint}"

    def _select_generation_endpoint(self, request_data: Mapping[str, object]) -> str:
        if request_data.get("promptVideo") is not None or request_data.get("videoUri") is not None:
            return "video_to_video"
        if request_data.get("promptImage") is not None:
            return "image_to_video"
        return "text_to_video"

    def transform_video_create_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
        custom_llm_provider: str | None = None,
        request_data: dict | None = None,
    ) -> VideoObject:
        """
        Transform the RunwayML video creation response.

        RunwayML returns a task object that looks like:
        {
            "id": "task_123...",
            "status": "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED",
            "output": ["https://...video.mp4"] (when succeeded)
        }

        We map this to OpenAI VideoObject format.
        """
        response_data: Final = _parse_runway_task_response(raw_response)

        # Map RunwayML task response to VideoObject format
        video_data: Final[_VideoObjectData] = {
            "id": response_data.get("id", ""),
            "object": "video",
            "status": self._map_runway_status(response_data.get("status", "pending")),
            "created_at": self._parse_runway_timestamp(response_data.get("createdAt")),
        }

        # Add optional fields if present
        if "output" in response_data and response_data["output"]:
            # RunwayML returns output as array of URLs when task succeeds
            video_data["output_url"] = (
                response_data["output"][0] if isinstance(response_data["output"], list) else response_data["output"]
            )

        if "completedAt" in response_data:
            video_data["completed_at"] = self._parse_runway_timestamp(response_data.get("completedAt"))

        if "failureCode" in response_data or "failure" in response_data:
            video_data["error"] = {
                "code": response_data.get("failureCode", "unknown"),
                "message": response_data.get("failure", "Video generation failed"),
            }

        # Add model and size info if available from request
        if request_data:
            if "model" in request_data:
                video_data["model"] = request_data["model"]
            if "ratio" in request_data:
                # Convert ratio back to size format
                ratio: Final = request_data["ratio"]
                if isinstance(ratio, str) and ":" in ratio:
                    video_data["size"] = ratio.replace(":", "x")
            if "duration" in request_data:
                video_data["seconds"] = str(request_data["duration"])

        video_obj: Final = VideoObject(**video_data)

        if custom_llm_provider and video_obj.id:
            video_obj.id = encode_video_id_with_provider(video_obj.id, custom_llm_provider, model)

        # Add usage data for cost tracking
        video_obj.usage = {
            key: value
            for key, value in (
                ("duration_seconds", _duration_seconds(video_obj.seconds)),
                ("video_resolution", _ratio_to_resolution(request_data.get("ratio") if request_data else None)),
                ("provider_reported_cost_usd", _estimated_cost_usd(response_data)),
            )
            if value is not None
        }

        return video_obj

    def _map_runway_status(self, runway_status: str) -> str:
        """
        Map RunwayML status to OpenAI status format.

        RunwayML statuses: PENDING, RUNNING, SUCCEEDED, FAILED, CANCELLED
        OpenAI statuses: queued, in_progress, completed, failed
        """
        status_map: Final = {
            "PENDING": "queued",
            "RUNNING": "in_progress",
            "SUCCEEDED": "completed",
            "FAILED": "failed",
            "CANCELLED": "failed",
            "THROTTLED": "queued",
        }
        return status_map.get(runway_status.upper(), "queued")

    def _parse_runway_timestamp(self, timestamp_str: str | None) -> int:
        """
        Convert RunwayML ISO 8601 timestamp to Unix timestamp.

        RunwayML returns timestamps like: "2025-11-11T21:48:50.448Z"
        We need to convert to Unix timestamp (seconds since epoch).
        """
        if not timestamp_str:
            return 0

        try:
            # Parse ISO 8601 timestamp
            dt: Final = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
            # Convert to Unix timestamp
            return int(dt.timestamp())
        except (ValueError, AttributeError):
            return 0

    def transform_video_content_request(
        self,
        video_id: str,
        api_base: str,
        litellm_params: GenericLiteLLMParams,
        headers: dict,
        variant: str | None = None,
    ) -> tuple[str, dict]:
        """
        Transform the video content request for RunwayML API.

        RunwayML doesn't have a separate content download endpoint.
        The video URL is returned in the task output field.
        We'll retrieve the task and extract the video URL.
        """
        original_video_id: Final = extract_original_video_id(video_id)
        encoded_video_id: Final = encode_url_path_segment(original_video_id, field_name="video_id")

        # Get task status to retrieve video URL
        url: Final = f"{api_base}/tasks/{encoded_video_id}"

        return url, dict[str, str]()

    def _extract_video_url_from_response(self, response_data: _RunwayTaskResponse) -> str:
        """
        Helper method to extract video URL from RunwayML response.
        Shared between sync and async transforms.
        """
        # Extract video URL from the output field
        video_url = None
        raw_output: Final = response_data.get("output")
        if raw_output:
            video_url = raw_output if isinstance(raw_output, str) else raw_output[0]

        if not video_url:
            # Check if the video generation failed or is still processing
            status: Final = response_data.get("status", "UNKNOWN")
            if status in ["PENDING", "RUNNING", "THROTTLED"]:
                raise ValueError(f"Video is still processing (status: {status}). Please wait and try again.")
            elif status == "FAILED":
                failure_reason: Final = response_data.get("failure", "Unknown error")
                raise ValueError(f"Video generation failed: {failure_reason}")
            else:
                raise ValueError("Video URL not found in response. Video may not be ready yet.")

        return video_url

    def transform_video_content_response(
        self,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> bytes:
        """
        Transform the RunwayML video content download response (synchronous).

        RunwayML's task endpoint returns JSON with a video URL in the output field.
        We need to extract the URL and download the video.

        Example response:
        {
            "id":"63fd0f13-f29d-4e58-99d3-1cb9efa14a5b",
            "createdAt":"2025-11-11T21:48:50.448Z",
            "status":"SUCCEEDED",
            "output":["https://dnznrvs05pmza.cloudfront.net/.../video.mp4?_jwt=..."]
        }
        """
        response_data: Final[_RunwayTaskResponse] = self._parse_task_response(raw_response)
        video_url: Final = self._extract_video_url_from_response(response_data)

        # Download the video from the CloudFront URL synchronously
        httpx_client: Final[HTTPHandler] = _get_httpx_client()
        video_response: Final = httpx_client.get(video_url)
        video_response.raise_for_status()

        return video_response.content

    async def async_transform_video_content_response(
        self,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> bytes:
        """
        Transform the RunwayML video content download response (asynchronous).

        RunwayML's task endpoint returns JSON with a video URL in the output field.
        We need to extract the URL and download the video asynchronously.

        Example response:
        {
            "id":"63fd0f13-f29d-4e58-99d3-1cb9efa14a5b",
            "createdAt":"2025-11-11T21:48:50.448Z",
            "status":"SUCCEEDED",
            "output":["https://dnznrvs05pmza.cloudfront.net/.../video.mp4?_jwt=..."]
        }
        """
        response_data: Final[_RunwayTaskResponse] = self._parse_task_response(raw_response)
        video_url: Final = self._extract_video_url_from_response(response_data)

        # Download the video from the CloudFront URL asynchronously
        async_httpx_client: Final[AsyncHTTPHandler] = get_async_httpx_client(
            llm_provider=litellm.LlmProviders.RUNWAYML,
        )
        video_response: Final = await async_httpx_client.get(video_url)
        video_response.raise_for_status()

        return video_response.content

    def transform_video_remix_request(
        self,
        video_id: str,
        prompt: str,
        api_base: str,
        litellm_params: GenericLiteLLMParams,
        headers: dict,
        extra_body: Mapping[str, object] | None = None,
    ) -> tuple[str, dict]:
        """
        Transform the video remix request for RunwayML API.

        RunwayML doesn't have a direct remix endpoint in their current API.
        This would need to be implemented when/if they add this feature.
        """
        raise NotImplementedError("Video remix is not yet supported by RunwayML API")

    def transform_video_remix_response(
        self,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
        custom_llm_provider: str | None = None,
    ) -> VideoObject:
        """Transform the RunwayML video remix response."""
        raise NotImplementedError("Video remix is not yet supported by RunwayML API")

    def transform_video_list_request(
        self,
        api_base: str,
        litellm_params: GenericLiteLLMParams,
        headers: dict,
        after: str | None = None,
        limit: int | None = None,
        order: str | None = None,
        extra_query: Mapping[str, object] | None = None,
    ) -> tuple[str, dict]:
        """
        Transform the video list request for RunwayML API.

        RunwayML doesn't expose a list endpoint in their public API yet.
        """
        raise NotImplementedError("Video listing is not yet supported by RunwayML API")

    def transform_video_list_response(
        self,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
        custom_llm_provider: str | None = None,
    ) -> dict[str, str]:
        """Transform the RunwayML video list response."""
        raise NotImplementedError("Video listing is not yet supported by RunwayML API")

    def transform_video_delete_request(
        self,
        video_id: str,
        api_base: str,
        litellm_params: GenericLiteLLMParams,
        headers: dict,
    ) -> tuple[str, dict]:
        """
        Transform the video delete request for RunwayML API.

        RunwayML uses task cancellation.
        """
        original_video_id: Final = extract_original_video_id(video_id)
        encoded_video_id: Final = encode_url_path_segment(original_video_id, field_name="video_id")

        # Construct the URL for task cancellation
        url: Final = f"{api_base}/tasks/{encoded_video_id}/cancel"

        return url, dict[str, str]()

    def transform_video_delete_response(
        self,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> VideoObject:
        """Transform the RunwayML video delete/cancel response."""
        response_data: Final = _parse_runway_task_response(raw_response)

        video_obj: Final = VideoObject(
            id=response_data.get("id", ""),
            object="video",
            status="cancelled",
            created_at=self._parse_runway_timestamp(response_data.get("createdAt")),
        )

        return video_obj

    def transform_video_status_retrieve_request(
        self,
        video_id: str,
        api_base: str,
        litellm_params: GenericLiteLLMParams,
        headers: dict,
    ) -> tuple[str, dict]:
        """
        Transform the RunwayML video status retrieve request.

        RunwayML uses GET /v1/tasks/{task_id} to retrieve task status.
        """
        original_video_id: Final = extract_original_video_id(video_id)
        encoded_video_id: Final = encode_url_path_segment(original_video_id, field_name="video_id")

        # Construct the full URL for task status retrieval
        url: Final = f"{api_base}/tasks/{encoded_video_id}"

        # Empty dict for GET request (no body)
        return url, dict[str, str]()

    def transform_video_status_retrieve_response(
        self,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
        custom_llm_provider: str | None = None,
    ) -> VideoObject:
        """
        Transform the RunwayML video status retrieve response.
        """
        response_data: Final = _parse_runway_task_response(raw_response)

        # Map RunwayML task response to VideoObject format
        video_data: Final[_VideoObjectData] = {
            "id": response_data.get("id", ""),
            "object": "video",
            "status": self._map_runway_status(response_data.get("status", "pending")),
            "created_at": self._parse_runway_timestamp(response_data.get("createdAt")),
        }

        # Add optional fields if present
        if "output" in response_data and response_data["output"]:
            video_data["output_url"] = (
                response_data["output"][0] if isinstance(response_data["output"], list) else response_data["output"]
            )

        if "completedAt" in response_data:
            video_data["completed_at"] = self._parse_runway_timestamp(response_data.get("completedAt"))

        progress_value: Final = response_data.get("progress")
        if progress_value is not None:
            video_data["progress"] = _progress_percent(progress_value)

        if "failureCode" in response_data or "failure" in response_data:
            video_data["error"] = {
                "code": response_data.get("failureCode", "unknown"),
                "message": response_data.get("failure", "Video generation failed"),
            }

        video_obj: Final = VideoObject(**video_data)

        if custom_llm_provider and video_obj.id:
            video_obj.id = encode_video_id_with_provider(video_obj.id, custom_llm_provider, None)

        return video_obj

    def transform_video_create_character_request(self, name, video: object, api_base, litellm_params, headers):
        raise NotImplementedError("video create character is not supported for RunwayML")

    def transform_video_create_character_response(self, raw_response, logging_obj):
        raise NotImplementedError("video create character is not supported for RunwayML")

    def transform_video_get_character_request(self, character_id, api_base, litellm_params, headers):
        raise NotImplementedError("video get character is not supported for RunwayML")

    def transform_video_get_character_response(self, raw_response, logging_obj):
        raise NotImplementedError("video get character is not supported for RunwayML")

    def transform_video_edit_request(
        self,
        prompt,
        video_id,
        api_base,
        litellm_params,
        headers,
        video_file=None,
        extra_body=None,
        prefetched_source_data=None,
    ):
        raise NotImplementedError("video edit is not supported for RunwayML")

    def transform_video_edit_response(
        self,
        raw_response,
        logging_obj,
        custom_llm_provider=None,
        request_data=None,
    ):
        raise NotImplementedError("video edit is not supported for RunwayML")

    def transform_video_extension_request(
        self,
        prompt,
        video_id,
        seconds,
        api_base,
        litellm_params,
        headers,
        extra_body=None,
    ):
        raise NotImplementedError("video extension is not supported for RunwayML")

    def transform_video_extension_response(self, raw_response, logging_obj, custom_llm_provider=None):
        raise NotImplementedError("video extension is not supported for RunwayML")

    def get_error_class(self, error_message: str, status_code: int, headers: dict | httpx.Headers) -> BaseLLMException:
        return RunwayMLError(
            status_code=status_code,
            message=error_message,
            headers=headers,
        )
