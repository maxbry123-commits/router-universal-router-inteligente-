

# Chat package initialization