"""Build FlowDefinition actions into live runtime callables."""

from __future__ import annotations

import ast
import asyncio
from collections.abc import Awaitable, Callable, Mapping
import contextvars
import inspect
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, cast

from crewai.flow.expressions import Expression, ExpressionData
from crewai.flow.flow_definition import (
    FlowActionDefinition,
    FlowAgentActionDefinition,
    FlowCodeActionDefinition,
    FlowCrewActionDefinition,
    FlowEachActionDefinition,
    FlowEachStepDefinition,
    FlowExpressionActionDefinition,
    FlowScriptActionDefinition,
    FlowToolActionDefinition,
)
from crewai.flow.runtime._outputs import outputs_by_name
from crewai.utilities.declarative_refs import (
    InvalidRefError,
    resolve_class_ref,
    resolve_ref,
)
from crewai.utilities.types import LLMMessage


if TYPE_CHECKING:
    from crewai.flow.runtime import Flow


__all__ = ["FlowScriptExecutionDisabledError", "build_action"]

LocalContext = dict[str, Any]
NestedStepRunner = Callable[[LocalContext], Awaitable[Any]]
NestedStep = tuple[str, str | None, NestedStepRunner]
_LOCAL_CONTEXT_KWARG = "__flow_definition_local_context"
_ALLOW_SCRIPT_EXECUTION_ENV_VAR = "CREWAI_ALLOW_FLOW_SCRIPT_EXECUTION"
_TRUSTED_SCRIPT_EXECUTION_VALUES = frozenset({"1", "true", "yes"})


class FlowScriptExecutionDisabledError(RuntimeError):
    """Raised when a flow definition tries to execute inline script code."""


class _BuiltAction(Protocol):
    def run(self, *args: Any, **kwargs: Any) -> Any: ...


class _ActionType(Protocol):
    definition_type: type[Any]

    def __call__(self, flow: Flow[Any], definition: Any) -> _BuiltAction: ...


class CodeAction:
    definition_type = FlowCodeActionDefinition

    def __init__(self, flow: Flow[Any], definition: FlowCodeActionDefinition) -> None:
        self.flow = flow
        self.definition = definition
        self.handler = self._resolve_handler()
        self.signature = inspect.signature(self.handler)

    def run(self, *args: Any, **kwargs: Any) -> Any:
        local_context = _pop_local_context(kwargs)
        if self.definition.with_ is None:
            return self.handler(*args, **kwargs)
        return self.handler(
            **Expression.from_flow(
                self.definition.with_, self.flow, local_context=local_context
            ).render_template()
        )

    def _resolve_handler(self) -> Callable[..., Any]:
        ref = self.definition.ref
        target = resolve_ref(ref, field="do")
        if not callable(target):
            raise InvalidRefError(f"invalid do ref {ref!r}; object is not callable")
        handler = cast(Callable[..., Any], target)
        if getattr(handler, "__self__", None) is None and hasattr(handler, "__get__"):
            handler = handler.__get__(self.flow, type(self.flow))
        return handler


class ToolAction:
    definition_type = FlowToolActionDefinition

    def __init__(self, flow: Flow[Any], definition: FlowToolActionDefinition) -> None:
        self.flow = flow
        self.definition = definition
        self.tool = self._build_tool()
        self.kwargs = definition.with_ or {}

    def run(self, *_args: Any, **kwargs: Any) -> Any:
        local_context = _pop_local_context(kwargs)
        return self.tool.run(
            **Expression.from_flow(
                self.kwargs, self.flow, local_context=local_context
            ).render_template()
        )

    def _build_tool(self) -> Any:
        from crewai.tools import BaseTool

        tool_cls = cast(
            Callable[[], BaseTool],
            resolve_class_ref(
                self.definition.ref,
                field="do",
                base_class=BaseTool,
            ),
        )
        try:
            return tool_cls()
        except Exception as e:
            raise InvalidRefError(
                f"cannot instantiate tool ref {self.definition.ref!r} "
                f"without arguments: {e}"
            ) from e


class CrewAction:
    definition_type = FlowCrewActionDefinition

    def __init__(self, flow: Flow[Any], definition: FlowCrewActionDefinition) -> None:
        self.flow = flow
        self.definition = definition

    async def run(self, *_args: Any, **kwargs: Any) -> Any:
        from crewai.project.crew_loader import load_crew, load_crew_from_definition

        local_context = _pop_local_context(kwargs)
        if self.definition.from_declaration is not None:
            crew, default_inputs = await asyncio.to_thread(
                load_crew,
                _resolve_crew_declaration(
                    self.definition.from_declaration,
                    base_dir=self.flow._definition.source_dir,
                ),
            )
            input_template = {**default_inputs, **(self.definition.inputs or {})}
        else:
            crew_definition = self.definition.with_
            if crew_definition is None:
                raise ValueError(
                    "crew action requires exactly one of from_declaration or with"
                )
            input_template = {
                **crew_definition.inputs,
                **(self.definition.inputs or {}),
            }
            crew, _ = await asyncio.to_thread(
                load_crew_from_definition, crew_definition, source="crew action"
            )

        inputs = Expression.from_flow(
            cast(ExpressionData, input_template),
            self.flow,
            local_context=local_context,
        ).render_template()
        return await crew.kickoff_async(inputs=inputs)


class AgentAction:
    definition_type = FlowAgentActionDefinition

    def __init__(self, flow: Flow[Any], definition: FlowAgentActionDefinition) -> None:
        self.flow = flow
        self.definition = definition

    async def run(self, *_args: Any, **kwargs: Any) -> Any:
        from crewai.project.json_loader import load_agent_from_definition

        local_context = _pop_local_context(kwargs)
        rendered_input = Expression.from_flow(
            cast(ExpressionData, self.definition.with_.input),
            self.flow,
            local_context=local_context,
        ).render_template()
        agent_input = _normalize_agent_input(rendered_input)

        agent, response_format = await asyncio.to_thread(
            load_agent_from_definition,
            self.definition.with_,
            source="agent action",
        )
        return await agent.kickoff_async(
            agent_input,
            response_format=response_format,
        )


def _normalize_agent_input(rendered: Any) -> str | list[LLMMessage]:
    """Accept a prompt string or a rendered conversation.

    A whole-string ``${...}`` template keeps its evaluated type, so a CEL
    expression over ``state.messages`` renders a list. ``message_to_llm_dict``
    drops the metadata and ``None`` keys a serialized message carries, which
    the agent event schema rejects.
    """
    if isinstance(rendered, str):
        return rendered
    if isinstance(rendered, list) and all(
        isinstance(item, Mapping) for item in rendered
    ):
        from crewai.flow.conversational import message_to_llm_dict

        # ``message_to_llm_dict`` only drops ``None`` keys for a model input;
        # a CEL render is plain dicts, so a serialized message keeps its
        # ``name: None`` -- which the agent event schema rejects.
        return [
            cast(
                LLMMessage,
                {
                    key: value
                    for key, value in message_to_llm_dict(item).items()
                    if value is not None or key == "content"
                },
            )
            for item in rendered
        ]
    raise ValueError(
        "agent input must render to a string or a list of messages; "
        f"got {type(rendered).__name__}"
    )


class ExpressionAction:
    definition_type = FlowExpressionActionDefinition

    def __init__(
        self, flow: Flow[Any], definition: FlowExpressionActionDefinition
    ) -> None:
        self.flow = flow
        self.definition = definition

    def run(self, *_args: Any, **kwargs: Any) -> Any:
        local_context = _pop_local_context(kwargs)
        return Expression.from_flow(
            self.definition.expr, self.flow, local_context=local_context
        ).evaluate()


class ScriptAction:
    definition_type = FlowScriptActionDefinition

    def __init__(self, flow: Flow[Any], definition: FlowScriptActionDefinition) -> None:
        self.flow = flow
        self.definition = definition
        self.handler = self._compile_handler()

    def run(self, *args: Any, **kwargs: Any) -> Any:
        local_context = _pop_local_context(kwargs)
        return self.handler(
            state=self.flow.state,
            outputs=outputs_by_name(
                self.flow._method_outputs,
                local_outputs=local_context.get("outputs") if local_context else None,
            ),
            input=args[0] if args else None,
            item=local_context.get("item") if local_context else None,
        )

    def _compile_handler(self) -> Callable[..., Any]:
        raw = os.environ.get(_ALLOW_SCRIPT_EXECUTION_ENV_VAR, "")
        if raw.strip().lower() not in _TRUSTED_SCRIPT_EXECUTION_VALUES:
            raise FlowScriptExecutionDisabledError(
                "Flow script execution is disabled by default. "
                f"Set {_ALLOW_SCRIPT_EXECUTION_ENV_VAR}=1 to enable it only for "
                "trusted flow definitions."
            )

        filename = f"crewai.flow.script.{self.flow._definition.name}"
        module = ast.parse(self.definition.code, filename=filename)
        function = ast.FunctionDef(
            name="_flow_script",
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg) for arg in ("state", "outputs", "input", "item")],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[],
            ),
            body=module.body or [ast.Pass()],
            decorator_list=[],
            returns=None,
            type_comment=None,
            type_params=[],
        )
        module.body = [function]
        ast.fix_missing_locations(module)

        # The YAML here is trusted project source authored by the code owner,
        # so this has the same trust boundary as using custom tools. We
        # intentionally do not interpolate user input and runtime values are passed
        # as function arguments. This is still arbitrary trusted Python execution,
        # so it remains disabled by default behind `CREWAI_ALLOW_FLOW_SCRIPT_EXECUTION`
        namespace: dict[str, Any] = {"__name__": filename}
        exec(compile(module, filename, "exec"), namespace)  # nosec B102 # noqa: S102
        return cast(Callable[..., Any], namespace["_flow_script"])


class EachAction:
    definition_type = FlowEachActionDefinition

    def __init__(self, flow: Flow[Any], definition: FlowEachActionDefinition) -> None:
        self.flow = flow
        self.definition = definition
        self.steps: list[NestedStep] = [
            (step.name, step.if_, self._build_step_action(step))
            for step in definition.do
        ]

    async def run(self, *_args: Any, **_kwargs: Any) -> list[Any]:
        items = Expression.from_flow(self.definition.in_, self.flow).evaluate()
        if not isinstance(items, list):
            raise ValueError("each.in must evaluate to an array")

        results: list[Any] = []

        for item in items:
            local_outputs: dict[str, Any] = {}
            local_context = {"item": item, "outputs": local_outputs}
            last_output: Any = None
            for name, condition, run_step_action in self.steps:
                if condition is not None and not self._condition_matches(
                    condition, local_context
                ):
                    continue

                last_output = await run_step_action(local_context)
                local_outputs[name] = last_output
            results.append(last_output)

        return results

    def _condition_matches(self, condition: str, local_context: LocalContext) -> bool:
        result = Expression.from_flow(
            condition, self.flow, local_context=local_context
        ).evaluate()
        if not isinstance(result, bool):
            raise ValueError("if expression must evaluate to a boolean")
        return result

    def _build_step_action(self, step: FlowEachStepDefinition) -> NestedStepRunner:
        run_action = build_action(self.flow, step.action)

        async def run_step_action(local_context: LocalContext) -> Any:
            kwargs = {_LOCAL_CONTEXT_KWARG: local_context}
            if inspect.iscoroutinefunction(run_action):
                result = run_action(**kwargs)
            else:
                ctx = contextvars.copy_context()

                def run_with_context() -> Any:
                    return run_action(**kwargs)

                result = await asyncio.to_thread(ctx.run, run_with_context)
            if inspect.isawaitable(result):
                result = await result
            return result

        return run_step_action


_ACTION_TYPES: tuple[_ActionType, ...] = (
    EachAction,
    CodeAction,
    ToolAction,
    AgentAction,
    CrewAction,
    ExpressionAction,
    ScriptAction,
)


def build_action(
    flow: Flow[Any], definition: FlowActionDefinition
) -> Callable[..., Any]:
    """Turn one `do:` action into the callable the flow runs for that node."""
    for action_type in _ACTION_TYPES:
        if isinstance(definition, action_type.definition_type):
            return _as_flow_method(action_type(flow, definition))
    raise ValueError(f"unknown call type {getattr(definition, 'call', None)!r}")


def _as_flow_method(action: _BuiltAction) -> Callable[..., Any]:
    run: Callable[..., Any]
    if inspect.iscoroutinefunction(action.run):

        async def run_async(*args: Any, **kwargs: Any) -> Any:
            return await action.run(*args, **kwargs)

        run = run_async
    else:

        def run_sync(*args: Any, **kwargs: Any) -> Any:
            return action.run(*args, **kwargs)

        run = run_sync

    signature = getattr(action, "signature", None)
    if signature is not None:
        object.__setattr__(run, "__signature__", signature)
    return run


def _pop_local_context(kwargs: dict[str, Any]) -> LocalContext | None:
    local_context = kwargs.pop(_LOCAL_CONTEXT_KWARG, None)
    if local_context is None:
        return None
    if not isinstance(local_context, dict):
        raise TypeError("flow definition local context must be a mapping")
    return cast(LocalContext, local_context)


def _resolve_crew_declaration(
    from_declaration: str, *, base_dir: Path | None = None
) -> Path:
    path = Path(from_declaration).expanduser()
    if base_dir is not None:
        resolved_base_dir = base_dir.expanduser().resolve()
        if not path.is_absolute():
            path = resolved_base_dir / path
        resolved_path = path.resolve()
        if not resolved_path.is_relative_to(resolved_base_dir):
            raise ValueError(
                "crew declaration path must be within the flow definition directory"
            )
        path = resolved_path

    if not path.is_dir():
        return path

    for name in ("crew.jsonc", "crew.json"):
        candidate = path / name
        if candidate.is_file():
            return candidate

    return path / "crew.jsonc"
