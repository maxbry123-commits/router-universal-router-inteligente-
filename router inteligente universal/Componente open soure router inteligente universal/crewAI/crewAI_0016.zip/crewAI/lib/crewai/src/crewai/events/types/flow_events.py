from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, field_serializer

from crewai.events.base_events import BaseEvent


class FlowEvent(BaseEvent):
    """Base class for all flow events"""

    type: str
    flow_name: str


class FlowStartedEvent(FlowEvent):
    """Event emitted when a flow starts execution"""

    flow_name: str
    inputs: dict[str, Any] | None = None
    type: Literal["flow_started"] = "flow_started"


class FlowCreatedEvent(FlowEvent):
    """Event emitted when a flow is created"""

    flow_name: str
    type: Literal["flow_created"] = "flow_created"


class MethodExecutionStartedEvent(FlowEvent):
    """Event emitted when a flow method starts execution"""

    flow_name: str
    method_name: str
    state: dict[str, Any] | BaseModel
    params: dict[str, Any] | None = None
    type: Literal["method_execution_started"] = "method_execution_started"


class MethodExecutionFinishedEvent(FlowEvent):
    """Event emitted when a flow method completes execution"""

    flow_name: str
    method_name: str
    result: Any = None
    state: dict[str, Any] | BaseModel
    type: Literal["method_execution_finished"] = "method_execution_finished"


class MethodExecutionFailedEvent(FlowEvent):
    """Event emitted when a flow method fails execution"""

    flow_name: str
    method_name: str
    error: Exception
    type: Literal["method_execution_failed"] = "method_execution_failed"

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_serializer("error")
    def _serialize_error(self, error: Exception) -> str:
        return str(error)


class MethodExecutionPausedEvent(FlowEvent):
    """Event emitted when a flow method is paused waiting for human feedback.

    This event is emitted when a @human_feedback decorated method with an
    async provider raises HumanFeedbackPending to pause execution.

    Attributes:
        flow_name: Name of the flow that is paused.
        method_name: Name of the method waiting for feedback.
        state: Current flow state when paused.
        flow_id: Unique identifier for this flow execution.
        message: The message shown when requesting feedback.
        emit: Optional list of possible outcomes for routing.
    """

    method_name: str
    state: dict[str, Any] | BaseModel
    flow_id: str
    message: str
    emit: list[str] | None = None
    type: Literal["method_execution_paused"] = "method_execution_paused"


class FlowFinishedEvent(FlowEvent):
    """Event emitted when a flow completes execution"""

    flow_name: str
    result: Any | None = None
    type: Literal["flow_finished"] = "flow_finished"
    state: dict[str, Any] | BaseModel


class FlowFailedEvent(FlowEvent):
    """Event emitted when a flow execution fails.

    Attributes:
        flow_name: Name of the flow that failed.
        error: The exception that ended the execution.
    """

    error: Exception
    type: Literal["flow_failed"] = "flow_failed"

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_serializer("error")
    def _serialize_error(self, error: Exception) -> str:
        return str(error)


class FlowPausedEvent(FlowEvent):
    """Event emitted when a flow is paused waiting for human feedback.

    This event is emitted when a flow is paused due to a @human_feedback
    decorated method with an async provider raising HumanFeedbackPending.

    Attributes:
        flow_name: Name of the flow that is paused.
        flow_id: Unique identifier for this flow execution.
        method_name: Name of the method waiting for feedback.
        state: Current flow state when paused.
        message: The message shown when requesting feedback.
        emit: Optional list of possible outcomes for routing.
    """

    flow_id: str
    method_name: str
    state: dict[str, Any] | BaseModel
    message: str
    emit: list[str] | None = None
    type: Literal["flow_paused"] = "flow_paused"


class FlowPlotEvent(FlowEvent):
    """Event emitted when a flow plot is created"""

    flow_name: str
    type: Literal["flow_plot"] = "flow_plot"


class FlowInputRequestedEvent(FlowEvent):
    """Event emitted when a flow requests user input via ``Flow.ask()``.

    This event is emitted before the flow suspends waiting for user input,
    allowing UI frameworks and observability tools to know when a flow
    needs user interaction.

    Attributes:
        flow_name: Name of the flow requesting input.
        method_name: Name of the flow method that called ``ask()``.
        message: The question or prompt being shown to the user.
        metadata: Optional metadata sent with the question (e.g., user ID,
            channel, session context).
    """

    method_name: str
    message: str
    metadata: dict[str, Any] | None = None
    type: Literal["flow_input_requested"] = "flow_input_requested"


class FlowInputReceivedEvent(FlowEvent):
    """Event emitted when user input is received after ``Flow.ask()``.

    This event is emitted after the user provides input (or the request
    times out), allowing UI frameworks and observability tools to track
    input collection.

    Attributes:
        flow_name: Name of the flow that received input.
        method_name: Name of the flow method that called ``ask()``.
        message: The original question or prompt.
        response: The user's response, or None if timed out / unavailable.
        metadata: Optional metadata sent with the question.
        response_metadata: Optional metadata from the provider about the
            response (e.g., who responded, thread ID, timestamps).
    """

    method_name: str
    message: str
    response: str | None = None
    metadata: dict[str, Any] | None = None
    response_metadata: dict[str, Any] | None = None
    type: Literal["flow_input_received"] = "flow_input_received"


class ConversationMessageAddedEvent(FlowEvent):
    """Event emitted when a conversational Flow records a message.

    This gives trace consumers a first-class transcript signal instead of
    requiring them to inspect the full method state payload.
    """

    session_id: str
    role: Literal["user", "assistant", "system", "tool"]
    content: Any
    message_index: int
    type: Literal["conversation_message_added"] = "conversation_message_added"


class ConversationTurnStartedEvent(FlowEvent):
    """Event emitted when a conversational Flow starts a user turn."""

    session_id: str
    type: Literal["conversation_turn_started"] = "conversation_turn_started"


class ConversationTurnCompletedEvent(FlowEvent):
    """Event emitted when a conversational Flow completes a user turn."""

    session_id: str
    type: Literal["conversation_turn_completed"] = "conversation_turn_completed"


class ConversationTurnFailedEvent(FlowEvent):
    """Event emitted when a conversational Flow turn fails."""

    session_id: str
    error: Exception
    type: Literal["conversation_turn_failed"] = "conversation_turn_failed"

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_serializer("error")
    def _serialize_error(self, error: Exception) -> str:
        return str(error)


class ConversationRouteSelectedEvent(FlowEvent):
    """Event emitted when a conversational Flow selects a route for a turn."""

    session_id: str
    route: str
    user_message: str | None = None
    message_index: int | None = None
    previous_intent: str | None = None
    type: Literal["conversation_route_selected"] = "conversation_route_selected"


class HumanFeedbackRequestedEvent(FlowEvent):
    """Event emitted when human feedback is requested.

    This event is emitted when a @human_feedback decorated method
    requires input from a human reviewer.

    Attributes:
        flow_name: Name of the flow requesting feedback.
        method_name: Name of the method decorated with @human_feedback.
        output: The method output shown to the human for review.
        message: The message displayed when requesting feedback.
        emit: Optional list of possible outcomes for routing.
        request_id: Platform-assigned identifier for this feedback request,
            used for correlating the request across system boundaries.
    """

    method_name: str
    output: Any
    message: str
    emit: list[str] | None = None
    request_id: str | None = None
    type: Literal["human_feedback_requested"] = "human_feedback_requested"


class HumanFeedbackReceivedEvent(FlowEvent):
    """Event emitted when human feedback is received.

    This event is emitted after a human provides feedback in response
    to a @human_feedback decorated method.

    Attributes:
        flow_name: Name of the flow that received feedback.
        method_name: Name of the method that received feedback.
        feedback: The raw text feedback provided by the human.
        outcome: The collapsed outcome string (if emit was specified).
        request_id: Platform-assigned identifier for this feedback request,
            used for correlating the response back to its originating request.
    """

    method_name: str
    feedback: str
    outcome: str | None = None
    request_id: str | None = None
    type: Literal["human_feedback_received"] = "human_feedback_received"
