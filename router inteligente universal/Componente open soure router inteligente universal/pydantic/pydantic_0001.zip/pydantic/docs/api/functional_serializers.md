::: pydantic.functional_serializers
