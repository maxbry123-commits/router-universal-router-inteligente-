currentDirectory::/home/src/workspaces/solution
useCaseSensitiveFileNames::true
Input::
//// [/home/src/workspaces/solution/project1/src/a.ts] *new* 
export const a = 10;const aLocal = 10;
//// [/home/src/workspaces/solution/project1/src/b.ts] *new* 
export const b = 10;const bLocal = 10;
//// [/home/src/workspaces/solution/project1/src/c.ts] *new* 
import { a } from "./a";export const c = a;
//// [/home/src/workspaces/solution/project1/src/d.ts] *new* 
import { b } from "./b";export const d = b;
//// [/home/src/workspaces/solution/project1/src/tsconfig.json] *new* 
{
    "compilerOptions": { "declaration": true }
}
//// [/home/src/workspaces/solution/project2/src/e.ts] *new* 
export const e = 10;
//// [/home/src/workspaces/solution/project2/src/f.ts] *new* 
import { a } from "../../project1/src/a"; export const f = a;
//// [/home/src/workspaces/solution/project2/src/g.ts] *new* 
import { b } from "../../project1/src/b"; export const g = b;
//// [/home/src/workspaces/solution/project2/src/tsconfig.json] *new* 
{
    "compilerOptions": { "declaration": true },
    "references": [{ "path": "../../project1/src" }]
}

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output file 'project1/src/tsconfig.tsbuildinfo' does not exist

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because output file 'project2/src/tsconfig.tsbuildinfo' does not exist

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/tslibs/TS/Lib/lib.es2025.full.d.ts] *Lib*
/// <reference no-default-lib="true"/>
interface Boolean {}
interface Function {}
interface CallableFunction {}
interface NewableFunction {}
interface IArguments {}
interface Number { toExponential: any; }
interface Object {}
interface RegExp {}
interface String { charAt: any; }
interface Array<T> { length: number; [n: number]: T; }
interface ReadonlyArray<T> {}
interface SymbolConstructor {
    (desc?: string | number): symbol;
    for(name: string): symbol;
    readonly toStringTag: symbol;
}
declare var Symbol: SymbolConstructor;
interface Symbol {
    readonly [Symbol.toStringTag]: string;
}
declare const console: { log(msg: any): void; };
//// [/home/src/workspaces/solution/project1/src/a.d.ts] *new* 
export declare const a = 10;

//// [/home/src/workspaces/solution/project1/src/b.d.ts] *new* 
export declare const b = 10;

//// [/home/src/workspaces/solution/project1/src/c.d.ts] *new* 
export declare const c = 10;

//// [/home/src/workspaces/solution/project1/src/d.d.ts] *new* 
export declare const d = 10;

//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *new* 
{"version":"FakeTSVersion","root":["./a.ts","./b.ts","./c.ts","./d.ts"]}
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *new* 
{
  "version": "FakeTSVersion",
  "root": [
    {
      "files": [
        "./a.ts"
      ],
      "original": "./a.ts"
    },
    {
      "files": [
        "./b.ts"
      ],
      "original": "./b.ts"
    },
    {
      "files": [
        "./c.ts"
      ],
      "original": "./c.ts"
    },
    {
      "files": [
        "./d.ts"
      ],
      "original": "./d.ts"
    }
  ],
  "size": 72
}
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *new* 
export declare const e = 10;

//// [/home/src/workspaces/solution/project2/src/f.d.ts] *new* 
export declare const f = 10;

//// [/home/src/workspaces/solution/project2/src/g.d.ts] *new* 
export declare const g = 10;

//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *new* 
{"version":"FakeTSVersion","errors":true,"root":["./e.ts","./f.ts","./g.ts"]}
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *new* 
{
  "version": "FakeTSVersion",
  "errors": true,
  "root": [
    {
      "files": [
        "./e.ts"
      ],
      "original": "./e.ts"
    },
    {
      "files": [
        "./f.ts"
      ],
      "original": "./f.ts"
    },
    {
      "files": [
        "./g.ts"
      ],
      "original": "./g.ts"
    }
  ],
  "size": 77
}

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [0]:: no change

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is up to date because newest input 'project1/src/d.ts' is older than output 'project1/src/a.d.ts'

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [1]:: local change
//// [/home/src/workspaces/solution/project1/src/a.ts] *modified* 
export const a = 10;const aLocal = 10;const aa = 10;

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output 'project1/src/tsconfig.tsbuildinfo' is older than input 'project1/src/a.ts'

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [2]:: non local change
//// [/home/src/workspaces/solution/project1/src/a.ts] *modified* 
export const a = 10;const aLocal = 10;const aa = 10;export const aaa = 10;

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output 'project1/src/tsconfig.tsbuildinfo' is older than input 'project1/src/a.ts'

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *modified* 
export declare const a = 10;
export declare const aaa = 10;

//// [/home/src/workspaces/solution/project1/src/b.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [3]:: emit js files

tsgo --b project2/src --verbose
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output file 'project1/src/a.js' does not exist

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/a.js] *new* 
export const a = 10;
const aLocal = 10;
const aa = 10;
export const aaa = 10;

//// [/home/src/workspaces/solution/project1/src/b.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.js] *new* 
export const b = 10;
const bLocal = 10;

//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/c.js] *new* 
import { a } from "./a";
export const c = a;

//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.js] *new* 
import { b } from "./b";
export const d = b;

//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.js] *new* 
export const e = 10;

//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.js] *new* 
import { a } from "../../project1/src/a";
export const f = a;

//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.js] *new* 
import { b } from "../../project1/src/b";
export const g = b;

//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [4]:: no change

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is up to date because newest input 'project1/src/a.ts' is older than output 'project1/src/a.d.ts'

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [5]:: js emit with change without emitDeclarationOnly
//// [/home/src/workspaces/solution/project1/src/b.ts] *modified* 
export const b = 10;const bLocal = 10;const alocal = 10;

tsgo --b project2/src --verbose
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output 'project1/src/tsconfig.tsbuildinfo' is older than input 'project1/src/b.ts'

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/a.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.js] *modified* 
export const b = 10;
const bLocal = 10;
const alocal = 10;

//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/c.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [6]:: local change
//// [/home/src/workspaces/solution/project1/src/b.ts] *modified* 
export const b = 10;const bLocal = 10;const alocal = 10;const aaaa = 10;

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output 'project1/src/tsconfig.tsbuildinfo' is older than input 'project1/src/b.ts'

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [7]:: non local change
//// [/home/src/workspaces/solution/project1/src/b.ts] *modified* 
export const b = 10;const bLocal = 10;const alocal = 10;const aaaa = 10;export const aaaaa = 10;

tsgo --b project2/src --verbose --emitDeclarationOnly
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output 'project1/src/tsconfig.tsbuildinfo' is older than input 'project1/src/b.ts'

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.d.ts] *modified* 
export declare const b = 10;
export declare const aaaaa = 10;

//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::


Edit [8]:: js emit with change without emitDeclarationOnly
//// [/home/src/workspaces/solution/project1/src/b.ts] *modified* 
export const b = 10;const bLocal = 10;const alocal = 10;const aaaa = 10;export const aaaaa = 10;export const a2 = 10;

tsgo --b project2/src --verbose
ExitStatus:: DiagnosticsPresent_OutputsGenerated
Output::
[[90mHH:MM:SS AM[0m] Projects in this build: 
    * project1/src/tsconfig.json
    * project2/src/tsconfig.json

[[90mHH:MM:SS AM[0m] Project 'project1/src/tsconfig.json' is out of date because output 'project1/src/tsconfig.tsbuildinfo' is older than input 'project1/src/b.ts'

[[90mHH:MM:SS AM[0m] Building project 'project1/src/tsconfig.json'...

[[90mHH:MM:SS AM[0m] Project 'project2/src/tsconfig.json' is out of date because buildinfo file 'project2/src/tsconfig.tsbuildinfo' indicates that program needs to report errors.

[[90mHH:MM:SS AM[0m] Building project 'project2/src/tsconfig.json'...

[96mproject2/src/tsconfig.json[0m:[93m3[0m:[93m20[0m - [91merror[0m[90m TS6306: [0mReferenced project '/home/src/workspaces/solution/project1/src' must have setting "composite": true.

[7m3[0m     "references": [{ "path": "../../project1/src" }]
[7m [0m [91m                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[0m


Found 1 error in project2/src/tsconfig.json[90m:3[0m

//// [/home/src/workspaces/solution/project1/src/a.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/a.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/b.d.ts] *modified* 
export declare const b = 10;
export declare const aaaaa = 10;
export declare const a2 = 10;

//// [/home/src/workspaces/solution/project1/src/b.js] *modified* 
export const b = 10;
const bLocal = 10;
const alocal = 10;
const aaaa = 10;
export const aaaaa = 10;
export const a2 = 10;

//// [/home/src/workspaces/solution/project1/src/c.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/c.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/d.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project1/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/e.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/f.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.d.ts] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/g.js] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo] *rewrite with same content*
//// [/home/src/workspaces/solution/project2/src/tsconfig.tsbuildinfo.readable.baseline.txt] *rewrite with same content*

project1/src/tsconfig.json::
SemanticDiagnostics::
*refresh*    /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*refresh*    /home/src/workspaces/solution/project1/src/a.ts
*refresh*    /home/src/workspaces/solution/project1/src/b.ts
*refresh*    /home/src/workspaces/solution/project1/src/c.ts
*refresh*    /home/src/workspaces/solution/project1/src/d.ts
Signatures::

project2/src/tsconfig.json::
SemanticDiagnostics::
*not cached* /home/src/tslibs/TS/Lib/lib.es2025.full.d.ts
*not cached* /home/src/workspaces/solution/project2/src/e.ts
*not cached* /home/src/workspaces/solution/project1/src/a.d.ts
*not cached* /home/src/workspaces/solution/project2/src/f.ts
*not cached* /home/src/workspaces/solution/project1/src/b.d.ts
*not cached* /home/src/workspaces/solution/project2/src/g.ts
Signatures::
