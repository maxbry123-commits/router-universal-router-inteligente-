//// [tests/cases/compiler/declFileGenericType2.ts] ////

//// [declFileGenericType2.ts]
declare namespace templa.mvc {
    interface IModel {
    }
}
declare namespace templa.mvc {
    interface IController<ModelType extends templa.mvc.IModel> {
    }
}
declare namespace templa.mvc {
    class AbstractController<ModelType extends templa.mvc.IModel> implements mvc.IController<ModelType> {
    }
}
declare namespace templa.mvc.composite {
    interface ICompositeControllerModel extends mvc.IModel {
        getControllers(): mvc.IController<mvc.IModel>[];
    }
}
namespace templa.dom.mvc {
    export interface IElementController<ModelType extends templa.mvc.IModel> extends templa.mvc.IController<ModelType> {
    }
}
// Module
namespace templa.dom.mvc {

    export class AbstractElementController<ModelType extends templa.mvc.IModel> extends templa.mvc.AbstractController<ModelType> implements IElementController<ModelType> {
        constructor() {
            super();
        }
    }
}
// Module
namespace templa.dom.mvc.composite {
    export class AbstractCompositeElementController<ModelType extends templa.mvc.composite.ICompositeControllerModel> extends templa.dom.mvc.AbstractElementController<ModelType> {
        public _controllers: templa.mvc.IController<templa.mvc.IModel>[];
        constructor() {
            super();
            this._controllers = [];
        }
    }
}


//// [declFileGenericType2.js]
"use strict";
// Module
var templa;
(function (templa) {
    var dom;
    (function (dom) {
        var mvc;
        (function (mvc) {
            class AbstractElementController extends templa.mvc.AbstractController {
                constructor() {
                    super();
                }
            }
            mvc.AbstractElementController = AbstractElementController;
        })(mvc = dom.mvc || (dom.mvc = {}));
    })(dom = templa.dom || (templa.dom = {}));
})(templa || (templa = {}));
// Module
(function (templa) {
    var dom;
    (function (dom) {
        var mvc;
        (function (mvc) {
            var composite;
            (function (composite) {
                class AbstractCompositeElementController extends templa.dom.mvc.AbstractElementController {
                    constructor() {
                        super();
                        this._controllers = [];
                    }
                }
                composite.AbstractCompositeElementController = AbstractCompositeElementController;
            })(composite = mvc.composite || (mvc.composite = {}));
        })(mvc = dom.mvc || (dom.mvc = {}));
    })(dom = templa.dom || (templa.dom = {}));
})(templa || (templa = {}));


//// [declFileGenericType2.d.ts]
declare namespace templa.mvc {
    interface IModel {
    }
}
declare namespace templa.mvc {
    interface IController<ModelType extends templa.mvc.IModel> {
    }
}
declare namespace templa.mvc {
    class AbstractController<ModelType extends templa.mvc.IModel> implements mvc.IController<ModelType> {
    }
}
declare namespace templa.mvc.composite {
    interface ICompositeControllerModel extends mvc.IModel {
        getControllers(): mvc.IController<mvc.IModel>[];
    }
}
declare namespace templa.dom.mvc {
    interface IElementController<ModelType extends templa.mvc.IModel> extends templa.mvc.IController<ModelType> {
    }
}
declare namespace templa.dom.mvc {
    class AbstractElementController<ModelType extends templa.mvc.IModel> extends templa.mvc.AbstractController<ModelType> implements IElementController<ModelType> {
        constructor();
    }
}
declare namespace templa.dom.mvc.composite {
    class AbstractCompositeElementController<ModelType extends templa.mvc.composite.ICompositeControllerModel> extends templa.dom.mvc.AbstractElementController<ModelType> {
        _controllers: templa.mvc.IController<templa.mvc.IModel>[];
        constructor();
    }
}
