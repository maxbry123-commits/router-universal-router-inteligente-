//// [tests/cases/compiler/interMixingModulesInterfaces3.ts] ////

//// [interMixingModulesInterfaces3.ts]
namespace A {

    namespace B {
        export function createB(): B {
            return null;
        }
    }

    export interface B {
        name: string;
        value: number;
    }
}

var x: A.B = null;

//// [interMixingModulesInterfaces3.js]
"use strict";
var A;
(function (A) {
    let B;
    (function (B) {
        function createB() {
            return null;
        }
        B.createB = createB;
    })(B || (B = {}));
})(A || (A = {}));
var x = null;
