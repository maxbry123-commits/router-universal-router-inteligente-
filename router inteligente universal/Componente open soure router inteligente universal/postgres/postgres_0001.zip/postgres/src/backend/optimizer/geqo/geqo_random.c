/*------------------------------------------------------------------------
 *
 * geqo_random.c
 *	   random number generator
 *
 * Portions Copyright (c) 1996-2026, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * src/backend/optimizer/geqo/geqo_random.c
 *
 *-------------------------------------------------------------------------
 */

#include "postgres.h"

#include "optimizer/geqo_random.h"

void
geqo_set_seed(PlannerInfo *root, double seed)
{
	GeqoPrivateData *private = GetGeqoPrivateData(root);

	pg_prng_fseed(&private->random_state, seed);
}

double
geqo_rand(PlannerInfo *root)
{
	GeqoPrivateData *private = GetGeqoPrivateData(root);

	return pg_prng_double(&private->random_state);
}

int
geqo_randint(PlannerInfo *root, int upper, int lower)
{
	GeqoPrivateData *private = GetGeqoPrivateData(root);

	/*
	 * In current usage, "lower" is never negative so we can just use
	 * pg_prng_uint64_range directly.
	 */
	return (int) pg_prng_uint64_range(&private->random_state, lower, upper);
}
