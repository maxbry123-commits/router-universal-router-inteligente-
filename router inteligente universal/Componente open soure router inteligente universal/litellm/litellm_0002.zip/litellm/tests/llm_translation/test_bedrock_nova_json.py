from base_llm_unit_tests import BaseLLMChatTest
import pytest

import litellm


class TestBedrockNovaJson(BaseLLMChatTest):
    def get_base_completion_call_args(self) -> dict:
        litellm._turn_on_debug()
        return {
            "model": "bedrock/converse/us.amazon.nova-micro-v1:0",
        }

    def test_json_response_nested_pydantic_obj(self):
        pass

    def test_json_response_nested_json_schema(self):
        pass

    def test_tool_call_no_arguments(self, tool_call_no_arguments):
        """Test that tool calls with no arguments is translated correctly. Relevant issue: https://github.com/BerriAI/litellm/issues/6833"""
        pass

    def test_prompt_caching(self):
        """
        Remove override once we have access to Bedrock prompt caching
        """
        pass

    # @pytest.fixture(autouse=True)
    # def skip_non_json_tests(self, request):
    #     if not "json" in request.function.__name__.lower():
    #         pytest.skip(
    #             f"Skipping non-JSON test: {request.function.__name__} does not contain 'json'"
    #         )
