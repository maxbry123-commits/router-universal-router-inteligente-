package appregistry

import (
	"github.com/google/wire"

	"github.com/grafana/grafana/pkg/registry/apps/alerting/historian"
	"github.com/grafana/grafana/pkg/registry/apps/alerting/notifications"
	"github.com/grafana/grafana/pkg/registry/apps/alerting/rules"
	"github.com/grafana/grafana/pkg/registry/apps/annotation"
	"github.com/grafana/grafana/pkg/registry/apps/correlations"
	"github.com/grafana/grafana/pkg/registry/apps/dashvalidator"
	"github.com/grafana/grafana/pkg/registry/apps/example"
	"github.com/grafana/grafana/pkg/registry/apps/live"
	"github.com/grafana/grafana/pkg/registry/apps/logsdrilldown"
	"github.com/grafana/grafana/pkg/registry/apps/playlist"
	"github.com/grafana/grafana/pkg/registry/apps/plugins"
	"github.com/grafana/grafana/pkg/registry/apps/quotas"
	"github.com/grafana/grafana/pkg/registry/apps/shorturl"
)

var WireSet = wire.NewSet(
	ProvideAppInstallers,
	ProvideBuilderRunners,
	playlist.RegisterAppInstaller,
	plugins.ProvideAppInstaller,
	shorturl.RegisterAppInstaller,
	correlations.RegisterAppInstaller,
	rules.RegisterAppInstaller,
	live.RegisterAppInstaller,
	notifications.RegisterAppInstaller,
	historian.RegisterAppInstaller,
	logsdrilldown.RegisterAppInstaller,
	annotation.RegisterAppInstaller,
	quotas.RegisterAppInstaller,
	example.RegisterAppInstaller,
	dashvalidator.RegisterAppInstaller,
)
