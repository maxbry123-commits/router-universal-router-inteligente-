import { type IExecuteFunctions, type INodeExecutionData } from 'n8n-workflow';

import * as base from './base/base.resource';
import * as linkrows from './linkrows/linkrows.resource';
import * as rows from './rows/rows.resource';

export async function router(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
	let operationResult: INodeExecutionData[][] = [];

	const resource = this.getNodeParameter('resource', 0);
	const operation = this.getNodeParameter('operation', 0);

	switch (resource) {
		case 'base': {
			switch (operation) {
				case 'get': {
					operationResult = await base.get.execute.call(this);
					break;
				}
				case 'getAll': {
					operationResult = await base.getAll.execute.call(this);
					break;
				}
			}
			break;
		}
		case 'row': {
			switch (operation) {
				case 'count': {
					operationResult = await rows.count.execute.call(this);
					break;
				}
				case 'get': {
					operationResult = await rows.get.execute.call(this);
					break;
				}
				case 'search': {
					operationResult = await rows.search.execute.call(this);
					break;
				}
				case 'create': {
					operationResult = await rows.create.execute.call(this);
					break;
				}
				case 'update': {
					operationResult = await rows.update.execute.call(this);
					break;
				}
				case 'upsert': {
					operationResult = await rows.upsert.execute.call(this);
					break;
				}
				case 'upload': {
					operationResult = await rows.upload.execute.call(this);
					break;
				}
				case 'delete': {
					operationResult = await rows.delete.execute.call(this);
					break;
				}
			}
			break;
		}
		case 'linkrow': {
			switch (operation) {
				case 'list': {
					operationResult = await linkrows.list.execute.call(this);
					break;
				}
				case 'link': {
					operationResult = await linkrows.link.execute.call(this);
					break;
				}
				case 'unlink': {
					operationResult = await linkrows.unlink.execute.call(this);
					break;
				}
			}
			break;
		}
	}

	return operationResult;
}
