import { setTestFlags } from '@grafana/test-utils/unstable';

import { FlagKeys } from '../../internal/openFeature/openfeature.gen';
import { invalidateCachedPromisesCache } from '../../utils/getCachedPromise';
import { type MonitoringLogger } from '../../utils/logging';
import { type BackendSrv, setBackendSrv } from '../backendSrv';
import { setLogger, initializeLoggersRegistry } from '../logging/registry';
import { getPluginMetaFromCache, refetchPluginMeta } from '../pluginMeta/plugins';
import { clockPanelMetaOnPrem, myOrgTestAppMeta, v0alpha1Response } from '../pluginMeta/test-fixtures/v0alpha1Response';

import { getPluginSettings } from './getPluginSettings';
import { legacyMyOrgTestAppSettings } from './test-fixtures/legacy.settings';
import {
  clockPanelOnPremPluginMeta,
  cloudwatchPluginMeta,
  myOrgTestAppSettings,
} from './test-fixtures/v0alpha1Response';

jest.mock('../pluginMeta/plugins', () => ({
  ...jest.requireActual('../pluginMeta/plugins'),
  getPluginMetaFromCache: jest.fn(),
  refetchPluginMeta: jest.fn(),
}));

const getPluginMetaFromCacheMock = jest.mocked(getPluginMetaFromCache);
const refetchPluginMetaMock = jest.mocked(refetchPluginMeta);
const cloudwatch = v0alpha1Response.items.find((i) => i.spec.pluginJson.id === 'cloudwatch')!;

describe('settings', () => {
  let backendSrv: BackendSrv;
  let logger: MonitoringLogger;

  beforeAll(() => {
    initializeLoggersRegistry();
  });

  beforeEach(() => {
    jest.clearAllMocks();
    invalidateCachedPromisesCache();
    backendSrv = {
      chunked: jest.fn(),
      delete: jest.fn(),
      fetch: jest.fn(),
      get: jest.fn(),
      patch: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      datasourceRequest: jest.fn(),
      request: jest.fn(),
    };
    setBackendSrv(backendSrv);
    logger = {
      logDebug: jest.fn(),
      logError: jest.fn(),
      logInfo: jest.fn(),
      logMeasurement: jest.fn(),
      logWarning: jest.fn(),
    };
    setLogger('grafana/runtime.plugins.settings', logger);
  });

  describe('when plugins.useMTPluginSettings flag is enabled', () => {
    beforeAll(() => {
      setTestFlags({ [FlagKeys.PluginsUseMTPluginSettings]: true });
    });

    afterAll(() => {
      setTestFlags({});
    });

    beforeEach(() => {
      getPluginMetaFromCacheMock.mockResolvedValue(myOrgTestAppMeta);
      refetchPluginMetaMock.mockResolvedValue(myOrgTestAppMeta);
      backendSrv.get = jest.fn().mockResolvedValue(myOrgTestAppSettings);
    });

    describe('getPluginSettings', () => {
      it('should fetch settings from new apis when cache is empty', async () => {
        const response = await getPluginSettings(myOrgTestAppSettings.metadata.name);

        expect(response).toMatchObject(legacyMyOrgTestAppSettings);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith(
          '/apis/myorg-test-app/v0alpha1/namespaces/default/app/instance',
          undefined,
          undefined,
          {
            showErrorAlert: false,
            validatePath: true,
          }
        );
      });

      it('should not fetch settings from new apis when cache exists', async () => {
        const resp1 = await getPluginSettings(myOrgTestAppSettings.metadata.name);
        const resp2 = await getPluginSettings(myOrgTestAppSettings.metadata.name);

        expect(resp1).toMatchObject(legacyMyOrgTestAppSettings);
        expect(resp1).toStrictEqual(resp2);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith(
          '/apis/myorg-test-app/v0alpha1/namespaces/default/app/instance',
          undefined,
          undefined,
          {
            showErrorAlert: false,
            validatePath: true,
          }
        );
      });

      it('should just map panel plugins', async () => {
        getPluginMetaFromCacheMock.mockResolvedValue(clockPanelMetaOnPrem);

        const result = await getPluginSettings(clockPanelMetaOnPrem.spec.pluginJson.id);

        expect(result).toEqual(clockPanelOnPremPluginMeta);
        expect(backendSrv.get).not.toHaveBeenCalled();
      });

      it('should just map data source plugins', async () => {
        getPluginMetaFromCacheMock.mockResolvedValue(cloudwatch);

        const result = await getPluginSettings(cloudwatch.spec.pluginJson.id);

        expect(result).toEqual(cloudwatchPluginMeta);
        expect(backendSrv.get).not.toHaveBeenCalled();
      });

      it('should reject with Unknown Plugin message if error status is not 403 or 401', async () => {
        const error = { status: 404, message: 'Not found' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(myOrgTestAppSettings.metadata.name)).rejects.toEqual(
          new Error('Unknown Plugin')
        );
      });

      it('should reject thrown error if error status is 403', async () => {
        const error = { status: 403, message: 'Forbidden' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(myOrgTestAppSettings.metadata.name)).rejects.toEqual({
          ...error,
          isHandled: true,
        });
      });

      it('should reject thrown error if error status is 401', async () => {
        const error = { status: 401, message: 'Unauthorized' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(myOrgTestAppSettings.metadata.name)).rejects.toEqual({
          ...error,
          isHandled: true,
        });
      });

      it('should fallback to legacy api when meta is null', async () => {
        getPluginMetaFromCacheMock.mockResolvedValue(null);
        backendSrv.get = jest.fn().mockResolvedValue(legacyMyOrgTestAppSettings);

        const response = await getPluginSettings(legacyMyOrgTestAppSettings.id);

        expect(response).toMatchObject(legacyMyOrgTestAppSettings);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith('/api/plugins/myorg-test-app/settings', undefined, undefined, {
          showErrorAlert: false,
          validatePath: true,
        });
      });
    });
  });

  describe('when plugins.useMTPluginSettings flag is disabled', () => {
    beforeAll(() => {
      setTestFlags({ [FlagKeys.PluginsUseMTPluginSettings]: false });
    });

    afterAll(() => {
      setTestFlags({});
    });

    beforeEach(() => {
      backendSrv.get = jest.fn().mockResolvedValue(legacyMyOrgTestAppSettings);
    });

    describe('getPluginSettings', () => {
      it('should fetch settings when cache is empty', async () => {
        const response = await getPluginSettings(legacyMyOrgTestAppSettings.id);

        expect(response).toEqual(legacyMyOrgTestAppSettings);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith('/api/plugins/myorg-test-app/settings', undefined, undefined, {
          showErrorAlert: false,
          validatePath: true,
        });
      });

      it('should not fetch settings from new apis when cache exists', async () => {
        const resp1 = await getPluginSettings(legacyMyOrgTestAppSettings.id);
        const resp2 = await getPluginSettings(legacyMyOrgTestAppSettings.id);

        expect(resp1).toMatchObject(legacyMyOrgTestAppSettings);
        expect(resp1).toStrictEqual(resp2);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith('/api/plugins/myorg-test-app/settings', undefined, undefined, {
          showErrorAlert: false,
          validatePath: true,
        });
      });

      it('should reject with Unknown Plugin message if error status is not 403 or 401', async () => {
        const error = { status: 404, message: 'Not found' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(legacyMyOrgTestAppSettings.id)).rejects.toEqual(new Error('Unknown Plugin'));
      });

      it('should reject thrown error if error status is 403', async () => {
        const error = { status: 403, message: 'Forbidden' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(legacyMyOrgTestAppSettings.id)).rejects.toEqual({ ...error, isHandled: true });
      });

      it('should reject thrown error if error status is 401', async () => {
        const error = { status: 401, message: 'Unauthorized' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(legacyMyOrgTestAppSettings.id)).rejects.toEqual({ ...error, isHandled: true });
      });
    });
  });

  describe('when plugins.useMTPluginSettings flag is enabled but plugins.useMTPlugins is disabled', () => {
    beforeAll(() => {
      setTestFlags({ [FlagKeys.PluginsUseMTPlugins]: false });
      setTestFlags({ [FlagKeys.PluginsUseMTPluginSettings]: true });
    });

    afterAll(() => {
      setTestFlags({});
    });

    beforeEach(() => {
      backendSrv.get = jest.fn().mockResolvedValue(legacyMyOrgTestAppSettings);
    });

    describe('getPluginSettings', () => {
      it('should fetch settings when cache is empty', async () => {
        const response = await getPluginSettings(legacyMyOrgTestAppSettings.id);

        expect(response).toEqual(legacyMyOrgTestAppSettings);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith('/api/plugins/myorg-test-app/settings', undefined, undefined, {
          showErrorAlert: false,
          validatePath: true,
        });
      });

      it('should not fetch settings from new apis when cache exists', async () => {
        const resp1 = await getPluginSettings(legacyMyOrgTestAppSettings.id);
        const resp2 = await getPluginSettings(legacyMyOrgTestAppSettings.id);

        expect(resp1).toMatchObject(legacyMyOrgTestAppSettings);
        expect(resp1).toStrictEqual(resp2);
        expect(backendSrv.get).toHaveBeenCalledTimes(1);
        expect(backendSrv.get).toHaveBeenCalledWith('/api/plugins/myorg-test-app/settings', undefined, undefined, {
          showErrorAlert: false,
          validatePath: true,
        });
      });

      it('should reject with Unknown Plugin message if error status is not 403 or 401', async () => {
        const error = { status: 404, message: 'Not found' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(legacyMyOrgTestAppSettings.id)).rejects.toEqual(new Error('Unknown Plugin'));
      });

      it('should reject thrown error if error status is 403', async () => {
        const error = { status: 403, message: 'Forbidden' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(legacyMyOrgTestAppSettings.id)).rejects.toEqual({ ...error, isHandled: true });
      });

      it('should reject thrown error if error status is 401', async () => {
        const error = { status: 401, message: 'Unauthorized' };
        backendSrv.get = jest.fn().mockRejectedValue(error);

        await expect(getPluginSettings(legacyMyOrgTestAppSettings.id)).rejects.toEqual({ ...error, isHandled: true });
      });
    });
  });
});
