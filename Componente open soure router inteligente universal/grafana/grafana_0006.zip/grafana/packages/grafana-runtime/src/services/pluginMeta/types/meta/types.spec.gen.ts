// Code generated - EDITING IS FUTILE. DO NOT EDIT.

/**
 * JSON configuration schema for Grafana plugins
 * Converted from: https://github.com/grafana/grafana/blob/main/docs/sources/developers/plugins/plugin.schema.json
 */
export interface JSONData {
	// Unique name of the plugin
	id: string;
	// Plugin type
	type: "app" | "datasource" | "panel" | "renderer";
	// Human-readable name of the plugin
	name: string;
	// Metadata for the plugin
	info: Info;
	// Dependency information
	dependencies: Dependencies;
	// Optional fields
	alerting?: boolean;
	annotations?: boolean;
	autoEnabled?: boolean;
	backend?: boolean;
	buildMode?: string;
	builtIn?: boolean;
	category?: string;
	enterpriseFeatures?: EnterpriseFeatures;
	executable?: string;
	hideFromList?: boolean;
	// +listType=atomic
	includes?: Include[];
	logs?: boolean;
	metrics?: boolean;
	multiValueFilterOperators?: boolean;
	pascalName?: string;
	preload?: boolean;
	queryOptions?: QueryOptions;
	// +listType=atomic
	routes?: Route[];
	skipDataQuery?: boolean;
	state?: "alpha" | "beta" | "stable" | "deprecated";
	streaming?: boolean;
	suggestions?: boolean;
	tracing?: boolean;
	iam?: IAM;
	// +listType=atomic
	roles?: Role[];
	extensions?: Extensions;
	// +listType=atomic
	languages?: string[];
}

export const defaultJSONData = (): JSONData => ({
	id: "",
	type: "app",
	name: "",
	info: defaultInfo(),
	dependencies: defaultDependencies(),
});

export interface Info {
	// Required fields
	// +listType=set
	keywords: string[];
	logos: {
		small: string;
		large: string;
	};
	updated: string;
	version: string;
	// Optional fields
	author?: {
		name?: string;
		email?: string;
		url?: string;
	};
	description?: string;
	build?: {
		time?: number;
		repo?: string;
		branch?: string;
		hash?: string;
		// Quoted to avoid conflict with CUE 'number' type
		number?: number;
		pr?: number;
		build?: number;
	};
	// +listType=atomic
	links?: {
		name?: string;
		url?: string;
		target?: "_blank" | "_self" | "_parent" | "_top";
	}[];
	// +listType=atomic
	screenshots?: {
		name?: string;
		path?: string;
	}[];
}

export const defaultInfo = (): Info => ({
	keywords: [],
	logos: {
	small: "",
	large: "",
},
	updated: "",
	version: "",
});

export interface Dependencies {
	// Required field
	grafanaDependency: string;
	// Optional fields
	grafanaVersion?: string;
	// +listType=set
	// +listMapKey=id
	plugins?: {
		id: string;
		type: "app" | "datasource" | "panel";
		name: string;
	}[];
	extensions?: {
		// +listType=set
		exposedComponents?: string[];
	};
}

export const defaultDependencies = (): Dependencies => ({
	grafanaDependency: "",
});

export interface EnterpriseFeatures {
	// Allow additional properties
	healthDiagnosticsErrors?: boolean;
}

export const defaultEnterpriseFeatures = (): EnterpriseFeatures => ({
	healthDiagnosticsErrors: false,
});

export interface Include {
	uid?: string;
	type?: "dashboard" | "page" | "panel" | "datasource";
	name?: string;
	component?: string;
	role?: "Admin" | "Editor" | "Viewer" | "None";
	action?: string;
	path?: string;
	addToNav?: boolean;
	defaultNav?: boolean;
	icon?: string;
}

export const defaultInclude = (): Include => ({
});

export interface QueryOptions {
	maxDataPoints?: boolean;
	minInterval?: boolean;
	cacheTimeout?: boolean;
}

export const defaultQueryOptions = (): QueryOptions => ({
});

export interface Route {
	path?: string;
	method?: string;
	url?: string;
	reqSignedIn?: boolean;
	reqRole?: string;
	reqAction?: string;
	// +listType=atomic
	headers?: {
		name: string;
		content: string;
	}[];
	body?: Record<string, any>;
	tokenAuth?: {
		url?: string;
		// +listType=set
		scopes?: string[];
		params?: {
			// Allow additional properties
			grant_type?: string;
			// Allow additional properties
			client_id?: string;
			// Allow additional properties
			client_secret?: string;
			// Allow additional properties
			resource?: string;
		};
	};
	jwtTokenAuth?: {
		url?: string;
		// +listType=set
		scopes?: string[];
		params?: {
			// Allow additional properties
			token_uri?: string;
			// Allow additional properties
			client_email?: string;
			// Allow additional properties
			private_key?: string;
		};
	};
	// +listType=atomic
	urlParams?: {
		name?: string;
		content?: string;
	}[];
}

export const defaultRoute = (): Route => ({
});

export interface IAM {
	// +listType=atomic
	permissions?: {
		action?: string;
		scope?: string;
	}[];
}

export const defaultIAM = (): IAM => ({
});

export interface Role {
	role?: {
		name?: string;
		description?: string;
		// +listType=atomic
		permissions?: {
			action?: string;
			scope?: string;
		}[];
	};
	// +listType=set
	grants?: string[];
}

export const defaultRole = (): Role => ({
});

export interface Extensions {
	// +listType=atomic
	addedComponents?: {
		// +listType=set
		targets: string[];
		title: string;
		description?: string;
	}[];
	// +listType=atomic
	addedLinks?: {
		// +listType=set
		targets: string[];
		title: string;
		description?: string;
	}[];
	// +listType=atomic
	addedFunctions?: {
		// +listType=set
		targets: string[];
		title: string;
		description?: string;
	}[];
	// +listType=set
	// +listMapKey=id
	exposedComponents?: {
		id: string;
		title?: string;
		description?: string;
	}[];
	// +listType=set
	// +listMapKey=id
	extensionPoints?: {
		id: string;
		title?: string;
		description?: string;
	}[];
}

export const defaultExtensions = (): Extensions => ({
});

export interface Spec {
	pluginJson: JSONData;
	class: "core" | "external";
	module: {
		path: string;
		hash?: string;
		loadingStrategy: "fetch" | "script";
	};
	baseURL: string;
	signature: {
		status: "internal" | "valid" | "invalid" | "modified" | "unsigned";
		type?: "grafana" | "commercial" | "community" | "private" | "private-glob";
		org?: string;
	};
	translations?: Record<string, string>;
	// +listType=atomic
	children?: string[];
	// +listType=atomic
	aliasIds?: string[];
}

export const defaultSpec = (): Spec => ({
	pluginJson: defaultJSONData(),
	class: "core",
	module: {
	path: "",
	loadingStrategy: "fetch",
},
	baseURL: "",
	signature: {
	status: "internal",
},
});

