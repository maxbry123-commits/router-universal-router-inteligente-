import type { JsonTree } from '@react-awesome-query-builder/ui';

import {
  type DataFrame,
  type DataQuery,
  type DataSourceJsonData,
  type MetricFindValue,
  type SelectableValue,
  type TimeRange,
  toOption as toOptionFromData,
} from '@grafana/data';
import { type EditorMode, type LanguageDefinition } from '@grafana/plugin-ui';

import { type QueryWithDefaults } from './defaults';
import {
  type QueryEditorFunctionExpression,
  type QueryEditorGroupByExpression,
  type QueryEditorPropertyExpression,
} from './expressions';

export interface SQLConnectionLimits {
  maxOpenConns: number;
  maxIdleConns: number;
  maxIdleConnsAuto: boolean;
  connMaxLifetime: number;
}

export interface SQLOptions extends SQLConnectionLimits, DataSourceJsonData {
  tlsAuth: boolean;
  tlsAuthWithCACert: boolean;
  timezone: string;
  tlsSkipVerify: boolean;
  user: string;
  database: string;
  url: string;
  timeInterval: string;
}

export enum QueryFormat {
  Timeseries = 'time_series',
  Table = 'table',
}

export type SQLQueryMeta = { valueField?: string; textField?: string };

export interface SQLQuery extends DataQuery {
  alias?: string;
  format?: QueryFormat;
  rawSql?: string;
  dataset?: string;
  table?: string;
  sql?: SQLExpression;
  editorMode?: EditorMode;
  rawQuery?: boolean;
  meta?: SQLQueryMeta;
}

export type SQLVariableQuery = { query: string } & SQLQuery;

interface NameValue {
  name: string;
  value: string;
}

type SQLFilters = NameValue[];

export interface SQLExpression {
  columns?: QueryEditorFunctionExpression[];
  whereJsonTree?: JsonTree;
  whereString?: string;
  filters?: SQLFilters;
  groupBy?: QueryEditorGroupByExpression[];
  orderBy?: QueryEditorPropertyExpression;
  orderByDirection?: 'ASC' | 'DESC';
  limit?: number;
  offset?: number;
}

export interface QueryRowFilter {
  filter: boolean;
  group: boolean;
  order: boolean;
  preview: boolean;
}

export const QUERY_FORMAT_OPTIONS = [
  { label: 'Time series', value: QueryFormat.Timeseries },
  { label: 'Table', value: QueryFormat.Table },
];

const backWardToOption = (value: string) => ({ label: value, value });

export const toOption = toOptionFromData ?? backWardToOption;

export interface ResourceSelectorProps {
  disabled?: boolean;
  className?: string;
  applyDefault?: boolean;
}
// React Awesome Query builder field types.
// These are responsible for rendering the correct UI for the field.
export type RAQBFieldTypes = 'text' | 'number' | 'boolean' | 'datetime' | 'date' | 'time';

export interface SQLSelectableValue extends SelectableValue {
  type?: string;
  raqbFieldType?: RAQBFieldTypes;
}

export interface DB {
  init?: (datasourceId?: string) => Promise<boolean>;
  datasets: () => Promise<string[]>;
  tables: (dataset?: string) => Promise<string[]>;
  fields: (query: SQLQuery, order?: boolean) => Promise<SQLSelectableValue[]>;
  validateQuery: (query: SQLQuery, range?: TimeRange) => Promise<ValidationResults>;
  dispose?: (dsID?: string) => void;
  lookup?: (path?: string) => Promise<Array<{ name: string; completion: string }>>;
  getEditorLanguageDefinition: () => LanguageDefinition;
  toRawSql: (query: SQLQuery) => string;
  functions: () => Func[];
}

export interface FuncParameter {
  name: string;
  required?: boolean;
  options?: (query: SQLQuery) => Promise<SelectableValue[]>;
}
export interface Func {
  name: string;
  parameters?: FuncParameter[];
  description?: string;
}

export interface QueryEditorProps {
  db: DB;
  query: QueryWithDefaults;
  onChange: (query: SQLQuery) => void;
  range?: TimeRange;
}

export interface ValidationResults {
  query: SQLQuery;
  rawSql?: string;
  error: string;
  isError: boolean;
  isValid: boolean;
  statistics?: {
    TotalBytesProcessed: number;
  } | null;
}

export interface SqlQueryModel {
  quoteLiteral: (v: string) => string;
}

export interface ResponseParser {
  transformMetricFindResponse: (frame: DataFrame) => MetricFindValue[];
}

export type SQLDialect = 'postgres' | 'influx' | 'other';
