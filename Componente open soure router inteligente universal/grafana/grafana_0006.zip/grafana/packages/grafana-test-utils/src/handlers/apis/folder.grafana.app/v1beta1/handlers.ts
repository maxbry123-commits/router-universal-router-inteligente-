import { Chance } from 'chance';
import { HttpResponse, http, type HttpResponseResolver } from 'msw';

import type {
  DescendantCounts,
  Folder,
  FolderAccessInfo,
  FolderInfoList,
  FolderList,
  OwnerReference,
} from '@grafana/api-clients/rtkq/folder/v1beta1';

import { wellFormedTree } from '../../../../fixtures/folders';
import { MOCK_TEAMS } from '../../../../fixtures/teams';
import { getErrorResponse } from '../../../helpers';
const [mockTree, { folderA, folderB }] = wellFormedTree();
// folderD is included in mockTree and will be returned by the handlers with managedBy: 'repo'

const baseResponse = {
  kind: 'Folder',
  apiVersion: 'folder.grafana.app/v1beta1',
};

const specialCaseOwnerRef: OwnerReference[] = [
  {
    apiVersion: 'iam.grafana.app/v0alpha1',
    kind: 'Team',
    name: MOCK_TEAMS[0].metadata.name,
    uid: MOCK_TEAMS[0].metadata.name,
    controller: true,
    blockOwnerDeletion: false,
  },
];

const folderToAppPlatform = (folder: (typeof mockTree)[number]['item'], id?: number, namespace?: string): Folder => {
  return {
    ...baseResponse,

    metadata: {
      name: folder.uid,
      namespace: namespace ?? 'default',
      uid: folder.uid,
      creationTimestamp: '2023-01-01T00:00:00Z',
      annotations: {
        // TODO: Generalise annotations in fixture data
        'grafana.app/createdBy': 'user:1',
        'grafana.app/updatedBy': 'user:2',
        'grafana.app/managedBy': ('managedBy' in folder ? folder.managedBy : 'user') ?? 'user',
        'grafana.app/updatedTimestamp': '2024-01-01T00:00:00Z',
        ...(folder.kind === 'folder' && folder.parentUID ? { 'grafana.app/folder': folder.parentUID } : {}),
      },
      labels: {
        'grafana.app/deprecatedInternalID': String(id ?? '123'),
      },
      ...(folder.uid === folderA.item.uid ? { ownerReferences: specialCaseOwnerRef } : {}),
    },
    spec: { title: folder.title!, description: '' },
  };
};

export const BASE = '/apis/folder.grafana.app/v1beta1/namespaces/:namespace';
export const FOLDERS = `${BASE}/folders`;
export const FOLDER_BY_NAME = `${FOLDERS}/:folderUid`;

const folderNotFoundError = getErrorResponse('folder not found', 404);

const getFolderHandler = () =>
  http.get<{ folderUid: string; namespace: string }>(FOLDER_BY_NAME, ({ params }) => {
    const { folderUid, namespace } = params;
    const response = mockTree.find(({ item }) => {
      return item.uid === folderUid;
    });

    if (!response) {
      return HttpResponse.json(folderNotFoundError, { status: 404 });
    }

    const appPlatformFolder = folderToAppPlatform(response.item, undefined, namespace);

    return HttpResponse.json(appPlatformFolder);
  });

const fullAccess: FolderAccessInfo = {
  ...baseResponse,
  kind: 'FolderAccessInfo',
  canAdmin: true,
  canDelete: true,
  canEdit: true,
  canSave: true,
  accessControl: {
    'dashboards.permissions:write': true,
    'dashboards:create': true,
    'folders:write': true,
  },
};

// The "shared with me" folder is a virtual aggregation view with nothing to act
// on, so the backend reports no access for it.
const noAccess: FolderAccessInfo = {
  ...baseResponse,
  kind: 'FolderAccessInfo',
  canAdmin: false,
  canDelete: false,
  canEdit: false,
  canSave: false,
};

const getFolderAccessHandler = () =>
  http.get<{ folderUid: string; namespace: string }>(
    '/apis/folder.grafana.app/v1beta1/namespaces/:namespace/folders/:folderUid/access',
    ({ params }) => {
      const { folderUid } = params;

      // Virtual folders have no stored resource: the root folder resolves real
      // access against the "general" scope, while "shared with me" has none.
      if (folderUid === 'general') {
        return HttpResponse.json(fullAccess);
      }
      if (folderUid === 'sharedwithme') {
        return HttpResponse.json(noAccess);
      }

      const folder = mockTree.find(({ item }) => item.uid === folderUid);
      if (!folder) {
        return HttpResponse.json(folderNotFoundError, { status: 404 });
      }

      return HttpResponse.json(fullAccess);
    }
  );

const getFolderParentsHandler = () =>
  http.get<{ folderUid: string; namespace: string }>(`${FOLDER_BY_NAME}/parents`, ({ params }) => {
    const { folderUid } = params;

    const folder = mockTree.find(({ item }) => {
      return item.kind === 'folder' && item.uid === folderUid;
    });
    if (!folder || folder.item.kind !== 'folder') {
      return HttpResponse.json(folderNotFoundError, { status: 404 });
    }

    const findParents = (parents: Array<(typeof mockTree)[number]>, folderUid?: string) => {
      if (!folderUid) {
        return parents;
      }

      const parent = mockTree.find(({ item }) => {
        return item.kind === 'folder' && item.uid === folderUid;
      });

      if (parent) {
        parents.push(parent);
        return findParents(parents, parent.item.kind === 'folder' ? parent.item.parentUID : undefined);
      }
      return parents;
    };

    const parents = findParents([], folder?.item?.parentUID);

    const mapped = parents.map((parent) => ({
      name: parent.item.uid,
      title: parent.item.title!,
      parent: parent.item.kind === 'folder' ? parent.item.parentUID : undefined,
    }));

    if (folder) {
      mapped.push({
        name: folder.item.uid,
        title: folder.item.title!,
        parent: folder.item.parentUID,
      });
    }

    const response: FolderInfoList = {
      ...baseResponse,
      kind: 'FolderInfoList',
      metadata: {},
      items: mapped,
    };

    return HttpResponse.json(response);
  });

type PartialFolderPayload = Pick<Folder, 'spec' | 'metadata'>;

const createFolderHandler = () =>
  http.post<{ namespace: string }, PartialFolderPayload>(FOLDERS, async ({ params, request }) => {
    const { namespace } = params;
    const body = await request.json();
    const title = body?.spec?.title;
    if (!body || !title) {
      return HttpResponse.json(getErrorResponse('folder title cannot be empty', 400), { status: 400 });
    }

    const parentUid = body?.metadata?.annotations?.['grafana.app/folder'];
    const random = Chance(title);
    const uid = random.string({ length: 45 });
    const id = random.integer({ min: 1, max: 1000 });

    const appPlatformFolder = folderToAppPlatform({ uid, title, parentUID: parentUid, kind: 'folder' }, id, namespace);
    return HttpResponse.json(appPlatformFolder);
  });

const replaceFolderHandler = () =>
  http.put<{ folderUid: string; namespace: string }, PartialFolderPayload>(
    FOLDER_BY_NAME,
    async ({ params, request }) => {
      const body = await request.json();
      const { folderUid } = params;
      const response = mockTree.find(({ item }) => {
        return item.uid === folderUid;
      });

      if (!response) {
        return HttpResponse.json(folderNotFoundError, { status: 404 });
      }

      const modifiedFolder = {
        ...response.item,
        title: body.spec.title,
      };

      const appPlatformFolder = folderToAppPlatform(modifiedFolder);

      return HttpResponse.json(appPlatformFolder);
    }
  );

type JsonPatchPayload = Array<{
  op: 'replace' | 'add' | 'remove';
  path: string;
  value?: unknown;
}>;

const updateFolderHandler = () =>
  http.patch<{ folderUid: string; namespace: string }, PartialFolderPayload | JsonPatchPayload>(
    FOLDER_BY_NAME,
    async ({ params, request }) => {
      const body = await request.json();
      const { folderUid } = params;
      const existingFolder = mockTree.find(({ item }) => {
        return item.uid === folderUid;
      });

      if (!existingFolder) {
        return HttpResponse.json(folderNotFoundError, { status: 404 });
      }

      // Handle JSON Patch payload
      if (Array.isArray(body)) {
        const appPlatformFolder = folderToAppPlatform(existingFolder.item);

        // For now, only support /metadata path operations in the mock API,
        body.forEach((patch) => {
          const path = patch.path.replace('/metadata/', '');
          if (patch.op === 'replace' && path === 'ownerReferences') {
            (appPlatformFolder.metadata as Record<string, unknown>)[path] = patch.value;
          }

          if (patch.op === 'remove' && path === 'ownerReferences') {
            delete (appPlatformFolder.metadata as Record<string, unknown>)[path];
          }
        });

        return HttpResponse.json(appPlatformFolder);
      }

      const modifiedFolder = {
        ...existingFolder.item,
        title: body.spec.title,
      };

      const appPlatformFolder = folderToAppPlatform(modifiedFolder);

      return HttpResponse.json(appPlatformFolder);
    }
  );

const getMockFolderCounts = (
  folders: number,
  dashboards: number,
  library_elements: number,
  alertrules: number
): DescendantCounts => {
  return {
    kind: 'DescendantCounts',
    apiVersion: 'folder.grafana.app/v1beta1',
    counts: [
      {
        group: 'dashboard.grafana.app',
        resource: 'dashboards',
        count: dashboards,
      },
      {
        group: 'sql-fallback',
        resource: 'alertrules',
        count: alertrules,
      },
      {
        group: 'sql-fallback',
        resource: 'dashboards',
        count: dashboards,
      },
      {
        group: 'sql-fallback',
        resource: 'folders',
        count: folders,
      },
      {
        group: 'sql-fallback',
        resource: 'library_elements',
        count: library_elements,
      },
    ],
  };
};

const folderCountsHandler = () =>
  http.get<{ folderUid: string; namespace: string }, PartialFolderPayload>(
    `${FOLDER_BY_NAME}/counts`,
    async ({ params }) => {
      const { folderUid } = params;
      const matchedFolder = mockTree.find(({ item }) => {
        return item.uid === folderUid;
      });

      if (!matchedFolder) {
        // The API returns 0's for a folder that doesn't exist 🤷‍♂️
        return HttpResponse.json(getMockFolderCounts(0, 0, 0, 0));
      }

      if (folderUid === folderB.item.uid) {
        return HttpResponse.json({}, { status: 500 });
      }

      return HttpResponse.json(getMockFolderCounts(1, 1, 1, 1));
    }
  );

const getFolderListHandler = () =>
  http.get<{ namespace: string }>(FOLDERS, ({ params }) => {
    const { namespace } = params;
    const folders = mockTree.map(({ item }, index) => folderToAppPlatform(item, index + 1, namespace));

    const response: FolderList = {
      kind: 'FolderList',
      apiVersion: 'folder.grafana.app/v1beta1',
      metadata: {},
      items: folders,
    };

    return HttpResponse.json(response);
  });

export const customCreateFolderHandler = (resolver: HttpResponseResolver) => http.post(FOLDERS, resolver);

const customFolderCountsHandler = (resolver: HttpResponseResolver) =>
  http.get('/apis/folder.grafana.app/:version/namespaces/:namespace/folders/:folderUid/counts', resolver);

export const mockFolderCountsHandler = (panels: number, rules: number, recordingRules = 0) =>
  customFolderCountsHandler(() =>
    HttpResponse.json({
      kind: 'DescendantCounts',
      apiVersion: 'folder.grafana.app/v1beta1',
      counts: [
        { group: 'sql-fallback', resource: 'library_elements', count: panels },
        { group: 'sql-fallback', resource: 'alertrules', count: rules },
        { group: 'sql-fallback', resource: 'recordingrules', count: recordingRules },
      ],
    })
  );

export const mockFolderCountsErrorHandler = (status = 500) =>
  customFolderCountsHandler(() => HttpResponse.json({ message: 'error' }, { status }));

export default [
  getFolderListHandler(),
  getFolderHandler(),
  getFolderAccessHandler(),
  getFolderParentsHandler(),
  createFolderHandler(),
  replaceFolderHandler(),
  updateFolderHandler(),
  folderCountsHandler(),
];
