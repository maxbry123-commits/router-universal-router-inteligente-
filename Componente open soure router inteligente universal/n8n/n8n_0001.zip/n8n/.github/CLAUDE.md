@../AGENTS.md

## .github Quick Reference

This folder contains n8n's GitHub Actions infrastructure.

### Key Files

| File/Folder | Purpose |
|-------------|---------|
| `WORKFLOWS.md` | Complete CI/CD documentation |
| `DEVELOPING_V3.md` | How to develop v3 features (master + 3.x branch model, opt-in flags) |
| `workflows/` | GitHub Actions workflows |
| `actions/` | Reusable composite actions |
| `scripts/` | Release & Docker automation |
| `CODEOWNERS` | Team review ownership |

### Workflow Naming

| Prefix | Purpose |
|--------|---------|
| `test-` | Testing (unit, E2E, visual) |
| `ci-` | Continuous integration |
| `util-` | Utilities (notifications) |
| `build-` | Build processes |
| `release-` | Release automation |
| `sec-` | Security scanning |

Reusable workflows: add `-reusable` or `-callable` suffix.

### Common Tasks

**Add workflow:** Create in `workflows/`, document in `WORKFLOWS.md`.
Always declare a least-privilege top-level `permissions:` block (usually
`contents: read`) — without one the workflow runs with the repo's broad
default token and review flags it. Jobs needing more override at job level;
a job calling a reusable workflow must grant at least what that workflow
declares.

**Add script:** Create `.mjs` in `scripts/`, document in `WORKFLOWS.md`

### Reference

See `WORKFLOWS.md` for:
- Architecture diagrams
- Workflow call graph
- Scheduled jobs & triggers
- Runners & secrets
