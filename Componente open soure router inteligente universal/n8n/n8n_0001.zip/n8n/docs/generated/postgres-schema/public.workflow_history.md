# public.workflow_history

## Columns

| Name | Type | Default | Nullable | Children | Parents | Comment |
| ---- | ---- | ------- | -------- | -------- | ------- | ------- |
| authors | varchar(255) |  | false |  |  |  |
| autosaved | boolean | false | false |  |  |  |
| connections | json |  | false |  |  |  |
| createdAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| description | text |  | true |  |  |  |
| name | varchar(128) |  | true |  |  |  |
| nodeGroups | json | '[]'::json | false |  |  |  |
| nodes | json |  | false |  |  |  |
| updatedAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| versionId | varchar(36) |  | false | [public.workflow_entity](public.workflow_entity.md) [public.workflow_publication_trigger_status](public.workflow_publication_trigger_status.md) [public.workflow_publish_history](public.workflow_publish_history.md) [public.workflow_published_version](public.workflow_published_version.md) [public.workflow_review_request_workflow](public.workflow_review_request_workflow.md) |  |  |
| workflowId | varchar(36) |  | false |  | [public.workflow_entity](public.workflow_entity.md) |  |

## Constraints

| Name | Type | Definition |
| ---- | ---- | ---------- |
| FK_1e31657f5fe46816c34be7c1b4b | FOREIGN KEY | FOREIGN KEY ("workflowId") REFERENCES workflow_entity(id) ON DELETE CASCADE |
| PK_b6572dd6173e4cd06fe79937b58 | PRIMARY KEY | PRIMARY KEY ("versionId") |
| workflow_history_authors_not_null | n | NOT NULL authors |
| workflow_history_autosaved_not_null | n | NOT NULL autosaved |
| workflow_history_connections_not_null | n | NOT NULL connections |
| workflow_history_createdAt_not_null | n | NOT NULL "createdAt" |
| workflow_history_nodeGroups_not_null | n | NOT NULL "nodeGroups" |
| workflow_history_nodes_not_null | n | NOT NULL nodes |
| workflow_history_updatedAt_not_null | n | NOT NULL "updatedAt" |
| workflow_history_versionId_not_null | n | NOT NULL "versionId" |
| workflow_history_workflowId_not_null | n | NOT NULL "workflowId" |

## Indexes

| Name | Definition |
| ---- | ---------- |
| IDX_1e31657f5fe46816c34be7c1b4 | CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON public.workflow_history USING btree ("workflowId") |
| PK_b6572dd6173e4cd06fe79937b58 | CREATE UNIQUE INDEX "PK_b6572dd6173e4cd06fe79937b58" ON public.workflow_history USING btree ("versionId") |

## Relations

```mermaid
erDiagram

"public.workflow_entity" }o--o| "public.workflow_history" : "FOREIGN KEY (#quot;activeVersionId#quot;) REFERENCES workflow_history(#quot;versionId#quot;) ON DELETE RESTRICT"
"public.workflow_publication_trigger_status" }o--|| "public.workflow_history" : "FOREIGN KEY (#quot;versionId#quot;) REFERENCES workflow_history(#quot;versionId#quot;) ON DELETE CASCADE"
"public.workflow_publish_history" }o--o| "public.workflow_history" : "FOREIGN KEY (#quot;versionId#quot;) REFERENCES workflow_history(#quot;versionId#quot;) ON DELETE SET NULL"
"public.workflow_published_version" }o--|| "public.workflow_history" : "FOREIGN KEY (#quot;publishedVersionId#quot;) REFERENCES workflow_history(#quot;versionId#quot;) ON DELETE RESTRICT"
"public.workflow_review_request_workflow" }o--o| "public.workflow_history" : "FOREIGN KEY (#quot;workflowVersionId#quot;) REFERENCES workflow_history(#quot;versionId#quot;) ON DELETE SET NULL"
"public.workflow_review_request_workflow" }o--o| "public.workflow_history" : "FOREIGN KEY (#quot;baselineVersionId#quot;) REFERENCES workflow_history(#quot;versionId#quot;) ON DELETE SET NULL"
"public.workflow_history" }o--|| "public.workflow_entity" : "FOREIGN KEY (#quot;workflowId#quot;) REFERENCES workflow_entity(id) ON DELETE CASCADE"

"public.workflow_history" {
  varchar_255_ authors
  boolean autosaved
  json connections
  timestamp_3__with_time_zone createdAt
  text description
  varchar_128_ name
  json nodeGroups
  json nodes
  timestamp_3__with_time_zone updatedAt
  varchar_36_ versionId
  varchar_36_ workflowId FK
}
"public.workflow_entity" {
  boolean active
  varchar_36_ activeVersionId FK
  json connections
  timestamp_3__with_time_zone createdAt
  text description
  varchar_36_ id
  boolean isArchived
  json meta
  varchar_128_ name
  json nodeGroups
  json nodes
  varchar_36_ parentFolderId FK
  json pinData
  json settings
  varchar sourceWorkflowId
  json staticData
  integer triggerCount
  timestamp_3__with_time_zone updatedAt
  integer versionCounter
  character_36_ versionId
}
"public.workflow_publication_trigger_status" {
  timestamp_3__with_time_zone createdAt
  text errorMessage
  varchar_36_ nodeId
  varchar_20_ status
  varchar_20_ triggerKind
  timestamp_3__with_time_zone updatedAt
  varchar_36_ versionId FK
  varchar_36_ workflowId FK
}
"public.workflow_publish_history" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ event
  integer id
  uuid userId FK
  varchar_36_ versionId FK
  varchar_36_ workflowId FK
}
"public.workflow_published_version" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ publishedVersionId FK
  timestamp_3__with_time_zone updatedAt
  varchar_36_ workflowId FK
}
"public.workflow_review_request_workflow" {
  varchar_36_ baselineVersionId FK
  varchar_36_ id
  varchar_36_ workflowId FK
  varchar_36_ workflowReviewRequestId FK
  varchar_36_ workflowVersionId FK
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
