import { cadvisor } from './cadvisor';
import { cloudflared } from './cloudflared';
import { gitea, createGiteaHelper } from './gitea';
import { kafka, createKafkaHelper } from './kafka';
import { kent, createKentHelper } from './kent';
import { keycloak, createKeycloakHelper } from './keycloak';
import { loadBalancer } from './load-balancer';
import { localstack, createLocalStackHelper } from './localstack';
import { mailpit, createMailpitHelper } from './mailpit';
import { mysqlService } from './mysql';
import { ngrok } from './ngrok';
import { createObservabilityHelper } from './observability';
import { postgres, createPostgresHelper } from './postgres';
import { postgresExporter } from './postgres-exporter';
import { proxy, createProxyHelper } from './proxy';
import { redis } from './redis';
import { sandbox } from './sandbox';
import { taskRunner } from './task-runner';
import { tracing, createTracingHelper } from './tracing';
import type { Service, ServiceName, ServiceResult, HelperFactories } from './types';
import { vector } from './vector';
import { victoriaLogs } from './victoria-logs';
import { victoriaMetrics } from './victoria-metrics';

/** Service registry - must include all ServiceName entries */
export const services: Record<ServiceName, Service<ServiceResult>> = {
	postgres,
	redis,
	mailpit,
	gitea,
	keycloak,
	victoriaLogs,
	victoriaMetrics,
	vector,
	tracing,
	proxy,
	taskRunner,
	loadBalancer,
	cloudflared,
	ngrok,
	kafka,
	mysql: mysqlService,
	localstack,
	kent,
	postgresExporter,
	cadvisor,
	sandbox,
};

export const helperFactories: Partial<HelperFactories> = {
	postgres: createPostgresHelper,
	mailpit: createMailpitHelper,
	gitea: createGiteaHelper,
	keycloak: createKeycloakHelper,
	observability: createObservabilityHelper,
	tracing: createTracingHelper,
	proxy: createProxyHelper,
	kafka: createKafkaHelper,
	localstack: createLocalStackHelper,
	kent: createKentHelper,
};
