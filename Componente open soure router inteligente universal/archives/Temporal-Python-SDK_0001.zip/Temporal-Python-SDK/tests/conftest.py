import asyncio
import multiprocessing.context
import os
import sys
from collections.abc import AsyncGenerator, Iterator

import opentelemetry._logs._internal
import opentelemetry.metrics
import opentelemetry.metrics._internal
import opentelemetry.trace
import pytest
import pytest_asyncio
from opentelemetry.metrics import NoOpMeterProvider
from opentelemetry.util._once import Once

from temporalio.client import Client
from temporalio.envconfig import ClientConfigProfile
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import SharedStateManager
from tests.helpers.worker import ExternalPythonWorker, ExternalWorker

from . import DEV_SERVER_DOWNLOAD_VERSION

# If there is an integration test environment variable set, we must remove the
# first path from the sys.path so we can import the wheel instead
if os.getenv("TEMPORAL_INTEGRATION_TEST"):
    assert sys.path[0] == os.getcwd(), (
        "Expected first sys.path to be the current working dir"
    )
    sys.path.pop(0)
    # Import temporalio and confirm it is prefixed with virtual env
    import temporalio

    assert temporalio.__file__.startswith(sys.prefix), (
        f"Expected {temporalio.__file__} to be in {sys.prefix}"
    )

# Unless specifically overridden, we expect tests to run under protobuf 4.x/5.x/6.x/7.x lib
import google.protobuf

protobuf_version = google.protobuf.__version__
if os.getenv("TEMPORAL_TEST_PROTO3"):
    assert protobuf_version.startswith("3."), (
        f"Expected protobuf 3.x, got {protobuf_version}"
    )
else:
    assert (
        protobuf_version.startswith("4.")
        or protobuf_version.startswith("5.")
        or protobuf_version.startswith("6.")
        or protobuf_version.startswith("7.")
    ), f"Expected protobuf 4.x/5.x/6.x/7.x, got {protobuf_version}"


def pytest_runtest_setup(item):  # type: ignore[reportMissingParameterType]
    """Print a newline so that custom printed output starts on new line."""
    if item.config.getoption("-s"):
        print()


def pytest_addoption(parser):  # type: ignore[reportMissingParameterType]
    parser.addoption(
        "-E",
        "--workflow-environment",
        default="local",
        help="Which workflow environment to use ('local', 'time-skipping', 'envconfig', or ip:port for existing server)",
    )


def _uses_envconfig_server(env_type: str) -> bool:
    return env_type == "envconfig"


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "requires_local_server: test requires local-server-only behavior and cannot run against an envconfig server",
    )


def pytest_collection_modifyitems(
    config: pytest.Config, items: list[pytest.Item]
) -> None:
    if not _uses_envconfig_server(config.getoption("--workflow-environment")):
        return
    skip_local_only = pytest.mark.skip(
        reason="requires a local Temporal server, not the configured envconfig server"
    )
    for item in items:
        if item.get_closest_marker("requires_local_server"):
            item.add_marker(skip_local_only)


async def _create_env_from_envconfig() -> WorkflowEnvironment:
    config = ClientConfigProfile.load().to_client_connect_config()
    if not config.get("target_host"):
        raise ValueError(
            "An envconfig workflow environment requires TEMPORAL_ADDRESS or an envconfig profile with an address"
        )
    return WorkflowEnvironment.from_client(await Client.connect(**config))


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()  # type: ignore[reportDeprecated]
    yield loop
    try:
        loop.close()
    except TypeError:
        raise


class NoEventLoopPolicy(asyncio.AbstractEventLoopPolicy):  # type: ignore[name-defined]
    def __init__(self, underlying: asyncio.AbstractEventLoopPolicy):  # type: ignore[name-defined]
        super().__init__()
        self._underlying = underlying

    def get_event_loop(self):
        return self._underlying.get_event_loop()

    def set_event_loop(self, loop):  # type: ignore[reportMissingParameterType]
        return self._underlying.set_event_loop(loop)

    def new_event_loop(self):  # type: ignore[reportIncompatibleMethodOverride]
        return None

    def get_child_watcher(self):
        return self._underlying.get_child_watcher()  # type: ignore[reportDeprecated]

    def set_child_watcher(self, watcher):  # type: ignore[reportMissingParameterType]
        return self._underlying.set_child_watcher(watcher)  # type: ignore[reportDeprecated]


@pytest.fixture(scope="session")
def env_type(request: pytest.FixtureRequest) -> str:
    return request.config.getoption("--workflow-environment")  # type: ignore[reportReturnType]


@pytest_asyncio.fixture(scope="session")  # type: ignore[reportUntypedFunctionDecorator]
async def env(env_type: str) -> AsyncGenerator[WorkflowEnvironment, None]:
    if _uses_envconfig_server(env_type):
        env = await _create_env_from_envconfig()
    elif env_type == "local":
        env = await WorkflowEnvironment.start_local(
            dev_server_extra_args=[
                "--dynamic-config-value",
                "system.forceSearchAttributesCacheRefreshOnRead=true",
                "--dynamic-config-value",
                f"limit.historyCount.suggestContinueAsNew={CONTINUE_AS_NEW_SUGGEST_HISTORY_COUNT}",
                "--dynamic-config-value",
                "system.enableEagerWorkflowStart=true",
                "--dynamic-config-value",
                "frontend.enableExecuteMultiOperation=true",
                "--dynamic-config-value",
                "frontend.workerVersioningWorkflowAPIs=true",
                "--dynamic-config-value",
                "frontend.workerVersioningDataAPIs=true",
                "--dynamic-config-value",
                "system.enableDeploymentVersions=true",
                "--dynamic-config-value",
                "frontend.activityAPIsEnabled=true",
                "--dynamic-config-value",
                "frontend.enableCancelWorkerPollsOnShutdown=true",
                "--dynamic-config-value",
                "component.nexusoperations.recordCancelRequestCompletionEvents=true",
                "--dynamic-config-value",
                "activity.enableStandalone=true",
                "--dynamic-config-value",
                "activity.startDelayEnabled=true",
                "--dynamic-config-value",
                "history.enableChasm=true",
                "--dynamic-config-value",
                "history.enableTransitionHistory=true",
                "--dynamic-config-value",
                "history.enableCHASMCallbacks=true",
                "--dynamic-config-value",
                "history.enableCHASMSignalBacklinks=true",
                "--dynamic-config-value",
                "nexusoperation.enableStandalone=true",
                "--dynamic-config-value",
                'system.system.refreshNexusEndpointsMinWait="0s"',
                "--dynamic-config-value",
                "history.enableSignalWithStartFromWorkflow=true",
                "--dynamic-config-value",
                "history.enableUpdateCallbacks=true",
                "--dynamic-config-value",
                "activity.enableCallbacks=true",
            ],
            dev_server_download_version=DEV_SERVER_DOWNLOAD_VERSION,
        )
    elif env_type == "time-skipping":
        env = await WorkflowEnvironment.start_time_skipping()
    else:
        env = WorkflowEnvironment.from_client(await Client.connect(env_type))

    yield env
    await env.shutdown()


@pytest.fixture(scope="session")
def shared_state_manager() -> Iterator[SharedStateManager]:
    mp_mgr = multiprocessing.Manager()
    mgr = SharedStateManager.create_from_multiprocessing(mp_mgr)

    try:
        yield mgr
    finally:
        mp_mgr.shutdown()


@pytest.fixture(scope="session")
def mp_fork_ctx() -> Iterator[multiprocessing.context.BaseContext | None]:
    mp_ctx = None
    try:
        mp_ctx = multiprocessing.get_context("fork")
    except ValueError:
        pass

    try:
        yield mp_ctx
    finally:
        if mp_ctx:
            for p in mp_ctx.active_children():
                p.terminate()
                p.join()


@pytest_asyncio.fixture  # type: ignore[reportUntypedFunctionDecorator]
async def client(env: WorkflowEnvironment) -> Client:
    return env.client


@pytest_asyncio.fixture(scope="session")  # type: ignore[reportUntypedFunctionDecorator]
async def worker(
    env: WorkflowEnvironment,
) -> AsyncGenerator[ExternalWorker, None]:
    worker = ExternalPythonWorker(env)
    yield worker
    await worker.close()


# There is an issue in tests sometimes in GitHub actions where even though all tests
# pass, an unclear outer area is killing the process with a bad exit code. This
# hook forcefully kills the process as success when the exit code from pytest
# is a success.
@pytest.hookimpl(hookwrapper=True, trylast=True)
def pytest_cmdline_main(config):  # type: ignore[reportMissingParameterType, reportUnusedParameter]
    result = yield
    exit_code = result.get_result()
    numprocesses = getattr(config.option, "numprocesses", None)
    running_with_xdist = hasattr(config, "workerinput") or numprocesses not in (
        None,
        0,
        "0",
    )
    if exit_code == 0 and not running_with_xdist:
        os._exit(0)
    return exit_code


CONTINUE_AS_NEW_SUGGEST_HISTORY_COUNT = 50


@pytest.fixture
def continue_as_new_suggest_history_count() -> int:
    return CONTINUE_AS_NEW_SUGGEST_HISTORY_COUNT


# OpenTelemetry's global providers are set-once per process with no public
# way to unset them, so tests needing their own provider must reset the
# globals directly -- the same isolation pattern OpenTelemetry's own test
# suite uses (opentelemetry.test.globals_test). Isolation cannot be delegated
# to scheduling: CI runs pytest-xdist with --dist=worksteal, which ignores
# xdist_group pinning, so any test in the suite can share a worker process
# with any other. Every test that installs a global provider must therefore
# use these fixtures and leave the globals reset behind it.


@pytest.fixture
def reset_otel_tracer_provider():
    """Isolate global OpenTelemetry tracer provider state around a test.

    Proxy tracers bound to a real provider stay bound forever; OTel has no
    rebind mechanism for tracers. Tests must install their provider before
    any span is created through a proxy tracer they care about.
    """
    opentelemetry.trace._TRACER_PROVIDER_SET_ONCE = Once()
    opentelemetry.trace._TRACER_PROVIDER = None
    yield
    opentelemetry.trace._TRACER_PROVIDER_SET_ONCE = Once()
    opentelemetry.trace._TRACER_PROVIDER = None


def _reset_meter_provider_globals() -> None:
    # Reset the set-once latch, then park proxy meters on a no-op provider:
    # set_meter_provider rebinds every proxy meter and its instruments, so
    # instruments bound during an earlier test stop recording into that
    # test's dead reader. Reset the latch again so the next installer wins.
    opentelemetry.metrics._internal._METER_PROVIDER_SET_ONCE = Once()
    opentelemetry.metrics._internal._METER_PROVIDER = None
    opentelemetry.metrics.set_meter_provider(NoOpMeterProvider())
    opentelemetry.metrics._internal._METER_PROVIDER_SET_ONCE = Once()
    opentelemetry.metrics._internal._METER_PROVIDER = None


@pytest.fixture
def reset_otel_meter_provider():
    """Isolate global OpenTelemetry meter provider state around a test.

    Both setup and teardown park proxy meters on a no-op provider, so
    instruments bound by other tests neither record into this test's provider
    unexpectedly nor keep recording into this test's reader afterwards. Any
    set_meter_provider call rebinds proxy meters, so tests that install their
    own provider are unaffected by the parking.
    """
    _reset_meter_provider_globals()
    yield
    _reset_meter_provider_globals()


@pytest.fixture
def reset_otel_logger_provider():
    """Isolate global OpenTelemetry logger provider state around a test.

    Unlike proxy meters, proxy loggers cache their real logger on first use
    and never rebind, even across a later set_logger_provider call. Tests
    exercising a library's module-level logger must clear that cache
    themselves (e.g. Google ADK's telemetry logger).
    """
    opentelemetry._logs._internal._LOGGER_PROVIDER_SET_ONCE = Once()
    opentelemetry._logs._internal._LOGGER_PROVIDER = None
    yield
    opentelemetry._logs._internal._LOGGER_PROVIDER_SET_ONCE = Once()
    opentelemetry._logs._internal._LOGGER_PROVIDER = None
