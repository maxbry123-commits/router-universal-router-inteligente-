"""Shared test helpers for LangSmith plugin tests."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock

import pytest

from tests.helpers.trace import TraceNode


@pytest.fixture(autouse=True)
def _clear_langsmith_env_cache() -> Any:  # pyright: ignore[reportUnusedFunction]
    """Clear langsmith's lru_cache before and after each test.

    Tests manipulate LANGSMITH_TRACING / LANGCHAIN_TRACING_V2 env vars.
    langsmith.utils.get_env_var caches results, so stale values would
    leak across tests (or into other test modules in the same session).
    """
    import langsmith.utils

    langsmith.utils.get_env_var.cache_clear()  # type: ignore[attr-defined]
    yield
    langsmith.utils.get_env_var.cache_clear()  # type: ignore[attr-defined]


@pytest.fixture(autouse=True)
def _enable_langsmith_tracing(monkeypatch: pytest.MonkeyPatch) -> None:  # pyright: ignore[reportUnusedFunction]
    """Enable LangSmith tracing by default for all tests in this directory.

    The plugin defers to ``langsmith.utils.tracing_is_enabled()``, which
    requires ``LANGSMITH_TRACING=true`` (or equivalent). Without this
    fixture, tests that expect runs would see zero.

    Individual tests can override with ``monkeypatch.setenv("LANGSMITH_TRACING", "false")``
    to verify disabled behavior.
    """
    monkeypatch.setenv("LANGSMITH_TRACING", "true")


@dataclass
class _RunRecord:
    """A single recorded run."""

    id: str
    parent_run_id: str | None
    name: str
    run_type: str
    inputs: dict[str, Any]
    outputs: dict[str, Any] | None = None
    error: str | None = None


class InMemoryRunCollector:
    """Collects runs from a mock LangSmith client.

    Each call to create_run / update_run appends or updates an entry.
    """

    def __init__(self) -> None:
        self.runs: list[_RunRecord] = []
        self._by_id: dict[str, _RunRecord] = {}

    def record_create(self, **kwargs: Any) -> None:
        run_id = str(kwargs.get("id", kwargs.get("run_id", "")))
        if run_id in self._by_id:
            return
        rec = _RunRecord(
            id=run_id,
            parent_run_id=(
                str(kwargs["parent_run_id"]) if kwargs.get("parent_run_id") else None
            ),
            name=kwargs.get("name", ""),
            run_type=kwargs.get("run_type", "chain"),
            inputs=kwargs.get("inputs", {}),
        )
        self.runs.append(rec)
        self._by_id[rec.id] = rec

    def record_update(self, run_id: str, **kwargs: Any) -> None:
        run_id_str = str(run_id)
        rec = self._by_id.get(run_id_str)
        if rec is None:
            return
        if "outputs" in kwargs:
            rec.outputs = kwargs["outputs"]
        if "error" in kwargs:
            rec.error = kwargs["error"]

    def clear(self) -> None:
        self.runs.clear()
        self._by_id.clear()


def build_trace_trees(collector: InMemoryRunCollector) -> list[TraceNode]:
    """Build trace trees from the collector's run parent relationships."""
    runs = collector.runs
    children: dict[str | None, list[_RunRecord]] = {}
    for r in runs:
        children.setdefault(r.parent_run_id, []).append(r)

    # Strict: reject dangling parent references
    known_ids = {r.id for r in runs}
    for r in runs:
        if r.parent_run_id is not None and r.parent_run_id not in known_ids:
            raise AssertionError(
                f"Run {r.name!r} (id={r.id}) has parent_run_id={r.parent_run_id} "
                f"which is not in the collected runs — dangling parent reference"
            )

    def build_tree(run: _RunRecord) -> TraceNode:
        return TraceNode(
            run.name,
            [build_tree(child) for child in children.get(run.id, [])],
        )

    return [build_tree(root) for root in children.get(None, [])]


def find_trace_trees(traces: list[TraceNode], root_name: str) -> list[TraceNode]:
    """Filter trace trees by exact root run name."""
    return [trace for trace in traces if trace.name == root_name]


def make_mock_ls_client(collector: InMemoryRunCollector) -> MagicMock:
    """Create a mock langsmith.Client wired to a collector."""
    client = MagicMock()
    client.create_run.side_effect = collector.record_create
    client.update_run.side_effect = collector.record_update
    client.session = MagicMock()
    client.tracing_queue = MagicMock()
    return client
