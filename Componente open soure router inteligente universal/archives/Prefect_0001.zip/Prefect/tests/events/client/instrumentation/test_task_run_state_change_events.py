import uuid
from pathlib import Path
from typing import Any

import pytest

from prefect import flow, task
from prefect.client.orchestration import PrefectClient
from prefect.client.schemas.objects import State
from prefect.events.clients import AssertingEventsClient
from prefect.events.schemas.events import Resource
from prefect.events.worker import EventsWorker
from prefect.filesystems import LocalFileSystem
from prefect.task_worker import TaskWorker
from prefect.telemetry.run_telemetry import LABELS_TRACEPARENT_KEY, TRACEPARENT_KEY
from prefect.types._datetime import parse_datetime


def pop_trace_details(payload: dict[str, Any]) -> dict[str, Any]:
    """Remove OpenTelemetry trace information from an event payload.

    Runs get a traceparent when the environment configures OpenTelemetry, for
    example when the suite runs with `pytest --logfire`.
    """
    for state_key in ("initial_state", "validated_state"):
        state = payload.get(state_key)
        if state:
            state.get("state_details", {}).pop(TRACEPARENT_KEY, None)
    task_run = payload.get("task_run")
    if task_run:
        task_run.get("labels", {}).pop(LABELS_TRACEPARENT_KEY, None)
    return payload


@pytest.mark.usefixtures("reset_worker_events")
async def test_task_state_change_happy_path(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    events_pipeline: Any,
):
    @task
    def happy_little_tree():
        return "🌳"

    @flow
    def happy_path():
        return happy_little_tree(return_state=True)

    flow_state: State[State[str]] = happy_path(return_state=True)

    await events_pipeline.process_events(dequeue_events=False)

    task_state: State[str] = await flow_state.result()
    task_run_id = task_state.state_details.task_run_id

    task_run = await prefect_client.read_task_run(task_run_id)
    task_run_states = await prefect_client.read_task_run_states(task_run_id)

    await asserting_events_worker.drain()
    assert isinstance(asserting_events_worker._client, AssertingEventsClient)
    events = [
        event
        for event in asserting_events_worker._client.events
        if event.event.startswith("prefect.task-run.")
    ]
    assert len(task_run_states) == len(events) == 3

    for event in events:
        pop_trace_details(event.payload)

    pending, running, completed = events

    assert pending.event == "prefect.task-run.Pending"
    assert pending.id == task_run_states[0].id
    assert pending.occurred == task_run_states[0].timestamp
    assert pending.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run.id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "0",
            "prefect.state-message": "",
            "prefect.state-type": "PENDING",
            "prefect.state-name": "Pending",
            "prefect.state-timestamp": task_run_states[0].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )
    assert (
        parse_datetime(pending.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )
    assert pending.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert pending.payload == {
        "initial_state": None,
        "intended": {"from": None, "to": "PENDING"},
        "validated_state": {
            "type": "PENDING",
            "name": "Pending",
            "message": "",
            "state_details": {},
            "data": None,
        },
        "task_run": {
            "dynamic_key": task_run.dynamic_key,
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 0,
            "name": task_run.name,
            "run_count": 0,
            "tags": [],
            "labels": {},
            "task_inputs": {},
            "total_run_time": 0.0,
        },
    }

    assert running.event == "prefect.task-run.Running"
    assert running.id == task_run_states[1].id
    assert running.occurred == task_run_states[1].timestamp
    assert running.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run.id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "1",
            "prefect.state-message": "",
            "prefect.state-type": "RUNNING",
            "prefect.state-name": "Running",
            "prefect.state-timestamp": task_run_states[1].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )
    assert (
        parse_datetime(running.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )
    assert running.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert (
        parse_datetime(running.payload["task_run"].pop("start_time"))
        == task_run.start_time
    )
    assert running.payload == {
        "intended": {"from": "PENDING", "to": "RUNNING"},
        "initial_state": {
            "type": "PENDING",
            "name": "Pending",
            "message": "",
            "state_details": {},
        },
        "validated_state": {
            "type": "RUNNING",
            "name": "Running",
            "message": "",
            "state_details": {},
            "data": None,
        },
        "task_run": {
            "dynamic_key": task_run.dynamic_key,
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 1,
            "name": task_run.name,
            "run_count": 1,
            "tags": [],
            "labels": {},
            "task_inputs": {},
            "total_run_time": 0.0,
        },
    }

    assert completed.event == "prefect.task-run.Completed"
    assert completed.id == task_run_states[2].id
    assert completed.occurred == task_run_states[2].timestamp
    assert completed.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run.id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "1",
            "prefect.state-message": "",
            "prefect.state-type": "COMPLETED",
            "prefect.state-name": "Completed",
            "prefect.state-timestamp": task_run_states[2].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )
    assert (
        parse_datetime(completed.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )
    assert completed.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert (
        parse_datetime(completed.payload["task_run"].pop("start_time"))
        == task_run.start_time
    )
    assert (
        parse_datetime(completed.payload["task_run"].pop("end_time"))
        == task_run.end_time
    )
    assert completed.payload["task_run"].pop("total_run_time") > 0.0
    assert completed.payload == {
        "intended": {"from": "RUNNING", "to": "COMPLETED"},
        "initial_state": {
            "type": "RUNNING",
            "name": "Running",
            "message": "",
            "state_details": {},
        },
        "validated_state": {
            "type": "COMPLETED",
            "name": "Completed",
            "message": "",
            "state_details": {},
            "data": None,
        },
        "task_run": {
            "dynamic_key": task_run.dynamic_key,
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 1,
            "name": task_run.name,
            "run_count": 1,
            "tags": [],
            "labels": {},
            "task_inputs": {},
        },
    }


@pytest.mark.usefixtures("reset_worker_events")
async def test_task_state_change_task_failure(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    events_pipeline: Any,
):
    @task
    def happy_little_tree():
        raise ValueError("Here's a happy little accident.")

    @flow
    def happy_path():
        return happy_little_tree(return_state=True)

    flow_state = happy_path(return_state=True)
    await events_pipeline.process_events(dequeue_events=False)

    task_state = await flow_state.result(raise_on_failure=False)
    task_run_id = task_state.state_details.task_run_id

    task_run = await prefect_client.read_task_run(task_run_id)
    task_run_states = await prefect_client.read_task_run_states(task_run_id)

    await asserting_events_worker.drain()
    assert isinstance(asserting_events_worker._client, AssertingEventsClient)
    events = [
        event
        for event in asserting_events_worker._client.events
        if event.event.startswith("prefect.task-run.")
    ]
    assert len(task_run_states) == len(events) == 3

    for event in events:
        pop_trace_details(event.payload)

    pending, running, failed = events

    assert pending.event == "prefect.task-run.Pending"
    assert pending.id == task_run_states[0].id
    assert pending.occurred == task_run_states[0].timestamp
    assert pending.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run.id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "0",
            "prefect.state-message": "",
            "prefect.state-type": "PENDING",
            "prefect.state-name": "Pending",
            "prefect.state-timestamp": task_run_states[0].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )
    assert (
        parse_datetime(pending.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )
    assert pending.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert pending.payload == {
        "initial_state": None,
        "intended": {"from": None, "to": "PENDING"},
        "validated_state": {
            "type": "PENDING",
            "name": "Pending",
            "message": "",
            "state_details": {},
            "data": None,
        },
        "task_run": {
            "dynamic_key": task_run.dynamic_key,
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 0,
            "name": task_run.name,
            "run_count": 0,
            "tags": [],
            "labels": {},
            "task_inputs": {},
            "total_run_time": 0.0,
        },
    }

    assert running.event == "prefect.task-run.Running"
    assert running.id == task_run_states[1].id
    assert running.occurred == task_run_states[1].timestamp
    assert running.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run.id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "1",
            "prefect.state-message": "",
            "prefect.state-type": "RUNNING",
            "prefect.state-name": "Running",
            "prefect.state-timestamp": task_run_states[1].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )
    assert (
        parse_datetime(running.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )
    assert (
        parse_datetime(running.payload["task_run"].pop("start_time"))
        == task_run.start_time
    )
    assert running.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert running.payload == {
        "intended": {"from": "PENDING", "to": "RUNNING"},
        "initial_state": {
            "type": "PENDING",
            "name": "Pending",
            "message": "",
            "state_details": {},
        },
        "validated_state": {
            "type": "RUNNING",
            "name": "Running",
            "message": "",
            "state_details": {},
            "data": None,
        },
        "task_run": {
            "dynamic_key": task_run.dynamic_key,
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 1,
            "name": task_run.name,
            "run_count": 1,
            "tags": [],
            "labels": {},
            "task_inputs": {},
            "total_run_time": 0.0,
        },
    }

    assert failed.event == "prefect.task-run.Failed"
    assert failed.id == task_run_states[2].id
    assert failed.occurred == task_run_states[2].timestamp
    assert failed.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run.id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "1",
            "prefect.state-message": (
                "Task run encountered an exception ValueError: "
                "Here's a happy little accident."
            ),
            "prefect.state-type": "FAILED",
            "prefect.state-name": "Failed",
            "prefect.state-timestamp": task_run_states[2].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )
    assert (
        parse_datetime(failed.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )
    assert failed.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert (
        parse_datetime(failed.payload["task_run"].pop("start_time"))
        == task_run.start_time
    )
    assert (
        parse_datetime(failed.payload["task_run"].pop("end_time")) == task_run.end_time
    )
    assert failed.payload["task_run"].pop("total_run_time") > 0
    assert failed.payload == {
        "intended": {"from": "RUNNING", "to": "FAILED"},
        "initial_state": {
            "type": "RUNNING",
            "name": "Running",
            "message": "",
            "state_details": {},
        },
        "validated_state": {
            "type": "FAILED",
            "name": "Failed",
            "message": (
                "Task run encountered an exception ValueError: "
                "Here's a happy little accident."
            ),
            "state_details": {"retriable": False},
            "data": None,
        },
        "task_run": {
            "dynamic_key": task_run.dynamic_key,
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 1,
            "name": task_run.name,
            "run_count": 1,
            "tags": [],
            "labels": {},
            "task_inputs": {},
        },
    }


@pytest.mark.usefixtures("reset_worker_events")
async def test_background_task_state_changes(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    tmp_path: Path,
    events_pipeline: Any,
):
    storage = LocalFileSystem(basepath=str(tmp_path))
    await storage.save(f"test-{uuid.uuid4()}")

    @task(result_storage=storage)
    def foo():
        pass

    task_run_future = foo.apply_async()
    task_run = await prefect_client.read_task_run(task_run_future.task_run_id)

    await TaskWorker(foo).execute_task_run(task_run)
    await events_pipeline.process_events(dequeue_events=False)

    task_run_states = await prefect_client.read_task_run_states(
        task_run_future.task_run_id
    )

    await asserting_events_worker.drain()

    events = sorted(asserting_events_worker._client.events, key=lambda e: e.occurred)
    events = [e for e in events if e.event.startswith("prefect.task-run.")]

    assert len(task_run_states) == len(events) == 4

    assert [e.event for e in events] == [
        "prefect.task-run.Scheduled",
        "prefect.task-run.Pending",
        "prefect.task-run.Running",
        "prefect.task-run.Completed",
    ]

    observed = [
        (e.payload["intended"]["from"], e.payload["intended"]["to"])
        for e in events
        if e.event.startswith("prefect.task-run.")
    ]
    expected = [
        (None, "SCHEDULED"),
        ("SCHEDULED", "PENDING"),
        ("PENDING", "RUNNING"),
        ("RUNNING", "COMPLETED"),
    ]
    assert observed == expected


async def test_task_state_change_includes_tags_as_related_resources(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    events_pipeline: Any,
):
    @task(tags=["tag-c", "tag-a", "tag-b"])
    def tagged_task():
        return "tagged"

    @flow
    def flow_with_tagged_task():
        return tagged_task(return_state=True)

    flow_state: State[State[str]] = flow_with_tagged_task(return_state=True)

    await events_pipeline.process_events(dequeue_events=False)

    task_state: State[str] = await flow_state.result()
    task_run_id = task_state.state_details.task_run_id

    task_run = await prefect_client.read_task_run(task_run_id)
    assert sorted(task_run.tags) == ["tag-a", "tag-b", "tag-c"]

    await asserting_events_worker.drain()
    assert isinstance(asserting_events_worker._client, AssertingEventsClient)
    events = [
        event
        for event in asserting_events_worker._client.events
        if event.event.startswith("prefect.task-run.")
    ]
    assert len(events) == 3

    # Check all three events have tags as related resources
    for event in events:
        tag_related = [r for r in event.related if r["prefect.resource.role"] == "tag"]
        assert len(tag_related) == 3

        # Verify tags are sorted
        tag_ids = [r["prefect.resource.id"] for r in tag_related]
        assert tag_ids == [
            "prefect.tag.tag-a",
            "prefect.tag.tag-b",
            "prefect.tag.tag-c",
        ]

        # Verify each tag has the correct structure
        for tag_resource in tag_related:
            assert tag_resource["prefect.resource.role"] == "tag"
            assert tag_resource["prefect.resource.id"].startswith("prefect.tag.")


async def test_task_state_change_with_no_tags_has_no_tag_related_resources(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    events_pipeline: Any,
):
    @task
    def untagged_task():
        return "untagged"

    @flow
    def flow_with_untagged_task():
        return untagged_task(return_state=True)

    flow_state: State[State[str]] = flow_with_untagged_task(return_state=True)

    await events_pipeline.process_events(dequeue_events=False)

    await flow_state.result()

    await asserting_events_worker.drain()
    assert isinstance(asserting_events_worker._client, AssertingEventsClient)
    events = [
        event
        for event in asserting_events_worker._client.events
        if event.event.startswith("prefect.task-run.")
    ]
    assert len(events) == 3

    # Check no events have tag related resources
    for event in events:
        tag_related = [r for r in event.related if r["prefect.resource.role"] == "tag"]
        assert len(tag_related) == 0


async def test_apply_async_emits_scheduled_event(
    asserting_events_worker: Any,
    prefect_client: PrefectClient,
):
    @task
    def happy_little_tree():
        return "🌳"

    future = happy_little_tree.apply_async()
    task_run_id = future.task_run_id

    await asserting_events_worker.drain()

    events = asserting_events_worker._client.events
    assert len(events) == 1
    scheduled = events[0]
    pop_trace_details(scheduled.payload)

    task_run = await prefect_client.read_task_run(task_run_id)
    assert task_run
    assert task_run.id == task_run_id
    task_run_states = await prefect_client.read_task_run_states(task_run_id)
    assert len(task_run_states) == 1

    assert scheduled.event == "prefect.task-run.Scheduled"
    assert scheduled.id == task_run_states[0].id
    assert scheduled.occurred == task_run_states[0].timestamp
    assert scheduled.resource == Resource(
        {
            "prefect.resource.id": f"prefect.task-run.{task_run_id}",
            "prefect.resource.name": task_run.name,
            "prefect.run-count": "0",
            "prefect.state-message": "",
            "prefect.state-type": "SCHEDULED",
            "prefect.state-name": "Scheduled",
            "prefect.state-timestamp": task_run_states[0].timestamp.isoformat(),
            "prefect.orchestration": "client",
        }
    )

    assert (
        parse_datetime(
            scheduled.payload["validated_state"]["state_details"].pop("scheduled_time")
        )
        == task_run.expected_start_time
    )
    assert (
        parse_datetime(scheduled.payload["task_run"].pop("next_scheduled_start_time"))
        == task_run.next_scheduled_start_time
    )
    assert (
        parse_datetime(scheduled.payload["task_run"].pop("expected_start_time"))
        == task_run.expected_start_time
    )

    assert scheduled.payload["task_run"].pop("name").startswith("happy_little_tree")
    assert (
        scheduled.payload["task_run"].pop("dynamic_key").startswith("happy_little_tree")
    )
    assert scheduled.payload["task_run"].pop("task_key").startswith("happy_little_tree")
    assert scheduled.payload == {
        "initial_state": None,
        "intended": {"from": None, "to": "SCHEDULED"},
        "validated_state": {
            "type": "SCHEDULED",
            "name": "Scheduled",
            "message": "",
            "state_details": {
                "pause_reschedule": False,
                "untrackable_result": False,
                "deferred": True,
            },
            "data": None,
        },
        "task_run": {
            "empirical_policy": {
                "max_retries": 0,
                "retries": 0,
                "retry_delay": 0,
                "retry_delay_seconds": 0.0,
            },
            "flow_run_run_count": 0,
            "run_count": 0,
            "tags": [],
            "labels": {},
            "task_inputs": {},
            "total_run_time": 0.0,
        },
    }


@pytest.mark.usefixtures("reset_worker_events")
async def test_nested_task_pending_event_has_no_stale_task_run_related_resource(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    events_pipeline: Any,
):
    """Regression test: when task_a calls task_b (nested), task_b's Pending
    event must not include task_a's task run ID as a related resource.

    Before the fix, the Pending event was emitted before setup_run_context()
    entered the new TaskRunContext for the inner task.  EventsWorker captures
    context via copy_context() at emission time, so task_a's TaskRunContext
    leaked into task_b's Pending event as a 'task-run' related resource."""

    @task
    def inner_task():
        return "inner"

    @task
    def outer_task():
        return inner_task()

    @flow
    def nesting_flow():
        return outer_task()

    nesting_flow()

    await events_pipeline.process_events(dequeue_events=False)
    await asserting_events_worker.drain()
    assert isinstance(asserting_events_worker._client, AssertingEventsClient)

    task_events = [
        event
        for event in asserting_events_worker._client.events
        if event.event.startswith("prefect.task-run.")
    ]
    # 3 events per task (Pending, Running, Completed) x 2 tasks = 6
    assert len(task_events) == 6

    # For every task event, no related resource with role "task-run" should
    # point to a *different* task run.  The event's own task run is already
    # the primary resource and gets excluded by the worker, so no task-run
    # related resource should appear at all.
    for event in task_events:
        task_run_related = [
            r for r in event.related if r.get("prefect.resource.role") == "task-run"
        ]
        assert task_run_related == [], (
            f"{event.event} for {event.resource['prefect.resource.id']} "
            f"has unexpected task-run related resource(s): "
            f"{[r['prefect.resource.id'] for r in task_run_related]}"
        )


@pytest.mark.usefixtures("reset_worker_events")
async def test_async_nested_task_pending_event_has_no_stale_task_run_related_resource(
    asserting_events_worker: EventsWorker,
    prefect_client: PrefectClient,
    events_pipeline: Any,
):
    """Async variant of the stale TaskRunContext regression test.

    Both SyncTaskRunEngine and AsyncTaskRunEngine were fixed, so both
    paths need coverage."""

    @task
    async def async_inner_task():
        return "inner"

    @task
    async def async_outer_task():
        return await async_inner_task()

    @flow
    async def async_nesting_flow():
        return await async_outer_task()

    await async_nesting_flow()

    await events_pipeline.process_events(dequeue_events=False)
    await asserting_events_worker.drain()
    assert isinstance(asserting_events_worker._client, AssertingEventsClient)

    task_events = [
        event
        for event in asserting_events_worker._client.events
        if event.event.startswith("prefect.task-run.")
    ]
    assert len(task_events) == 6

    for event in task_events:
        task_run_related = [
            r for r in event.related if r.get("prefect.resource.role") == "task-run"
        ]
        assert task_run_related == [], (
            f"{event.event} for {event.resource['prefect.resource.id']} "
            f"has unexpected task-run related resource(s): "
            f"{[r['prefect.resource.id'] for r in task_run_related]}"
        )
