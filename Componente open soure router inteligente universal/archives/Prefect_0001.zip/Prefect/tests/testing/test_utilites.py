import contextvars
import gc
import unittest
import uuid
import warnings
from unittest.mock import MagicMock

import pytest

from prefect import flow, task
from prefect.client.orchestration import get_client
from prefect.server import schemas
from prefect.server.api.server import SubprocessASGIServer
from prefect.settings import (
    PREFECT_API_URL,
    PREFECT_SERVER_DATABASE_CONNECTION_URL,
    PREFECT_SERVER_EPHEMERAL_STARTUP_TIMEOUT_SECONDS,
    get_current_settings,
)
from prefect.testing.utilities import assert_does_not_warn, prefect_test_harness

pytestmark = pytest.mark.clear_db


def _multiprocessing_worker():
    """
    Worker function for multiprocessing test. Must be at module level for pickling.
    """
    import os

    # os._exit() is required here despite the underscore prefix. On Linux with fork(),
    # the child process inherits Prefect's logging/event state. Normal exit (return or
    # sys.exit) triggers Python cleanup that fails with this inherited state, causing
    # exitcode=1. os._exit() bypasses cleanup and is documented for use "in the child
    # process after os.fork()" - which is exactly this scenario.
    os._exit(0)


def _api_url_without_settings_context() -> str:
    return contextvars.Context().run(lambda: str(get_current_settings().api.url))


def test_assert_does_not_warn_no_warning():
    with assert_does_not_warn():
        pass


def test_assert_does_not_warn_does_not_capture_exceptions():
    with pytest.raises(ValueError):
        with assert_does_not_warn():
            raise ValueError()


def test_assert_does_not_warn_raises_assertion_error():
    with pytest.raises(AssertionError, match="Warning was raised"):
        with assert_does_not_warn():
            warnings.warn("Test")


async def test_prefect_test_harness():
    # TODO: This test fails intermittently with a directory error in Windows
    # due to temporary directory differences
    very_specific_name = str(uuid.uuid4())

    @task
    def test_task():
        pass

    @flow(name=very_specific_name)
    def test_flow():
        test_task()
        return "foo"

    existing_db_url = PREFECT_SERVER_DATABASE_CONNECTION_URL.value()
    existing_api_url = PREFECT_API_URL.value()

    with prefect_test_harness():
        async with get_client() as client:
            # should be able to run a flow
            assert test_flow() == "foo"

            # should be able to query for generated data
            flows = await client.read_flows(
                flow_filter=schemas.filters.FlowFilter(
                    name={"any_": [very_specific_name]}
                )
            )
            assert len(flows) == 1
            assert flows[0].name == very_specific_name

            assert PREFECT_API_URL.value() != existing_api_url

    # API URL should be reset
    assert PREFECT_API_URL.value() == existing_api_url

    # database connection should be reset
    assert PREFECT_SERVER_DATABASE_CONNECTION_URL.value() == existing_db_url

    # outside the context, none of the test runs should not persist
    async with get_client() as client:
        flows = await client.read_flows(
            flow_filter=schemas.filters.FlowFilter(name={"any_": [very_specific_name]})
        )
        assert len(flows) == 0


def test_prefect_test_harness_settings_visible_in_isolated_asyncio_test_case():
    """
    Regression test for issue #15818 - `unittest.IsolatedAsyncioTestCase` copies
    the current `contextvars` context when it is constructed, which happens
    before a session-scoped fixture enters the test harness. The harness
    settings must still be visible inside the isolated test case.
    """
    observed: dict[str, str] = {}

    class _Case(unittest.IsolatedAsyncioTestCase):
        def test_sync(self):
            observed["sync"] = str(get_current_settings().api.url)

        async def test_async(self):
            observed["async"] = str(get_current_settings().api.url)

    # Construct the cases in an empty context to emulate collection happening
    # before any settings context is entered
    sync_case = contextvars.Context().run(_Case, "test_sync")
    async_case = contextvars.Context().run(_Case, "test_async")

    with prefect_test_harness():
        harness_api_url = str(get_current_settings().api.url)
        sync_result = sync_case.run()
        async_result = async_case.run()

    assert sync_result is not None and sync_result.wasSuccessful(), sync_result.errors
    assert async_result is not None and async_result.wasSuccessful(), (
        async_result.errors
    )
    assert observed["sync"] == harness_api_url
    assert observed["async"] == harness_api_url


def test_prefect_test_harness_restores_global_settings_context():
    """The process-global settings context is restored when the harness exits."""
    before = _api_url_without_settings_context()

    with prefect_test_harness():
        during = _api_url_without_settings_context()
        harness_api_url = str(get_current_settings().api.url)

    assert during == harness_api_url
    assert during != before
    assert _api_url_without_settings_context() == before


def test_prefect_test_harness_nested_restores_outer_settings_context():
    """Nested harnesses restore the enclosing harness settings, not the import-time global."""
    before = _api_url_without_settings_context()

    with prefect_test_harness():
        outer_api_url = _api_url_without_settings_context()
        with prefect_test_harness():
            inner_api_url = _api_url_without_settings_context()
        assert _api_url_without_settings_context() == outer_api_url

    assert inner_api_url != outer_api_url
    assert _api_url_without_settings_context() == before


def test_prefect_test_harness_uses_fresh_server_when_default_server_is_running():
    stray_server = SubprocessASGIServer()
    stray_server.start()

    try:
        with prefect_test_harness():
            assert PREFECT_API_URL.value() != stray_server.api_url

        assert stray_server.running
    finally:
        stray_server.stop()


def test_prefect_test_harness_timeout(monkeypatch):
    server = MagicMock()
    monkeypatch.setattr(
        "prefect.testing.utilities.SubprocessASGIServer",
        server,
    )
    server().api_url = "http://localhost:42000"

    with prefect_test_harness():
        server().start.assert_called_once_with(timeout=30)

    server().start.reset_mock()

    with prefect_test_harness(server_startup_timeout=120):
        server().start.assert_called_once_with(timeout=120)

    server().start.reset_mock()

    with prefect_test_harness(server_startup_timeout=None):
        server().start.assert_called_once_with(
            timeout=PREFECT_SERVER_EPHEMERAL_STARTUP_TIMEOUT_SECONDS.value()
        )


@pytest.mark.unix
def test_multiprocessing_after_test_harness():
    """
    Test that multiprocessing works after using prefect_test_harness.

    Regression test for issue #19112 - on Linux, multiprocessing.Process() would
    deadlock after using the test harness because fork() inherited locked thread
    state from background threads.
    """
    import multiprocessing

    @task
    def test_task():
        return 1

    @flow
    def test_flow():
        return test_task.submit()

    # Use test harness which starts background threads
    with prefect_test_harness():
        test_flow()

    # This should not deadlock
    process = multiprocessing.Process(target=_multiprocessing_worker)
    process.start()
    process.join(timeout=5)

    # Verify process completed successfully
    assert process.exitcode == 0, "Process should complete without deadlock"


def test_prefect_test_harness_multiple_runs():
    """
    Test that running prefect_test_harness multiple times doesn't cause errors.

    Regression test for issue #19342 - running the test harness multiple times
    in the same process would cause FOREIGN KEY constraint failures because the
    EventsWorker singleton persisted stale events across harness sessions.
    """

    @task
    def example_task():
        return "task completed"

    @flow
    def example_flow():
        return example_task()

    # Run the test harness twice - the second run would fail with the bug
    with prefect_test_harness():
        result1 = example_flow()
        assert result1 == "task completed"

    with prefect_test_harness():
        result2 = example_flow()
        assert result2 == "task completed"


def test_prefect_test_harness_does_not_spawn_second_server():
    """
    Test that prefect_test_harness does not spawn a second SubprocessASGIServer.

    Regression test for issue #21544 - when prefect_test_harness passed a specific
    port to SubprocessASGIServer, the singleton keyed by that port did not match
    subsequent SubprocessASGIServer() calls (keyed by None), causing a second
    unmanaged server subprocess to be spawned. This second server was never
    explicitly stopped, causing pytest to hang on CI after all tests completed.
    """

    @task
    def simple_task():
        return 1

    @flow
    def simple_flow():
        return simple_task.submit()

    with prefect_test_harness():
        simple_flow()
        # All instance entries should point to the same server object.
        # If a SubprocessASGIServer() call during flow execution created a
        # separate instance (different object), it means an unmanaged server
        # subprocess was spawned that would never be explicitly stopped.
        unique_instances = set(
            id(inst) for inst in SubprocessASGIServer._instances.values()
        )
        assert len(unique_instances) == 1, (
            f"Expected all SubprocessASGIServer entries to be the same instance, "
            f"but found {len(unique_instances)} distinct instances "
            f"across keys {list(SubprocessASGIServer._instances.keys())}"
        )


@pytest.mark.filterwarnings("error::pytest.PytestUnraisableExceptionWarning")
async def test_prefect_test_harness_async_cleanup():
    """
    Test that prefect_test_harness properly cleans up in async contexts.

    Regression test for issue #19762 - when prefect_test_harness is used in an
    async context, the drain_all() and drain() calls return coroutines that were
    never awaited, causing RuntimeWarning: coroutine 'wait' was never awaited.
    """
    with prefect_test_harness():
        pass
    # Force garbage collection to trigger finalization of any unawaited coroutines
    gc.collect()
