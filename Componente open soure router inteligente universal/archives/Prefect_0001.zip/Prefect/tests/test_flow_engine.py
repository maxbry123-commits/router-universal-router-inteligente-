import asyncio
import logging
import signal
import threading
import time
import uuid
from collections.abc import AsyncGenerator, Awaitable, Callable, Generator
from contextlib import asynccontextmanager, contextmanager, nullcontext
from textwrap import dedent
from types import SimpleNamespace
from typing import Any, Literal, Optional
from unittest import mock
from unittest.mock import ANY, AsyncMock, MagicMock
from uuid import UUID

import anyio
import pydantic
import pytest

import prefect.flow_engine as flow_engine_module
import prefect.utilities.engine as engine_utils
from prefect import Flow, __development_base_path__, flow, states, task
from prefect._flow_run_suspension import (
    FlowRunSuspensionRequest,
    mark_flow_run_suspension_requested,
)
from prefect._internal.attempt_control import EngineOutcomeReceipt
from prefect.cache_policies import INPUTS
from prefect.client.orchestration import PrefectClient, SyncPrefectClient, get_client
from prefect.client.schemas.filters import FlowFilter, FlowFilterName, FlowRunFilter
from prefect.client.schemas.objects import StateType
from prefect.client.schemas.sorting import FlowRunSort
from prefect.concurrency.asyncio import concurrency as aconcurrency
from prefect.concurrency.sync import concurrency
from prefect.context import (
    FlowRunContext,
    TagsContext,
    TaskRunContext,
    get_run_context,
)
from prefect.engine import _drive_run_flow_result, handle_engine_signals
from prefect.exceptions import (
    Abort,
    CrashedRun,
    FlowPauseTimeout,
    ParameterTypeError,
    Pause,
    TerminationSignal,
)
from prefect.flow_engine import (
    MINIMUM_HEARTBEAT_INTERVAL,
    AsyncFlowRunEngine,
    FlowRunEngine,
    NotSet,
    _load_flow_from_runtime_entrypoint,
    _main,
    _run_flow_from_runtime_entrypoint,
    _run_serialized_call_with_control_bootstrap,
    _runtime_subprocess_env,
    _send_heartbeats,
    load_flow_and_flow_run,
    run_flow,
    run_flow_async,
    run_flow_in_subprocess,
    run_flow_sync,
)
from prefect.flow_runs import pause_flow_run, resume_flow_run, suspend_flow_run
from prefect.input.actions import read_flow_run_input
from prefect.input.run_input import RunInput
from prefect.logging import get_run_logger
from prefect.results import get_result_store
from prefect.runtime import flow_run as runtime_flow_run
from prefect.server.schemas.core import ConcurrencyLimitV2
from prefect.server.schemas.core import FlowRun as ServerFlowRun
from prefect.settings import PREFECT_LOGGING_LOG_PRINTS, temporary_settings
from prefect.states import Running
from prefect.utilities.callables import get_call_parameters
from prefect.utilities.engine import capture_sigterm, propose_state, propose_state_sync
from prefect.utilities.filesystem import tmpchdir


@flow
async def foo():
    return 42


class TestFlowRunNameSetBeforeRunningEvent:
    @staticmethod
    def _track_sync_running_names(
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
    ) -> list[str]:
        names_at_running_transition: list[str] = []
        original_propose = propose_state_sync

        def tracking_propose(client, state, **kwargs):
            if state.is_running():
                flow_run = sync_prefect_client.read_flow_run(kwargs["flow_run_id"])
                names_at_running_transition.append(flow_run.name)
            return original_propose(client, state, **kwargs)

        monkeypatch.setattr("prefect.flow_engine.propose_state_sync", tracking_propose)
        return names_at_running_transition

    @staticmethod
    def _track_async_running_names(
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
    ) -> list[str]:
        names_at_running_transition: list[str] = []
        original_propose = propose_state

        async def tracking_propose(client, state, **kwargs):
            if state.is_running():
                flow_run = sync_prefect_client.read_flow_run(kwargs["flow_run_id"])
                names_at_running_transition.append(flow_run.name)
            return await original_propose(client, state, **kwargs)

        monkeypatch.setattr("prefect.flow_engine.propose_state", tracking_propose)
        return names_at_running_transition

    async def test_sync_flow_string_template_name_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_sync_running_names(
            sync_prefect_client, monkeypatch
        )

        @flow(flow_run_name="custom-{x}")
        def my_flow(x):
            return FlowRunContext.get().flow_run.id

        result = run_flow_sync(my_flow, parameters={"x": "hello"})
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "custom-hello"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "custom-hello"

    async def test_async_flow_string_template_name_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_async_running_names(
            sync_prefect_client, monkeypatch
        )

        @flow(flow_run_name="custom-{x}")
        async def my_flow(x):
            return FlowRunContext.get().flow_run.id

        result = await run_flow(my_flow, parameters={"x": "world"})
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "custom-world"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "custom-world"

    async def test_sync_flow_callable_name_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_sync_running_names(
            sync_prefect_client, monkeypatch
        )

        def generate_name():
            return "callable-name"

        @flow(flow_run_name=generate_name)
        def my_flow():
            return FlowRunContext.get().flow_run.id

        result = run_flow_sync(my_flow)
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "callable-name"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "callable-name"

    async def test_async_flow_callable_name_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_async_running_names(
            sync_prefect_client, monkeypatch
        )

        def generate_name():
            return "callable-name"

        @flow(flow_run_name=generate_name)
        async def my_flow():
            return FlowRunContext.get().flow_run.id

        result = await run_flow(my_flow)
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "callable-name"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "callable-name"

    async def test_sync_flow_callable_with_runtime_params_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_sync_running_names(
            sync_prefect_client, monkeypatch
        )

        def generate_name():
            return f"runtime-{runtime_flow_run.parameters['x']}"

        @flow(flow_run_name=generate_name)
        def my_flow(x):
            return FlowRunContext.get().flow_run.id

        result = run_flow_sync(my_flow, parameters={"x": "hello"})
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "runtime-hello"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "runtime-hello"

    async def test_async_flow_callable_with_runtime_params_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_async_running_names(
            sync_prefect_client, monkeypatch
        )

        def generate_name():
            return f"runtime-{runtime_flow_run.parameters['x']}"

        @flow(flow_run_name=generate_name)
        async def my_flow(x):
            return FlowRunContext.get().flow_run.id

        result = await run_flow(my_flow, parameters={"x": "world"})
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "runtime-world"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "runtime-world"

    async def test_sync_flow_multi_param_template_name_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_sync_running_names(
            sync_prefect_client, monkeypatch
        )

        @flow(flow_run_name="custom-{x}-{y}")
        def my_flow(x, y):
            return FlowRunContext.get().flow_run.id

        result = run_flow_sync(my_flow, parameters={"x": "hello", "y": "world"})
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "custom-hello-world"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "custom-hello-world"

    async def test_async_flow_multi_param_template_name_set_before_running(
        self, sync_prefect_client: SyncPrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        names_at_running_transition = self._track_async_running_names(
            sync_prefect_client, monkeypatch
        )

        @flow(flow_run_name="custom-{x}-{y}")
        async def my_flow(x, y):
            return FlowRunContext.get().flow_run.id

        result = await run_flow(my_flow, parameters={"x": "hello", "y": "world"})
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "custom-hello-world"
        assert names_at_running_transition
        assert names_at_running_transition[0] == "custom-hello-world"

    async def test_sync_temporary_context_does_not_break_subflow_log_prints(
        self, caplog: pytest.LogCaptureFixture
    ):
        @flow(flow_run_name="child-name")
        def child_flow():
            print("hello from child")

        @flow(log_prints=True)
        def parent_flow():
            child_flow()

        with temporary_settings({PREFECT_LOGGING_LOG_PRINTS: False}):
            parent_flow()

        assert "hello from child" in caplog.text

    async def test_async_temporary_context_does_not_break_subflow_log_prints(
        self, caplog: pytest.LogCaptureFixture
    ):
        @flow(flow_run_name="child-name")
        async def child_flow():
            print("hello from child")

        @flow(log_prints=True)
        async def parent_flow():
            await child_flow()

        with temporary_settings({PREFECT_LOGGING_LOG_PRINTS: False}):
            await parent_flow()

        assert "hello from child" in caplog.text


class TestFlowRunEngine:
    def test_basic_init(self):
        engine = FlowRunEngine(flow=foo)
        assert isinstance(engine.flow, Flow)
        assert engine.flow.name == "foo"
        assert engine.parameters == {}

    def test_empty_init(self):
        with pytest.raises(
            TypeError, match="missing 1 required positional argument: 'flow'"
        ):
            FlowRunEngine()

    def test_client_attr_raises_informative_error(self):
        engine = FlowRunEngine(flow=foo)
        with pytest.raises(RuntimeError, match="not started"):
            engine.client

    def test_client_attr_returns_client_after_starting(self):
        engine = FlowRunEngine(flow=foo)
        with engine.initialize_run():
            client = engine.client
            assert isinstance(client, SyncPrefectClient)

        with pytest.raises(RuntimeError, match="not started"):
            engine.client


class TestAsyncFlowRunEngine:
    def test_basic_init(self):
        engine = AsyncFlowRunEngine(flow=foo)
        assert isinstance(engine.flow, Flow)
        assert engine.flow.name == "foo"
        assert engine.parameters == {}

    def test_empty_init(self):
        with pytest.raises(
            TypeError, match="missing 1 required positional argument: 'flow'"
        ):
            AsyncFlowRunEngine()

    def test_client_attr_raises_informative_error(self):
        engine = AsyncFlowRunEngine(flow=foo)
        with pytest.raises(RuntimeError, match="not started"):
            engine.client

    async def test_client_attr_returns_client_after_starting(self):
        engine = AsyncFlowRunEngine(flow=foo)
        async with engine.initialize_run():
            client = engine.client
            assert isinstance(client, PrefectClient)

        with pytest.raises(RuntimeError, match="not started"):
            engine.client


class TestCancellationAndCrashedHookGating:
    def test_runner_managed_subflows_suppress_only_cancellation_hooks(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        hook_calls: list[str] = []
        monkeypatch.setenv("PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "false")

        def on_cancellation(flow, flow_run, state):
            hook_calls.append("cancel")

        def on_crashed(flow, flow_run, state):
            hook_calls.append("crash")

        @flow(on_cancellation=[on_cancellation], on_crashed=[on_crashed])
        def child_flow():
            return None

        flow_run = MagicMock()
        flow_run.parent_task_run_id = uuid.uuid4()
        flow_run.deployment_id = uuid.uuid4()

        engine = FlowRunEngine(flow=child_flow, flow_run=flow_run)
        engine._started_with_in_process_parent_flow_run_context = False

        engine.call_hooks(states.Cancelling())
        engine.call_hooks(states.Crashed(message="boom"))

        assert hook_calls == ["crash"]

    async def test_async_runner_managed_subflows_suppress_only_cancellation_hooks(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        hook_calls: list[str] = []
        monkeypatch.setenv("PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "false")

        async def on_cancellation(flow, flow_run, state):
            hook_calls.append("cancel")

        async def on_crashed(flow, flow_run, state):
            hook_calls.append("crash")

        @flow(on_cancellation=[on_cancellation], on_crashed=[on_crashed])
        async def child_flow():
            return None

        flow_run = MagicMock()
        flow_run.parent_task_run_id = uuid.uuid4()
        flow_run.deployment_id = uuid.uuid4()

        engine = AsyncFlowRunEngine(flow=child_flow, flow_run=flow_run)
        engine._started_with_in_process_parent_flow_run_context = False

        await engine.call_hooks(states.Cancelling())
        await engine.call_hooks(states.Crashed(message="boom"))

        assert hook_calls == ["crash"]

    def test_same_process_subflows_ignore_env_suppression(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        hook_calls: list[str] = []
        monkeypatch.setenv("PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "false")

        def on_cancellation(flow, flow_run, state):
            hook_calls.append("cancel")

        @flow(on_cancellation=[on_cancellation])
        def child_flow():
            return None

        flow_run = MagicMock()
        flow_run.parent_task_run_id = uuid.uuid4()
        flow_run.deployment_id = None

        engine = FlowRunEngine(flow=child_flow, flow_run=flow_run)
        engine._started_with_in_process_parent_flow_run_context = True

        engine.call_hooks(states.Cancelling())

        assert hook_calls == ["cancel"]

    def test_detached_parent_context_subflows_respect_env_suppression(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        hook_calls: list[str] = []
        monkeypatch.setenv("PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "false")

        def on_cancellation(flow, flow_run, state):
            hook_calls.append("cancel")

        @flow(on_cancellation=[on_cancellation])
        def child_flow():
            return None

        engine = FlowRunEngine(flow=child_flow, flow_run=MagicMock())
        engine._started_with_in_process_parent_flow_run_context = False

        engine.call_hooks(states.Cancelling())

        assert hook_calls == []


class TestCancellationStateOwnership:
    def test_runner_managed_subprocesses_skip_child_owned_cancellation_state_writes(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setenv("PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "false")
        engine = FlowRunEngine(flow=foo, flow_run=MagicMock())
        engine._started_with_in_process_parent_flow_run_context = False
        engine.set_state = MagicMock()
        engine._telemetry = MagicMock()
        exc = TerminationSignal(signal.SIGTERM)

        engine.handle_cancellation(exc)

        engine.set_state.assert_not_called()
        assert engine._raised is exc
        engine._telemetry.record_exception.assert_called_once_with(exc)
        engine._telemetry.end_span_on_failure.assert_called_once_with(
            "Flow run was cancelled."
        )

    def test_top_level_non_runner_flows_force_cancellation_state_writes(self):
        engine = FlowRunEngine(flow=foo, flow_run=MagicMock())
        engine._started_with_in_process_parent_flow_run_context = False
        engine.set_state = MagicMock()
        engine._telemetry = MagicMock()
        exc = TerminationSignal(signal.SIGTERM)

        engine.handle_cancellation(exc)

        assert engine.set_state.call_count == 2
        first_state = engine.set_state.call_args_list[0].args[0]
        second_state = engine.set_state.call_args_list[1].args[0]
        assert first_state.is_cancelling()
        assert second_state.is_cancelled()

    def test_same_process_subflows_force_cancellation_state_writes(self):
        engine = FlowRunEngine(flow=foo, flow_run=MagicMock())
        engine._started_with_in_process_parent_flow_run_context = True
        engine.set_state = MagicMock()
        engine._telemetry = MagicMock()
        exc = TerminationSignal(signal.SIGTERM)

        engine.handle_cancellation(exc)

        assert engine.set_state.call_count == 2
        first_state = engine.set_state.call_args_list[0].args[0]
        second_state = engine.set_state.call_args_list[1].args[0]
        assert first_state.is_cancelling()
        assert second_state.is_cancelled()

    async def test_async_runner_managed_subprocesses_skip_child_owned_state_writes(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setenv("PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "false")
        engine = AsyncFlowRunEngine(flow=foo, flow_run=MagicMock())
        engine._started_with_in_process_parent_flow_run_context = False
        engine.set_state = AsyncMock()
        engine._telemetry = MagicMock()
        exc = TerminationSignal(signal.SIGTERM)

        await engine.handle_cancellation(exc)

        engine.set_state.assert_not_called()
        assert engine._raised is exc
        engine._telemetry.record_exception.assert_called_once_with(exc)
        engine._telemetry.end_span_on_failure.assert_called_once_with(
            "Flow run was cancelled."
        )

    async def test_async_top_level_non_runner_flows_force_cancellation_state_writes(
        self,
    ):
        engine = AsyncFlowRunEngine(flow=foo, flow_run=MagicMock())
        engine._started_with_in_process_parent_flow_run_context = False
        engine.set_state = AsyncMock()
        engine._telemetry = MagicMock()
        exc = TerminationSignal(signal.SIGTERM)

        await engine.handle_cancellation(exc)

        assert engine.set_state.await_count == 2
        first_state = engine.set_state.await_args_list[0].args[0]
        second_state = engine.set_state.await_args_list[1].args[0]
        assert first_state.is_cancelling()
        assert second_state.is_cancelled()


class TestStartFlowRunEngine:
    async def test_start_updates_empirical_policy_on_provided_flow_run(
        self, prefect_client: PrefectClient
    ):
        @flow(retries=3, retry_delay_seconds=10)
        def flow_with_retries():
            pass

        flow_run = await prefect_client.create_flow_run(flow_with_retries)

        engine = FlowRunEngine(flow=flow_with_retries, flow_run=flow_run)
        with engine.start():
            assert engine.flow_run.empirical_policy.retries == 3
            assert engine.flow_run.empirical_policy.retry_delay == 10

            # avoid error on teardown
            engine.begin_run()


class TestStartAsyncFlowRunEngine:
    async def test_start_updates_empirical_policy_on_provided_flow_run(
        self, prefect_client: PrefectClient
    ):
        @flow(retries=3, retry_delay_seconds=10)
        def flow_with_retries():
            pass

        flow_run = await prefect_client.create_flow_run(flow_with_retries)

        engine = AsyncFlowRunEngine(flow=flow_with_retries, flow_run=flow_run)
        async with engine.start():
            assert engine.flow_run.empirical_policy.retries == 3
            assert engine.flow_run.empirical_policy.retry_delay == 10

            # avoid error on teardown
            await engine.begin_run()


FlowExecutionShape = Literal["sync", "async", "generator", "async-generator"]


def _reject_terminal_transition(
    monkeypatch: pytest.MonkeyPatch,
    *,
    async_engine: bool,
    exception: BaseException,
) -> None:
    if not async_engine:
        original_propose_state = flow_engine_module.propose_state_sync

        def reject_terminal_state(
            client: Any, state: states.State[Any], **kwargs: Any
        ) -> Any:
            if state.is_final():
                raise exception
            return original_propose_state(client, state, **kwargs)

        monkeypatch.setattr(
            flow_engine_module,
            "propose_state_sync",
            reject_terminal_state,
        )
        return

    original_propose_state = flow_engine_module.propose_state

    async def reject_terminal_state_async(
        client: Any, state: states.State[Any], **kwargs: Any
    ) -> Any:
        if state.is_final():
            raise exception
        return await original_propose_state(client, state, **kwargs)

    monkeypatch.setattr(
        flow_engine_module,
        "propose_state",
        reject_terminal_state_async,
    )


@pytest.mark.parametrize(
    "execution_shape", ["sync", "async", "generator", "async-generator"]
)
class TestEngineOutcomeReceiptExecutionShapes:
    @pytest.fixture
    def build_flow_shape(
        self,
        execution_shape: FlowExecutionShape,
    ) -> Callable[[Callable[[], str], int], Flow[Any, Any]]:
        def build(flow_body: Callable[[], str], retries: int = 0) -> Flow[Any, Any]:
            if execution_shape == "sync":

                @flow(retries=retries)
                def test_flow() -> str:
                    return flow_body()

            elif execution_shape == "async":

                @flow(retries=retries)
                async def test_flow() -> str:
                    return flow_body()

            elif execution_shape == "generator":

                @flow(retries=retries)
                def test_flow() -> Generator[str, None, str]:
                    yield "yielded"
                    return flow_body()

            else:

                @flow(retries=retries)
                async def test_flow() -> AsyncGenerator[str, None]:
                    yield "yielded"
                    flow_body()

            return test_flow

        return build

    @pytest.fixture
    def run_flow_shape(
        self,
        execution_shape: FlowExecutionShape,
    ) -> Callable[[Flow[Any, Any], list[Any]], Awaitable[Any]]:
        async def run(test_flow: Flow[Any, Any], yielded: list[Any]) -> Any:
            flow_result: Any = test_flow()
            if execution_shape == "sync":
                return flow_result
            if execution_shape == "async":
                return await flow_result
            if execution_shape == "generator":
                yielded.extend(flow_result)
                return yielded
            async for value in flow_result:
                yielded.append(value)
            return yielded

        return run

    @pytest.mark.parametrize(
        ("eventual_state_type", "retries"),
        [
            (StateType.COMPLETED, 0),
            (StateType.FAILED, 0),
            (StateType.COMPLETED, 1),
            (StateType.FAILED, 1),
        ],
    )
    async def test_reports_one_authoritative_conclusion(
        self,
        execution_shape: FlowExecutionShape,
        eventual_state_type: StateType,
        retries: int,
        build_flow_shape: Callable[[Callable[[], str], int], Flow[Any, Any]],
        run_flow_shape: Callable[[Flow[Any, Any], list[Any]], Awaitable[Any]],
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
    ):
        attempts = 0
        flow_run_id: UUID | None = None
        observed_events: list[str] = []

        def record_receipt(_receipt: EngineOutcomeReceipt) -> bool:
            observed_events.append("receipt")
            return True

        report_engine_outcome = MagicMock(side_effect=record_receipt)
        monkeypatch.setattr(
            flow_engine_module,
            "report_engine_outcome",
            report_engine_outcome,
        )

        def begin_attempt() -> None:
            nonlocal attempts, flow_run_id
            attempts += 1
            flow_run_id = FlowRunContext.get().flow_run.id
            if attempts > 1:
                report_engine_outcome.assert_not_called()

        def finish_attempt() -> str:
            if attempts <= retries or eventual_state_type == StateType.FAILED:
                raise ValueError(f"attempt {attempts} failed")
            return "completed"

        def flow_body() -> str:
            begin_attempt()
            return finish_attempt()

        yielded: list[Any] = []
        test_flow = build_flow_shape(flow_body, retries)
        if eventual_state_type == StateType.FAILED:
            with pytest.raises(ValueError, match=f"attempt {retries + 1} failed"):
                await run_flow_shape(test_flow, yielded)
            observed_events.append("exception")
            assert observed_events == ["receipt", "exception"]
        else:
            result = await run_flow_shape(test_flow, yielded)
            if execution_shape in ("generator", "async-generator"):
                assert result == ["yielded"] * (retries + 1)
            else:
                assert result == "completed"
            assert observed_events == ["receipt"]

        assert attempts == retries + 1
        assert flow_run_id is not None
        flow_run = sync_prefect_client.read_flow_run(flow_run_id)
        assert flow_run.state is not None
        assert flow_run.state.type == eventual_state_type
        report_engine_outcome.assert_called_once_with(
            EngineOutcomeReceipt.state_reported(
                state_id=flow_run.state.id,
                state_type=flow_run.state.type.value,
                state_name=flow_run.state.name,
            )
        )

    async def test_reports_rejected_paused_transition(
        self,
        execution_shape: FlowExecutionShape,
        build_flow_shape: Callable[[Callable[[], str], int], Flow[Any, Any]],
        run_flow_shape: Callable[[Flow[Any, Any], list[Any]], Awaitable[Any]],
        monkeypatch: pytest.MonkeyPatch,
    ):
        paused_state = states.Paused(
            id=uuid.uuid4(),
            name="PausedByOrchestration",
            message="private message",
            data="private result",
        )
        report_engine_outcome = MagicMock(return_value=True)
        monkeypatch.setattr(
            flow_engine_module,
            "report_engine_outcome",
            report_engine_outcome,
        )

        _reject_terminal_transition(
            monkeypatch,
            async_engine=execution_shape in ("async", "async-generator"),
            exception=Pause("paused by orchestration", state=paused_state),
        )

        yielded: list[Any] = []
        test_flow = build_flow_shape(lambda: "completed", 0)
        with pytest.raises(Pause, match="paused by orchestration"):
            await run_flow_shape(test_flow, yielded)

        if execution_shape in ("generator", "async-generator"):
            assert yielded == ["yielded"]
        report_engine_outcome.assert_called_once_with(
            EngineOutcomeReceipt.state_reported(
                state_id=paused_state.id,
                state_type=paused_state.type.value,
                state_name=paused_state.name,
            )
        )


@pytest.mark.parametrize("engine_type", ["sync", "async"])
class TestEngineOutcomeReceipts:
    @pytest.fixture
    def run_rejected_terminal_transition(
        self,
        engine_type: Literal["sync", "async"],
        monkeypatch: pytest.MonkeyPatch,
    ) -> Callable[[BaseException], Awaitable[None]]:
        if engine_type == "sync":

            async def run_sync_engine(exception: BaseException) -> None:
                _reject_terminal_transition(
                    monkeypatch, async_engine=False, exception=exception
                )

                @flow
                def test_flow() -> str:
                    return "done"

                run_flow_sync(test_flow)

            return run_sync_engine

        async def run_async_engine(exception: BaseException) -> None:
            _reject_terminal_transition(
                monkeypatch, async_engine=True, exception=exception
            )

            @flow
            async def test_flow() -> str:
                return "done"

            await run_flow_async(test_flow)

        return run_async_engine

    @pytest.mark.parametrize(
        ("state_type", "raised_exception"),
        [
            (StateType.CANCELLED, None),
            (StateType.CRASHED, KeyboardInterrupt),
        ],
    )
    async def test_reports_nonstandard_authoritative_terminal_state(
        self,
        engine_type: Literal["sync", "async"],
        state_type: StateType,
        raised_exception: type[BaseException] | None,
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
    ):
        flow_run_id: UUID | None = None
        report_engine_outcome = MagicMock(return_value=False)
        monkeypatch.setattr(
            flow_engine_module,
            "report_engine_outcome",
            report_engine_outcome,
        )

        def sync_flow_body() -> Any:
            nonlocal flow_run_id
            flow_run_id = FlowRunContext.get().flow_run.id
            if raised_exception is ValueError:
                raise ValueError("application failure")
            if raised_exception is KeyboardInterrupt:
                raise KeyboardInterrupt()
            if state_type == StateType.CANCELLED:
                return states.Cancelled(data="private result")
            return "completed"

        if engine_type == "sync":
            test_flow = flow(sync_flow_body)
        else:

            @flow
            async def test_flow() -> str:
                return sync_flow_body()

        if state_type == StateType.CANCELLED:
            if engine_type == "sync":
                run_flow_sync(test_flow, return_type="state")
            else:
                await run_flow_async(test_flow, return_type="state")
        elif raised_exception is None:
            if engine_type == "sync":
                assert run_flow_sync(test_flow) == "completed"
            else:
                assert await run_flow_async(test_flow) == "completed"
        else:
            with pytest.raises(raised_exception):
                if engine_type == "sync":
                    run_flow_sync(test_flow)
                else:
                    await run_flow_async(test_flow)

        assert flow_run_id is not None
        flow_run = sync_prefect_client.read_flow_run(flow_run_id)
        assert flow_run.state is not None
        assert flow_run.state.type == state_type
        report_engine_outcome.assert_called_once_with(
            EngineOutcomeReceipt.state_reported(
                state_id=flow_run.state.id,
                state_type=flow_run.state.type.value,
                state_name=flow_run.state.name,
            )
        )

    @pytest.mark.parametrize("state_name", ["", "x" * 257])
    async def test_reports_authoritative_state_name_without_altering_it(
        self,
        engine_type: Literal["sync", "async"],
        state_name: str,
        monkeypatch: pytest.MonkeyPatch,
    ):
        report_engine_outcome = MagicMock(return_value=True)
        monkeypatch.setattr(
            flow_engine_module,
            "report_engine_outcome",
            report_engine_outcome,
        )

        if engine_type == "sync":

            @flow
            def test_flow() -> states.State[str]:
                return states.Completed(name=state_name, data="private result")

            state = run_flow_sync(test_flow, return_type="state")
        else:

            @flow
            async def test_flow() -> states.State[str]:
                return states.Completed(name=state_name, data="private result")

            state = await run_flow_async(test_flow, return_type="state")

        assert isinstance(state, states.State)
        report_engine_outcome.assert_called_once_with(
            EngineOutcomeReceipt.state_reported(
                state_id=state.id,
                state_type=state.type.value,
                state_name=state_name,
            )
        )

    async def test_reports_orchestration_abort_without_state(
        self,
        monkeypatch: pytest.MonkeyPatch,
        run_rejected_terminal_transition: Callable[[BaseException], Awaitable[None]],
    ):
        report_engine_outcome = MagicMock(return_value=True)
        monkeypatch.setattr(
            flow_engine_module,
            "report_engine_outcome",
            report_engine_outcome,
        )

        with pytest.raises(Abort, match="aborted by orchestration"):
            await run_rejected_terminal_transition(Abort("aborted by orchestration"))

        report_engine_outcome.assert_called_once_with(
            EngineOutcomeReceipt.orchestration_aborted()
        )


class TestFlowRunsAsync:
    async def test_basic(self):
        @flow
        async def foo():
            return 42

        result = await run_flow(foo)

        assert result == 42

    async def test_with_params(self):
        @flow
        async def bar(x: int, y: Optional[str] = None):
            return x, y

        parameters = get_call_parameters(bar.fn, (42,), dict(y="nate"))
        result = await run_flow(bar, parameters=parameters)

        assert result == (42, "nate")

    async def test_with_default_pydantic_model_dict_params(
        self, prefect_client: PrefectClient
    ):
        class TheModel(pydantic.BaseModel):
            x: int
            y: str

        @flow
        async def bar(required: str, model: TheModel = {"x": 42, "y": "nate"}):  # type: ignore
            return required, model.x, model.y

        flow_run = await prefect_client.create_flow_run(
            bar, parameters={"required": "hello"}
        )
        result = await run_flow(flow=bar, flow_run=flow_run)
        assert result == ("hello", 42, "nate")

    async def test_with_param_validation(self):
        @flow
        async def bar(x: int):
            return x

        parameters = get_call_parameters(bar.fn, tuple(), dict(x="42"))
        result = await run_flow(bar, parameters=parameters)

        assert result == 42

    async def test_with_param_validation_failure(self):
        @flow
        async def bar(x: int):
            return x

        parameters = get_call_parameters(bar.fn, tuple(), dict(x="FAIL!"))
        state = await run_flow(bar, parameters=parameters, return_type="state")

        assert state.is_failed()
        with pytest.raises(
            ParameterTypeError, match="Flow run received invalid parameters"
        ):
            await state.result()

    async def test_param_validation_failure_sets_start_and_end_time(
        self, sync_prefect_client
    ):
        @flow
        async def bar(x: int):
            return x

        parameters = get_call_parameters(bar.fn, tuple(), dict(x="FAIL!"))
        state = await run_flow(bar, parameters=parameters, return_type="state")

        assert state.is_failed()
        flow_run = sync_prefect_client.read_flow_run(state.state_details.flow_run_id)
        assert flow_run.start_time is not None
        assert flow_run.end_time is not None
        assert flow_run.start_time == flow_run.end_time

    async def test_flow_run_name(self, sync_prefect_client):
        @flow(flow_run_name="name is {x}")
        async def foo(x):
            return FlowRunContext.get().flow_run.id

        result = await run_flow(foo, parameters=dict(x="blue"))
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "name is blue"

    async def test_with_args(self):
        @flow
        async def f(*args):
            return args

        args = (42, "nate")
        result = await f(*args)
        assert result == args

    async def test_with_kwargs(self):
        @flow
        async def f(**kwargs):
            return kwargs

        kwargs = dict(x=42, y="nate")
        result = await f(**kwargs)
        assert result == kwargs

    async def test_with_args_kwargs(self):
        @flow
        async def f(*args, x, **kwargs):
            return args, x, kwargs

        result = await f(1, 2, x=5, y=6, z=7)
        assert result == ((1, 2), 5, dict(y=6, z=7))

    async def test_get_run_logger(self, caplog):
        caplog.set_level(logging.CRITICAL)

        @flow(flow_run_name="test-run")
        async def my_log_flow():
            get_run_logger().critical("hey yall")

        result = await run_flow(my_log_flow)

        assert result is None
        record = next((r for r in caplog.records if r.message == "hey yall"), None)
        assert record is not None, "Couldn't find expected log record"

        assert record.flow_name == "my-log-flow"
        assert record.flow_run_name == "test-run"
        assert UUID(record.flow_run_id)
        assert record.message == "hey yall"
        assert record.levelname == "CRITICAL"

    async def test_flow_ends_in_completed(self, sync_prefect_client):
        @flow
        async def foo():
            return FlowRunContext.get().flow_run.id

        result = await run_flow(foo)
        run = sync_prefect_client.read_flow_run(result)

        assert run.state_type == StateType.COMPLETED

    async def test_flow_ends_in_failed(self, sync_prefect_client):
        ID = None

        @flow
        async def foo():
            nonlocal ID
            ID = FlowRunContext.get().flow_run.id
            raise ValueError("xyz")

        with pytest.raises(ValueError, match="xyz"):
            await run_flow(foo)

        run = sync_prefect_client.read_flow_run(ID)

        assert run.state_type == StateType.FAILED

    def test_subflow_inside_task_tracks_all_parents(
        self, sync_prefect_client: SyncPrefectClient
    ):
        tracker = {}

        @flow
        def flow_3():
            tracker["flow_3"] = FlowRunContext.get().flow_run.id

        @task
        def task_2():
            tracker["task_2"] = TaskRunContext.get().task_run.id
            flow_3()

        @flow
        def flow_1():
            task_2()

        flow_1()

        # retrieve the flow 3 subflow run
        l3 = sync_prefect_client.read_flow_run(tracker["flow_3"])
        # retrieve the dummy task for the flow 3 subflow run
        l3_dummy = sync_prefect_client.read_task_run(l3.parent_task_run_id)

        # assert the parent of the dummy task is task 2
        assert l3_dummy.task_inputs["__parents__"][0].id == tracker["task_2"]

    async def test_with_provided_context(self, prefect_client: PrefectClient):
        tags_context = TagsContext(current_tags={"foo", "bar"})

        @flow
        async def foo():
            return TagsContext.get().current_tags

        context = {"tags_context": tags_context.serialize()}

        result = await run_flow_async(foo, context=context)

        assert result == {"foo", "bar"}


class TestFlowRunsSync:
    async def test_basic(self):
        @flow
        def foo():
            return 42

        result = run_flow_sync(foo)

        assert result == 42

    async def test_with_params(self):
        @flow
        def bar(x: int, y: Optional[str] = None):
            return x, y

        parameters = get_call_parameters(bar.fn, (42,), dict(y="nate"))
        result = run_flow_sync(bar, parameters=parameters)

        assert result == (42, "nate")

    async def test_with_default_pydantic_model_dict_params(
        self, prefect_client: PrefectClient
    ):
        class TheModel(pydantic.BaseModel):
            x: int
            y: str

        @flow
        def bar(required: str, model: TheModel = {"x": 42, "y": "nate"}):  # type: ignore
            return required, model.x, model.y

        flow_run = await prefect_client.create_flow_run(
            bar, parameters={"required": "hello"}
        )
        result = run_flow(flow=bar, flow_run=flow_run)
        assert result == ("hello", 42, "nate")

    async def test_with_param_validation(self):
        @flow
        def bar(x: int):
            return x

        parameters = get_call_parameters(bar.fn, tuple(), dict(x="42"))
        result = run_flow_sync(bar, parameters=parameters)

        assert result == 42

    async def test_with_param_validation_failure(self):
        @flow
        def bar(x: int):
            return x

        parameters = get_call_parameters(bar.fn, tuple(), dict(x="FAIL!"))
        state = run_flow_sync(bar, parameters=parameters, return_type="state")

        assert state.is_failed()
        with pytest.raises(
            ParameterTypeError, match="Flow run received invalid parameters"
        ):
            await state.result()

    async def test_param_validation_failure_sets_start_and_end_time(
        self, sync_prefect_client
    ):
        @flow
        def bar(x: int):
            return x

        parameters = get_call_parameters(bar.fn, tuple(), dict(x="FAIL!"))
        state = run_flow_sync(bar, parameters=parameters, return_type="state")

        assert state.is_failed()
        flow_run = sync_prefect_client.read_flow_run(state.state_details.flow_run_id)
        assert flow_run.start_time is not None
        assert flow_run.end_time is not None
        assert flow_run.start_time == flow_run.end_time

    async def test_flow_run_name(self, sync_prefect_client):
        @flow(flow_run_name="name is {x}")
        def foo(x):
            return FlowRunContext.get().flow_run.id

        result = run_flow_sync(foo, parameters=dict(x="blue"))
        run = sync_prefect_client.read_flow_run(result)

        assert run.name == "name is blue"

    def test_with_args(self):
        @flow
        def f(*args):
            return args

        args = (42, "nate")
        result = f(*args)
        assert result == args

    def test_with_kwargs(self):
        @flow
        def f(**kwargs):
            return kwargs

        kwargs = dict(x=42, y="nate")
        result = f(**kwargs)
        assert result == kwargs

    def test_with_args_kwargs(self):
        @flow
        def f(*args, x, **kwargs):
            return args, x, kwargs

        result = f(1, 2, x=5, y=6, z=7)
        assert result == ((1, 2), 5, dict(y=6, z=7))

    async def test_get_run_logger(self, caplog):
        caplog.set_level(logging.CRITICAL)

        @flow(flow_run_name="test-run")
        def my_log_flow():
            get_run_logger().critical("hey yall")

        result = run_flow_sync(my_log_flow)

        assert result is None
        record = next((r for r in caplog.records if r.message == "hey yall"), None)
        assert record is not None, "Couldn't find expected log record"

        assert record.flow_name == "my-log-flow"
        assert record.flow_run_name == "test-run"
        assert UUID(record.flow_run_id)
        assert record.message == "hey yall"
        assert record.levelname == "CRITICAL"

    async def test_flow_ends_in_completed(self, sync_prefect_client):
        @flow
        def foo():
            return FlowRunContext.get().flow_run.id

        result = run_flow_sync(foo)
        run = sync_prefect_client.read_flow_run(result)

        assert run.state_type == StateType.COMPLETED

    async def test_flow_ends_in_failed(self, sync_prefect_client):
        ID = None

        @flow
        def foo():
            nonlocal ID
            ID = FlowRunContext.get().flow_run.id
            raise ValueError("xyz")

        with pytest.raises(ValueError, match="xyz"):
            run_flow_sync(foo)

        run = sync_prefect_client.read_flow_run(ID)

        assert run.state_type == StateType.FAILED

    async def test_failed_subflow_does_not_report_child_attempt_outcome(
        self,
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
    ):
        child_flow_run_id: UUID | None = None
        parent_flow_run_id: UUID | None = None
        report_engine_outcome = MagicMock(return_value=True)
        monkeypatch.setattr(
            flow_engine_module,
            "report_engine_outcome",
            report_engine_outcome,
        )

        @flow
        def child():
            nonlocal child_flow_run_id
            child_flow_run_id = FlowRunContext.get().flow_run.id
            raise ValueError("child failure")

        @flow
        def parent():
            nonlocal parent_flow_run_id
            parent_flow_run_id = FlowRunContext.get().flow_run.id
            with pytest.raises(ValueError, match="child failure"):
                child()

        run_flow_sync(parent)

        assert child_flow_run_id is not None
        assert parent_flow_run_id is not None
        child_flow_run = sync_prefect_client.read_flow_run(child_flow_run_id)
        parent_flow_run = sync_prefect_client.read_flow_run(parent_flow_run_id)
        assert child_flow_run.state is not None
        assert child_flow_run.state.is_failed()
        assert parent_flow_run.state is not None
        assert parent_flow_run.state.is_completed()
        report_engine_outcome.assert_called_once_with(
            EngineOutcomeReceipt.state_reported(
                state_id=parent_flow_run.state.id,
                state_type=parent_flow_run.state.type.value,
                state_name=parent_flow_run.state.name,
            )
        )

    async def test_with_provided_context(self, prefect_client: PrefectClient):
        tags_context = TagsContext(current_tags={"foo", "bar"})

        @flow
        def foo():
            return TagsContext.get().current_tags

        context = {"tags_context": tags_context.serialize()}

        result = run_flow_sync(foo, context=context)

        assert result == {"foo", "bar"}


class TestFlowRetries:
    async def test_flow_retry_with_error_in_flow(self):
        run_count = 0

        @flow(retries=1)
        async def foo():
            nonlocal run_count
            run_count += 1
            if run_count == 1:
                raise ValueError()
            return "hello"

        assert await foo() == "hello"
        assert run_count == 2

    async def test_flow_retry_with_error_in_flow_sync(self):
        run_count = 0

        @flow(retries=1)
        def foo():
            nonlocal run_count
            run_count += 1
            if run_count == 1:
                raise ValueError()
            return "hello"

        assert foo() == "hello"
        assert run_count == 2

    async def test_flow_retry_with_error_in_flow_and_successful_task(self):
        task_run_count = 0
        flow_run_count = 0

        @task(persist_result=True)
        async def my_task():
            nonlocal task_run_count
            task_run_count += 1
            return "hello"

        @flow(retries=1, persist_result=True)
        async def foo():
            nonlocal flow_run_count
            flow_run_count += 1

            state = await my_task(return_state=True)

            if flow_run_count == 1:
                raise ValueError()

            return await state.result()

        assert await foo() == "hello"
        assert flow_run_count == 2
        assert task_run_count == 1

    def test_flow_retry_with_no_error_in_flow_and_one_failed_task(self):
        task_run_count = 0
        flow_run_count = 0

        @task
        def my_task():
            nonlocal task_run_count
            task_run_count += 1

            # Fail on the first flow run but not the retry
            if flow_run_count == 1:
                raise ValueError()

            return "hello"

        @flow(retries=1)
        def foo():
            nonlocal flow_run_count
            flow_run_count += 1
            return my_task()

        assert foo() == "hello"
        assert flow_run_count == 2
        assert task_run_count == 2, "Task should be reset and run again"

    def test_flow_retry_with_error_in_flow_and_one_failed_task(self):
        task_run_count = 0
        flow_run_count = 0

        @task
        def my_task():
            nonlocal task_run_count
            task_run_count += 1

            # Fail on the first flow run but not the retry
            if flow_run_count == 1:
                raise ValueError()

            return "hello"

        @flow(retries=1)
        def my_flow():
            nonlocal flow_run_count
            flow_run_count += 1

            fut = my_task()

            # It is important that the flow run fails after the task run is created
            if flow_run_count == 1:
                raise ValueError()

            return fut

        assert my_flow() == "hello"
        assert flow_run_count == 2
        assert task_run_count == 2, "Task should be reset and run again"

    @pytest.mark.xfail
    async def test_flow_retry_with_branched_tasks(self, sync_prefect_client):
        flow_run_count = 0

        @task
        def identity(value):
            return value

        @flow(retries=1)
        def my_flow():
            nonlocal flow_run_count
            flow_run_count += 1

            # Raise on the first run but use 'foo'
            if flow_run_count == 1:
                identity("foo")
                raise ValueError()
            else:
                # On the second run, switch to 'bar'
                result = identity("bar")

            return result

        my_flow()

        assert flow_run_count == 2

        # The state is pulled from the API and needs to be decoded
        document = await (await my_flow().result()).result()
        result = sync_prefect_client.retrieve_data(document)

        assert result == "bar"
        # AssertionError: assert 'foo' == 'bar'
        # Wait, what? Because tasks are identified by dynamic key which is a simple
        # increment each time the task is called, if there branching is different
        # after a flow run retry, the stale value will be pulled from the cache.

    async def test_flow_retry_with_no_error_in_flow_and_one_failed_child_flow(
        self, sync_prefect_client
    ):
        child_run_count = 0
        flow_run_count = 0

        @flow
        async def child_flow():
            nonlocal child_run_count
            child_run_count += 1

            # Fail on the first flow run but not the retry
            if flow_run_count == 1:
                raise ValueError()

            return "hello"

        @flow(retries=1)
        async def parent_flow():
            nonlocal flow_run_count
            flow_run_count += 1
            return await child_flow()

        state = await parent_flow(return_state=True)
        assert await state.result() == "hello"
        assert flow_run_count == 2
        assert child_run_count == 2, "Child flow should be reset and run again"
        # Ensure that the tracking task run for the subflow is reset and tracked
        task_runs = sync_prefect_client.read_task_runs(
            flow_run_filter=FlowRunFilter(
                id={"any_": [state.state_details.flow_run_id]}
            )
        )
        state_types = {task_run.state_type for task_run in task_runs}
        assert state_types == {StateType.COMPLETED}

        # There should only be the child flow run's task
        assert len(task_runs) == 1

    async def test_flow_retry_with_error_in_flow_and_one_successful_child_flow(self):
        child_run_count = 0
        flow_run_count = 0

        @flow(persist_result=True)
        async def child_flow():
            nonlocal child_run_count
            child_run_count += 1
            return "hello"

        @flow(retries=1, persist_result=True)
        async def parent_flow():
            nonlocal flow_run_count
            flow_run_count += 1
            child_result = await child_flow()

            # Fail on the first flow run but not the retry
            if flow_run_count == 1:
                raise ValueError()

            return child_result

        assert await parent_flow() == "hello"
        assert flow_run_count == 2
        assert child_run_count == 1, "Child flow should not run again"

    async def test_flow_retry_with_error_in_flow_and_one_failed_child_flow(
        self, sync_prefect_client: SyncPrefectClient
    ):
        child_flow_run_count = 0
        flow_run_count = 0
        child_flow_name = f"child-flow-{uuid.uuid4()}"

        @flow(name=child_flow_name)
        def child_flow():
            nonlocal child_flow_run_count
            child_flow_run_count += 1

            # Fail on the first flow run but not the retry
            if flow_run_count == 1:
                raise ValueError()

            return "hello"

        @flow(retries=1)
        def parent_flow():
            nonlocal flow_run_count
            flow_run_count += 1

            state = child_flow(return_state=True)

            # It is important that the flow run fails after the child flow run is created
            if flow_run_count == 1:
                raise ValueError()

            return state

        parent_state = parent_flow(return_state=True)
        child_state = await parent_state.result()
        assert await child_state.result() == "hello"
        assert flow_run_count == 2
        assert child_flow_run_count == 2, "Child flow should run again"

        child_flow_run = sync_prefect_client.read_flow_run(
            child_state.state_details.flow_run_id
        )
        child_flow_runs = sync_prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[child_flow_name])),
            sort=FlowRunSort.EXPECTED_START_TIME_ASC,
        )

        assert len(child_flow_runs) == 2

        # The original flow run has its failed state preserved
        assert child_flow_runs[0].state.is_failed()

        # The final flow run is the one returned by the parent flow
        assert child_flow_runs[-1] == child_flow_run

    async def test_flow_retry_with_failed_child_flow_with_failed_task(self):
        child_task_run_count = 0
        child_flow_run_count = 0
        flow_run_count = 0

        @task
        async def child_task():
            nonlocal child_task_run_count
            child_task_run_count += 1

            # Fail on the first task run but not the retry
            if child_task_run_count == 1:
                raise ValueError()

            return "hello"

        @flow
        async def child_flow():
            nonlocal child_flow_run_count
            child_flow_run_count += 1
            return await child_task()

        @flow(retries=1)
        async def parent_flow():
            nonlocal flow_run_count
            flow_run_count += 1

            state = await child_flow()

            return state

        assert await parent_flow() == "hello"
        assert flow_run_count == 2
        assert child_flow_run_count == 2, "Child flow should run again"
        assert child_task_run_count == 2, "Child tasks should run again with child flow"

    def test_flow_retry_with_error_in_flow_and_one_failed_task_with_retries(self):
        task_run_retry_count = 0
        task_run_count = 0
        flow_run_count = 0

        @task(retries=1)
        def my_task():
            nonlocal task_run_count, task_run_retry_count
            task_run_count += 1
            task_run_retry_count += 1

            # Always fail on the first flow run
            if flow_run_count == 1:
                raise ValueError("Fail on first flow run")

            # Only fail the first time this task is called within a given flow run
            # This ensures that we will always retry this task so we can ensure
            # retry logic is preserved
            if task_run_retry_count == 1:
                raise ValueError("Fail on first task run")

            return "hello"

        @flow(retries=1)
        def foo():
            nonlocal flow_run_count, task_run_retry_count
            task_run_retry_count = 0
            flow_run_count += 1

            fut = my_task()

            # It is important that the flow run fails after the task run is created
            if flow_run_count == 1:
                raise ValueError()

            return fut

        assert foo() == "hello"
        assert flow_run_count == 2
        assert task_run_count == 4, "Task should use all of its retries every time"

    async def test_flow_retry_with_error_in_flow_and_one_failed_task_with_retries_cannot_exceed_retries(
        self,
    ):
        task_run_count = 0
        flow_run_count = 0

        @task(retries=2)
        async def my_task():
            nonlocal task_run_count
            task_run_count += 1
            raise ValueError("This task always fails")

        @flow(retries=1)
        async def my_flow():
            nonlocal flow_run_count
            flow_run_count += 1

            fut = await my_task()

            # It is important that the flow run fails after the task run is created
            if flow_run_count == 1:
                raise ValueError()

            return fut

        with pytest.raises(ValueError, match="This task always fails"):
            fut = await my_flow()
            flow_result = await fut.result()
            await flow_result.result()

        assert flow_run_count == 2
        assert task_run_count == 6, "Task should use all of its retries every time"

    async def test_flow_with_failed_child_flow_with_retries(self):
        child_flow_run_count = 0
        flow_run_count = 0

        @flow(retries=1)
        def child_flow():
            nonlocal child_flow_run_count
            child_flow_run_count += 1

            # Fail on first try.
            if child_flow_run_count == 1:
                raise ValueError()

            return "hello"

        @flow
        def parent_flow():
            nonlocal flow_run_count
            flow_run_count += 1

            state = child_flow()

            return state

        assert parent_flow() == "hello"
        assert flow_run_count == 1, "Parent flow should only run once"
        assert child_flow_run_count == 2, "Child flow should run again"

    async def test_parent_flow_retries_failed_child_flow_with_retries(self):
        child_flow_retry_count = 0
        child_flow_run_count = 0
        flow_run_count = 0

        @flow(retries=1)
        def child_flow():
            nonlocal child_flow_run_count, child_flow_retry_count
            child_flow_run_count += 1
            child_flow_retry_count += 1

            # Fail during first parent flow run, but not on parent retry.
            if flow_run_count == 1:
                raise ValueError()

            # Fail on first try after parent retry.
            if child_flow_retry_count == 1:
                raise ValueError()

            return "hello"

        @flow(retries=1)
        def parent_flow():
            nonlocal flow_run_count, child_flow_retry_count
            child_flow_retry_count = 0
            flow_run_count += 1

            state = child_flow()

            return state

        assert parent_flow() == "hello"
        assert flow_run_count == 2, "Parent flow should exhaust retries"
        assert child_flow_run_count == 4, (
            "Child flow should run 2 times for each parent run"
        )


class TestLoadSubflowRun:
    """Tests for load_subflow_run reattach behavior to prevent duplicate
    subflow runs when a process is re-executed (e.g. K8s pod restart)."""

    async def test_sync_reattaches_to_existing_subflow_when_parent_task_run_is_running(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """When the parent_task_run is still Running (non-final), load_subflow_run
        should find and return the existing subflow run instead of returning None,
        which would cause a duplicate to be created."""
        child_flow_run_ids: list[UUID] = []

        @flow
        def child():
            child_flow_run_ids.append(FlowRunContext.get().flow_run.id)

        @flow
        def parent():
            child()

        # Run the parent flow normally; this creates the child subflow run
        parent()

        assert len(child_flow_run_ids) == 1
        first_child_id = child_flow_run_ids[0]

        # Look up the child flow run and its parent_task_run
        child_run = sync_prefect_client.read_flow_run(first_child_id)
        assert child_run.parent_task_run_id is not None
        parent_task_run = sync_prefect_client.read_task_run(
            child_run.parent_task_run_id
        )

        # Simulate the pod-restart scenario: set the parent_task_run to Running
        # (as if the orphaned subflow's Running state was synced back via
        # UpdateSubflowParentTaskRun before the process died)
        sync_prefect_client.set_task_run_state(
            parent_task_run.id, Running(), force=True
        )
        parent_task_run = sync_prefect_client.read_task_run(parent_task_run.id)
        assert parent_task_run.state.is_running()

        # Now simulate what the engine does on re-execution: call
        # load_subflow_run with the Running parent_task_run
        parent_run = sync_prefect_client.read_flow_run(parent_task_run.flow_run_id)
        engine = FlowRunEngine(flow=child, flow_run=None)
        context = FlowRunContext(
            flow=parent,
            flow_run=parent_run,
            client=sync_prefect_client,
            task_runner=parent.task_runner,
            result_store=get_result_store(),
        )
        result = engine.load_subflow_run(
            parent_task_run=parent_task_run,
            client=sync_prefect_client,
            context=context,
        )

        assert result is not None, (
            "load_subflow_run should reattach to the existing subflow run"
        )
        assert result.id == first_child_id

    async def test_async_reattaches_to_existing_subflow_when_parent_task_run_is_running(
        self, prefect_client: PrefectClient
    ):
        """Async variant: same reattach behavior for AsyncFlowRunEngine."""
        child_flow_run_ids: list[UUID] = []

        @flow
        async def child():
            child_flow_run_ids.append(FlowRunContext.get().flow_run.id)

        @flow
        async def parent():
            await child()

        await parent()

        assert len(child_flow_run_ids) == 1
        first_child_id = child_flow_run_ids[0]

        child_run = await prefect_client.read_flow_run(first_child_id)
        assert child_run.parent_task_run_id is not None
        parent_task_run = await prefect_client.read_task_run(
            child_run.parent_task_run_id
        )

        await prefect_client.set_task_run_state(
            parent_task_run.id, Running(), force=True
        )
        parent_task_run = await prefect_client.read_task_run(parent_task_run.id)
        assert parent_task_run.state.is_running()

        parent_run = await prefect_client.read_flow_run(parent_task_run.flow_run_id)
        engine = AsyncFlowRunEngine(flow=child, flow_run=None)
        context = FlowRunContext(
            flow=parent,
            flow_run=parent_run,
            client=prefect_client,
            task_runner=parent.task_runner,
            result_store=get_result_store(),
        )
        result = await engine.load_subflow_run(
            parent_task_run=parent_task_run,
            client=prefect_client,
            context=context,
        )

        assert result is not None, (
            "load_subflow_run should reattach to the existing subflow run"
        )
        assert result.id == first_child_id

    async def test_does_not_set_return_value_when_reattaching_to_nonfinal_subflow(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """When reattaching to a non-final subflow run, _return_value should
        NOT be set so the engine re-executes the flow code."""
        child_flow_run_id: UUID | None = None

        @flow
        def child():
            nonlocal child_flow_run_id
            child_flow_run_id = FlowRunContext.get().flow_run.id

        @flow
        def parent():
            child()

        parent()

        assert child_flow_run_id is not None
        child_run = sync_prefect_client.read_flow_run(child_flow_run_id)
        assert child_run.parent_task_run_id is not None

        parent_task_run = sync_prefect_client.read_task_run(
            child_run.parent_task_run_id
        )

        # Force parent_task_run to Running
        sync_prefect_client.set_task_run_state(
            parent_task_run.id, Running(), force=True
        )
        parent_task_run = sync_prefect_client.read_task_run(parent_task_run.id)

        parent_run = sync_prefect_client.read_flow_run(parent_task_run.flow_run_id)
        engine = FlowRunEngine(flow=child, flow_run=None)
        context = FlowRunContext(
            flow=parent,
            flow_run=parent_run,
            client=sync_prefect_client,
            task_runner=parent.task_runner,
            result_store=get_result_store(),
        )
        result = engine.load_subflow_run(
            parent_task_run=parent_task_run,
            client=sync_prefect_client,
            context=context,
        )

        assert result is not None
        assert engine._return_value is NotSet, (
            "_return_value should not be set for non-final parent task runs"
        )

    async def test_returns_none_when_no_existing_subflow_run(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """When there is no existing subflow run, load_subflow_run should
        return None regardless of parent_task_run state."""
        parent_flow_run_id: UUID | None = None

        @flow
        def child():
            pass

        @flow
        def parent():
            nonlocal parent_flow_run_id
            parent_flow_run_id = FlowRunContext.get().flow_run.id

        parent()

        assert parent_flow_run_id is not None
        parent_run = sync_prefect_client.read_flow_run(parent_flow_run_id)

        # Use a mock task run with a UUID that has no matching subflow runs
        mock_task_run = MagicMock()
        mock_task_run.id = uuid.uuid4()
        mock_task_run.state = Running()

        engine = FlowRunEngine(flow=child, flow_run=None)
        context = FlowRunContext(
            flow=parent,
            flow_run=parent_run,
            client=sync_prefect_client,
            task_runner=parent.task_runner,
            result_store=get_result_store(),
        )
        result = engine.load_subflow_run(
            parent_task_run=mock_task_run,
            client=sync_prefect_client,
            context=context,
        )

        assert result is None

    async def test_sets_return_value_when_parent_task_run_is_final(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """When parent_task_run is final, _return_value should be set
        to cache the result (existing behavior preserved)."""
        child_flow_run_id: UUID | None = None

        @flow
        def child():
            nonlocal child_flow_run_id
            child_flow_run_id = FlowRunContext.get().flow_run.id
            return 42

        @flow
        def parent():
            return child()

        parent()

        assert child_flow_run_id is not None
        child_run = sync_prefect_client.read_flow_run(child_flow_run_id)
        assert child_run.parent_task_run_id is not None

        parent_task_run = sync_prefect_client.read_task_run(
            child_run.parent_task_run_id
        )
        # After normal completion, parent_task_run should be final
        assert parent_task_run.state.is_final()

        parent_run = sync_prefect_client.read_flow_run(parent_task_run.flow_run_id)
        engine = FlowRunEngine(flow=child, flow_run=None)
        context = FlowRunContext(
            flow=parent,
            flow_run=parent_run,
            client=sync_prefect_client,
            task_runner=parent.task_runner,
            result_store=get_result_store(),
        )
        result = engine.load_subflow_run(
            parent_task_run=parent_task_run,
            client=sync_prefect_client,
            context=context,
        )

        assert result is not None
        assert result.id == child_run.id
        assert engine._return_value is not NotSet, (
            "_return_value should be set for final parent task runs"
        )


class TestSubflowDynamicKeyRace:
    """Regression tests for concurrent subflow calls adopting the wrong
    persisted result on parent flow retry (OSS-8038 / #22259).

    When subflows are called from within submitted tasks, the tracking
    task run now uses UUID dynamic keys so that on retry, a re-executed
    subflow call cannot match a different subflow's completed task run.
    """

    async def test_concurrent_subflow_retry_returns_correct_result(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """Regression test for #22259: on attempt 2 of a parent flow,
        an uncached wrapper task re-executes and calls its child subflow.
        Without the fix, the child's tracking task run adopts a sibling's
        completed tracking task run (due to positional dynamic_key
        collision) and silently returns the wrong persisted result.

        Shape:
        - Attempt 1: chunk-1, chunk-2, chunk-3 complete; chunk-0 fails
          *before* calling child, so siblings occupy counter keys first.
        - Attempt 2: chunk-1..3 are served from INPUTS cache; chunk-0
          re-executes and must create/run its own child flow run.
        - Assert the final result for chunk-0 is correct and that the
          child flow actually executed for chunk-0 on the second attempt.
        """
        # per-test nonce avoids cache pollution across test runs
        nonce = uuid.uuid4().hex[:8]
        child_executions: list[str] = []
        attempt = 0

        @flow(persist_result=True)
        def child(chunk: str, nonce: str) -> str:
            child_executions.append(chunk)
            return f"result-for-{chunk}"

        @task(persist_result=True, cache_policy=INPUTS)
        def run_chunk(chunk: str, nonce: str) -> str:
            # On attempt 1, chunk-0 fails before calling child so it
            # never caches.  Siblings complete and their subflows occupy
            # counter-based tracking task keys.
            if chunk == "chunk-0" and attempt == 1:
                raise ValueError(f"{chunk} fails on first attempt")
            return child(chunk, nonce)

        @flow(retries=1, persist_result=True)
        def parent():
            nonlocal attempt
            attempt += 1

            # Submit chunk-1..3 first so their subflows complete and
            # occupy counter-based tracking task keys on attempt 1,
            # then submit chunk-0 which will fail.
            order = ["chunk-1", "chunk-2", "chunk-3", "chunk-0"]
            futures = {name: run_chunk.submit(name, nonce) for name in order}
            return {name: f.result() for name, f in futures.items()}

        final = parent()

        assert attempt == 2
        # chunk-0 must have its own correct result, not an adopted sibling's
        for name in ["chunk-0", "chunk-1", "chunk-2", "chunk-3"]:
            assert final[name] == f"result-for-{name}", (
                f"{name} got wrong result: {final[name]}"
            )
        # The child flow must have actually executed for chunk-0
        assert "chunk-0" in child_executions, (
            "child flow never executed for chunk-0 on retry"
        )

    async def test_async_subflow_from_task_uses_uuid_dynamic_key(
        self, prefect_client: PrefectClient
    ):
        """Async path: subflow tracking task runs called from within a
        task context get UUID dynamic keys (mirrors sync behaviour)."""
        child_flow_run_ids: list[UUID] = []

        @flow
        async def child(x: int) -> int:
            child_flow_run_ids.append(FlowRunContext.get().flow_run.id)
            return x

        @task
        async def run_child(x: int) -> int:
            return await child(x)

        @flow
        async def parent():
            return await run_child(1)

        await parent()

        assert len(child_flow_run_ids) == 1
        child_run = await prefect_client.read_flow_run(child_flow_run_ids[0])
        assert child_run.parent_task_run_id is not None
        task_run = await prefect_client.read_task_run(child_run.parent_task_run_id)
        assert len(task_run.dynamic_key) > 8, (
            f"Expected UUID dynamic key, got: {task_run.dynamic_key}"
        )

    async def test_direct_subflow_keeps_stable_key_for_retry_optimisation(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """Direct subflow calls (no task context) keep stable sequential
        keys so the retry optimisation (reuse completed subflow result)
        still works."""
        child_flow_run_ids: list[UUID] = []

        @flow
        def child() -> str:
            child_flow_run_ids.append(FlowRunContext.get().flow_run.id)
            return "hello"

        @flow
        def parent():
            child()

        parent()

        child_run = sync_prefect_client.read_flow_run(child_flow_run_ids[0])
        assert child_run.parent_task_run_id is not None
        task_run = sync_prefect_client.read_task_run(child_run.parent_task_run_id)
        assert task_run.dynamic_key == "0", (
            f"Expected stable key '0', got: {task_run.dynamic_key}"
        )

    async def test_nested_direct_subflow_from_task_keeps_stable_key(
        self, sync_prefect_client: SyncPrefectClient
    ):
        """A direct nested subflow should keep stable tracking identity even
        when its parent flow was called from a task context."""
        grandchild_flow_run_ids: list[UUID] = []
        child_attempt = 0

        @flow(persist_result=True)
        def grandchild() -> str:
            grandchild_flow_run_ids.append(FlowRunContext.get().flow_run.id)
            return "hello"

        @flow(retries=1, persist_result=True)
        def child() -> str:
            nonlocal child_attempt
            child_attempt += 1
            result = grandchild()
            if child_attempt == 1:
                raise ValueError("child fails after grandchild")
            return result

        @task
        def run_child() -> str:
            return child()

        @flow
        def parent() -> str:
            return run_child()

        assert parent() == "hello"

        assert child_attempt == 2
        assert len(set(grandchild_flow_run_ids)) == 1
        grandchild_run = sync_prefect_client.read_flow_run(grandchild_flow_run_ids[0])
        assert grandchild_run.parent_task_run_id is not None
        task_run = sync_prefect_client.read_task_run(grandchild_run.parent_task_run_id)
        assert task_run.dynamic_key == "0", (
            f"Expected stable key '0', got: {task_run.dynamic_key}"
        )


class TestFlowCrashDetection:
    @pytest.mark.parametrize("interrupt_type", [KeyboardInterrupt, SystemExit])
    async def test_interrupt_in_flow_function_crashes_flow(
        self, prefect_client, interrupt_type
    ):
        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        async def my_flow():
            raise interrupt_type()

        with pytest.raises(interrupt_type):
            await my_flow()

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        assert flow_run.state.is_crashed()
        assert flow_run.state.type == StateType.CRASHED
        assert "Execution was aborted" in flow_run.state.message
        with pytest.raises(CrashedRun, match="Execution was aborted"):
            await flow_run.state.result()

    @pytest.mark.parametrize("interrupt_type", [KeyboardInterrupt, SystemExit])
    async def test_interrupt_in_flow_function_crashes_flow_sync(
        self, prefect_client, interrupt_type
    ):
        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        def my_flow():
            raise interrupt_type()

        with pytest.raises(interrupt_type):
            my_flow()

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        assert flow_run.state.is_crashed()
        assert flow_run.state.type == StateType.CRASHED
        assert "Execution was aborted" in flow_run.state.message
        with pytest.raises(CrashedRun, match="Execution was aborted"):
            await flow_run.state.result()

    @pytest.mark.parametrize("interrupt_type", [KeyboardInterrupt, SystemExit])
    async def test_interrupt_in_flow_orchestration_crashes_flow(
        self, prefect_client, interrupt_type, monkeypatch
    ):
        monkeypatch.setattr(
            FlowRunEngine, "begin_run", MagicMock(side_effect=interrupt_type)
        )

        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        def my_flow():
            pass

        with pytest.raises(interrupt_type):
            my_flow()

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        assert flow_run.state.is_crashed()
        assert flow_run.state.type == StateType.CRASHED
        assert "Execution was aborted" in flow_run.state.message
        with pytest.raises(CrashedRun, match="Execution was aborted"):
            await flow_run.state.result()

    async def test_base_exception_after_user_code_finishes_does_not_crash_sync(
        self, prefect_client, monkeypatch, caplog
    ):
        """
        Test that a BaseException raised after user code finishes executing
        does not crash the flow run (sync flow).
        """
        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        def my_flow():
            return 42

        # Mock the flow run engine to raise a BaseException after handle_success
        original_handle_success = FlowRunEngine.handle_success

        def handle_success_with_exception(self, result):
            original_handle_success(self, result)
            # At this point the flow run state is final (Completed)
            raise BaseException("Post-execution error")

        monkeypatch.setattr(
            FlowRunEngine, "handle_success", handle_success_with_exception
        )

        # The flow should complete successfully and return the result
        result = my_flow()
        assert result == 42

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        # The flow run should be completed, not crashed
        assert flow_run.state.is_completed()
        assert not flow_run.state.is_crashed()
        # Verify the debug log message was recorded
        assert (
            "BaseException was raised after user code finished executing" in caplog.text
        )

    async def test_base_exception_after_user_code_finishes_does_not_crash_async(
        self, prefect_client, monkeypatch, caplog
    ):
        """
        Test that a BaseException raised after user code finishes executing
        does not crash the flow run (async flow).
        """
        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        async def my_flow():
            return 42

        # Mock the flow run engine to raise a BaseException after handle_success
        original_handle_success = AsyncFlowRunEngine.handle_success

        async def handle_success_with_exception(self, result):
            await original_handle_success(self, result)
            # At this point the flow run state is final (Completed)
            raise BaseException("Post-execution error")

        monkeypatch.setattr(
            AsyncFlowRunEngine, "handle_success", handle_success_with_exception
        )

        # The flow should complete successfully and return the result
        result = await my_flow()
        assert result == 42

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        # The flow run should be completed, not crashed
        assert flow_run.state.is_completed()
        assert not flow_run.state.is_crashed()
        # Verify the debug log message was recorded
        assert (
            "BaseException was raised after user code finished executing" in caplog.text
        )

    async def test_base_exception_before_user_code_finishes_crashes_sync(
        self, prefect_client, monkeypatch
    ):
        """
        Test that a BaseException raised before user code finishes executing
        still crashes the flow run (sync flow).
        """
        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        def my_flow():
            return 42

        # Mock the flow run engine to raise a BaseException during begin_run
        monkeypatch.setattr(
            FlowRunEngine,
            "begin_run",
            MagicMock(side_effect=BaseException("Pre-execution error")),
        )

        with pytest.raises(BaseException, match="Pre-execution error"):
            my_flow()

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        # The flow run should be crashed
        assert flow_run.state.is_crashed()

    async def test_base_exception_before_user_code_finishes_crashes_async(
        self, prefect_client, monkeypatch
    ):
        """
        Test that a BaseException raised before user code finishes executing
        still crashes the flow run (async flow).
        """
        flow_name = f"my-flow-{uuid.uuid4()}"

        @flow(name=flow_name)
        async def my_flow():
            return 42

        # Mock the flow run engine to raise a BaseException during begin_run
        async def begin_run_with_exception(self):
            raise BaseException("Pre-execution error")

        monkeypatch.setattr(AsyncFlowRunEngine, "begin_run", begin_run_with_exception)

        with pytest.raises(BaseException, match="Pre-execution error"):
            await my_flow()

        flow_runs = await prefect_client.read_flow_runs(
            flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
        )
        assert len(flow_runs) == 1
        flow_run = flow_runs[0]
        # The flow run should be crashed
        assert flow_run.state.is_crashed()

    async def test_async_runtime_cancellation_with_control_intent_routes_to_handle_cancellation(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        @flow
        async def my_flow():
            return 42

        engine = AsyncFlowRunEngine(flow=my_flow)
        engine.handle_cancellation = AsyncMock()
        engine.handle_crash = AsyncMock()

        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: "cancel"
        )
        monkeypatch.setattr("prefect.flow_engine.get_intent", lambda: "cancel")

        with pytest.raises(TerminationSignal) as exc_info:
            async with engine.initialize_run():
                await engine.begin_run()
                raise asyncio.CancelledError()

        assert isinstance(exc_info.value.__cause__, asyncio.CancelledError)
        engine.handle_cancellation.assert_awaited_once()
        engine.handle_crash.assert_not_awaited()


class TestRunFlowBaseExceptionErrorLogger:
    """Regression tests for explicit BaseException logging in run_flow().

    These verify that when a BaseException (e.g. KeyboardInterrupt, SystemExit)
    is raised before setup_run_context() installs the flow-run-scoped logger,
    the error_logger passed to run_flow() still records the interrupt.
    """

    def test_sync_base_exception_logs_via_error_logger(self, prefect_client):
        @flow
        def my_flow():
            pass

        error_logger = MagicMock()

        with mock.patch.object(
            FlowRunEngine, "begin_run", side_effect=KeyboardInterrupt
        ):
            with pytest.raises(KeyboardInterrupt):
                run_flow(my_flow, error_logger=error_logger)

        error_logger.error.assert_called_once_with(
            "Engine execution interrupted by base exception", exc_info=True
        )

    async def test_async_base_exception_logs_via_error_logger(self, prefect_client):
        @flow
        async def my_flow():
            pass

        error_logger = MagicMock()

        # Patch _flow_parameters so the SystemExit fires in the synchronous
        # body of run_flow() — before the async coroutine is returned.
        with mock.patch("prefect.flow_engine._flow_parameters", side_effect=SystemExit):
            with pytest.raises(SystemExit):
                run_flow(my_flow, error_logger=error_logger)

        error_logger.error.assert_called_once_with(
            "Engine execution interrupted by base exception", exc_info=True
        )

    def test_control_termination_does_not_log_generic_base_exception(
        self, prefect_client, monkeypatch: pytest.MonkeyPatch
    ):
        @flow
        def my_flow():
            pass

        error_logger = MagicMock()

        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: "cancel"
        )
        monkeypatch.setattr("prefect.flow_engine.get_intent", lambda: "cancel")

        with mock.patch.object(
            FlowRunEngine,
            "begin_run",
            side_effect=TerminationSignal(signal=signal.SIGTERM),
        ):
            with pytest.raises(TerminationSignal):
                run_flow(my_flow, error_logger=error_logger)

        error_logger.error.assert_not_called()


class TestHandleEngineSignals:
    @pytest.mark.parametrize("intent", ["cancel", "reschedule", "relinquish"])
    def test_intent_exits_zero_on_termination_signal(
        self, intent: str, monkeypatch: pytest.MonkeyPatch
    ):
        """Any intent means someone else owns the run's state, so the engine exits
        cleanly instead of letting a non-zero code imply a crash."""
        clear_intent = MagicMock()
        monkeypatch.setattr("prefect.engine.get_intent", lambda: intent)
        monkeypatch.setattr("prefect.engine.clear_intent", clear_intent)

        with pytest.raises(SystemExit) as exc:
            with handle_engine_signals(uuid.uuid4()):
                raise TerminationSignal(signal=signal.SIGTERM)

        assert exc.value.code == 0
        clear_intent.assert_called_once_with()

    def test_raw_termination_signal_still_bubbles_without_intent(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setattr("prefect.engine.get_intent", lambda: None)
        monkeypatch.setattr("prefect.engine.engine_outcome_is_handled", lambda: False)

        with pytest.raises(TerminationSignal):
            with handle_engine_signals(uuid.uuid4()):
                raise TerminationSignal(signal=signal.SIGTERM)

    def test_handled_engine_outcome_exits_zero_on_exception(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setattr("prefect.engine.engine_outcome_is_handled", lambda: True)

        with pytest.raises(SystemExit) as exc:
            with handle_engine_signals(uuid.uuid4()):
                raise ValueError("application failure")

        assert exc.value.code == 0


class TestDriveRunFlowResult:
    def test_consumes_coroutines(self):
        seen: list[str] = []

        async def _coro() -> None:
            seen.append("ran")

        _drive_run_flow_result(
            SimpleNamespace(isasync=True, isgenerator=False), _coro()
        )

        assert seen == ["ran"]

    def test_consumes_async_generators(self):
        seen: list[int | str] = []

        async def _agen():
            seen.append(1)
            yield 1
            seen.append(2)
            yield 2
            seen.append("done")

        _drive_run_flow_result(SimpleNamespace(isasync=True, isgenerator=True), _agen())

        assert seen == [1, 2, "done"]

    def test_consumes_generators(self):
        seen: list[int | str] = []

        def _gen():
            seen.append(1)
            yield 1
            seen.append(2)
            yield 2
            seen.append("done")

        _drive_run_flow_result(SimpleNamespace(isasync=False, isgenerator=True), _gen())

        assert seen == [1, 2, "done"]

    def test_does_not_consume_generator_returned_by_sync_non_generator_flow(self):
        seen: list[int] = []

        def _gen():
            seen.append(1)
            yield 1

        gen = _gen()

        _drive_run_flow_result(SimpleNamespace(isasync=False, isgenerator=False), gen)

        assert seen == []
        assert next(gen) == 1
        assert seen == [1]

    def test_does_not_run_coroutine_returned_by_sync_non_generator_flow(self):
        seen: list[str] = []

        async def _coro() -> None:
            seen.append("ran")

        coro = _coro()
        try:
            _drive_run_flow_result(
                SimpleNamespace(isasync=False, isgenerator=False), coro
            )
            assert seen == []
        finally:
            coro.close()


class TestCaptureSigterm:
    @pytest.mark.parametrize("intent", ["reschedule", "relinquish"])
    def test_supervisor_owned_intent_bubbles_in_sync_initialize_run(
        self, intent: str, monkeypatch: pytest.MonkeyPatch
    ):
        @contextmanager
        def _fake_sync_client_context():
            yield MagicMock(client=MagicMock())

        @contextmanager
        def _fake_hydrated_context(_context: object | None = None):
            yield

        engine = FlowRunEngine(flow=foo, flow_run=MagicMock(state=states.Pending()))
        engine.cancel_all_tasks = MagicMock()
        engine.handle_crash = MagicMock()
        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: intent
        )
        monkeypatch.setattr("prefect.flow_engine.get_intent", lambda: intent)
        monkeypatch.setattr(
            "prefect.flow_engine.SyncClientContext.get_or_create",
            _fake_sync_client_context,
        )
        monkeypatch.setattr(
            "prefect.flow_engine.hydrated_context", _fake_hydrated_context
        )
        monkeypatch.setattr(
            engine._telemetry,
            "start_span",
            MagicMock(),
        )

        with pytest.raises(TerminationSignal):
            with engine.initialize_run():
                raise TerminationSignal(signal.SIGTERM)

        engine.handle_crash.assert_not_called()

    async def test_supervisor_owned_intent_bubbles_in_async_initialize_run(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        @asynccontextmanager
        async def _fake_async_client_context():
            yield MagicMock(client=AsyncMock())

        @contextmanager
        def _fake_hydrated_context(_context: object | None = None):
            yield

        engine = AsyncFlowRunEngine(
            flow=foo,
            flow_run=MagicMock(state=states.Pending()),
        )
        engine.cancel_all_tasks = MagicMock()
        engine.handle_crash = AsyncMock()
        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: "relinquish"
        )
        monkeypatch.setattr("prefect.flow_engine.get_intent", lambda: "relinquish")
        monkeypatch.setattr(
            "prefect.flow_engine.AsyncClientContext.get_or_create",
            _fake_async_client_context,
        )
        monkeypatch.setattr(
            "prefect.flow_engine.hydrated_context", _fake_hydrated_context
        )
        monkeypatch.setattr(
            engine._telemetry,
            "async_start_span",
            AsyncMock(),
        )

        with pytest.raises(TerminationSignal):
            async with engine.initialize_run():
                raise TerminationSignal(signal.SIGTERM)

        engine.handle_crash.assert_not_called()

    @pytest.fixture
    def async_cancellation_engine(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> AsyncFlowRunEngine:
        """Async engine set up to reach the `except BaseException` dispatch by
        raising inside `initialize_run`."""

        @asynccontextmanager
        async def _fake_async_client_context():
            yield MagicMock(client=AsyncMock())

        @contextmanager
        def _fake_hydrated_context(_context: object | None = None):
            yield

        engine = AsyncFlowRunEngine(
            flow=foo, flow_run=MagicMock(state=states.Pending())
        )
        engine.cancel_all_tasks = MagicMock()
        engine.handle_crash = AsyncMock()
        engine.handle_cancellation = AsyncMock()
        monkeypatch.setattr(
            "prefect.flow_engine.AsyncClientContext.get_or_create",
            _fake_async_client_context,
        )
        monkeypatch.setattr(
            "prefect.flow_engine.hydrated_context", _fake_hydrated_context
        )
        monkeypatch.setattr(engine._telemetry, "async_start_span", AsyncMock())
        return engine

    async def test_async_cancellation_bubbles_for_supervisor_owned_intent(
        self,
        async_cancellation_engine: AsyncFlowRunEngine,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """A supervisor-driven SIGTERM can surface as a cancellation instead of a
        TerminationSignal; it must bubble rather than crash the run."""
        engine = async_cancellation_engine
        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: "relinquish"
        )
        monkeypatch.setattr("prefect.flow_engine.get_intent", lambda: "relinquish")

        with pytest.raises(TerminationSignal):
            async with engine.initialize_run():
                raise anyio.get_cancelled_exc_class()()

        engine.handle_crash.assert_not_called()

    async def test_async_cancellation_crashes_without_intent(
        self,
        async_cancellation_engine: AsyncFlowRunEngine,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """An ordinary cancellation (e.g. a flow timeout) carries no intent, so it
        must still crash rather than be mistaken for a supervisor termination."""
        engine = async_cancellation_engine
        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: None
        )
        monkeypatch.setattr("prefect.flow_engine.get_intent", lambda: None)

        with pytest.raises(anyio.get_cancelled_exc_class()):
            async with engine.initialize_run():
                raise anyio.get_cancelled_exc_class()()

        engine.handle_crash.assert_awaited_once()

    def test_can_ack_control_intent_requires_prefect_handler(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        current_handlers: dict[int, object] = {signal.SIGTERM: signal.SIG_DFL}

        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )

        assert engine_utils.can_ack_control_intent() is False

        current_handlers[signal.SIGTERM] = engine_utils._prefect_sigterm_handler
        assert engine_utils.can_ack_control_intent() is True

    def test_commit_control_intent_and_ack_holds_bridge_lock_through_ack(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        current_handlers: dict[int, object] = {
            signal.SIGTERM: engine_utils._prefect_sigterm_handler
        }
        ack_started = threading.Event()
        allow_ack_finish = threading.Event()
        handler_restored = threading.Event()
        committed_intents: list[str] = []
        result: list[bool] = []
        errors: list[BaseException] = []

        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )

        def _attempt_restore_handler() -> None:
            ack_started.wait(timeout=1.0)
            with engine_utils._prefect_sigterm_bridge_lock:
                current_handlers[signal.SIGTERM] = signal.SIG_DFL
                handler_restored.set()

        restore_thread = threading.Thread(target=_attempt_restore_handler, daemon=True)
        restore_thread.start()

        def _send_ack() -> None:
            ack_started.set()
            allow_ack_finish.wait(timeout=1.0)

        def _commit_and_ack() -> None:
            try:
                result.append(
                    engine_utils.commit_control_intent_and_ack(
                        commit_intent=lambda: committed_intents.append("cancel"),
                        clear_intent=lambda: committed_intents.clear(),
                        send_ack=_send_ack,
                    )
                )
            except BaseException as exc:  # pragma: no cover - test propagation guard
                errors.append(exc)

        try:
            commit_thread = threading.Thread(target=_commit_and_ack, daemon=True)
            commit_thread.start()
            assert ack_started.wait(timeout=1.0) is True
            assert handler_restored.wait(timeout=0.05) is False
            allow_ack_finish.set()
            commit_thread.join(timeout=1.0)
            assert commit_thread.is_alive() is False
        finally:
            allow_ack_finish.set()
            restore_thread.join(timeout=1.0)

        assert errors == []
        assert result == [True]
        assert committed_intents == ["cancel"]
        assert handler_restored.is_set() is True

    def test_commit_control_intent_and_ack_holds_bridge_lock_through_trigger(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        current_handlers: dict[int, object] = {
            signal.SIGTERM: engine_utils._prefect_sigterm_handler
        }
        trigger_started = threading.Event()
        allow_trigger_finish = threading.Event()
        handler_restored = threading.Event()
        result: list[bool] = []

        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )

        def _attempt_restore_handler() -> None:
            trigger_started.wait(timeout=1.0)
            with engine_utils._prefect_sigterm_bridge_lock:
                current_handlers[signal.SIGTERM] = signal.SIG_DFL
                handler_restored.set()

        restore_thread = threading.Thread(target=_attempt_restore_handler, daemon=True)
        restore_thread.start()

        def _trigger_cancel() -> None:
            trigger_started.set()
            allow_trigger_finish.wait(timeout=1.0)

        commit_thread = threading.Thread(
            target=lambda: result.append(
                engine_utils.commit_control_intent_and_ack(
                    commit_intent=lambda: None,
                    clear_intent=lambda: None,
                    send_ack=lambda: None,
                    trigger_cancel=_trigger_cancel,
                )
            ),
            daemon=True,
        )

        try:
            commit_thread.start()
            assert trigger_started.wait(timeout=1.0) is True
            assert handler_restored.wait(timeout=0.05) is False
            allow_trigger_finish.set()
            commit_thread.join(timeout=1.0)
            assert commit_thread.is_alive() is False
        finally:
            allow_trigger_finish.set()
            restore_thread.join(timeout=1.0)

        assert result == [True]
        assert handler_restored.is_set() is True

    def test_installs_handler_even_with_existing_flow_run_context(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        signal_calls: list[tuple[int, object]] = []
        current_handlers: dict[int, object] = {signal.SIGTERM: signal.SIG_DFL}
        start = MagicMock()
        stop = MagicMock()

        def fake_signal(sig: int, handler: object) -> object:
            previous = current_handlers.get(sig, signal.SIG_DFL)
            current_handlers[sig] = handler
            signal_calls.append((sig, handler))
            return previous

        monkeypatch.setattr(engine_utils, "_prefect_sigterm_handler_depth", 0)
        monkeypatch.setattr(signal, "signal", fake_signal)
        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )
        monkeypatch.setattr("prefect.context.FlowRunContext.get", lambda: MagicMock())
        monkeypatch.setattr("prefect._internal.control_listener.start", start)
        monkeypatch.setattr("prefect._internal.control_listener.stop", stop)

        with capture_sigterm():
            assert engine_utils._prefect_sigterm_handler_depth == 1

        assert engine_utils._prefect_sigterm_handler_depth == 0
        assert len(signal_calls) == 2
        start.assert_called_once_with()
        stop.assert_called_once_with()

    def test_posix_cancel_intent_keeps_prefect_handler_installed_on_exit(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        signal_calls: list[tuple[int, object]] = []
        current_handlers: dict[int, object] = {signal.SIGTERM: signal.SIG_DFL}
        start = MagicMock()
        stop = MagicMock()

        def fake_signal(sig: int, handler: object) -> object:
            previous = current_handlers.get(sig, signal.SIG_DFL)
            current_handlers[sig] = handler
            signal_calls.append((sig, handler))
            return previous

        monkeypatch.setattr(engine_utils, "_prefect_sigterm_handler_depth", 0)
        monkeypatch.setattr(signal, "signal", fake_signal)
        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )
        monkeypatch.setattr(
            "prefect._internal.control_listener.get_intent", lambda: "cancel"
        )
        monkeypatch.setattr("prefect._internal.control_listener.start", start)
        monkeypatch.setattr("prefect._internal.control_listener.stop", stop)

        with capture_sigterm():
            assert (
                current_handlers[signal.SIGTERM]
                is engine_utils._prefect_sigterm_handler
            )

        assert engine_utils._prefect_sigterm_handler_depth == 0
        assert len(signal_calls) == 1
        assert current_handlers[signal.SIGTERM] is engine_utils._prefect_sigterm_handler
        start.assert_called_once_with()
        stop.assert_called_once_with()

    def test_nested_capture_sigterm_reuses_outer_prefect_handler(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        signal_calls: list[tuple[int, object]] = []
        current_handlers: dict[int, object] = {signal.SIGTERM: signal.SIG_DFL}
        start = MagicMock()
        stop = MagicMock()

        def fake_signal(sig: int, handler: object) -> object:
            previous = current_handlers.get(sig, signal.SIG_DFL)
            current_handlers[sig] = handler
            signal_calls.append((sig, handler))
            return previous

        monkeypatch.setattr(engine_utils, "_prefect_sigterm_handler_depth", 0)
        monkeypatch.setattr(signal, "signal", fake_signal)
        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )
        monkeypatch.setattr("prefect._internal.control_listener.start", start)
        monkeypatch.setattr("prefect._internal.control_listener.stop", stop)

        with capture_sigterm():
            assert engine_utils._prefect_sigterm_handler_depth == 1
            with capture_sigterm():
                assert engine_utils._prefect_sigterm_handler_depth == 2
            assert engine_utils._prefect_sigterm_handler_depth == 1

        assert engine_utils._prefect_sigterm_handler_depth == 0
        start.assert_called_once_with()
        stop.assert_called_once_with()

    def test_run_serialized_call_with_control_bootstrap_configures_before_deserializing(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        calls: list[object] = []
        fake_environ: dict[str, str] = {}

        monkeypatch.setattr(
            "prefect.flow_engine.configure_from_env",
            lambda: calls.append("configure"),
        )
        monkeypatch.setattr(
            "prefect.flow_engine._run_serialized_call",
            lambda payload: calls.append(("deserialize", payload)) or b"done",
        )
        monkeypatch.setattr("prefect.flow_engine.os.environ", fake_environ)

        result = _run_serialized_call_with_control_bootstrap(
            b"payload",
            {
                "PREFECT__CONTROL_PORT": "4200",
                "PREFECT__CONTROL_TOKEN": "deadbeef",
            },
        )

        assert result == b"done"
        assert calls == ["configure", ("deserialize", b"payload")]
        assert fake_environ == {
            "PREFECT__CONTROL_PORT": "4200",
            "PREFECT__CONTROL_TOKEN": "deadbeef",
        }

    def test_runtime_subprocess_env_drops_control_keys_and_none_values(self):
        assert _runtime_subprocess_env(
            {
                "PREFECT__CONTROL_PORT": "4200",
                "PREFECT__CONTROL_TOKEN": "deadbeef",
                "KEEP_ME": "value",
                "DROP_ME": None,
            }
        ) == {
            "KEEP_ME": "value",
        }

    def test_nested_capture_sigterm_reinstalls_prefect_handler_after_custom_swap(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        signal_calls: list[tuple[int, object]] = []
        current_handlers: dict[int, object] = {signal.SIGTERM: signal.SIG_DFL}
        start = MagicMock()
        stop = MagicMock()

        def fake_signal(sig: int, handler: object) -> object:
            previous = current_handlers.get(sig, signal.SIG_DFL)
            current_handlers[sig] = handler
            signal_calls.append((sig, handler))
            return previous

        monkeypatch.setattr(engine_utils, "_prefect_sigterm_handler_depth", 0)
        monkeypatch.setattr(signal, "signal", fake_signal)
        monkeypatch.setattr(
            signal, "getsignal", lambda sig: current_handlers.get(sig, signal.SIG_DFL)
        )
        monkeypatch.setattr("prefect._internal.control_listener.start", start)
        monkeypatch.setattr("prefect._internal.control_listener.stop", stop)

        def custom_handler(signum: int, frame: object | None) -> None:
            return None

        with capture_sigterm():
            assert engine_utils._prefect_sigterm_handler_depth == 1
            fake_signal(signal.SIGTERM, custom_handler)
            with capture_sigterm():
                assert engine_utils._prefect_sigterm_handler_depth == 2
            assert engine_utils._prefect_sigterm_handler_depth == 1
            assert current_handlers[signal.SIGTERM] is custom_handler

        assert engine_utils._prefect_sigterm_handler_depth == 0
        assert len(signal_calls) == 5
        start.assert_called_once_with()
        stop.assert_called_once_with()

    def test_initialize_run_sets_nested_ownership_before_begin_run_sync(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        @contextmanager
        def _fake_sync_client_context():
            yield MagicMock(client=MagicMock())

        @contextmanager
        def _fake_hydrated_context(_context: object | None = None):
            yield

        engine = FlowRunEngine(flow=foo, flow_run=MagicMock(state=states.Pending()))
        parent_context = MagicMock(detached=False)
        monkeypatch.setattr(
            "prefect.flow_engine.hydrated_context", _fake_hydrated_context
        )
        monkeypatch.setattr(
            "prefect.flow_engine.FlowRunContext.get", lambda: parent_context
        )
        monkeypatch.setattr(
            "prefect.flow_engine.SyncClientContext.get_or_create",
            _fake_sync_client_context,
        )
        monkeypatch.setattr(engine._telemetry, "start_span", MagicMock())

        with engine.initialize_run():
            assert engine._started_with_in_process_parent_flow_run_context is True

    async def test_initialize_run_sets_nested_ownership_before_begin_run_async(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        @asynccontextmanager
        async def _fake_async_client_context():
            yield MagicMock(client=AsyncMock())

        @contextmanager
        def _fake_hydrated_context(_context: object | None = None):
            yield

        engine = AsyncFlowRunEngine(
            flow=foo,
            flow_run=MagicMock(state=states.Pending()),
        )
        parent_context = MagicMock(detached=False)
        monkeypatch.setattr(
            "prefect.flow_engine.hydrated_context", _fake_hydrated_context
        )
        monkeypatch.setattr(
            "prefect.flow_engine.FlowRunContext.get", lambda: parent_context
        )
        monkeypatch.setattr(
            "prefect.flow_engine.AsyncClientContext.get_or_create",
            _fake_async_client_context,
        )
        monkeypatch.setattr(engine._telemetry, "async_start_span", AsyncMock())

        async with engine.initialize_run():
            assert engine._started_with_in_process_parent_flow_run_context is True

    def test_begin_run_treats_detached_parent_context_as_not_in_process(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        engine = FlowRunEngine(flow=foo, flow_run=MagicMock(state=states.Pending()))
        detached_parent_context = MagicMock(detached=True)

        monkeypatch.setattr(
            "prefect.flow_engine.FlowRunContext.get", lambda: detached_parent_context
        )
        monkeypatch.setattr(engine, "_resolve_parameters", MagicMock())
        monkeypatch.setattr(engine, "_wait_for_dependencies", MagicMock())
        monkeypatch.setattr(
            engine, "set_state", MagicMock(return_value=states.Running())
        )

        engine.begin_run()

        assert engine._started_with_in_process_parent_flow_run_context is False


class TestPauseFlowRun:
    async def test_pause_flow_run_from_task_pauses_parent_flow(
        self, prefect_client, events_pipeline
    ):
        """Test that calling pause_flow_run from within a task pauses the parent flow."""
        flow_run_id = None

        @task
        async def task_that_pauses():
            await pause_flow_run(timeout=0.1)
            return True

        @flow
        async def flow_with_pausing_task():
            nonlocal flow_run_id
            context = FlowRunContext.get()
            flow_run_id = context.flow_run.id
            return await task_that_pauses()

        # The flow should timeout because it gets paused and never resumed
        with pytest.raises(FlowPauseTimeout):
            await flow_with_pausing_task()

        # Verify the flow run was actually paused
        flow_run = await prefect_client.read_flow_run(flow_run_id)
        assert flow_run.state.is_paused() or flow_run.state.is_failed()

    async def test_pause_flow_run_from_task_with_input(self, prefect_client):
        """Test that pause_flow_run from within a task can receive input and resume."""
        flow_run_id = None

        class ApprovalInput(RunInput):
            approved: bool

        @task
        async def get_approval():
            approval = await pause_flow_run(
                timeout=10, poll_interval=2, wait_for_input=ApprovalInput
            )
            return approval.approved

        @flow(persist_result=False)
        async def flow_with_approval_task():
            nonlocal flow_run_id
            context = FlowRunContext.get()
            flow_run_id = context.flow_run.id

            approved = await get_approval()
            return approved

        async def flow_resumer():
            # Wait on flow run to start
            while not flow_run_id:
                await anyio.sleep(0.1)

            # Wait on flow run to pause
            flow_run = await prefect_client.read_flow_run(flow_run_id)
            while not flow_run.state.is_paused():
                await asyncio.sleep(0.1)
                flow_run = await prefect_client.read_flow_run(flow_run_id)

            keyset = flow_run.state.state_details.run_input_keyset
            assert keyset

            # Wait for the flow run input schema to be saved
            while not (await read_flow_run_input(keyset["schema"], flow_run_id)):
                await asyncio.sleep(0.1)

            await resume_flow_run(flow_run_id, run_input={"approved": True})

        flow_run_state, _ = await asyncio.gather(
            flow_with_approval_task(return_state=True),
            flow_resumer(),
        )
        approved = await flow_run_state.result()
        assert approved is True

        # Ensure that the flow run did create the corresponding schema input
        schema = await read_flow_run_input(
            key="paused-1-schema", flow_run_id=flow_run_id
        )
        assert schema is not None

    async def test_paused_flows_fail_if_not_resumed(self):
        @task
        async def doesnt_pause():
            return 42

        @flow
        async def pausing_flow():
            await doesnt_pause()
            await pause_flow_run(timeout=0.1)
            await doesnt_pause()

        with pytest.raises(FlowPauseTimeout):
            await pausing_flow()

    def test_paused_flows_block_execution_in_sync_flows(self, prefect_client):
        completed = False

        @flow
        def pausing_flow():
            nonlocal completed
            pause_flow_run(timeout=0.1)
            completed = True

        pausing_flow(return_state=True)
        assert not completed

    async def test_paused_flows_block_execution_in_async_flows(
        self, prefect_client, events_pipeline
    ):
        @task
        async def foo():
            return 42

        @flow
        async def pausing_flow():
            await foo()
            await foo()
            await pause_flow_run(timeout=0.1)
            await foo()

        flow_run_state = await pausing_flow(return_state=True)
        flow_run_id = flow_run_state.state_details.flow_run_id
        await events_pipeline.process_events()
        task_runs = await prefect_client.read_task_runs(
            flow_run_filter=FlowRunFilter(id={"any_": [flow_run_id]})
        )
        assert len(task_runs) == 2, "only two tasks should have completed"

    async def test_paused_flows_can_be_resumed(self, prefect_client, events_pipeline):
        flow_run_id = None

        @task
        async def foo():
            return 42

        @flow
        async def pausing_flow():
            nonlocal flow_run_id
            context = FlowRunContext.get()
            flow_run_id = context.flow_run.id
            await foo()
            await foo()
            await pause_flow_run(timeout=10, poll_interval=2, key="do-not-repeat")
            await foo()
            await pause_flow_run(timeout=10, poll_interval=2, key="do-not-repeat")
            await foo()
            await foo()

        async def flow_resumer():
            # Wait for the flow run to start
            while not flow_run_id:
                await anyio.sleep(0.1)

            # Wait for the flow run to pause
            flow_run = await prefect_client.read_flow_run(flow_run_id)
            while not flow_run.state.is_paused():
                await anyio.sleep(0.1)
                flow_run = await prefect_client.read_flow_run(flow_run_id)

            await resume_flow_run(flow_run_id)

        flow_run_state, the_answer = await asyncio.gather(
            pausing_flow(return_state=True),
            flow_resumer(),
        )
        await events_pipeline.process_events()
        task_runs = await prefect_client.read_task_runs(
            flow_run_filter=FlowRunFilter(id={"any_": [flow_run_id]})
        )
        assert len(task_runs) == 5, "all tasks should finish running"

    async def test_paused_flows_can_receive_input(self, prefect_client):
        flow_run_id = None

        class FlowInput(RunInput):
            x: int

        @flow(persist_result=False)
        async def pausing_flow():
            nonlocal flow_run_id
            context = FlowRunContext.get()
            flow_run_id = context.flow_run.id

            flow_input = await pause_flow_run(
                timeout=10, poll_interval=2, wait_for_input=FlowInput
            )
            return flow_input

        async def flow_resumer():
            # Wait on flow run to start
            while not flow_run_id:
                await anyio.sleep(0.1)

            # Wait on flow run to pause
            flow_run = await prefect_client.read_flow_run(flow_run_id)
            while not flow_run.state.is_paused():
                await asyncio.sleep(0.1)
                flow_run = await prefect_client.read_flow_run(flow_run_id)

            keyset = flow_run.state.state_details.run_input_keyset
            assert keyset

            # Wait for the flow run input schema to be saved
            while not (await read_flow_run_input(keyset["schema"], flow_run_id)):
                await asyncio.sleep(0.1)

            await resume_flow_run(flow_run_id, run_input={"x": 42})

        flow_run_state, the_answer = await asyncio.gather(
            pausing_flow(return_state=True),
            flow_resumer(),
        )
        flow_input = await flow_run_state.result()
        assert isinstance(flow_input, FlowInput)
        assert flow_input.x == 42

        # Ensure that the flow run did create the corresponding schema input
        schema = await read_flow_run_input(
            key="paused-1-schema", flow_run_id=flow_run_id
        )
        assert schema is not None

    async def test_paused_flows_can_receive_automatic_input(
        self, prefect_client: PrefectClient
    ):
        flow_run_id = None

        @flow
        async def pausing_flow():
            nonlocal flow_run_id
            context = FlowRunContext.get()
            flow_run_id = context.flow_run.id

            age = await pause_flow_run(int, timeout=10, poll_interval=2)
            return age

        async def flow_resumer():
            # Wait on flow run to start
            while not flow_run_id:
                await anyio.sleep(0.1)

            # Wait on flow run to pause
            flow_run = await prefect_client.read_flow_run(flow_run_id)
            while not flow_run.state.is_paused():
                await asyncio.sleep(0.1)
                flow_run = await prefect_client.read_flow_run(flow_run_id)

            keyset = flow_run.state.state_details.run_input_keyset
            assert keyset

            # Wait for the flow run input schema to be saved
            while not (await read_flow_run_input(keyset["schema"], flow_run_id)):
                await asyncio.sleep(0.1)

            await resume_flow_run(flow_run_id, run_input={"value": 42})

        flow_run_state, the_answer = await asyncio.gather(
            pausing_flow(return_state=True),
            flow_resumer(),
        )
        age = await flow_run_state.result()
        assert isinstance(age, int)
        assert age == 42

        # Ensure that the flow run did create the corresponding schema input
        schema = await read_flow_run_input(
            key="paused-1-schema", flow_run_id=flow_run_id
        )
        assert schema is not None

    @pytest.mark.xfail(
        reason="Client-side task run orchestration does not prevent tasks from running in paused flows yet"
    )
    async def test_paused_task_polling(self, prefect_client):
        sleeper = AsyncMock(side_effect=[None, None, None, None, None])

        @task
        async def doesnt_pause():
            return 42

        @task
        async def doesnt_run():
            assert False, "This task should not run"

        @flow
        async def pausing_flow():
            await doesnt_pause()
            # don't wait on this to avoid blocking execution
            asyncio.create_task(pause_flow_run(timeout=20, poll_interval=100))

            # wait for the flow run to enter the paused state
            flow_run_id = FlowRunContext.get().flow_run.id
            flow_run = await prefect_client.read_flow_run(flow_run_id)
            while not flow_run.state.is_paused():
                await asyncio.sleep(0.1)
                flow_run = await prefect_client.read_flow_run(flow_run_id)

            # execution isn't blocked, so this task should enter the engine, but not begin
            # execution
            with mock.patch("prefect.task_engine.anyio.sleep", sleeper):
                with pytest.raises(RuntimeError):
                    # the sleeper mock will exhaust its side effects after 6 calls
                    await doesnt_run()

        await pausing_flow()

        sleep_intervals = [c.args[0] for c in sleeper.call_args_list]
        assert len(sleep_intervals) == 6


class TestFlowRunSuspensionRequest:
    def test_raise_if_requested_uses_marked_suspended_state(self):
        suspension_request = FlowRunSuspensionRequest()
        suspended_state = states.Suspended(message="Suspend me")

        assert not suspension_request.is_requested()
        assert suspension_request.get_state() is None
        suspension_request.raise_if_requested()

        suspension_request.mark_requested(suspended_state)

        assert suspension_request.is_requested()
        assert suspension_request.get_state() is suspended_state

        with pytest.raises(Pause) as exc_info:
            suspension_request.raise_if_requested()

        assert exc_info.value.state is suspended_state


class TestSuspendFlowRun:
    async def _attach_deployment_to_current_flow_run(self, deployment, session) -> UUID:
        context = get_run_context()
        assert context.flow_run

        from prefect.server.models.flow_runs import update_flow_run

        await update_flow_run(
            session,
            context.flow_run.id,
            ServerFlowRun.model_construct(deployment_id=deployment.id),
        )
        await session.commit()

        return context.flow_run.id

    async def _create_deployment_backed_flow_run(
        self,
        prefect_client: PrefectClient,
        suspension_flow: Flow[Any, Any],
    ):
        flow_id = await prefect_client.create_flow(suspension_flow)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"flow-run-suspension-{uuid.uuid4()}",
        )
        return await prefect_client.create_flow_run_from_deployment(deployment_id)

    async def _run_suspension_boundary_flow(
        self,
        prefect_client: PrefectClient,
        suspension_flow: Flow[Any, Any],
        engine_type: Literal["sync", "async"],
    ) -> UUID:
        flow_run = await self._create_deployment_backed_flow_run(
            prefect_client, suspension_flow
        )

        with pytest.raises(Pause):
            if engine_type == "sync":
                run_flow_sync(suspension_flow, flow_run=flow_run)
            else:
                await run_flow_async(suspension_flow, flow_run=flow_run)

        return flow_run.id

    async def test_suspended_flow_runs_do_not_block_execution(
        self, prefect_client, deployment, session
    ):
        flow_run_id = None

        @flow()
        async def suspending_flow():
            nonlocal flow_run_id
            context = get_run_context()
            assert context.flow_run
            flow_run_id = context.flow_run.id

            from prefect.server.models.flow_runs import update_flow_run

            await update_flow_run(
                session,
                flow_run_id,
                ServerFlowRun.model_construct(deployment_id=deployment.id),
            )
            await session.commit()

            await suspend_flow_run()
            await asyncio.sleep(20)

        start = time.time()
        with pytest.raises(Pause):
            await suspending_flow()
        end = time.time()
        assert end - start < 20

    async def test_suspended_flow_run_has_correct_state(
        self, prefect_client, deployment, session
    ):
        flow_run_id = None

        @flow()
        async def suspending_flow():
            nonlocal flow_run_id
            context = get_run_context()
            assert context.flow_run
            flow_run_id = context.flow_run.id

            from prefect.server.models.flow_runs import update_flow_run

            await update_flow_run(
                session,
                flow_run_id,
                ServerFlowRun.model_construct(deployment_id=deployment.id),
            )
            await session.commit()

            await suspend_flow_run()

        with pytest.raises(Pause):
            await suspending_flow()

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        state = flow_run.state
        assert state.is_paused()
        assert state.name == "Suspended"

    async def test_suspending_flow_run_without_deployment_fails(self):
        @flow()
        async def suspending_flow():
            await suspend_flow_run()

        with pytest.raises(
            RuntimeError, match="Cannot suspend flows without a deployment."
        ):
            await suspending_flow()

    async def test_suspending_sub_flow_run_fails(self):
        @flow()
        async def suspending_flow():
            await suspend_flow_run()

        @flow
        async def main_flow():
            await suspending_flow()

        with pytest.raises(RuntimeError, match="Cannot suspend subflows."):
            await main_flow()

    async def test_suspend_flow_run_by_id(self, prefect_client, deployment, session):
        flow_run_id = None
        task_completions = 0

        @task
        async def increment_completions():
            nonlocal task_completions
            task_completions += 1
            await asyncio.sleep(1)

        @flow
        async def suspendable_flow():
            nonlocal flow_run_id
            context = get_run_context()
            assert context.flow_run

            from prefect.server.models.flow_runs import update_flow_run

            await update_flow_run(
                session,
                context.flow_run.id,
                ServerFlowRun.model_construct(deployment_id=deployment.id),
            )
            await session.commit()

            flow_run_id = context.flow_run.id

            for i in range(20):
                await increment_completions()

        async def suspending_func():
            nonlocal flow_run_id

            while flow_run_id is None:
                await asyncio.sleep(0.1)

            # Sleep for a bit to let some of `suspendable_flow`s tasks complete
            await asyncio.sleep(2)

            await suspend_flow_run(flow_run_id=flow_run_id)

        with pytest.raises(Pause):
            await asyncio.gather(suspendable_flow(), suspending_func())

        # When suspending a flow run by id, that flow run must use tasks for
        # the suspension to take place. This setup allows for `suspendable_flow`
        # to complete some tasks before `suspending_flow` suspends the flow run.
        # Here then we check to ensure that some tasks completed but not _all_
        # of the tasks.
        assert task_completions > 0 and task_completions < 20

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        state = flow_run.state
        assert state.is_paused(), state
        assert state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_pre_start_suspension_stops_before_running(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        flow_ran = False

        if engine_type == "sync":

            @flow(name=f"test_pre_start_suspension_{uuid.uuid4()}")
            def suspendable_flow():
                nonlocal flow_ran
                flow_ran = True
        else:

            @flow(name=f"test_pre_start_suspension_{uuid.uuid4()}")
            async def suspendable_flow():
                nonlocal flow_ran
                flow_ran = True

        flow_run = await self._create_deployment_backed_flow_run(
            prefect_client, suspendable_flow
        )
        await prefect_client.set_flow_run_state(
            flow_run.id, states.Suspended(), force=True
        )

        with pytest.raises(Pause):
            if engine_type == "sync":
                run_flow_sync(suspendable_flow, flow_run=flow_run)
            else:
                await run_flow_async(suspendable_flow, flow_run=flow_run)

        assert not flow_ran

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_begin_run_rechecks_suspension_before_running(
        self,
        prefect_client: PrefectClient,
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
        engine_type: Literal["sync", "async"],
    ):
        flow_ran = False
        suspended_state = states.Suspended()

        def suspend_during_flow_run_name_resolution(
            flow: Flow[Any, Any], parameters: dict[str, Any]
        ) -> str:
            _ = flow, parameters
            flow_run_context = FlowRunContext.get()
            assert flow_run_context
            flow_run_id = flow_run_context.flow_run.id
            sync_prefect_client.set_flow_run_state(
                flow_run_id,
                suspended_state,
                force=True,
            )
            assert mark_flow_run_suspension_requested(flow_run_id, suspended_state)
            return "suspended-before-running"

        monkeypatch.setattr(
            "prefect.flow_engine.resolve_custom_flow_run_name",
            suspend_during_flow_run_name_resolution,
        )

        if engine_type == "sync":

            @flow(
                name=f"test_begin_run_rechecks_suspension_before_running_{uuid.uuid4()}",
                flow_run_name="custom-name",
            )
            def suspendable_flow():
                nonlocal flow_ran
                flow_ran = True
        else:

            @flow(
                name=f"test_begin_run_rechecks_suspension_before_running_{uuid.uuid4()}",
                flow_run_name="custom-name",
            )
            async def suspendable_flow():
                nonlocal flow_ran
                flow_ran = True

        flow_run = await self._create_deployment_backed_flow_run(
            prefect_client, suspendable_flow
        )

        with pytest.raises(Pause):
            if engine_type == "sync":
                run_flow_sync(suspendable_flow, flow_run=flow_run)
            else:
                await run_flow_async(suspendable_flow, flow_run=flow_run)

        assert not flow_ran

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_completion_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        task_ran = False

        if engine_type == "sync":

            @task
            def complete_task_boundary():
                nonlocal task_ran
                task_ran = True

            @flow(name=f"test_completion_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                complete_task_boundary()
                suspend_flow_run(flow_run_id=flow_run_id)
                return "should-not-complete"
        else:

            @task
            async def complete_task_boundary():
                nonlocal task_ran
                task_ran = True

            @flow(name=f"test_completion_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await complete_task_boundary()
                await suspend_flow_run(flow_run_id=flow_run_id)
                return "should-not-complete"

        flow_run_id = await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        assert task_ran

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_handle_success_rechecks_suspension_before_final_state(
        self,
        prefect_client: PrefectClient,
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
        engine_type: Literal["sync", "async"],
    ):
        suspended_state = states.Suspended()

        original_return_value_to_state = flow_engine_module.return_value_to_state

        async def suspend_during_terminal_state_preparation(*args: Any, **kwargs: Any):
            terminal_state = await original_return_value_to_state(*args, **kwargs)
            flow_run_context = FlowRunContext.get()
            assert flow_run_context
            flow_run_id = flow_run_context.flow_run.id
            sync_prefect_client.set_flow_run_state(
                flow_run_id,
                suspended_state,
                force=True,
            )
            assert mark_flow_run_suspension_requested(flow_run_id, suspended_state)
            return terminal_state

        monkeypatch.setattr(
            "prefect.flow_engine.return_value_to_state",
            suspend_during_terminal_state_preparation,
        )

        if engine_type == "sync":

            @flow(
                name=(
                    "test_handle_success_rechecks_suspension_before_final_state_"
                    f"{uuid.uuid4()}"
                )
            )
            def suspendable_flow():
                return "should-not-complete"
        else:

            @flow(
                name=(
                    "test_handle_success_rechecks_suspension_before_final_state_"
                    f"{uuid.uuid4()}"
                )
            )
            async def suspendable_flow():
                return "should-not-complete"

        flow_run = await self._create_deployment_backed_flow_run(
            prefect_client, suspendable_flow
        )

        with pytest.raises(Pause):
            if engine_type == "sync":
                run_flow_sync(suspendable_flow, flow_run=flow_run)
            else:
                await run_flow_async(suspendable_flow, flow_run=flow_run)

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_handle_exception_rechecks_suspension_before_failed_state(
        self,
        prefect_client: PrefectClient,
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
        engine_type: Literal["sync", "async"],
    ):
        suspended_state = states.Suspended()

        original_exception_to_failed_state = (
            flow_engine_module.exception_to_failed_state
        )

        async def suspend_during_failed_state_preparation(*args: Any, **kwargs: Any):
            terminal_state = await original_exception_to_failed_state(*args, **kwargs)
            flow_run_context = FlowRunContext.get()
            assert flow_run_context
            flow_run_id = flow_run_context.flow_run.id
            sync_prefect_client.set_flow_run_state(
                flow_run_id,
                suspended_state,
                force=True,
            )
            assert mark_flow_run_suspension_requested(flow_run_id, suspended_state)
            return terminal_state

        monkeypatch.setattr(
            "prefect.flow_engine.exception_to_failed_state",
            suspend_during_failed_state_preparation,
        )

        if engine_type == "sync":

            @flow(
                name=(
                    "test_handle_exception_rechecks_suspension_before_failed_state_"
                    f"{uuid.uuid4()}"
                )
            )
            def suspendable_flow():
                raise ValueError("should pause instead of fail")
        else:

            @flow(
                name=(
                    "test_handle_exception_rechecks_suspension_before_failed_state_"
                    f"{uuid.uuid4()}"
                )
            )
            async def suspendable_flow():
                raise ValueError("should pause instead of fail")

        flow_run = await self._create_deployment_backed_flow_run(
            prefect_client, suspendable_flow
        )

        with pytest.raises(Pause):
            if engine_type == "sync":
                run_flow_sync(suspendable_flow, flow_run=flow_run)
            else:
                await run_flow_async(suspendable_flow, flow_run=flow_run)

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_exception_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        if engine_type == "sync":

            @flow(name=f"test_exception_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                raise ValueError("should pause instead of fail")
        else:

            @flow(name=f"test_exception_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                raise ValueError("should pause instead of fail")

        flow_run_id = await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_timeout_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        if engine_type == "sync":

            @flow(
                name=f"test_timeout_stops_at_suspension_boundary_{uuid.uuid4()}",
                timeout_seconds=0.5,
            )
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                time.sleep(2)
        else:

            @flow(
                name=f"test_timeout_stops_at_suspension_boundary_{uuid.uuid4()}",
                timeout_seconds=0.5,
            )
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                await asyncio.sleep(2)

        flow_run_id = await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_setup_run_context_marks_refreshed_suspended_state(
        self,
        prefect_client: PrefectClient,
        sync_prefect_client: SyncPrefectClient,
        monkeypatch: pytest.MonkeyPatch,
        engine_type: Literal["sync", "async"],
    ):
        flow_ran = False

        def suspend_after_running(flow_run_id: UUID) -> None:
            sync_prefect_client.set_flow_run_state(
                flow_run_id,
                states.Suspended(),
                force=True,
            )

        monkeypatch.setattr(
            "prefect.flow_engine.observe_flow_run_suspension",
            lambda *args, **kwargs: nullcontext(),
        )

        if engine_type == "sync":
            original_begin_run = FlowRunEngine.begin_run

            def suspend_after_sync_begin_run(engine):
                state = original_begin_run(engine)
                suspend_after_running(engine.flow_run.id)
                return state

            monkeypatch.setattr(
                FlowRunEngine, "begin_run", suspend_after_sync_begin_run
            )

            @flow(name=f"test_setup_run_context_marks_suspended_state_{uuid.uuid4()}")
            def suspendable_flow():
                nonlocal flow_ran
                flow_ran = True
        else:
            original_begin_run = AsyncFlowRunEngine.begin_run

            async def suspend_after_async_begin_run(engine):
                state = await original_begin_run(engine)
                suspend_after_running(engine.flow_run.id)
                return state

            monkeypatch.setattr(
                AsyncFlowRunEngine, "begin_run", suspend_after_async_begin_run
            )

            @flow(name=f"test_setup_run_context_marks_suspended_state_{uuid.uuid4()}")
            async def suspendable_flow():
                nonlocal flow_ran
                flow_ran = True

        flow_run = await self._create_deployment_backed_flow_run(
            prefect_client, suspendable_flow
        )

        with pytest.raises(Pause):
            if engine_type == "sync":
                run_flow_sync(suspendable_flow, flow_run=flow_run)
            else:
                await run_flow_async(suspendable_flow, flow_run=flow_run)

        assert not flow_ran

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_paused(), flow_run.state
        assert flow_run.state.name == "Suspended"

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_task_call_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        task_ran = False

        if engine_type == "sync":

            @task
            def should_not_run():
                nonlocal task_ran
                task_ran = True

            @flow(name=f"test_task_call_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                should_not_run()
        else:

            @task
            async def should_not_run():
                nonlocal task_ran
                task_ran = True

            @flow(name=f"test_task_call_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                await should_not_run()

        await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        assert not task_ran

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_submit_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        task_ran = False

        if engine_type == "sync":

            @task
            def should_not_run():
                nonlocal task_ran
                task_ran = True

            @flow(name=f"test_submit_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                should_not_run.submit()
        else:

            @task
            async def should_not_run():
                nonlocal task_ran
                task_ran = True

            @flow(name=f"test_submit_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                should_not_run.submit()

        await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        assert not task_ran

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_map_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        task_runs = []

        if engine_type == "sync":

            @task
            def should_not_run(value: int):
                task_runs.append(value)

            @flow(name=f"test_map_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                should_not_run.map([1, 2, 3])
        else:

            @task
            async def should_not_run(value: int):
                task_runs.append(value)

            @flow(name=f"test_map_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                should_not_run.map([1, 2, 3])

        await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        assert task_runs == []

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_apply_async_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        if engine_type == "sync":

            @task
            def should_not_schedule(value: int):
                return value

            @flow(name=f"test_apply_async_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                should_not_schedule.apply_async(kwargs={"value": 1})
        else:

            @task
            async def should_not_schedule(value: int):
                return value

            @flow(name=f"test_apply_async_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                should_not_schedule.apply_async(kwargs={"value": 1})

        await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

    @pytest.mark.parametrize("engine_type", ["sync", "async"])
    async def test_child_flow_stops_at_suspension_boundary(
        self,
        prefect_client: PrefectClient,
        engine_type: Literal["sync", "async"],
    ):
        child_ran = False

        if engine_type == "sync":

            @flow(name=f"test_child_flow_boundary_child_{uuid.uuid4()}")
            def child_flow():
                nonlocal child_ran
                child_ran = True

            @flow(name=f"test_child_flow_stops_at_suspension_boundary_{uuid.uuid4()}")
            def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                suspend_flow_run(flow_run_id=flow_run_id)
                child_flow()
        else:

            @flow(name=f"test_child_flow_boundary_child_{uuid.uuid4()}")
            async def child_flow():
                nonlocal child_ran
                child_ran = True

            @flow(name=f"test_child_flow_stops_at_suspension_boundary_{uuid.uuid4()}")
            async def suspendable_flow():
                flow_run_id = get_run_context().flow_run.id
                await suspend_flow_run(flow_run_id=flow_run_id)
                await child_flow()

        await self._run_suspension_boundary_flow(
            prefect_client, suspendable_flow, engine_type
        )

        assert not child_ran

    async def test_suspend_can_receive_input(self, deployment, session, prefect_client):
        flow_run_id = None

        class FlowInput(RunInput):
            x: int

        @flow(persist_result=False)
        async def suspending_flow():
            nonlocal flow_run_id
            context = get_run_context()
            assert context.flow_run

            if not context.flow_run.deployment_id:
                # Ensure that the flow run has a deployment id so it's
                # suspendable.
                from prefect.server.models.flow_runs import update_flow_run

                await update_flow_run(
                    session,
                    context.flow_run.id,
                    ServerFlowRun.model_construct(deployment_id=deployment.id),
                )
                await session.commit()

            flow_run_id = context.flow_run.id

            flow_input = await suspend_flow_run(wait_for_input=FlowInput)

            return flow_input

        with pytest.raises(Pause):
            await suspending_flow()

        assert flow_run_id

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        keyset = flow_run.state.state_details.run_input_keyset

        schema = await read_flow_run_input(
            key=keyset["schema"], flow_run_id=flow_run_id
        )
        assert schema is not None

        await resume_flow_run(flow_run_id, run_input={"x": 42})

        flow_input = await run_flow_async(
            flow=suspending_flow,
            flow_run=flow_run,
            parameters={},
        )
        assert flow_input
        assert flow_input.x == 42

    async def test_suspend_can_receive_automatic_input(
        self, deployment, session, prefect_client
    ):
        flow_run_id = None

        @flow()
        async def suspending_flow():
            nonlocal flow_run_id
            context = get_run_context()
            assert context.flow_run

            if not context.flow_run.deployment_id:
                # Ensure that the flow run has a deployment id so it's
                # suspendable.
                from prefect.server.models.flow_runs import update_flow_run

                assert await update_flow_run(
                    session,
                    context.flow_run.id,
                    ServerFlowRun.model_construct(deployment_id=deployment.id),
                )
                await session.commit()

            flow_run_id = context.flow_run.id

            age = await suspend_flow_run(int)

            return age

        with pytest.raises(Pause):
            await suspending_flow()

        assert flow_run_id

        flow_run = await prefect_client.read_flow_run(flow_run_id)
        keyset = flow_run.state.state_details.run_input_keyset

        schema = await read_flow_run_input(
            key=keyset["schema"], flow_run_id=flow_run_id
        )
        assert schema is not None

        await resume_flow_run(flow_run_id, run_input={"value": 42})

        age = await run_flow_async(
            flow=suspending_flow,
            flow_run=flow_run,
            parameters={},
        )

        assert age == 42


class TestGenerators:
    async def test_generator_flow(self):
        """
        Test for generator behavior including StopIteration
        """

        @flow
        def g():
            yield 1
            yield 2

        gen = g()
        assert next(gen) == 1
        assert next(gen) == 2
        with pytest.raises(StopIteration):
            next(gen)

    async def test_generator_flow_requires_return_type_result(self):
        @flow
        def g():
            yield 1

        with pytest.raises(
            ValueError, match="The return_type for a generator flow must be 'result'"
        ):
            for i in g(return_state=True):
                pass

    async def test_generator_flow_states(self, prefect_client: PrefectClient):
        """
        Test for generator behavior including StopIteration
        """

        @flow
        def g():
            yield FlowRunContext.get().flow_run.id
            yield 2

        gen = g()
        tr_id = next(gen)
        tr = await prefect_client.read_flow_run(tr_id)
        assert tr.state.is_running()

        # exhaust the generator
        for _ in gen:
            pass

        tr = await prefect_client.read_flow_run(tr_id)
        assert tr.state.is_completed()

    async def test_generator_flow_with_return(self):
        """
        If a generator returns, the return value is trapped
        in its StopIteration error
        """

        @flow
        def g():
            yield 1
            return 2

        gen = g()
        assert next(gen) == 1
        with pytest.raises(StopIteration) as exc_info:
            next(gen)
        assert exc_info.value.value == 2

    async def test_generator_flow_with_exception(self):
        @flow
        def g():
            yield 1
            raise ValueError("xyz")

        gen = g()
        assert next(gen) == 1
        with pytest.raises(ValueError, match="xyz"):
            next(gen)

    async def test_generator_flow_with_exception_is_failed(
        self, prefect_client: PrefectClient, events_pipeline
    ):
        @task
        def g():
            yield TaskRunContext.get().task_run.id
            raise ValueError("xyz")

        gen = g()
        tr_id = next(gen)
        with pytest.raises(ValueError, match="xyz"):
            next(gen)

        await events_pipeline.process_events()
        tr = await prefect_client.read_task_run(tr_id)
        assert tr.state.is_failed()

    async def test_generator_retries(self):
        """
        Test that a generator can retry and will re-emit its events
        """

        @flow(retries=2)
        def g():
            yield 1
            yield 2
            raise ValueError()

        values = []
        try:
            for v in g():
                values.append(v)
        except ValueError:
            pass
        assert values == [1, 2, 1, 2, 1, 2]

    async def test_generator_timeout(self):
        """
        Test that a generator can timeout
        """

        @flow(timeout_seconds=0.1)
        def g():
            yield 1
            time.sleep(2)
            yield 2

        values = []
        with pytest.raises(TimeoutError):
            for v in g():
                values.append(v)
        assert values == [1]

    async def test_generator_doesnt_retry_on_generator_exception(self):
        """
        Test that a generator doesn't retry for normal generator exceptions like StopIteration
        """

        @flow(retries=2)
        def g():
            yield 1
            yield 2

        values = []
        try:
            for v in g():
                values.append(v)
        except ValueError:
            pass
        assert values == [1, 2]

    async def test_with_default_pydantic_model_dict_params(self):
        class TheModel(pydantic.BaseModel):
            x: list[int]

        @flow
        async def g(required: str, model: TheModel = {"x": [1, 2, 3]}):  # type: ignore
            for i in model.x:
                yield i

        assert [i async for i in g("hello")] == [1, 2, 3]


class TestAsyncGenerators:
    async def test_generator_flow(self):
        """
        Test for generator behavior including StopIteration
        """

        @flow
        async def g():
            yield 1
            yield 2

        counter = 0
        async for val in g():
            if counter == 0:
                assert val == 1
            if counter == 1:
                assert val == 2
            assert counter <= 1
            counter += 1

    async def test_generator_flow_requires_return_type_result(self):
        @flow
        async def g():
            yield 1

        with pytest.raises(
            ValueError, match="The return_type for a generator flow must be 'result'"
        ):
            async for i in g(return_state=True):
                pass

    async def test_generator_flow_states(self, prefect_client: PrefectClient):
        """
        Test for generator behavior including StopIteration
        """

        @flow
        async def g():
            yield FlowRunContext.get().flow_run.id

        async for val in g():
            tr_id = val
            tr = await prefect_client.read_flow_run(tr_id)
            assert tr.state.is_running()

        tr = await prefect_client.read_flow_run(tr_id)
        assert tr.state.is_completed()

    async def test_generator_flow_with_exception(self):
        @flow
        async def g():
            yield 1
            raise ValueError("xyz")

        with pytest.raises(ValueError, match="xyz"):
            async for val in g():
                assert val == 1

    async def test_generator_flow_with_exception_is_failed(
        self, prefect_client: PrefectClient
    ):
        @flow
        async def g():
            yield FlowRunContext.get().flow_run.id
            raise ValueError("xyz")

        with pytest.raises(ValueError, match="xyz"):
            async for val in g():
                tr_id = val

        tr = await prefect_client.read_flow_run(tr_id)
        assert tr.state.is_failed()

    async def test_generator_retries(self):
        """
        Test that a generator can retry and will re-emit its events
        """

        @flow(retries=2)
        async def g():
            yield 1
            yield 2
            raise ValueError()

        values = []
        try:
            async for v in g():
                values.append(v)
        except ValueError:
            pass
        assert values == [1, 2, 1, 2, 1, 2]

    @pytest.mark.xfail(
        reason="Synchronous sleep in an async flow is not interruptible by async timeout"
    )
    async def test_generator_timeout_with_sync_sleep(self):
        """
        Test that a generator can timeout
        """

        @flow(timeout_seconds=0.1)
        async def g():
            yield 1
            time.sleep(2)
            yield 2

        values = []
        with pytest.raises(TimeoutError):
            async for v in g():
                values.append(v)
        assert values == [1]

    async def test_generator_timeout_with_async_sleep(self):
        """
        Test that a generator can timeout
        """

        @flow(timeout_seconds=0.1)
        async def g():
            yield 1
            await asyncio.sleep(2)
            yield 2

        values = []
        with pytest.raises(TimeoutError):
            async for v in g():
                values.append(v)
        assert values == [1]

    async def test_generator_doesnt_retry_on_generator_exception(self):
        """
        Test that a generator doesn't retry for normal generator exceptions like StopIteration
        """

        @flow(retries=2)
        async def g():
            yield 1
            yield 2

        values = []
        try:
            async for v in g():
                values.append(v)
        except ValueError:
            pass
        assert values == [1, 2]

    async def test_with_default_pydantic_model_dict_params(self):
        class TheModel(pydantic.BaseModel):
            x: list[int]

        @flow
        def g(required: str, model: TheModel = {"x": [1, 2, 3]}):  # type: ignore
            yield required
            for i in model.x:
                yield i

        assert [i for i in g("hello")] == ["hello", 1, 2, 3]


class TestLoadFlowAndFlowRun:
    def test_load_flow_from_entrypoint(self, monkeypatch, tmp_path, flow_run):
        flow_code = """
        from prefect import flow

        @flow
        def dog():
            return "woof!"
        """
        fpath = tmp_path / "f.py"
        fpath.write_text(dedent(flow_code))

        monkeypatch.setenv("PREFECT__FLOW_ENTRYPOINT", f"{fpath}:dog")
        loaded_flow_run, flow = load_flow_and_flow_run(flow_run.id)
        assert loaded_flow_run.id == flow_run.id
        assert flow.fn() == "woof!"

    def test_load_flow_from_runtime_entrypoint_converts_plain_function(self, tmp_path):
        flow_code = """
        def dog():
            return "woof!"
        """
        fpath = tmp_path / "f.py"
        fpath.write_text(dedent(flow_code))

        flow = _load_flow_from_runtime_entrypoint(f"{fpath}:dog")

        assert flow.name == "dog"
        assert flow.fn() == "woof!"

    def test_load_flow_from_runtime_entrypoint_supports_module_path(self, tmp_path):
        package = tmp_path / "package"
        package.mkdir()
        (package / "__init__.py").write_text("")
        (package / "flows.py").write_text(
            dedent(
                """
                from prefect import flow

                @flow
                def dog():
                    return "woof!"
                """
            )
        )

        with tmpchdir(tmp_path):
            flow = _load_flow_from_runtime_entrypoint("package.flows:dog")

        assert flow.name == "dog"
        assert flow.fn() == "woof!"

    def test_flow_engine_main_reads_flow_run_id_from_env(self, monkeypatch):
        flow_run_id = uuid.uuid4()
        captured: dict[str, object] = {}

        def run_flow_from_runtime_entrypoint(flow_run_id_arg, entrypoint):
            captured["flow_run_id"] = flow_run_id_arg
            captured["entrypoint"] = entrypoint

        monkeypatch.setenv("PREFECT__FLOW_RUN_ID", str(flow_run_id))
        monkeypatch.setattr(
            "prefect.flow_engine._run_flow_from_runtime_entrypoint",
            run_flow_from_runtime_entrypoint,
        )

        assert _main(["package.flows:dog"]) == 0
        assert captured == {
            "flow_run_id": flow_run_id,
            "entrypoint": "package.flows:dog",
        }

    @pytest.mark.parametrize("argv", [[], ["one", "two"]])
    def test_flow_engine_main_requires_entrypoint_argument(self, monkeypatch, argv):
        run_flow_from_runtime_entrypoint = MagicMock()
        monkeypatch.setenv("PREFECT__FLOW_RUN_ID", str(uuid.uuid4()))
        monkeypatch.setattr(
            "prefect.flow_engine._run_flow_from_runtime_entrypoint",
            run_flow_from_runtime_entrypoint,
        )

        assert _main(argv) == 1
        run_flow_from_runtime_entrypoint.assert_not_called()

    @pytest.mark.parametrize("flow_run_id", [None, "not-a-uuid"])
    def test_flow_engine_main_requires_flow_run_id_env(self, monkeypatch, flow_run_id):
        run_flow_from_runtime_entrypoint = MagicMock()
        if flow_run_id is None:
            monkeypatch.delenv("PREFECT__FLOW_RUN_ID", raising=False)
        else:
            monkeypatch.setenv("PREFECT__FLOW_RUN_ID", flow_run_id)
        monkeypatch.setattr(
            "prefect.flow_engine._run_flow_from_runtime_entrypoint",
            run_flow_from_runtime_entrypoint,
        )

        assert _main(["package.flows:dog"]) == 1
        run_flow_from_runtime_entrypoint.assert_not_called()

    def test_run_flow_from_runtime_entrypoint_runs_loaded_flow(
        self, monkeypatch, flow_run
    ):
        loaded_flow = MagicMock()
        run_logger = MagicMock()
        events: list[object] = []

        @contextmanager
        def run_metrics(flow_run_arg, flow_arg):
            events.append(("metrics-enter", flow_run_arg, flow_arg))
            yield
            events.append("metrics-exit")

        monkeypatch.setattr(
            "prefect.flow_engine.configure_from_env",
            lambda: events.append("configure"),
        )
        monkeypatch.setattr(
            "prefect.flow_engine.load_flow_run", lambda flow_run_id: flow_run
        )
        monkeypatch.setattr(
            "prefect.flow_engine._load_flow_from_runtime_entrypoint",
            lambda entrypoint: loaded_flow,
        )
        monkeypatch.setattr(
            "prefect.flow_engine.flow_run_logger",
            lambda flow_run: run_logger,
        )
        monkeypatch.setattr("prefect.flow_engine.RunMetrics", run_metrics)
        monkeypatch.setattr(
            "prefect.flow_engine.run_flow",
            lambda flow, flow_run, error_logger: "run-result",
        )
        monkeypatch.setattr(
            "prefect.flow_engine._drive_run_flow_result",
            lambda flow, run_result: events.append(("drive", flow, run_result)),
        )

        _run_flow_from_runtime_entrypoint(flow_run.id, "package.flows:dog")

        assert events == [
            "configure",
            ("metrics-enter", flow_run, loaded_flow),
            ("drive", loaded_flow, "run-result"),
            "metrics-exit",
        ]

    async def test_load_flow_from_script_with_module_level_sync_compatible_call(
        self, prefect_client: PrefectClient, tmp_path
    ):
        """
        This test ensures that when a worker or runner loads a flow from a script, and
        that script contains a module-level call to a sync-compatible function, the sync
        compatible function is correctly runs as sync and does not prevent the flow from
        being loaded.

        Regression test for https://github.com/PrefectHQ/prefect/issues/14625
        """
        flow_id = await prefect_client.create_flow_from_name(flow_name="uses_block")
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name="test-load-flow-from-script-with-module-level-sync-compatible-call",
            path=str(__development_base_path__ / "tests" / "test-projects" / "flows"),
            entrypoint="uses_block.py:uses_block",
        )
        api_flow_run = await prefect_client.create_flow_run_from_deployment(
            deployment_id=deployment_id
        )

        with tmpchdir(tmp_path):
            flow_run, flow = load_flow_and_flow_run(api_flow_run.id)

        assert flow_run.id == api_flow_run.id

        assert await flow() == "bar"


class TestConcurrencyRelease:
    async def test_timeout_concurrency_slot_released_sync(
        self, concurrency_limit_v2: ConcurrencyLimitV2, prefect_client: PrefectClient
    ):
        # Use a generous timeout so that the watcher thread does not fire
        # before `run_context` reaches its `yield` while under heavy CI load
        # (the heartbeat-thread setup happens inside the timeout scope and
        # can take a non-trivial amount of time on contended runners).
        @flow(timeout_seconds=2)
        def expensive_flow():
            with concurrency(concurrency_limit_v2.name):
                # Use a time-bounded busy loop instead of time.sleep()
                # because sleep is a C-level call that cannot be interrupted
                # by WatcherThreadCancelScope.
                deadline = time.monotonic() + 30
                while time.monotonic() < deadline:
                    pass

        with pytest.raises(TimeoutError):
            expensive_flow()

        response = await prefect_client.read_global_concurrency_limit_by_name(
            concurrency_limit_v2.name
        )
        assert response.active_slots == 0

    async def test_timeout_concurrency_slot_released_async(
        self, concurrency_limit_v2: ConcurrencyLimitV2, prefect_client: PrefectClient
    ):
        @flow(timeout_seconds=2)
        async def expensive_flow():
            async with aconcurrency(concurrency_limit_v2.name):
                await asyncio.sleep(10)

        with pytest.raises(TimeoutError):
            await expensive_flow()

        response = await prefect_client.read_global_concurrency_limit_by_name(
            concurrency_limit_v2.name
        )
        assert response.active_slots == 0


@pytest.mark.parametrize("engine_type", ["sync", "async"])
class TestRunFlowInSubprocess:
    async def get_flow_run_for_flow(self, flow_name: str):
        async with get_client() as prefect_client:
            flow_runs = await prefect_client.read_flow_runs(
                flow_filter=FlowFilter(name=FlowFilterName(any_=[flow_name]))
            )
        assert len(flow_runs) == 1
        return flow_runs[0]

    async def test_basic(self, engine_type: Literal["sync", "async"]):
        if engine_type == "sync":

            @flow(name=f"test_basic_{uuid.uuid4()}", persist_result=True)
            def foo():
                return 42
        else:

            @flow(name=f"test_basic_{uuid.uuid4()}", persist_result=True)
            async def foo():
                return 42

        process = run_flow_in_subprocess(foo)

        process.join()
        assert process.exitcode == 0
        flow_run = await self.get_flow_run_for_flow(foo.name)

        assert flow_run.state.is_completed()
        assert await flow_run.state.result() == 42

    def test_uses_control_bootstrap_wrapper_before_deserializing_payload(
        self,
        engine_type: Literal["sync", "async"],
        monkeypatch: pytest.MonkeyPatch,
    ):
        captured: dict[str, Any] = {}

        @flow(name=f"control_bootstrap_wrapper_{uuid.uuid4()}")
        def wrapper_target():
            return None

        class _FakeProcess:
            def __init__(self, *, target: Any, args: tuple[Any, ...]) -> None:
                captured["target"] = target
                captured["args"] = args
                self.exitcode = None

            def start(self) -> None:
                captured["started"] = True

        class _FakeContext:
            def Process(self, *, target: Any, args: tuple[Any, ...]) -> _FakeProcess:
                return _FakeProcess(target=target, args=args)

        monkeypatch.setattr(
            "prefect.flow_engine.multiprocessing.get_context",
            lambda method: _FakeContext(),
        )

        def fake_cloudpickle_wrapped_call(fn: Any, **kwargs: Any) -> MagicMock:
            captured["wrapped_env"] = kwargs["env"]
            captured["remove_env"] = kwargs["remove_env"]
            return MagicMock(args=(b"payload",))

        monkeypatch.setattr(
            "prefect.flow_engine.cloudpickle_wrapped_call",
            fake_cloudpickle_wrapped_call,
        )
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(to_environment_variables=MagicMock(return_value={})),
        )
        monkeypatch.setattr("prefect.flow_engine.os.environ", {})

        process = run_flow_in_subprocess(
            wrapper_target,
            env={
                "PREFECT__CONTROL_PORT": "4200",
                "PREFECT__CONTROL_TOKEN": "deadbeef",
                "UNRELATED": "value",
            },
        )

        assert isinstance(process, _FakeProcess)
        assert captured["started"] is True
        assert captured["target"] is _run_serialized_call_with_control_bootstrap
        assert captured["args"][1] == {
            "PREFECT__CONTROL_PORT": "4200",
            "PREFECT__CONTROL_TOKEN": "deadbeef",
        }
        assert captured["remove_env"] == set()
        assert captured["wrapped_env"] == {
            "PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS": "false",
            "UNRELATED": "value",
        }

    def test_run_flow_in_subprocess_marks_none_env_values_for_removal(
        self,
        engine_type: Literal["sync", "async"],
        monkeypatch: pytest.MonkeyPatch,
    ):
        captured: dict[str, Any] = {}

        @flow(name=f"clear_env_wrapper_{uuid.uuid4()}")
        def wrapper_target():
            return None

        class _FakeProcess:
            def __init__(self, *, target: Any, args: tuple[Any, ...]) -> None:
                captured["target"] = target
                captured["args"] = args
                self.exitcode = None

            def start(self) -> None:
                captured["started"] = True

        class _FakeContext:
            def Process(self, *, target: Any, args: tuple[Any, ...]) -> _FakeProcess:
                return _FakeProcess(target=target, args=args)

        monkeypatch.setattr(
            "prefect.flow_engine.multiprocessing.get_context",
            lambda method: _FakeContext(),
        )

        def fake_cloudpickle_wrapped_call(fn: Any, **kwargs: Any) -> MagicMock:
            captured["wrapped_env"] = kwargs["env"]
            captured["remove_env"] = kwargs["remove_env"]
            return MagicMock(args=(b"payload",))

        monkeypatch.setattr(
            "prefect.flow_engine.cloudpickle_wrapped_call",
            fake_cloudpickle_wrapped_call,
        )
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(to_environment_variables=MagicMock(return_value={})),
        )
        monkeypatch.setattr(
            "prefect.flow_engine.os.environ",
            {"PREFECT__DEPLOYMENT_NAME": "stale-deployment"},
        )

        process = run_flow_in_subprocess(
            wrapper_target,
            env={"PREFECT__DEPLOYMENT_NAME": None},
        )

        assert isinstance(process, _FakeProcess)
        assert captured["wrapped_env"] == {
            "PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS": "false"
        }
        assert captured["remove_env"] == {"PREFECT__DEPLOYMENT_NAME"}

    async def test_with_params(self, engine_type: Literal["sync", "async"]):
        if engine_type == "sync":

            @flow(name=f"test_with_params_{uuid.uuid4()}", persist_result=True)
            def bar(x: int, y: Optional[str] = None):
                return x, y
        else:

            @flow(name=f"test_with_params_{uuid.uuid4()}", persist_result=True)
            async def bar(x: int, y: Optional[str] = None):
                return x, y

        parameters = get_call_parameters(bar.fn, (42,), dict(y="nate"))
        process = run_flow_in_subprocess(bar, parameters=parameters)

        process.join()
        assert process.exitcode == 0

        flow_run = await self.get_flow_run_for_flow(bar.name)

        assert flow_run.state.is_completed()
        assert await flow_run.state.result() == (42, "nate")

    async def test_flow_ends_in_failed(self, engine_type: Literal["sync", "async"]):
        if engine_type == "sync":

            @flow(name=f"test_flow_ends_in_failed_{uuid.uuid4()}")
            def foo():
                raise ValueError("xyz")
        else:

            @flow(name=f"test_flow_ends_in_failed_{uuid.uuid4()}")
            async def foo():
                raise ValueError("xyz")

        process = run_flow_in_subprocess(foo)

        process.join()
        assert process.exitcode == 0

        flow_run = await self.get_flow_run_for_flow(foo.name)

        assert flow_run.state.is_failed()

    async def test_tracks_parent_when_run_in_flow(
        self, prefect_client: PrefectClient, engine_type: Literal["sync", "async"]
    ):
        if engine_type == "sync":

            @flow(name=f"child_flow_{uuid.uuid4()}", persist_result=True)
            def child_flow():
                return 42
        else:

            @flow(name=f"child_flow_{uuid.uuid4()}", persist_result=True)
            async def child_flow():
                return 42

        @flow(name=f"parent_flow_{uuid.uuid4()}", persist_result=True)
        def parent_flow():
            process = run_flow_in_subprocess(child_flow)
            process.join()
            return process.exitcode

        assert run_flow(parent_flow) == 0

        parent_flow_run = await self.get_flow_run_for_flow(parent_flow.name)

        child_flow_run = await self.get_flow_run_for_flow(child_flow.name)
        dummy_task_run = await prefect_client.read_task_run(
            child_flow_run.parent_task_run_id
        )

        assert dummy_task_run.flow_run_id == parent_flow_run.id

    async def test_with_provided_context(
        self, prefect_client: PrefectClient, engine_type: Literal["sync", "async"]
    ):
        tags_context = TagsContext(current_tags={"foo", "bar"})

        if engine_type == "sync":

            @flow(
                name=f"test_with_provided_context_{uuid.uuid4()}", persist_result=True
            )
            def foo():
                return TagsContext.get().current_tags
        else:

            @flow(
                name=f"test_with_provided_context_{uuid.uuid4()}", persist_result=True
            )
            async def foo():
                return TagsContext.get().current_tags

        context = {"tags_context": tags_context.serialize()}

        process = run_flow_in_subprocess(foo, context=context)
        process.join()
        assert process.exitcode == 0

        flow_run = await self.get_flow_run_for_flow(foo.name)
        assert flow_run.state.is_completed()
        assert await flow_run.state.result() == {"foo", "bar"}

    async def test_with_provided_flow_run(
        self, engine_type: Literal["sync", "async"], prefect_client: PrefectClient
    ):
        if engine_type == "sync":

            @flow(
                name=f"test_with_provided_flow_run_{uuid.uuid4()}", persist_result=True
            )
            def foo():
                return 42
        else:

            @flow(
                name=f"test_with_provided_flow_run_{uuid.uuid4()}", persist_result=True
            )
            async def foo():
                return 42

        flow_run = await prefect_client.create_flow_run(
            flow=foo,
        )
        process = run_flow_in_subprocess(foo, flow_run=flow_run)
        process.join()
        assert process.exitcode == 0

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_completed()
        assert await flow_run.state.result() == 42

    async def test_flow_is_suspended(
        self, engine_type: Literal["sync", "async"], prefect_client: PrefectClient
    ):
        if engine_type == "sync":

            @flow(name=f"test_flow_is_suspended_{uuid.uuid4()}", persist_result=True)
            def foo():
                suspend_flow_run()
                return 42
        else:

            @flow(name=f"test_flow_is_suspended_{uuid.uuid4()}", persist_result=True)
            async def foo():
                await suspend_flow_run()
                return 42

        flow_id = await prefect_client.create_flow(foo)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_flow_is_suspended_{uuid.uuid4()}",
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)

        process = run_flow_in_subprocess(foo, flow_run)
        process.join()
        assert process.exitcode == 0

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_paused()

    async def test_flow_is_aborted(
        self, engine_type: Literal["sync", "async"], prefect_client: PrefectClient
    ):
        if engine_type == "sync":

            @flow(name=f"test_flow_is_aborted_{uuid.uuid4()}", persist_result=True)
            def foo():
                raise Abort()
        else:

            @flow(name=f"test_flow_is_aborted_{uuid.uuid4()}", persist_result=True)
            async def foo():
                raise Abort()

        flow_id = await prefect_client.create_flow(foo)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_flow_is_suspended_{uuid.uuid4()}",
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)

        process = run_flow_in_subprocess(foo, flow_run)
        process.join()
        assert process.exitcode == 0

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        # Stays in running state because the flow run is aborted manually
        assert flow_run.state.is_running()

    async def test_deployment_parameters_accessible_in_subprocess(
        self, engine_type: Literal["sync", "async"], prefect_client: PrefectClient
    ):
        """Test that deployment.parameters is accessible in subprocess (issue #19329)."""
        deployment_params = {
            "source_name": "ABC",
            "database_export_date": "2025-08-27",
            "bucket_name": "data-migration",
        }

        if engine_type == "sync":

            @flow(name=f"test_deployment_params_{uuid.uuid4()}", persist_result=True)
            def foo(source_name: str, database_export_date: str, bucket_name: str):
                from prefect.runtime import deployment

                return deployment.parameters
        else:

            @flow(name=f"test_deployment_params_{uuid.uuid4()}", persist_result=True)
            async def foo(
                source_name: str, database_export_date: str, bucket_name: str
            ):
                from prefect.runtime import deployment

                return deployment.parameters

        flow_id = await prefect_client.create_flow(foo)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_deployment_params_{uuid.uuid4()}",
            parameters=deployment_params,
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)

        process = run_flow_in_subprocess(foo, flow_run)
        process.join()
        assert process.exitcode == 0

        flow_run = await prefect_client.read_flow_run(flow_run.id)
        assert flow_run.state.is_completed()

        # deployment.parameters should match what we set
        result = await flow_run.state.result()
        assert result == deployment_params

    async def test_flow_raises_a_base_exception(
        self, engine_type: Literal["sync", "async"]
    ):
        if engine_type == "sync":

            @flow(
                name=f"test_flow_raises_a_base_exception_{uuid.uuid4()}",
                persist_result=True,
            )
            def foo():
                raise BaseException()
        else:

            @flow(
                name=f"test_flow_raises_a_base_exception_{uuid.uuid4()}",
                persist_result=True,
            )
            async def foo():
                raise BaseException()

        process = run_flow_in_subprocess(foo)
        process.join()
        assert process.exitcode == 0

        flow_run = await self.get_flow_run_for_flow(foo.name)
        assert flow_run.state.is_crashed()

    async def test_flow_process_is_killed(self, engine_type: Literal["sync", "async"]):
        if engine_type == "sync":

            @flow(
                name=f"test_flow_process_is_killed_{uuid.uuid4()}", persist_result=True
            )
            def foo():
                signal.raise_signal(signal.SIGKILL)
        else:

            @flow(
                name=f"test_flow_process_is_killed_{uuid.uuid4()}", persist_result=True
            )
            async def foo():
                signal.raise_signal(signal.SIGKILL)

        process = run_flow_in_subprocess(foo)
        process.join()
        assert process.exitcode == -9

        flow_run = await self.get_flow_run_for_flow(foo.name)
        # Stays in running state because the process died
        assert flow_run.state.is_running()


class TestLeaseRenewal:
    async def test_no_lease_renewal_sync(
        self, prefect_client: PrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        mock_maintain_concurrency_lease = MagicMock()
        monkeypatch.setattr(
            "prefect.flow_engine.maintain_concurrency_lease",
            mock_maintain_concurrency_lease,
        )

        @flow
        def foo():
            return 42

        flow_id = await prefect_client.create_flow(foo)
        # No limit, no lease
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_lease_renewal_{uuid.uuid4()}",
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)
        assert flow_run.state.is_scheduled()

        state = await propose_state(prefect_client, states.Pending(), flow_run.id)
        assert state.is_pending()

        run_flow(foo, flow_run)

        mock_maintain_concurrency_lease.assert_not_called()

    async def test_no_lease_renewal_async(
        self, prefect_client: PrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        mock_maintain_concurrency_lease = MagicMock()
        mock_maintain_concurrency_lease.return_value.__aenter__ = AsyncMock()
        mock_maintain_concurrency_lease.return_value.__aenter__.return_value.__aexit__ = AsyncMock()
        monkeypatch.setattr(
            "prefect.flow_engine.amaintain_concurrency_lease",
            mock_maintain_concurrency_lease,
        )

        @flow
        async def foo():
            return 42

        flow_id = await prefect_client.create_flow(foo)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_lease_renewal_{uuid.uuid4()}",
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)
        assert flow_run.state.is_scheduled()

        state = await propose_state(prefect_client, states.Pending(), flow_run.id)
        assert state.is_pending()

        await run_flow(foo, flow_run)

        mock_maintain_concurrency_lease.assert_not_called()

    async def test_lease_renewal_sync(
        self, prefect_client: PrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        mock_maintain_concurrency_lease = MagicMock()
        monkeypatch.setattr(
            "prefect.flow_engine.maintain_concurrency_lease",
            mock_maintain_concurrency_lease,
        )

        @flow
        def foo():
            return 42

        flow_id = await prefect_client.create_flow(foo)
        # Lease is created for the limit server-side
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_lease_renewal_{uuid.uuid4()}",
            concurrency_limit=1,
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)
        assert flow_run.state.is_scheduled()

        state = await propose_state(prefect_client, states.Pending(), flow_run.id)
        assert state.is_pending()

        run_flow(foo, flow_run)

        mock_maintain_concurrency_lease.assert_called_once_with(
            ANY, 300, raise_on_lease_renewal_failure=True
        )

    async def test_lease_renewal_async(
        self, prefect_client: PrefectClient, monkeypatch: pytest.MonkeyPatch
    ):
        mock_maintain_concurrency_lease = MagicMock()
        mock_maintain_concurrency_lease.return_value.__aenter__ = AsyncMock()
        mock_maintain_concurrency_lease.return_value.__aenter__.return_value.__aexit__ = AsyncMock()
        monkeypatch.setattr(
            "prefect.flow_engine.amaintain_concurrency_lease",
            mock_maintain_concurrency_lease,
        )

        @flow
        async def foo():
            return 42

        flow_id = await prefect_client.create_flow(foo)
        # Lease is created for the limit server-side
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name=f"test_lease_renewal_{uuid.uuid4()}",
            concurrency_limit=1,
        )

        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)
        assert flow_run.state.is_scheduled()

        state = await propose_state(prefect_client, states.Pending(), flow_run.id)
        assert state.is_pending()

        await run_flow(foo, flow_run)

        mock_maintain_concurrency_lease.assert_called_once_with(
            ANY, 300, raise_on_lease_renewal_failure=True
        )


class TestFlowRunEngineHeartbeat:
    """Tests for heartbeat integration in the flow run engine."""

    def test_heartbeat_context_manager_used_during_flow_execution_sync(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that heartbeat context manager is used during sync flow execution."""
        context_entered = []
        context_exited = []

        @contextmanager
        def mock__send_heartbeats(engine, **kwargs):
            context_entered.append(engine)
            try:
                yield
            finally:
                context_exited.append(engine)

        monkeypatch.setattr(
            "prefect.flow_engine._send_heartbeats", mock__send_heartbeats
        )

        # Set heartbeat_frequency to enable heartbeats
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        @flow
        def my_flow():
            return 42

        result = my_flow()
        assert result == 42

        # Heartbeat context manager should have been entered and exited
        assert len(context_entered) == 1
        assert len(context_exited) == 1
        assert isinstance(context_entered[0], FlowRunEngine)

    async def test_heartbeat_context_manager_used_during_flow_execution_async(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that heartbeat context manager is used during async flow execution."""
        context_entered = []
        context_exited = []

        @contextmanager
        def mock__send_heartbeats(engine, **kwargs):
            context_entered.append(engine)
            try:
                yield
            finally:
                context_exited.append(engine)

        monkeypatch.setattr(
            "prefect.flow_engine._send_heartbeats", mock__send_heartbeats
        )

        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        @flow
        async def my_flow():
            return 42

        result = await my_flow()
        assert result == 42

        assert len(context_entered) == 1
        assert len(context_exited) == 1
        assert isinstance(context_entered[0], AsyncFlowRunEngine)

    def test_heartbeat_not_emitted_when_frequency_is_none_sync(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that heartbeats are not emitted when frequency is None."""
        emitted_events = []

        def mock_emit_event(**kwargs):
            if kwargs.get("event") == "prefect.flow-run.heartbeat":
                emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        # Set heartbeat_frequency to None (disabled)
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=None)),
        )

        @flow
        def my_flow():
            return 42

        result = my_flow()
        assert result == 42

        # No heartbeat events should have been emitted
        assert len(emitted_events) == 0

    async def test_heartbeat_not_emitted_when_frequency_is_none_async(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that heartbeats are not emitted when frequency is None."""
        emitted_events = []

        def mock_emit_event(**kwargs):
            if kwargs.get("event") == "prefect.flow-run.heartbeat":
                emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        # Set heartbeat_frequency to None (disabled)
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=None)),
        )

        @flow
        async def my_flow():
            return 42

        result = await my_flow()
        assert result == 42

        assert len(emitted_events) == 0

    def test_heartbeat_emits_event_sync(self, monkeypatch: pytest.MonkeyPatch):
        """Test that heartbeat actually emits events for sync flows."""
        emitted_events = []

        def mock_emit_event(**kwargs):
            emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        @flow
        def my_flow():
            return 42

        engine = FlowRunEngine(flow=my_flow)

        with engine.initialize_run():
            # Manually call emit to test the method directly
            engine._emit_flow_run_heartbeat()

        assert len(emitted_events) == 1
        assert emitted_events[0]["event"] == "prefect.flow-run.heartbeat"
        assert (
            "prefect.flow-run" in emitted_events[0]["resource"]["prefect.resource.id"]
        )

    async def test_heartbeat_emits_event_async(self, monkeypatch: pytest.MonkeyPatch):
        """Test that heartbeat actually emits events for async flows."""
        emitted_events = []

        def mock_emit_event(**kwargs):
            emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        @flow
        async def my_flow():
            return 42

        engine = AsyncFlowRunEngine(flow=my_flow)

        async with engine.initialize_run():
            engine._emit_flow_run_heartbeat()

        assert len(emitted_events) == 1
        assert emitted_events[0]["event"] == "prefect.flow-run.heartbeat"
        assert (
            "prefect.flow-run" in emitted_events[0]["resource"]["prefect.resource.id"]
        )

    def test_heartbeat_cleanup_on_exception_sync(self, monkeypatch: pytest.MonkeyPatch):
        """Test that heartbeat context manager cleans up even when an exception occurs."""
        context_entered = []
        context_exited = []

        @contextmanager
        def mock__send_heartbeats(engine, **kwargs):
            context_entered.append(engine)
            try:
                yield
            finally:
                context_exited.append(engine)

        monkeypatch.setattr(
            "prefect.flow_engine._send_heartbeats", mock__send_heartbeats
        )

        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        @flow
        def my_flow():
            raise ValueError("test error")

        with pytest.raises(ValueError, match="test error"):
            my_flow()

        # Heartbeat context manager should have been entered and exited (cleanup)
        assert len(context_entered) == 1
        assert len(context_exited) == 1

    async def test_heartbeat_cleanup_on_exception_async(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that heartbeat context manager cleans up even when an exception occurs."""
        context_entered = []
        context_exited = []

        @contextmanager
        def mock__send_heartbeats(engine, **kwargs):
            context_entered.append(engine)
            try:
                yield
            finally:
                context_exited.append(engine)

        monkeypatch.setattr(
            "prefect.flow_engine._send_heartbeats", mock__send_heartbeats
        )

        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        @flow
        async def my_flow():
            raise ValueError("test error")

        with pytest.raises(ValueError, match="test error"):
            await my_flow()

        assert len(context_entered) == 1
        assert len(context_exited) == 1

    def test_heartbeat_includes_flow_related_resource(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that heartbeat event includes flow as related resource."""
        emitted_events = []

        def mock_emit_event(**kwargs):
            emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        @flow
        def my_flow():
            return 42

        engine = FlowRunEngine(flow=my_flow)

        with engine.initialize_run():
            engine._emit_flow_run_heartbeat()

        assert len(emitted_events) == 1
        related = emitted_events[0]["related"]
        flow_related = [r for r in related if r.get("prefect.resource.role") == "flow"]
        assert len(flow_related) == 1
        assert flow_related[0]["prefect.resource.name"] == "my-flow"

    async def test_heartbeat_includes_deployment_related_resource(
        self, monkeypatch: pytest.MonkeyPatch, prefect_client: PrefectClient
    ):
        """Test that heartbeat event includes deployment as related resource when present."""
        emitted_events = []

        def mock_emit_event(**kwargs):
            emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        @flow
        async def my_flow():
            return 42

        # Create a flow run with a deployment
        flow_id = await prefect_client.create_flow(my_flow)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name="test-deployment",
        )
        flow_run = await prefect_client.create_flow_run_from_deployment(deployment_id)

        engine = AsyncFlowRunEngine(flow=my_flow, flow_run=flow_run)

        async with engine.initialize_run():
            engine._emit_flow_run_heartbeat()

        assert len(emitted_events) == 1
        related = emitted_events[0]["related"]
        deployment_related = [
            r for r in related if r.get("prefect.resource.role") == "deployment"
        ]
        assert len(deployment_related) == 1
        assert (
            f"prefect.deployment.{deployment_id}"
            in deployment_related[0]["prefect.resource.id"]
        )

    def test_no_heartbeat_after_terminal_state_sync(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """
        Regression test for https://github.com/PrefectHQ/prefect/issues/19598

        Verifies that the heartbeat context manager checks flow state before
        emitting heartbeats and stops if the state is terminal. This prevents
        the race condition where heartbeats could be emitted after a flow run
        completes, incorrectly triggering zombie flow detection automations.
        """
        heartbeat_state_checks = []

        # Track the original _send_heartbeats to wrap it
        original__send_heartbeats = _send_heartbeats

        @contextmanager
        def tracking__send_heartbeats(engine, **kwargs):
            # Record state when entering context
            heartbeat_state_checks.append(
                ("enter", engine.flow_run.state.type if engine.flow_run else None)
            )
            with original__send_heartbeats(engine):
                yield
            # Record state when exiting context
            heartbeat_state_checks.append(
                ("exit", engine.flow_run.state.type if engine.flow_run else None)
            )

        monkeypatch.setattr(
            "prefect.flow_engine._send_heartbeats", tracking__send_heartbeats
        )

        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        @flow
        def my_flow():
            return 42

        result = my_flow()
        assert result == 42

        # Context manager should have been entered and exited
        assert len(heartbeat_state_checks) >= 2
        # The context manager should exit when the flow completes
        exit_states = [s for action, s in heartbeat_state_checks if action == "exit"]
        assert any(
            state_type in (StateType.COMPLETED, StateType.FAILED, StateType.CANCELLED)
            for state_type in exit_states
            if state_type is not None
        )

    async def test_no_heartbeat_after_terminal_state_async(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """
        Regression test for https://github.com/PrefectHQ/prefect/issues/19598

        Async version: Verifies that the heartbeat context manager checks flow
        state before emitting heartbeats and stops if the state is terminal.
        """
        heartbeat_state_checks = []

        # Track the original _send_heartbeats to wrap it
        original__send_heartbeats = _send_heartbeats

        @contextmanager
        def tracking__send_heartbeats(engine, **kwargs):
            # Record state when entering context
            heartbeat_state_checks.append(
                ("enter", engine.flow_run.state.type if engine.flow_run else None)
            )
            with original__send_heartbeats(engine):
                yield
            # Record state when exiting context
            heartbeat_state_checks.append(
                ("exit", engine.flow_run.state.type if engine.flow_run else None)
            )

        monkeypatch.setattr(
            "prefect.flow_engine._send_heartbeats", tracking__send_heartbeats
        )

        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        @flow
        async def my_flow():
            return 42

        result = await my_flow()
        assert result == 42

        assert len(heartbeat_state_checks) >= 2
        exit_states = [s for action, s in heartbeat_state_checks if action == "exit"]
        assert any(
            state_type in (StateType.COMPLETED, StateType.FAILED, StateType.CANCELLED)
            for state_type in exit_states
            if state_type is not None
        )

    @pytest.mark.parametrize("low_value", [1, 5, 10, 29])
    def test_heartbeat_seconds_property_clamps_low_values(
        self, monkeypatch: pytest.MonkeyPatch, low_value: int
    ):
        """Test that the heartbeat_seconds property clamps values below the minimum."""
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=low_value)),
        )

        engine = FlowRunEngine(flow=flow(lambda: None))
        assert engine.heartbeat_seconds == MINIMUM_HEARTBEAT_INTERVAL

    def test_heartbeat_seconds_property_allows_values_at_or_above_minimum(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that values at or above the minimum are not clamped."""
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=60)),
        )

        engine = FlowRunEngine(flow=flow(lambda: None))
        assert engine.heartbeat_seconds == 60

    def test_heartbeat_seconds_property_returns_none_when_disabled(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Test that None is returned when heartbeat is disabled."""
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=None)),
        )

        engine = FlowRunEngine(flow=flow(lambda: None))
        assert engine.heartbeat_seconds is None

    def test__send_heartbeats_clamps_low_values(self, monkeypatch: pytest.MonkeyPatch):
        """Test that _send_heartbeats clamps heartbeat_seconds below the minimum."""
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=5)),
        )

        engine = FlowRunEngine(flow=flow(lambda: None))

        with (
            mock.patch("prefect.flow_engine.threading.Event") as mock_event,
            mock.patch("prefect.flow_engine.threading.Thread"),
        ):
            mock_event.return_value.is_set.return_value = False
            with _send_heartbeats(engine):
                pass

        # The heartbeat_seconds used in the function should be clamped
        assert engine.heartbeat_seconds == MINIMUM_HEARTBEAT_INTERVAL

    def test_build_heartbeat_event_template(self, monkeypatch: pytest.MonkeyPatch):
        """Test that _build_heartbeat_event_template returns correct resource/related."""
        emitted_events: list[dict[str, object]] = []

        def mock_emit_event(**kwargs: object) -> None:
            emitted_events.append(kwargs)

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)

        @flow
        def my_flow():
            return 42

        engine = FlowRunEngine(flow=my_flow)

        with engine.initialize_run():
            resource, related = engine._build_heartbeat_event_template()

            assert "prefect.flow-run" in resource["prefect.resource.id"]
            assert resource["prefect.resource.name"] == engine.flow_run.name or ""

            flow_related = [
                r for r in related if r.get("prefect.resource.role") == "flow"
            ]
            assert len(flow_related) == 1
            assert flow_related[0]["prefect.resource.name"] == "my-flow"

    def test_async_heartbeats_fire_when_event_loop_blocked(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        """Heartbeats use a daemon thread, so they fire even when the event loop is blocked.

        This is the core fix for issue #20887: CPU-bound async flows previously
        starved the asyncio-based heartbeat task.
        """
        heartbeat_count = 0

        def mock_emit_event(**kwargs: object) -> None:
            nonlocal heartbeat_count
            if kwargs.get("event") == "prefect.flow-run.heartbeat":
                heartbeat_count += 1

        monkeypatch.setattr("prefect.flow_engine.emit_event", mock_emit_event)
        monkeypatch.setattr(
            "prefect.flow_engine.get_current_settings",
            lambda: MagicMock(flows=MagicMock(heartbeat_frequency=30)),
        )

        engine = FlowRunEngine(flow=flow(lambda: None))

        with engine.initialize_run():
            with _send_heartbeats(engine):
                # Block the current thread for 3 seconds — simulates a
                # CPU-bound task that would starve an asyncio heartbeat task.
                # The daemon thread should still emit at least one heartbeat.
                time.sleep(3)

        assert heartbeat_count >= 1
