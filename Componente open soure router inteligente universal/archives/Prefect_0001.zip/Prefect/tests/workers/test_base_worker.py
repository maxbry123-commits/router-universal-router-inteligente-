from __future__ import annotations

import asyncio
import base64
import copy
import logging
import sys
import uuid
from datetime import timedelta
from pathlib import Path
from typing import Any, Dict, Optional, Type
from unittest import mock
from unittest.mock import ANY, AsyncMock, MagicMock, Mock

import anyio.abc
import cloudpickle
import httpx
import orjson
import pytest
import respx
from exceptiongroup import ExceptionGroup
from pydantic import Field
from sqlalchemy.ext.asyncio import AsyncSession
from starlette import status
from websockets.exceptions import ConnectionClosedError, InvalidStatus
from websockets.frames import Close

import prefect
import prefect.client.schemas as schemas
from prefect._internal.compatibility.deprecated import PrefectDeprecationWarning
from prefect._internal.result_records import ResultRecord, ResultRecordMetadata
from prefect._internal.testing import retry_asserts
from prefect._internal.uuid7 import uuid7
from prefect.blocks.core import Block
from prefect.client.base import ServerType
from prefect.client.orchestration import PrefectClient, get_client
from prefect.client.schemas.actions import WorkPoolCreate
from prefect.client.schemas.objects import (
    Flow,
    FlowRun,
    Integration,
    StateType,
    WorkerMetadata,
    WorkPool,
    WorkPoolStorageConfiguration,
    WorkQueue,
)
from prefect.client.schemas.worker_channel import (
    WORK_POOL_SNAPSHOT_CAPABILITY,
    WORK_POOL_WORKER_CHANNEL_VERSION,
    WORKER_CHANNEL_SUBPROTOCOL,
    WORKER_HEARTBEAT_CAPABILITY,
    WorkerChannelCloseReason,
    WorkerReadyFrame,
    WorkPoolSnapshotPayload,
)
from prefect.context import FlowRunContext, TagsContext
from prefect.exceptions import (
    CrashedRun,
    ObjectAlreadyExists,
    ObjectNotFound,
)
from prefect.filesystems import WritableFileSystem
from prefect.flows import bind_flow_to_infrastructure, flow
from prefect.futures import PrefectFlowRunFuture
from prefect.serializers import PickleSerializer
from prefect.server import models
from prefect.server.schemas.actions import WorkPoolUpdate as ServerWorkPoolUpdate
from prefect.server.schemas.core import Deployment
from prefect.server.schemas.responses import DeploymentResponse
from prefect.settings import (
    PREFECT_API_URL,
    PREFECT_RESULTS_PERSIST_BY_DEFAULT,
    PREFECT_TEST_MODE,
    PREFECT_WORKER_DEBUG_MODE,
    PREFECT_WORKER_ENABLE_CANCELLATION,
    get_current_settings,
    temporary_settings,
)
from prefect.states import (
    Completed,
    Failed,
    Pending,
    Running,
    Scheduled,
    State,
)
from prefect.types._datetime import now as now_fn
from prefect.types._datetime import travel_to
from prefect.utilities.processutils import command_to_string
from prefect.utilities.pydantic import parse_obj_as
from prefect.workers._worker_channel import (
    WorkerChannelError,
    WorkerChannelRetryableError,
    WorkerChannelSession,
    WorkerChannelState,
    WorkerChannelStatus,
    WorkerChannelTerminalError,
    WorkPoolSnapshotState,
    WorkPoolWorkerChannel,
)
from prefect.workers._worker_channel._protocol import WorkerChannelProtocolHandler
from prefect.workers._worker_channel._transport import (
    WorkerChannelTransport,
    build_worker_channel_url,
)
from prefect.workers.base import (
    BaseJobConfiguration,
    BaseVariables,
    BaseWorker,
    BaseWorkerResult,
)

pytestmark = [pytest.mark.usefixtures("asserting_events_worker"), pytest.mark.clear_db]


class WorkerTestImpl(BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]):
    type: str = "test"
    job_configuration: Type[BaseJobConfiguration] = BaseJobConfiguration

    async def run(self):
        pass


class FakeResultStorageBlock(WritableFileSystem):
    place: str = Field(default="test-place")

    async def read_path(self, path: str) -> bytes:
        return base64.b64encode(cloudpickle.dumps("Here you go chief!"))

    async def write_path(self, path: str, content: bytes) -> None:
        print("What do you expect me to do with this?")


@pytest.fixture(autouse=True)
async def ensure_default_agent_pool_exists(session: AsyncSession):
    # The default agent work pool is created by a migration, but is cleared on
    # consecutive test runs. This fixture ensures that the default agent work
    # pool exists before each test.
    default_work_pool = await models.workers.read_work_pool_by_name(
        session=session, work_pool_name=models.workers.DEFAULT_AGENT_WORK_POOL_NAME
    )
    if default_work_pool is None:
        await models.workers.create_work_pool(
            session=session,
            work_pool=WorkPool(
                name=models.workers.DEFAULT_AGENT_WORK_POOL_NAME, type="prefect-agent"
            ),
        )
        await session.commit()


@pytest.fixture
async def variables(prefect_client: PrefectClient):
    await prefect_client._client.post(
        "/variables/", json={"name": "test_variable_1", "value": "test_value_1"}
    )
    await prefect_client._client.post(
        "/variables/", json={"name": "test_variable_2", "value": "test_value_2"}
    )


@pytest.fixture
def no_api_url():
    with temporary_settings(updates={PREFECT_TEST_MODE: False, PREFECT_API_URL: None}):
        yield


@pytest.fixture
def worker_channel_endpoint_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    async def endpoint_unavailable(
        self: WorkerChannelTransport, handshake: Any
    ) -> WorkerChannelSession:
        raise WorkerChannelTerminalError(
            "endpoint_unavailable",
            "Worker channel endpoint is unavailable",
        )

    monkeypatch.setattr(
        WorkerChannelTransport,
        "connect_once",
        endpoint_unavailable,
    )


@pytest.mark.usefixtures("no_api_url")
async def test_worker_requires_api_url_when_not_in_test_mode():
    with pytest.raises(ValueError, match="PREFECT_API_URL"):
        async with WorkerTestImpl(
            name="test",
            work_pool_name="test-work-pool",
        ):
            pass


class TestStartupWhenTheAPIIsUnreachable:
    @pytest.fixture
    def connect_error(self) -> httpx.ConnectError:
        return httpx.ConnectError("All connection attempts failed")

    async def test_setup_continues_when_the_api_is_unreachable(
        self,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
        connect_error: httpx.ConnectError,
    ):
        monkeypatch.setattr(
            WorkerTestImpl, "sync_with_backend", AsyncMock(side_effect=connect_error)
        )

        async with WorkerTestImpl(
            name="test", work_pool_name="test-work-pool"
        ) as worker:
            assert worker.is_setup
            assert not worker._has_successfully_synced

        assert "Unable to reach the Prefect API while starting up" in caplog.text

    async def test_setup_fails_for_non_transient_errors(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        request = httpx.Request("GET", "https://api.prefect.io/work_pools/test")
        unauthorized = httpx.HTTPStatusError(
            "Unauthorized",
            request=request,
            response=httpx.Response(401, request=request),
        )
        monkeypatch.setattr(
            WorkerTestImpl, "sync_with_backend", AsyncMock(side_effect=unauthorized)
        )

        with pytest.raises(httpx.HTTPStatusError):
            async with WorkerTestImpl(name="test", work_pool_name="test-work-pool"):
                pass

    async def test_polling_waits_for_a_complete_sync(
        self,
        monkeypatch: pytest.MonkeyPatch,
        connect_error: httpx.ConnectError,
        work_pool: WorkPool,
        worker_channel_endpoint_unavailable: None,
    ):
        heartbeat = AsyncMock(side_effect=[connect_error, None])
        monkeypatch.setattr(PrefectClient, "send_worker_heartbeat", heartbeat)
        get_scheduled_flow_runs = AsyncMock(return_value=[])

        async with WorkerTestImpl(name="test", work_pool_name=work_pool.name) as worker:
            monkeypatch.setattr(
                worker, "_get_scheduled_flow_runs", get_scheduled_flow_runs
            )

            # Reading the work pool succeeded before the heartbeat failed, so the
            # snapshot alone cannot be used as the worker's readiness signal.
            assert worker._work_pool is not None
            assert not worker._has_successfully_synced
            assert await worker.get_and_submit_flow_runs() == []
            get_scheduled_flow_runs.assert_not_awaited()

            await worker.sync_with_backend()

            assert worker._has_successfully_synced
            assert await worker.get_and_submit_flow_runs() == []
            get_scheduled_flow_runs.assert_awaited_once()

    async def test_worker_recovers_and_initializes_sync_dependent_services(
        self,
        monkeypatch: pytest.MonkeyPatch,
        connect_error: httpx.ConnectError,
        prefect_client: PrefectClient,
        worker_deployment_wq1: Deployment,
        work_pool: WorkPool,
        worker_channel_endpoint_unavailable: None,
    ):
        send_worker_heartbeat = PrefectClient.send_worker_heartbeat
        allow_recovery = anyio.Event()
        retry_started = anyio.Event()
        worker_started = anyio.Event()
        run_submitted = anyio.Event()
        observer_setup_started = anyio.Event()
        allow_observer_setup = anyio.Event()
        heartbeat_attempts = 0

        async def flaky_heartbeat(
            client: PrefectClient,
            work_pool_name: str,
            worker_name: str,
            heartbeat_interval_seconds: float | None = None,
            get_worker_id: bool = False,
            worker_metadata: WorkerMetadata | None = None,
        ) -> uuid.UUID | None:
            nonlocal heartbeat_attempts
            heartbeat_attempts += 1
            if heartbeat_attempts == 1:
                raise connect_error

            retry_started.set()
            await allow_recovery.wait()
            return await send_worker_heartbeat(
                client,
                work_pool_name=work_pool_name,
                worker_name=worker_name,
                heartbeat_interval_seconds=heartbeat_interval_seconds,
                get_worker_id=get_worker_id,
                worker_metadata=worker_metadata,
            )

        monkeypatch.setattr(PrefectClient, "send_worker_heartbeat", flaky_heartbeat)

        await prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id,
            state=Scheduled(scheduled_time=now_fn("UTC") - timedelta(seconds=1)),
        )

        async def run_flow_run(
            flow_run: FlowRun,
            configuration: BaseJobConfiguration,
            task_status: anyio.abc.TaskStatus[int] | None = None,
        ) -> BaseWorkerResult:
            run_submitted.set()
            return BaseWorkerResult(identifier=str(flow_run.id), status_code=0)

        def printer(message: str) -> None:
            if message.endswith("started!"):
                worker_started.set()

        worker = WorkerTestImpl(
            name="test",
            work_pool_name=work_pool.name,
            heartbeat_interval_seconds=1,
        )
        worker.run = AsyncMock(side_effect=run_flow_run)
        setup_cancellation_observer = worker._setup_cancellation_observer

        async def gated_cancellation_observer_setup() -> None:
            observer_setup_started.set()
            await allow_observer_setup.wait()
            await setup_cancellation_observer()

        monkeypatch.setattr(
            worker,
            "_setup_cancellation_observer",
            gated_cancellation_observer_setup,
        )

        async def start_worker() -> None:
            await worker.start(run_once=True, printer=printer)

        with temporary_settings(updates={PREFECT_WORKER_ENABLE_CANCELLATION: True}):
            async with anyio.create_task_group() as task_group:
                task_group.start_soon(start_worker)

                with anyio.fail_after(5):
                    await retry_started.wait()
                    await worker_started.wait()

                assert worker.is_setup
                assert worker._work_pool is not None
                assert not worker._has_successfully_synced
                assert worker._cancelling_observer is None
                assert not run_submitted.is_set()

                allow_recovery.set()

                with anyio.fail_after(5):
                    await observer_setup_started.wait()

                assert not worker._has_successfully_synced
                assert worker._cancelling_observer is None
                assert await worker.get_and_submit_flow_runs() == []
                assert not run_submitted.is_set()

                allow_observer_setup.set()

                with anyio.fail_after(5):
                    await run_submitted.wait()

                assert worker._has_successfully_synced
                assert worker._cancelling_observer is not None

    async def test_sustained_sync_failures_stop_the_worker(
        self,
        monkeypatch: pytest.MonkeyPatch,
        connect_error: httpx.ConnectError,
    ):
        monkeypatch.setattr(
            WorkerTestImpl, "sync_with_backend", AsyncMock(side_effect=connect_error)
        )

        def no_wait_interval(interval: float, clamping_factor: float) -> float:
            del interval, clamping_factor
            return 0

        monkeypatch.setattr(
            "prefect.utilities.services.clamped_poisson_interval",
            no_wait_interval,
        )
        worker = WorkerTestImpl(
            name="test",
            work_pool_name="test-work-pool",
            heartbeat_interval_seconds=1,
        )

        with anyio.fail_after(5):
            with pytest.raises(ExceptionGroup) as exc_info:
                await worker.start()

        assert len(exc_info.value.exceptions) == 1
        service_error = exc_info.value.exceptions[0]
        assert isinstance(service_error, RuntimeError)
        assert str(service_error) == "Service exceeded error threshold."


async def test_worker_creates_work_pool_by_default_during_sync(
    prefect_client: PrefectClient,
):
    with pytest.raises(ObjectNotFound):
        await prefect_client.read_work_pool("test-work-pool")

    async with WorkerTestImpl(
        name="test",
        work_pool_name="test-work-pool",
    ) as worker:
        await worker.sync_with_backend()
        worker_status = worker.get_status()
        assert worker_status["work_pool"]["name"] == "test-work-pool"

        work_pool = await prefect_client.read_work_pool("test-work-pool")
        assert str(work_pool.id) == worker_status["work_pool"]["id"]


async def test_worker_does_not_creates_work_pool_when_create_pool_is_false(
    prefect_client: PrefectClient,
):
    with pytest.raises(ObjectNotFound):
        await prefect_client.read_work_pool("test-work-pool")

    async with WorkerTestImpl(
        name="test", work_pool_name="test-work-pool", create_pool_if_not_found=False
    ) as worker:
        await worker.sync_with_backend()
        worker_status = worker.get_status()
        assert worker_status["work_pool"] is None

    with pytest.raises(ObjectNotFound):
        await prefect_client.read_work_pool("test-work-pool")


async def test_worker_respects_prefetch_seconds():
    assert (
        WorkerTestImpl(name="test", work_pool_name="test-work-pool").get_status()[
            "settings"
        ]["prefetch_seconds"]
        == get_current_settings().worker.prefetch_seconds
    )


async def test_worker_respects_a_prefetch_seconds_of_zero():
    """0 means no lookahead, and the CLI resolves it with an is-None check, so the
    worker must not fall back to the setting default."""
    worker = WorkerTestImpl(
        name="test", work_pool_name="test-work-pool", prefetch_seconds=0
    )
    assert worker.get_status()["settings"]["prefetch_seconds"] == 0


async def test_worker_sends_heartbeat_messages(
    prefect_client: PrefectClient,
    worker_channel_endpoint_unavailable: None,
):
    async with WorkerTestImpl(name="test", work_pool_name="test-work-pool") as worker:
        await worker.sync_with_backend()

        workers = await prefect_client.read_workers_for_work_pool(
            work_pool_name="test-work-pool"
        )
        assert len(workers) == 1
        first_heartbeat = workers[0].last_heartbeat_time
        assert first_heartbeat is not None

        await worker.sync_with_backend()

        workers = await prefect_client.read_workers_for_work_pool(
            work_pool_name="test-work-pool"
        )
        second_heartbeat = workers[0].last_heartbeat_time
        assert second_heartbeat > first_heartbeat


async def test_worker_sends_heartbeat_gets_id(
    respx_mock: respx.MockRouter,
    worker_channel_endpoint_unavailable: None,
):
    work_pool_name = "test-work-pool"
    test_worker_id = uuid.UUID("028EC481-5899-49D7-B8C5-37A2726E9840")
    # Pass through the non-relevant paths
    respx_mock.get(f"api/work_pools/{work_pool_name}").pass_through()
    respx_mock.get("api/csrf-token?").pass_through()
    respx_mock.post("api/work_pools/").pass_through()
    respx_mock.patch(f"api/work_pools/{work_pool_name}").pass_through()

    respx_mock.post(
        f"api/work_pools/{work_pool_name}/workers/heartbeat",
    ).mock(return_value=httpx.Response(status.HTTP_200_OK, text=str(test_worker_id)))
    async with WorkerTestImpl(name="test", work_pool_name=work_pool_name) as worker:
        worker._client.server_type = ServerType.CLOUD

        await worker.sync_with_backend()

        assert worker.backend_id == test_worker_id


async def test_worker_sends_heartbeat_only_gets_id_once(
    worker_channel_endpoint_unavailable: None,
):
    async with WorkerTestImpl(name="test", work_pool_name="test-work-pool") as worker:
        worker._client.server_type = ServerType.CLOUD
        mock = AsyncMock(return_value="test")
        setattr(worker._client, "send_worker_heartbeat", mock)
        await worker.sync_with_backend()
        await worker.sync_with_backend()

        second_call = mock.await_args_list[1]

        assert worker.backend_id == "test"
        assert not second_call.kwargs["get_worker_id"]


async def test_worker_with_work_pool(
    prefect_client: PrefectClient, worker_deployment_wq1: WorkQueue, work_pool: WorkPool
):
    @flow
    def test_flow():
        pass

    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    flow_runs = [
        await create_run_with_deployment(Pending()),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=20))
        ),
        await create_run_with_deployment(Running()),
        await create_run_with_deployment(Completed()),
        await prefect_client.create_flow_run(test_flow, state=Scheduled()),
    ]
    flow_run_ids = [run.id for run in flow_runs]

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        submitted_flow_runs = await worker.get_and_submit_flow_runs()

    # Should only include scheduled runs in the past or next prefetch seconds
    # Should not include runs without deployments
    assert {flow_run.id for flow_run in submitted_flow_runs} == set(flow_run_ids[1:4])


async def test_worker_with_work_pool_and_work_queue(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    worker_deployment_wq_2: WorkQueue,
    work_queue_1: WorkQueue,
    work_pool: WorkPool,
):
    @flow
    def test_flow():
        pass

    def create_run_with_deployment_1(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    def create_run_with_deployment_2(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq_2.id, state=state
        )

    flow_runs = [
        await create_run_with_deployment_1(Pending()),
        await create_run_with_deployment_1(
            Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
        ),
        await create_run_with_deployment_1(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment_2(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment_2(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=20))
        ),
        await create_run_with_deployment_1(Running()),
        await create_run_with_deployment_1(Completed()),
        await prefect_client.create_flow_run(test_flow, state=Scheduled()),
    ]
    flow_run_ids = [run.id for run in flow_runs]

    async with WorkerTestImpl(
        work_pool_name=work_pool.name, work_queues=[work_queue_1.name]
    ) as worker:
        submitted_flow_runs = await worker.get_and_submit_flow_runs()

    assert {flow_run.id for flow_run in submitted_flow_runs} == set(flow_run_ids[1:3])


async def test_workers_do_not_submit_flow_runs_awaiting_retry(
    prefect_client: PrefectClient,
    work_queue_1: WorkQueue,
    work_pool: WorkPool,
):
    """
    Regression test for https://github.com/PrefectHQ/prefect/issues/15458

    Ensure that flows in `AwaitingRetry` state are not submitted by workers. Previously,
    with a retry delay long enough, workers would pick up flow runs in `AwaitingRetry`
    state and submit them, even though the process they were initiated from is responsible
    for retrying them.

    The flows would be picked up by the worker because `AwaitingRetry` is a `SCHEDULED`
    state type.

    This test goes through the following steps:
        - Create a flow
        - Create a deployment for the flow
        - Create a flow run for the deployment
        - Set the flow run to `Running`
        - Set the flow run to failed
            - The server will reject this transition and put the flow run in an `AwaitingRetry` state
        - Have the worker pick up any available flow runs to make sure that the flow run in `AwaitingRetry` state
            is not picked up by the worker
    """

    @flow(retries=2)
    def test_flow():
        pass

    flow_id = await prefect_client.create_flow(
        flow=test_flow,
    )
    deployment_id = await prefect_client.create_deployment(
        flow_id=flow_id,
        name="test-deployment",
        work_queue_name=work_queue_1.name,
        work_pool_name=work_pool.name,
    )
    flow_run = await prefect_client.create_flow_run_from_deployment(
        deployment_id, state=Running()
    )
    # Need to update empirical policy so the server is aware of the retries
    flow_run.empirical_policy.retries = 2
    await prefect_client.update_flow_run(
        flow_run_id=flow_run.id,
        flow_version=test_flow.version,
        empirical_policy=flow_run.empirical_policy,
    )
    # Set the flow run to failed
    response = await prefect_client.set_flow_run_state(flow_run.id, state=Failed())
    # The transition should be rejected and the flow run should be in `AwaitingRetry` state
    assert response.state is not None, "State should not be None"
    assert response.state.name == "AwaitingRetry"
    assert response.state.type == StateType.SCHEDULED

    flow_run = await prefect_client.read_flow_run(flow_run.id)
    # Check to ensure that the flow has a scheduled time earlier than now to rule out
    # that the worker doesn't pick up the flow run due to its scheduled time being in the future
    assert (
        flow_run.state
        and flow_run.state.state_details
        and flow_run.state.state_details.scheduled_time
    )
    assert flow_run.state.state_details.scheduled_time < now_fn("UTC")

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        submitted_flow_runs = await worker.get_and_submit_flow_runs()

    assert submitted_flow_runs == []


async def test_priority_trumps_lateness(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    worker_deployment_wq_2: WorkQueue,
    work_queue_1: WorkQueue,
    work_pool: WorkPool,
):
    @flow
    def test_flow():
        pass

    def create_run_with_deployment_1(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    def create_run_with_deployment_2(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq_2.id, state=state
        )

    flow_runs = [
        await create_run_with_deployment_2(
            Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
        ),
        await create_run_with_deployment_1(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
    ]
    flow_run_ids = [run.id for run in flow_runs]

    async with WorkerTestImpl(work_pool_name=work_pool.name, limit=1) as worker:
        worker._submit_run = AsyncMock()  # don't run anything
        submitted_flow_runs = await worker.get_and_submit_flow_runs()

    assert {flow_run.id for flow_run in submitted_flow_runs} == set(flow_run_ids[1:2])


async def test_worker_releases_limit_slot_when_aborting_a_change_to_pending(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    work_pool: WorkPool,
):
    """Regression test for https://github.com/PrefectHQ/prefect/issues/15952"""

    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    flow_run = await create_run_with_deployment(
        Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
    )

    run_mock = AsyncMock()
    release_mock = Mock()

    async with WorkerTestImpl(work_pool_name=work_pool.name, limit=1) as worker:
        worker.run = run_mock
        worker._propose_pending_state = AsyncMock(return_value=False)
        worker._release_limit_slot = release_mock

        await worker.get_and_submit_flow_runs()

    run_mock.assert_not_called()
    release_mock.assert_called_once_with(flow_run.id)


async def test_worker_handles_double_release_gracefully(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    work_pool: WorkPool,
):
    """Regression test for https://github.com/PrefectHQ/prefect/issues/19157"""

    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    flow_run = await create_run_with_deployment(
        Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
    )

    async with WorkerTestImpl(work_pool_name=work_pool.name, limit=1) as worker:
        worker.run = AsyncMock(side_effect=Exception("Docker API error"))
        worker._work_pool = work_pool

        # Attempt to submit the flow run - should handle double-release gracefully
        await worker.get_and_submit_flow_runs()

    # After exiting the context, all tasks should be complete and token released
    # Verify the flow run ended up in a crashed state
    updated_flow_run = await prefect_client.read_flow_run(flow_run.id)
    assert updated_flow_run.state is not None
    assert updated_flow_run.state.is_crashed()


async def test_worker_with_work_pool_and_limit(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    work_pool: WorkPool,
):
    @flow
    def test_flow():
        pass

    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    flow_runs = [
        await create_run_with_deployment(Pending()),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=20))
        ),
        await create_run_with_deployment(Running()),
        await create_run_with_deployment(Completed()),
        await prefect_client.create_flow_run(test_flow, state=Scheduled()),
    ]
    flow_run_ids = [run.id for run in flow_runs]

    async with WorkerTestImpl(work_pool_name=work_pool.name, limit=2) as worker:
        worker._submit_run = AsyncMock()  # don't run anything

        submitted_flow_runs = await worker.get_and_submit_flow_runs()
        assert {flow_run.id for flow_run in submitted_flow_runs} == set(
            flow_run_ids[1:3]
        )

        submitted_flow_runs = await worker.get_and_submit_flow_runs()
        assert {flow_run.id for flow_run in submitted_flow_runs} == set(
            flow_run_ids[1:3]
        )

        worker._limiter.release_on_behalf_of(flow_run_ids[1])

        submitted_flow_runs = await worker.get_and_submit_flow_runs()
        assert {flow_run.id for flow_run in submitted_flow_runs} == set(
            flow_run_ids[1:4]
        )


async def test_worker_calls_run_with_expected_arguments(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    work_pool: WorkPool,
):
    run_mock = AsyncMock()

    @flow
    def test_flow():
        pass

    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    flow_runs = [
        await create_run_with_deployment(Pending()),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
        ),
        await create_run_with_deployment(
            Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=20))
        ),
        await create_run_with_deployment(Running()),
        await create_run_with_deployment(Completed()),
        await prefect_client.create_flow_run(test_flow, state=Scheduled()),
    ]

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        worker._work_pool = work_pool
        worker.run = run_mock  # don't run anything
        await worker.get_and_submit_flow_runs()

    assert run_mock.call_count == 3
    assert {call.kwargs["flow_run"].id for call in run_mock.call_args_list} == {
        fr.id for fr in flow_runs[1:4]
    }


async def test_worker_creates_only_one_client_context(
    prefect_client: PrefectClient,
    worker_deployment_wq1: WorkQueue,
    work_pool: WorkPool,
    monkeypatch: pytest.MonkeyPatch,
):
    tracking_mock = MagicMock()
    orig_get_client = get_client

    def get_client_spy(*args: Any, **kwargs: Any):
        tracking_mock(*args, **kwargs)
        return orig_get_client(*args, **kwargs)

    monkeypatch.setattr("prefect.workers.base.get_client", get_client_spy)

    run_mock = AsyncMock()

    @flow
    def test_flow():
        pass

    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    await create_run_with_deployment(
        Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
    )
    await create_run_with_deployment(
        Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
    )
    await create_run_with_deployment(
        Scheduled(scheduled_time=now_fn("UTC") + timedelta(seconds=5))
    )

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        worker._work_pool = work_pool
        worker.run = run_mock  # don't run anything
        await worker.get_and_submit_flow_runs()

    assert tracking_mock.call_count == 1


async def test_base_worker_gets_job_configuration_when_syncing_with_backend_with_just_job_config(
    session: AsyncSession,
    client: PrefectClient,
):
    """We don't really care how this happens as long as the worker winds up with a worker pool
    with a correct base_job_template when creating a new work pool"""

    class WorkerJobConfig(BaseJobConfiguration):
        other: Optional[str] = Field(
            default=None, json_schema_extra={"template": "{{ other }}"}
        )

    # Add a job configuration for the worker (currently used to create template
    # if not found on the worker pool)
    WorkerTestImpl.job_configuration = WorkerJobConfig

    expected_job_template = {
        "job_configuration": {
            "command": "{{ command }}",
            "env": "{{ env }}",
            "labels": "{{ labels }}",
            "name": "{{ name }}",
            "other": "{{ other }}",
        },
        "variables": {
            "properties": {
                "command": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                    "title": "Command",
                    "description": (
                        "The command to use when starting a flow run. "
                        "In most cases, this should be left blank and the command "
                        "will be automatically generated by the worker."
                    ),
                },
                "env": {
                    "title": "Environment Variables",
                    "type": "object",
                    "additionalProperties": {
                        "anyOf": [{"type": "string"}, {"type": "null"}]
                    },
                    "description": (
                        "Environment variables to set when starting a flow run."
                    ),
                },
                "labels": {
                    "title": "Labels",
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                    "description": (
                        "Labels applied to infrastructure created by the worker using "
                        "this job configuration."
                    ),
                },
                "name": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                    "title": "Name",
                    "description": (
                        "Name given to infrastructure created by the worker using this "
                        "job configuration. Supports templates using {{ ctx.flow.* }} and "
                        "{{ ctx.flow_run.* }} when prepared for a flow run."
                    ),
                },
                "other": {
                    "title": "Other",
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                },
            },
            "type": "object",
        },
    }

    pool_name = "test-pool"

    # Create a new worker pool
    response = await client.post(
        "/work_pools/", json=dict(name=pool_name, type="test-type")
    )
    result = parse_obj_as(schemas.objects.WorkPool, response.json())
    model = await models.workers.read_work_pool(session=session, work_pool_id=result.id)
    assert model.name == pool_name

    # Create a worker with the new pool and sync with the backend
    worker = WorkerTestImpl(
        name="test",
        work_pool_name=pool_name,
    )
    async with get_client() as client:
        worker._client = client
        await worker.sync_with_backend()

    assert worker._work_pool.base_job_template == expected_job_template


async def test_base_worker_gets_job_configuration_when_syncing_with_backend_with_job_config_and_variables(
    session, client
):
    """We don't really care how this happens as long as the worker winds up with a worker pool
    with a correct base_job_template when creating a new work pool"""

    class WorkerJobConfig(BaseJobConfiguration):
        other: Optional[str] = Field(
            default=None, json_schema_extra={"template": "{{ other }}"}
        )

    class WorkerVariables(BaseVariables):
        other: Optional[str] = Field(default="woof")

    # Add a job configuration and variables for the worker (currently used to create template
    # if not found on the worker pool)
    WorkerTestImpl.job_configuration = WorkerJobConfig
    WorkerTestImpl.job_configuration_variables = WorkerVariables

    pool_name = "test-pool"

    # Create a new worker pool
    response = await client.post(
        "/work_pools/", json=dict(name=pool_name, type="test-type")
    )
    result = parse_obj_as(schemas.objects.WorkPool, response.json())
    model = await models.workers.read_work_pool(session=session, work_pool_id=result.id)
    assert model.name == pool_name

    # Create a worker with the new pool and sync with the backend
    worker = WorkerTestImpl(
        name="test",
        work_pool_name=pool_name,
    )
    async with get_client() as client:
        worker._client = client
        await worker.sync_with_backend()

    assert (
        worker._work_pool.base_job_template
        == WorkerTestImpl.get_default_base_job_template()
    )


@pytest.mark.parametrize(
    "template,overrides,expected",
    [
        (
            {  # Base template with no overrides
                "job_configuration": {
                    "command": "{{ command }}",
                    "env": "{{ env }}",
                    "labels": "{{ labels }}",
                    "name": "{{ name }}",
                },
                "variables": {
                    "properties": {
                        "command": {
                            "type": "string",
                            "title": "Command",
                            "default": "echo hello",
                        },
                        "env": {
                            "title": "Environment Variables",
                            "type": "object",
                            "additionalProperties": {"type": "string"},
                            "description": (
                                "Environment variables to set when starting a flow run."
                            ),
                        },
                    },
                    "type": "object",
                },
            },
            {},  # No overrides
            {  # Expected result
                "command": "echo hello",
                "env": {},
                "labels": {},
                "name": None,
            },
        ),
    ],
)
async def test_base_job_configuration_from_template_and_overrides(
    template, overrides, expected
):
    """Test that the job configuration is correctly built from the template and overrides"""
    config = await BaseJobConfiguration.from_template_and_values(
        base_job_template=template, values=overrides
    )
    assert config.model_dump() == expected


@pytest.mark.parametrize(
    "template,overrides,expected",
    [
        (
            {  # Base template with no overrides
                "job_configuration": {
                    "var1": "{{ var1 }}",
                    "var2": "{{ var2 }}",
                },
                "variables": {
                    "properties": {
                        "var1": {
                            "type": "string",
                            "title": "Var1",
                            "default": "hello",
                        },
                        "var2": {
                            "type": "integer",
                            "title": "Var2",
                            "default": 42,
                        },
                    },
                    "required": [],
                },
            },
            {},  # No overrides
            {  # Expected result
                "command": None,
                "env": {},
                "labels": {},
                "name": None,
                "var1": "hello",
                "var2": 42,
            },
        ),
        (
            {  # Base template with no overrides, but unused variables
                "job_configuration": {
                    "var1": "{{ var1 }}",
                    "var2": "{{ var2 }}",
                },
                "variables": {
                    "properties": {
                        "var1": {
                            "type": "string",
                            "title": "Var1",
                            "default": "hello",
                        },
                        "var2": {
                            "type": "integer",
                            "title": "Var2",
                            "default": 42,
                        },
                        "var3": {
                            "type": "integer",
                            "title": "Var3",
                            "default": 21,
                        },
                    },
                    "required": [],
                },
            },
            {},  # No overrides
            {  # Expected result
                "command": None,
                "env": {},
                "labels": {},
                "name": None,
                "var1": "hello",
                "var2": 42,
            },
        ),
        (
            {  # Base template with command variables
                "job_configuration": {
                    "var1": "{{ var1 }}",
                    "var2": "{{ var2 }}",
                },
                "variables": {
                    "properties": {
                        "var1": {
                            "type": "string",
                            "title": "Var1",
                            "default": "hello",
                        },
                        "var2": {
                            "type": "integer",
                            "title": "Var2",
                            "default": 42,
                        },
                        "command": {
                            "type": "string",
                            "title": "Command",
                            "default": "echo hello",
                        },
                    },
                    "required": [],
                },
            },
            {},  # No overrides
            {  # Expected result
                "command": (
                    None
                ),  # command variable is not used in the job configuration
                "env": {},
                "labels": {},
                "name": None,
                "var1": "hello",
                "var2": 42,
            },
        ),
        (
            {  # Base template with var1 overridden
                "job_configuration": {
                    "var1": "{{ var1 }}",
                    "var2": "{{ var2 }}",
                },
                "variables": {
                    "properties": {
                        "var1": {
                            "type": "string",
                            "title": "Var1",
                            "default": "hello",
                        },
                        "var2": {
                            "type": "integer",
                            "title": "Var2",
                            "default": 42,
                        },
                    },
                },
                "required": [],
            },
            {"var1": "woof!"},  # var1 overridden
            {  # Expected result
                "command": None,
                "env": {},
                "labels": {},
                "name": None,
                "var1": "woof!",
                "var2": 42,
            },
        ),
        (
            {  # Base template with var1 overridden and var1 required
                "job_configuration": {
                    "var1": "{{ var1 }}",
                    "var2": "{{ var2 }}",
                },
                "variables": {
                    "properties": {
                        "var1": {
                            "type": "string",
                            "title": "Var1",
                        },
                        "var2": {
                            "type": "integer",
                            "title": "Var2",
                            "default": 42,
                        },
                    },
                },
                "required": ["var1"],
            },
            {"var1": "woof!"},  # var1 overridden
            {  # Expected result
                "command": None,
                "env": {},
                "labels": {},
                "name": None,
                "var1": "woof!",
                "var2": 42,
            },
        ),
    ],
)
async def test_job_configuration_from_template_and_overrides(
    template, overrides, expected
):
    """Test that the job configuration is correctly built from the template and overrides"""

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        var1: str = Field(json_schema_extra={"template": "{{ var1 }}"})
        var2: int = Field(json_schema_extra={"template": "{{ var2 }}"})

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template, values=overrides
    )
    assert config.model_dump() == expected


async def test_job_configuration_from_template_and_overrides_with_nested_variables():
    template = {
        "job_configuration": {
            "config": {
                "var1": "{{ var1 }}",
                "var2": "{{ var2 }}",
            }
        },
        "variables": {
            "properties": {
                "var1": {
                    "type": "string",
                    "title": "Var1",
                },
                "var2": {
                    "type": "integer",
                    "title": "Var2",
                    "default": 42,
                },
            },
        },
        "required": ["var1"],
    }

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        config: Dict[str, Any] = Field(
            json_schema_extra={
                "template": {"var1": "{{ var1 }}", "var2": "{{ var2 }}"}
            },
            default_factory=dict,
        )

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template, values={"var1": "woof!"}
    )
    assert config.model_dump() == {
        "command": None,
        "env": {},
        "labels": {},
        "name": None,
        "config": {
            "var1": "woof!",
            "var2": 42,
        },
    }


async def test_job_configuration_from_template_and_overrides_with_hard_coded_primitives():
    template = {
        "job_configuration": {"config": {"var1": 1, "var2": 1.1, "var3": True}},
        "variables": {},
    }

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        config: Dict[str, Any] = Field(
            json_schema_extra={"template": {"var1": 1, "var2": 1.1, "var3": True}}
        )

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template, values={}
    )
    assert config.model_dump() == {
        "command": None,
        "env": {},
        "labels": {},
        "name": None,
        "config": {"var1": 1, "var2": 1.1, "var3": True},
    }


async def test_job_configuration_from_template_overrides_with_block():
    class ArbitraryBlock(Block):
        a: int
        b: str

    template = {
        "job_configuration": {
            "var1": "{{ var1 }}",
            "arbitrary_block": "{{ arbitrary_block }}",
        },
        "variables": {
            "properties": {
                "var1": {
                    "type": "string",
                },
                "arbitrary_block": {},
            },
            "definitions": {
                "ArbitraryBlock": {
                    "title": "ArbitraryBlock",
                    "type": "object",
                    "properties": {
                        "a": {
                            "title": "A",
                            "type": "number",
                        },
                        "b": {
                            "title": "B",
                            "type": "string",
                        },
                    },
                    "required": ["a", "b"],
                    "block_type_slug": "arbitrary_block",
                    "secret_fields": [],
                    "block_schema_references": {},
                },
            },
            "required": ["var1", "arbitrary_block"],
        },
    }

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        var1: str
        arbitrary_block: ArbitraryBlock

    block_id = await ArbitraryBlock(a=1, b="hello").save(name="arbitrary-block")

    config: ArbitraryJobConfiguration = (
        await ArbitraryJobConfiguration.from_template_and_values(
            base_job_template=template,
            values={
                "var1": "woof!",
                "arbitrary_block": {"$ref": {"block_document_id": block_id}},
            },
        )
    )

    assert config.model_dump() == {
        "command": None,
        "env": {},
        "labels": {},
        "name": None,
        "var1": "woof!",
        # block_type_slug is added by Block.model_dump()
        "arbitrary_block": {"a": 1, "b": "hello", "block_type_slug": "arbitraryblock"},
    }

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template,
        values={
            "var1": "woof!",
            "arbitrary_block": "{{ prefect.blocks.arbitraryblock.arbitrary-block }}",
        },
    )

    assert config.model_dump() == {
        "command": None,
        "env": {},
        "labels": {},
        "name": None,
        "var1": "woof!",
        # block_type_slug is added by Block.model_dump()
        "arbitrary_block": {"a": 1, "b": "hello", "block_type_slug": "arbitraryblock"},
    }


async def test_job_configuration_from_template_coerces_work_pool_values():
    class ArbitraryJobConfiguration(BaseJobConfiguration):
        var1: str

    test_work_pool_base_job_config = {
        "job_configuration": {
            "var1": "hello",
            "env": {"MY_ENV_VAR": 42, "OTHER_ENV_VAR": None},
        },
        "variables": {
            "properties": {
                "var1": {
                    "type": "string",
                },
                "env": {
                    "type": "object",
                },
            },
        },
    }

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=test_work_pool_base_job_config, values={}
    )

    assert config.model_dump() == {
        "command": None,
        "env": {"MY_ENV_VAR": "42", "OTHER_ENV_VAR": None},
        "labels": {},
        "name": None,
        "var1": "hello",
    }

    assert isinstance(config, ArbitraryJobConfiguration)


@pytest.mark.usefixtures("variables")
async def test_job_configuration_from_template_overrides_with_remote_variables():
    template = {
        "job_configuration": {
            "var1": "{{ var1 }}",
            "env": "{{ env }}",
        },
        "variables": {
            "properties": {
                "var1": {
                    "type": "string",
                },
                "env": {
                    "type": "object",
                },
            }
        },
    }

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        var1: str
        env: Dict[str, str] = Field(default_factory=dict)

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template,
        values={
            "var1": "{{  prefect.variables.test_variable_1 }}",
            "env": {"MY_ENV_VAR": "{{  prefect.variables.test_variable_2 }}"},
        },
    )

    assert config.model_dump() == {
        "command": None,
        "env": {"MY_ENV_VAR": "test_value_2"},
        "labels": {},
        "name": None,
        "var1": "test_value_1",
    }


@pytest.mark.usefixtures("variables")
async def test_job_configuration_from_template_overrides_with_remote_variables_hardcodes():
    template = {
        "job_configuration": {
            "var1": "{{ prefect.variables.test_variable_1 }}",
            "env": {"MY_ENV_VAR": "{{ prefect.variables.test_variable_2 }}"},
        },
        "variables": {"properties": {}},
    }

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        var1: str
        env: Dict[str, str]

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template,
        values={},
    )

    assert config.model_dump() == {
        "command": None,
        "env": {"MY_ENV_VAR": "test_value_2"},
        "labels": {},
        "name": None,
        "var1": "test_value_1",
    }


async def test_job_configuration_from_template_and_overrides_with_variables_in_a_list():
    template = {
        "job_configuration": {"config": ["{{ var1 }}", "{{ var2 }}"]},
        "variables": {
            "properties": {
                "var1": {
                    "type": "string",
                    "title": "Var1",
                },
                "var2": {
                    "type": "integer",
                    "title": "Var2",
                    "default": 42,
                },
            },
        },
        "required": ["var1"],
    }

    class ArbitraryJobConfiguration(BaseJobConfiguration):
        config: list = Field(
            json_schema_extra={"template": ["{{ var1 }}", "{{ var2 }}"]}
        )

    config = await ArbitraryJobConfiguration.from_template_and_values(
        base_job_template=template, values={"var1": "woof!"}
    )
    assert config.model_dump() == {
        "command": None,
        "env": {},
        "labels": {},
        "name": None,
        "config": ["woof!", 42],
    }


@pytest.mark.parametrize(
    "falsey_value",
    [
        None,
        "",
    ],
)
async def test_base_job_configuration_converts_falsey_values_to_none(falsey_value):
    """Test that valid falsey values are converted to None for `command`"""
    template = await BaseJobConfiguration.from_template_and_values(
        base_job_template={
            "job_configuration": {
                "command": "{{ command }}",
            },
            "variables": {
                "properties": {
                    "command": {
                        "type": "string",
                        "title": "Command",
                    },
                },
                "required": [],
            },
        },
        values={"command": falsey_value},
    )
    assert template.command is None


async def test_base_job_configuration_transforms_dot_delimited_env_vars():
    """Test that dot-delimited keys like 'env.FOO' are transformed to nested dicts"""
    config = await BaseJobConfiguration.from_template_and_values(
        base_job_template={
            "job_configuration": {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
            },
            "variables": {
                "properties": {
                    "env": {
                        "title": "Environment Variables",
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": [],
            },
        },
        values={"env.EXTRA_PIP_PACKAGES": "s3fs"},
    )
    assert config.env == {"EXTRA_PIP_PACKAGES": "s3fs"}


async def test_base_job_configuration_transforms_multiple_dot_delimited_keys():
    """Test that multiple dot-delimited keys are all transformed correctly"""
    config = await BaseJobConfiguration.from_template_and_values(
        base_job_template={
            "job_configuration": {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
            },
            "variables": {
                "properties": {
                    "env": {
                        "title": "Environment Variables",
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": [],
            },
        },
        values={
            "env.FOO": "bar",
            "env.BAZ": "qux",
        },
    )
    assert config.env == {"FOO": "bar", "BAZ": "qux"}


async def test_base_job_configuration_nested_format_takes_precedence_over_dot_delimited():
    """Test that nested format takes precedence over dot-delimited format for same key"""
    config = await BaseJobConfiguration.from_template_and_values(
        base_job_template={
            "job_configuration": {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
            },
            "variables": {
                "properties": {
                    "env": {
                        "title": "Environment Variables",
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": [],
            },
        },
        values={
            "env.FOO": "from_dot",
            "env": {"FOO": "from_nested", "BAR": "also_nested"},
        },
    )
    # Nested format should take precedence
    assert config.env == {"FOO": "from_nested", "BAR": "also_nested"}


async def test_base_job_configuration_merges_dot_delimited_with_nested():
    """Test that dot-delimited and nested formats are merged when keys don't conflict"""
    config = await BaseJobConfiguration.from_template_and_values(
        base_job_template={
            "job_configuration": {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
            },
            "variables": {
                "properties": {
                    "env": {
                        "title": "Environment Variables",
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": [],
            },
        },
        values={
            "env.FOO": "from_dot",
            "env": {"BAR": "from_nested"},
        },
    )
    # Both should be present, with nested taking precedence for conflicts
    assert config.env == {"FOO": "from_dot", "BAR": "from_nested"}


async def test_base_job_configuration_dot_delimited_with_base_config_env():
    """Test that dot-delimited env vars merge correctly with base config env"""
    config = await BaseJobConfiguration.from_template_and_values(
        base_job_template={
            "job_configuration": {
                "command": "{{ command }}",
                "env": {"BASE_VAR": "base_value"},
                "labels": "{{ labels }}",
                "name": "{{ name }}",
            },
            "variables": {
                "properties": {
                    "env": {
                        "title": "Environment Variables",
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": [],
            },
        },
        values={"env.EXTRA_PIP_PACKAGES": "s3fs"},
    )
    assert config.env == {"BASE_VAR": "base_value", "EXTRA_PIP_PACKAGES": "s3fs"}


async def test_base_job_configuration_does_not_mutate_base_job_template():
    """Test that from_template_and_values does not mutate the original
    base_job_template, preventing env var leakage between concurrent runs
    that share the same cached template."""
    base_job_template = {
        "job_configuration": {
            "command": "{{ command }}",
            "env": {"SHARED_VAR": "shared_value"},
            "labels": {},
            "name": None,
        },
        "variables": {
            "properties": {
                "command": {
                    "type": "string",
                    "title": "Command",
                },
                "env": {
                    "type": "object",
                    "title": "Environment Variables",
                    "default": {"DEFAULT_VAR": "default_value"},
                },
            },
            "required": [],
        },
    }

    original_template = copy.deepcopy(base_job_template)

    # Simulate first deployment with its own env vars
    config_a = await BaseJobConfiguration.from_template_and_values(
        base_job_template=base_job_template,
        values={"env": {"DEPLOY_A_VAR": "a_value"}},
    )

    # The original template must not be mutated
    assert base_job_template == original_template, (
        "base_job_template was mutated by from_template_and_values"
    )

    # Simulate second deployment with different env vars
    config_b = await BaseJobConfiguration.from_template_and_values(
        base_job_template=base_job_template,
        values={"env": {"DEPLOY_B_VAR": "b_value"}},
    )

    # The original template must still not be mutated
    assert base_job_template == original_template, (
        "base_job_template was mutated by second call to from_template_and_values"
    )

    # Each config should have its own env vars plus the shared/default ones
    assert "DEPLOY_A_VAR" in config_a.env
    assert "DEPLOY_B_VAR" not in config_a.env

    assert "DEPLOY_B_VAR" in config_b.env
    assert "DEPLOY_A_VAR" not in config_b.env

    # Both should have the shared and default env vars
    assert config_a.env["SHARED_VAR"] == "shared_value"
    assert config_b.env["SHARED_VAR"] == "shared_value"
    assert config_a.env["DEFAULT_VAR"] == "default_value"
    assert config_b.env["DEFAULT_VAR"] == "default_value"


@pytest.mark.parametrize(
    "field_template_value,expected_final_template",
    [
        (
            "{{ var1 }}",
            {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
                "var1": "{{ var1 }}",
                "var2": "{{ var2 }}",
            },
        ),
        (
            None,
            {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
                "var1": "{{ var1 }}",
                "var2": "{{ var2 }}",
            },
        ),
        (
            "{{ dog }}",
            {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
                "var1": "{{ dog }}",
                "var2": "{{ var2 }}",
            },
        ),
    ],
)
def test_job_configuration_produces_correct_json_template(
    field_template_value, expected_final_template
):
    class ArbitraryJobConfiguration(BaseJobConfiguration):
        var1: str = Field(json_schema_extra={"template": field_template_value})
        var2: int = Field(json_schema_extra={"template": "{{ var2 }}"})

    template = ArbitraryJobConfiguration.json_template()
    assert template == expected_final_template


class TestWorkerProperties:
    def test_defaults(self):
        class WorkerImplNoCustomization(BaseWorker):
            type = "test-no-customization"

            async def run(self):
                pass

            async def verify_submitted_deployment(self, deployment):
                pass

        assert WorkerImplNoCustomization.get_logo_url() == ""
        assert WorkerImplNoCustomization.get_documentation_url() == ""
        assert WorkerImplNoCustomization.get_description() == ""
        assert WorkerImplNoCustomization.get_default_base_job_template() == {
            "job_configuration": {
                "command": "{{ command }}",
                "env": "{{ env }}",
                "labels": "{{ labels }}",
                "name": "{{ name }}",
            },
            "variables": {
                "properties": {
                    "command": {
                        "anyOf": [{"type": "string"}, {"type": "null"}],
                        "title": "Command",
                        "default": None,
                        "description": (
                            "The command to use when starting a flow run. "
                            "In most cases, this should be left blank and the command "
                            "will be automatically generated by the worker."
                        ),
                    },
                    "env": {
                        "title": "Environment Variables",
                        "type": "object",
                        "additionalProperties": {
                            "anyOf": [{"type": "string"}, {"type": "null"}]
                        },
                        "description": (
                            "Environment variables to set when starting a flow run."
                        ),
                    },
                    "labels": {
                        "title": "Labels",
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                        "description": (
                            "Labels applied to infrastructure created by the worker"
                            " using this job configuration."
                        ),
                    },
                    "name": {
                        "anyOf": [{"type": "string"}, {"type": "null"}],
                        "title": "Name",
                        "default": None,
                        "description": (
                            "Name given to infrastructure created by the worker using "
                            "this job configuration. Supports templates using {{ ctx.flow.* }} "
                            "and {{ ctx.flow_run.* }} when prepared for a flow run."
                        ),
                    },
                },
                "type": "object",
            },
        }

    def test_custom_logo_url(self):
        class WorkerImplWithLogoUrl(BaseWorker):
            type = "test-with-logo-url"
            job_configuration = BaseJobConfiguration

            _logo_url = "https://example.com/logo.png"

            async def run(self):
                pass

            async def verify_submitted_deployment(self, deployment):
                pass

        assert WorkerImplWithLogoUrl.get_logo_url() == "https://example.com/logo.png"

    def test_custom_documentation_url(self):
        class WorkerImplWithDocumentationUrl(BaseWorker):
            type = "test-with-documentation-url"
            job_configuration = BaseJobConfiguration

            _documentation_url = "https://example.com/docs"

            async def run(self):
                pass

            async def verify_submitted_deployment(self, deployment):
                pass

        assert (
            WorkerImplWithDocumentationUrl.get_documentation_url()
            == "https://example.com/docs"
        )

    def test_custom_description(self):
        class WorkerImplWithDescription(BaseWorker):
            type = "test-with-description"
            job_configuration = BaseJobConfiguration

            _description = "Custom Worker Description"

            async def run(self):
                pass

            async def verify_submitted_deployment(self, deployment):
                pass

        assert (
            WorkerImplWithDescription.get_description() == "Custom Worker Description"
        )

    def test_custom_base_job_configuration(self):
        class CustomBaseJobConfiguration(BaseJobConfiguration):
            var1: str = Field(json_schema_extra={"template": "{{ var1 }}"})
            var2: int = Field(json_schema_extra={"template": "{{ var2 }}"})

        class CustomBaseVariables(BaseVariables):
            var1: str = Field(default=...)
            var2: int = Field(default=1)

        class WorkerImplWithCustomBaseJobConfiguration(BaseWorker):
            type = "test-with-base-job-configuration"
            job_configuration = CustomBaseJobConfiguration
            job_configuration_variables = CustomBaseVariables

            async def run(self):
                pass

            async def verify_submitted_deployment(self, deployment):
                pass

        assert (
            WorkerImplWithCustomBaseJobConfiguration.get_default_base_job_template()
            == {
                "job_configuration": {
                    "command": "{{ command }}",
                    "env": "{{ env }}",
                    "labels": "{{ labels }}",
                    "name": "{{ name }}",
                    "var1": "{{ var1 }}",
                    "var2": "{{ var2 }}",
                },
                "variables": {
                    "properties": {
                        "command": {
                            "title": "Command",
                            "anyOf": [{"type": "string"}, {"type": "null"}],
                            "default": None,
                            "description": (
                                "The command to use when starting a flow run. "
                                "In most cases, this should be left blank and the command "
                                "will be automatically generated by the worker."
                            ),
                        },
                        "env": {
                            "title": "Environment Variables",
                            "type": "object",
                            "additionalProperties": {
                                "anyOf": [{"type": "string"}, {"type": "null"}]
                            },
                            "description": (
                                "Environment variables to set when starting a flow run."
                            ),
                        },
                        "labels": {
                            "title": "Labels",
                            "type": "object",
                            "additionalProperties": {"type": "string"},
                            "description": (
                                "Labels applied to infrastructure created by a worker."
                            ),
                        },
                        "name": {
                            "title": "Name",
                            "anyOf": [{"type": "string"}, {"type": "null"}],
                            "default": None,
                            "description": (
                                "Name given to infrastructure created by a worker."
                            ),
                        },
                        "var1": {"title": "Var1", "type": "string"},
                        "var2": {"title": "Var2", "type": "integer", "default": 1},
                    },
                    "required": ["var1"],
                    "type": "object",
                },
            }
        )


class TestPrepareForFlowRun:
    @pytest.fixture
    def job_config(self):
        return BaseJobConfiguration(
            env={"MY_VAR": "foo"},
            labels={"my-label": "foo"},
            name="my-job-name",
        )

    @pytest.fixture
    def flow_run(self):
        return FlowRun(name="my-flow-run-name", flow_id=uuid.uuid4())

    @pytest.fixture
    def flow(self):
        return Flow(name="my-flow-name")

    @pytest.fixture
    def deployment(self, flow):
        return DeploymentResponse(name="my-deployment-name", flow_id=flow.id)

    def test_prepare_for_flow_run_without_deployment_and_flow(
        self, job_config, flow_run
    ):
        job_config.prepare_for_flow_run(flow_run)

        assert job_config.env == {
            **get_current_settings().to_environment_variables(exclude_unset=True),
            "MY_VAR": "foo",
            "PREFECT__FLOW_RUN_ID": str(flow_run.id),
            "PREFECT__FLOW_ID": str(flow_run.flow_id),
        }
        assert job_config.labels == {
            "my-label": "foo",
            "prefect.io/flow-run-id": str(flow_run.id),
            "prefect.io/flow-run-name": flow_run.name,
            "prefect.io/version": prefect.__version__,
        }
        assert job_config.name == "my-job-name"
        assert job_config.command == "prefect flow-run execute"

    def test_prepare_for_flow_run(self, job_config, flow_run):
        job_config.prepare_for_flow_run(flow_run)

        assert job_config.env == {
            **get_current_settings().to_environment_variables(exclude_unset=True),
            "MY_VAR": "foo",
            "PREFECT__FLOW_RUN_ID": str(flow_run.id),
            "PREFECT__FLOW_ID": str(flow_run.flow_id),
        }
        assert job_config.labels == {
            "my-label": "foo",
            "prefect.io/flow-run-id": str(flow_run.id),
            "prefect.io/flow-run-name": flow_run.name,
            "prefect.io/version": prefect.__version__,
        }
        assert job_config.name == "my-job-name"
        # only thing that changes is the command
        assert job_config.command == "prefect flow-run execute"

    def test_prepare_for_flow_run_with_deployment_and_flow(
        self, job_config, flow_run, deployment, flow
    ):
        job_config.prepare_for_flow_run(flow_run, deployment=deployment, flow=flow)

        assert job_config.env == {
            **get_current_settings().to_environment_variables(exclude_unset=True),
            "MY_VAR": "foo",
            "PREFECT__FLOW_RUN_ID": str(flow_run.id),
            "PREFECT__FLOW_ID": str(flow_run.flow_id),
            "PREFECT__FLOW_NAME": flow.name,
            "PREFECT__DEPLOYMENT_NAME": deployment.name,
        }
        assert job_config.labels == {
            "my-label": "foo",
            "prefect.io/flow-run-id": str(flow_run.id),
            "prefect.io/flow-run-name": flow_run.name,
            "prefect.io/version": prefect.__version__,
            "prefect.io/deployment-id": str(deployment.id),
            "prefect.io/deployment-name": deployment.name,
            "prefect.io/flow-id": str(flow.id),
            "prefect.io/flow-name": flow.name,
        }
        assert job_config.name == "my-job-name"
        assert job_config.command == "prefect flow-run execute"

    def test_prepare_for_flow_run_renders_name_template(self, flow_run, flow):
        job_config = BaseJobConfiguration(
            name="worker-1/{{ ctx.flow.name }}/{{ ctx.flow_run.name }}"
        )

        job_config.prepare_for_flow_run(flow_run, flow=flow)

        assert job_config.name == f"worker-1/{flow.name}/{flow_run.name}"


async def test_get_flow_run_logger_without_worker_id_set(
    prefect_client: PrefectClient,
    worker_deployment_wq1,
    work_pool,
    worker_channel_endpoint_unavailable: None,
):
    flow_run = await prefect_client.create_flow_run_from_deployment(
        worker_deployment_wq1.id
    )

    async with WorkerTestImpl(
        name="test", work_pool_name=work_pool.name, create_pool_if_not_found=False
    ) as worker:
        await worker.sync_with_backend()
        assert worker.backend_id is None
        logger = worker.get_flow_run_logger(flow_run)

        assert logger.name == "prefect.flow_runs.worker"
        assert logger.extra == {
            "flow_run_name": flow_run.name,
            "flow_run_id": str(flow_run.id),
            "flow_name": "<unknown>",
            "deployment_name": None,
            "worker_name": "test",
            "work_pool_name": work_pool.name,
            "work_pool_id": str(work_pool.id),
        }


async def test_get_flow_run_logger_with_worker_id_set(
    prefect_client: PrefectClient,
    worker_deployment_wq1,
    work_pool,
):
    flow_run = await prefect_client.create_flow_run_from_deployment(
        worker_deployment_wq1.id
    )

    async with WorkerTestImpl(
        name="test", work_pool_name=work_pool.name, create_pool_if_not_found=False
    ) as worker:
        await worker.sync_with_backend()
        worker_id = uuid.uuid4()
        worker.backend_id = worker_id
        logger = worker.get_flow_run_logger(flow_run)

        assert logger.name == "prefect.flow_runs.worker"
        assert logger.extra == {
            "flow_run_name": flow_run.name,
            "flow_run_id": str(flow_run.id),
            "flow_name": "<unknown>",
            "deployment_name": None,
            "worker_name": "test",
            "work_pool_name": work_pool.name,
            "work_pool_id": str(work_pool.id),
            "worker_id": str(worker_id),
        }


class TestInfrastructureIntegration:
    async def test_worker_crashes_flow_if_infrastructure_submission_fails(
        self,
        prefect_client: PrefectClient,
        worker_deployment_infra_wq1: WorkQueue,
        work_pool: WorkPool,
        monkeypatch: pytest.MonkeyPatch,
    ):
        flow_run = await prefect_client.create_flow_run_from_deployment(
            worker_deployment_infra_wq1.id,
            state=Scheduled(scheduled_time=now_fn("UTC")),
        )
        await prefect_client.read_flow(worker_deployment_infra_wq1.flow_id)

        def raise_value_error():
            raise ValueError("Hello!")

        mock_run = MagicMock()
        mock_run.run = raise_value_error

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            worker._work_pool = work_pool
            monkeypatch.setattr(worker, "run", mock_run)
            monkeypatch.setattr(worker, "run", mock_run)
            await worker.get_and_submit_flow_runs()

        state = (await prefect_client.read_flow_run(flow_run.id)).state
        assert state.is_crashed()
        with pytest.raises(
            CrashedRun, match="Failed to submit flow run to infrastructure"
        ):
            await state.result()

    async def test_submission_failure_log_uses_flow_run_name(
        self,
        prefect_client: PrefectClient,
        worker_deployment_infra_wq1: WorkQueue,
        work_pool: WorkPool,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
    ):
        flow_run = await prefect_client.create_flow_run_from_deployment(
            worker_deployment_infra_wq1.id,
            state=Scheduled(scheduled_time=now_fn("UTC")),
        )
        await prefect_client.read_flow(worker_deployment_infra_wq1.flow_id)

        def raise_value_error():
            raise ValueError("Hello!")

        mock_run = MagicMock()
        mock_run.run = raise_value_error

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            worker._work_pool = work_pool
            monkeypatch.setattr(worker, "run", mock_run)
            with caplog.at_level(logging.ERROR):
                await worker.get_and_submit_flow_runs()

        assert any(
            f"Failed to submit flow run '{flow_run.name}'" in record.message
            for record in caplog.records
        )

    async def test_non_zero_exit_code_logs_resolution_hint(
        self,
        prefect_client: PrefectClient,
        worker_deployment_infra_wq1: WorkQueue,
        work_pool: WorkPool,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
    ):
        flow_run = await prefect_client.create_flow_run_from_deployment(
            worker_deployment_infra_wq1.id,
            state=Scheduled(scheduled_time=now_fn("UTC")),
        )
        await prefect_client.read_flow(worker_deployment_infra_wq1.flow_id)

        async def mock_run_fn(
            self: object,
            flow_run: FlowRun,
            configuration: object,
            task_status: anyio.abc.TaskStatus[int] | None = None,
        ) -> BaseWorkerResult:
            if task_status:
                task_status.started(1)
            return BaseWorkerResult(identifier="test", status_code=137)

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            worker._work_pool = work_pool
            monkeypatch.setattr(worker, "run", mock_run_fn.__get__(worker))
            with caplog.at_level(logging.INFO):
                await worker.get_and_submit_flow_runs()

        state = (await prefect_client.read_flow_run(flow_run.id)).state
        assert state is not None
        assert state.is_crashed()

        # The resolution hint should be emitted as a separate INFO log
        info_messages = [
            record.message
            for record in caplog.records
            if record.levelno == logging.INFO
        ]
        assert any("memory" in msg.lower() for msg in info_messages), (
            f"Expected resolution hint about memory in INFO logs, got: {info_messages}"
        )

    async def test_monitoring_error_log_uses_flow_run_name(
        self,
        prefect_client: PrefectClient,
        worker_deployment_infra_wq1: WorkQueue,
        work_pool: WorkPool,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
    ):
        flow_run = await prefect_client.create_flow_run_from_deployment(
            worker_deployment_infra_wq1.id,
            state=Scheduled(scheduled_time=now_fn("UTC")),
        )
        await prefect_client.read_flow(worker_deployment_infra_wq1.flow_id)

        async def mock_run_fn(
            self: object,
            flow_run: FlowRun,
            configuration: object,
            task_status: anyio.abc.TaskStatus[int] | None = None,
        ) -> BaseWorkerResult:
            if task_status:
                task_status.started(1)
            # Raise after marking as started to simulate monitoring error
            raise RuntimeError("Connection lost!")

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            worker._work_pool = work_pool
            monkeypatch.setattr(worker, "run", mock_run_fn.__get__(worker))
            with caplog.at_level(logging.ERROR):
                await worker.get_and_submit_flow_runs()

        assert any(
            f"Lost connection to flow run '{flow_run.name}' infrastructure"
            in record.message
            for record in caplog.records
        )


async def test_worker_set_last_polled_time(work_pool: WorkPool):
    now = now_fn("UTC")

    try:
        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            # initially, the worker should have _last_polled_time set to a recent time
            initial_poll_time = worker._last_polled_time
            assert initial_poll_time >= now

            # some arbitrary delta forward
            now2 = now + timedelta(seconds=49)
            with travel_to(now2):
                await worker.get_and_submit_flow_runs()
                # after polling, _last_polled_time should be updated to a more recent time
                assert worker._last_polled_time > initial_poll_time
                # check to make sure the time updated as expected
                assert worker._last_polled_time - timedelta(seconds=49) == now
    except ExceptionGroup as e:
        raise e.exceptions[0]


async def test_worker_last_polled_health_check(work_pool: WorkPool):
    now = now_fn("UTC")

    try:
        with travel_to(now):
            async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
                resp = worker.is_worker_still_polling(query_interval_seconds=10)
                assert resp is True

                with travel_to(now + timedelta(seconds=299)):
                    resp = worker.is_worker_still_polling(query_interval_seconds=10)
                    assert resp is True

                with travel_to(now + timedelta(seconds=301)):
                    resp = worker.is_worker_still_polling(query_interval_seconds=10)
                    assert resp is False

                with travel_to(now + timedelta(minutes=30)):
                    resp = worker.is_worker_still_polling(query_interval_seconds=60)
                    assert resp is True

                with travel_to(now + timedelta(minutes=30, seconds=1)):
                    resp = worker.is_worker_still_polling(query_interval_seconds=60)
                    assert resp is False

                # a day-scale gap must not report healthy: timedelta.seconds
                # discards the days component, so a worker dead for a day and
                # 30 seconds used to pass the 300 second threshold again
                with travel_to(now + timedelta(days=1, seconds=30)):
                    resp = worker.is_worker_still_polling(query_interval_seconds=10)
                    assert resp is False
    except ExceptionGroup as e:
        raise e.exceptions[0]


class TestBaseWorkerStart:
    async def test_start_syncs_with_the_server(self, work_pool: WorkPool):
        worker = WorkerTestImpl(work_pool_name=work_pool.name)
        assert worker._work_pool is None

        await worker.start(run_once=True)

        assert worker._work_pool is not None
        assert worker._work_pool.base_job_template == work_pool.base_job_template

    async def test_start_executes_flow_runs(
        self,
        prefect_client: PrefectClient,
        worker_deployment_wq1: Deployment,
        work_pool: WorkPool,
    ):
        @flow
        def test_flow():
            pass

        def create_run_with_deployment(state: State):
            return prefect_client.create_flow_run_from_deployment(
                worker_deployment_wq1.id, state=state
            )

        flow_run = await prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id,
            state=Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1)),
        )

        worker = WorkerTestImpl(work_pool_name=work_pool.name)
        worker.run = AsyncMock()
        await worker.start(run_once=True)

        worker.run.assert_awaited_once()
        assert worker.run.call_args[1]["flow_run"].id == flow_run.id


class FakeWorkerChannelWebSocket:
    def __init__(self, messages: list[dict[str, Any] | BaseException]):
        self.messages = list(messages)
        self.sent: list[dict[str, Any]] = []

    async def send(self, message: str) -> None:
        self.sent.append(orjson.loads(message))

    async def recv(self) -> str:
        if not self.messages:
            await anyio.sleep_forever()

        message = self.messages.pop(0)
        if isinstance(message, BaseException):
            raise message

        return orjson.dumps(message).decode()


class FakeWorkerChannelConnect:
    def __init__(self, websocket: FakeWorkerChannelWebSocket):
        self.websocket = websocket
        self.exited = False

    async def __aenter__(self) -> FakeWorkerChannelWebSocket:
        return self.websocket

    async def __aexit__(self, *exc_info: Any) -> None:
        self.exited = True


def worker_channel_ready_frame(
    consumer_id: uuid.UUID, worker_id: uuid.UUID | None = None
) -> dict[str, Any]:
    return {
        "type": "worker.ready.v1",
        "id": str(uuid7()),
        "sent_at": now_fn("UTC").isoformat(),
        "payload": {
            "consumer_id": str(consumer_id),
            "worker_id": str(worker_id) if worker_id else None,
            "selected_channel_version": WORK_POOL_WORKER_CHANNEL_VERSION,
            "effective_heartbeat_interval_seconds": 30,
            "accepted_capabilities": [
                WORKER_HEARTBEAT_CAPABILITY,
                WORK_POOL_SNAPSHOT_CAPABILITY,
            ],
            "rejected_capabilities": [],
            "effective_max_cleanup_concurrency": 0,
            "resolved_work_queues": [],
            "initial_snapshot": {
                "snapshot_sequence": 1,
                "reason": "initial",
                "work_pool": {
                    "id": str(uuid.uuid4()),
                    "name": "test-work-pool",
                    "type": "test",
                    "base_job_template": {},
                    "is_paused": False,
                    "storage_configuration": {},
                    "default_queue_id": str(uuid.uuid4()),
                },
            },
        },
    }


def worker_channel_snapshot_payload(
    sequence: int,
    *,
    base_job_template: dict[str, Any] | None = None,
    is_paused: bool = False,
    name: str = "test-work-pool",
    default_queue_id: uuid.UUID | None = None,
) -> WorkPoolSnapshotPayload:
    return WorkPoolSnapshotPayload.model_validate(
        {
            "snapshot_sequence": sequence,
            "reason": "work_pool_updated" if sequence != 1 else "initial",
            "work_pool": {
                "id": str(uuid.uuid4()),
                "name": name,
                "type": "test",
                "base_job_template": base_job_template or {},
                "is_paused": is_paused,
                "storage_configuration": {},
                "default_queue_id": str(default_queue_id or uuid.uuid4()),
            },
        }
    )


async def no_worker_channel_metadata() -> WorkerMetadata | None:
    return None


def worker_channel_test_client(
    server_type: ServerType = ServerType.SERVER,
    worker_id: uuid.UUID | None = None,
) -> Mock:
    client = Mock(server_type=server_type)
    client.send_worker_heartbeat = AsyncMock(return_value=worker_id)
    return client


class TestReconnectDelay:
    def test_exponential_backoff(self):
        transport = WorkerChannelTransport(
            api_url="http://localhost:4200/api",
            work_pool_name="test",
            logger=logging.getLogger("test"),
            reconnect_base_seconds=1.0,
            reconnect_max_seconds=30.0,
        )
        assert transport.reconnect_delay(1) == 1.0
        assert transport.reconnect_delay(2) == 2.0
        assert transport.reconnect_delay(3) == 4.0
        assert transport.reconnect_delay(6) == 30.0  # clamped to max

    def test_zero_base_returns_zero(self):
        transport = WorkerChannelTransport(
            api_url="http://localhost:4200/api",
            work_pool_name="test",
            logger=logging.getLogger("test"),
            reconnect_base_seconds=0,
            reconnect_max_seconds=30.0,
        )
        assert transport.reconnect_delay(1) == 0
        assert transport.reconnect_delay(9999) == 0

    def test_large_attempt_does_not_overflow(self):
        transport = WorkerChannelTransport(
            api_url="http://localhost:4200/api",
            work_pool_name="test",
            logger=logging.getLogger("test"),
            reconnect_base_seconds=1.0,
            reconnect_max_seconds=30.0,
        )
        # These previously raised OverflowError
        assert transport.reconnect_delay(1024) == 30.0
        assert transport.reconnect_delay(2000) == 30.0
        assert transport.reconnect_delay(100_000) == 30.0


class TestWorkerChannelClient:
    async def test_worker_uses_real_server_channel_for_setup_and_heartbeat(
        self,
        hosted_api_server: str,
        prefect_client: PrefectClient,
    ):
        assert PREFECT_API_URL.value() == hosted_api_server

        work_pool_name = f"worker-channel-e2e-{uuid.uuid4().hex}"
        worker_name = f"worker-channel-e2e-{uuid.uuid4().hex}"
        work_pool = await prefect_client.create_work_pool(
            WorkPoolCreate(
                name=work_pool_name,
                type=WorkerTestImpl.type,
                base_job_template=WorkerTestImpl.get_default_base_job_template(),
            )
        )

        async with WorkerTestImpl(
            name=worker_name,
            work_pool_name=work_pool_name,
            create_pool_if_not_found=False,
            heartbeat_interval_seconds=1,
        ) as worker:
            assert worker.backend_id is None
            assert worker.work_pool.id == work_pool.id

            workers = await prefect_client.read_workers_for_work_pool(work_pool_name)
            assert len(workers) == 1
            assert workers[0].name == worker_name
            assert workers[0].heartbeat_interval_seconds == 1
            initial_heartbeat_time = workers[0].last_heartbeat_time
            assert initial_heartbeat_time is not None

            async for attempt in retry_asserts(max_attempts=20, delay=0.25):
                with attempt:
                    [server_worker] = await prefect_client.read_workers_for_work_pool(
                        work_pool_name
                    )
                    assert server_worker.last_heartbeat_time is not None
                    assert server_worker.last_heartbeat_time > initial_heartbeat_time

    async def test_oss_worker_channel_does_not_set_worker_id_env_var(
        self,
        hosted_api_server: str,
        prefect_client: PrefectClient,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """OSS server returns worker_id=None in the ready frame, so
        PREFECT__WORKER_ID should never be set from the channel path."""
        monkeypatch.delenv("PREFECT__WORKER_ID", raising=False)
        assert PREFECT_API_URL.value() == hosted_api_server

        work_pool_name = f"worker-channel-e2e-{uuid.uuid4().hex}"
        await prefect_client.create_work_pool(
            WorkPoolCreate(
                name=work_pool_name,
                type=WorkerTestImpl.type,
                base_job_template=WorkerTestImpl.get_default_base_job_template(),
            )
        )

        async with WorkerTestImpl(
            name=f"worker-{uuid.uuid4().hex}",
            work_pool_name=work_pool_name,
            create_pool_if_not_found=False,
            heartbeat_interval_seconds=1,
        ) as worker:
            assert worker.backend_id is None
            assert worker.work_pool is not None
            assert worker.work_pool.name == work_pool_name
            import os

            assert os.environ.get("PREFECT__WORKER_ID") is None

    async def test_oss_worker_channel_still_healthy_without_worker_id(
        self,
        hosted_api_server: str,
        prefect_client: PrefectClient,
    ):
        """OSS channel setup becomes healthy and applies initial snapshot
        even though worker_id is None in the ready frame."""
        assert PREFECT_API_URL.value() == hosted_api_server

        work_pool_name = f"worker-channel-e2e-{uuid.uuid4().hex}"
        work_pool = await prefect_client.create_work_pool(
            WorkPoolCreate(
                name=work_pool_name,
                type=WorkerTestImpl.type,
                base_job_template=WorkerTestImpl.get_default_base_job_template(),
            )
        )

        async with WorkerTestImpl(
            name=f"worker-{uuid.uuid4().hex}",
            work_pool_name=work_pool_name,
            create_pool_if_not_found=False,
            heartbeat_interval_seconds=1,
        ) as worker:
            assert worker.backend_id is None
            assert worker.work_pool.id == work_pool.id
            assert worker.work_pool.is_paused is False

    def test_builds_websocket_url_from_prefect_api_url(self):
        assert (
            build_worker_channel_url("http://localhost:4200/api", "default pool")
            == "ws://localhost:4200/api/work_pools/default%20pool/workers/connect"
        )
        assert (
            build_worker_channel_url(
                "https://api.prefect.cloud/api/accounts/a/workspaces/w",
                "default",
            )
            == "wss://api.prefect.cloud/api/accounts/a/workspaces/w/work_pools/default/workers/connect"
        )

    def test_channel_state_derives_flags_from_status(self):
        state = WorkerChannelState()

        assert state.status == WorkerChannelStatus.FALLBACK_RETRYING
        assert state.rest_fallback_enabled is True
        assert state.healthy is False
        assert state.terminal is False

        state.mark_connecting()
        assert state.status == WorkerChannelStatus.CONNECTING
        assert state.rest_fallback_enabled is True
        assert state.healthy is False
        assert state.terminal is False

        state.mark_healthy()
        assert state.status == WorkerChannelStatus.HEALTHY
        assert state.rest_fallback_enabled is False
        assert state.healthy is True
        assert state.terminal is False

        state.mark_unhealthy("setup_timeout")
        assert state.status == WorkerChannelStatus.FALLBACK_RETRYING
        assert state.rest_fallback_enabled is True
        assert state.healthy is False
        assert state.terminal is False
        assert state.reason == "setup_timeout"

        state.mark_terminal("endpoint_unavailable")
        assert state.status == WorkerChannelStatus.DISABLED
        assert state.rest_fallback_enabled is True
        assert state.healthy is False
        assert state.terminal is True
        assert state.reason == "endpoint_unavailable"

    def test_work_pool_snapshot_state_applies_full_replacements_by_sequence(self):
        state = WorkPoolSnapshotState()
        initial_template = {"job_configuration": {"env": {"A": "1"}}, "variables": {}}
        updated_template = {"job_configuration": {"env": {"B": "2"}}, "variables": {}}

        first = state.apply_snapshot(
            worker_channel_snapshot_payload(
                1, base_job_template=initial_template, is_paused=False
            )
        )
        second = state.apply_snapshot(
            worker_channel_snapshot_payload(
                3, base_job_template=updated_template, is_paused=True
            )
        )

        assert first is not None
        assert second is not None
        assert second is not first
        assert state.last_applied_sequence == 3
        assert state.work_pool is not None
        assert state.work_pool.base_job_template == updated_template
        assert state.work_pool.is_paused is True

    def test_work_pool_snapshot_state_ignores_stale_and_duplicate_sequences(self):
        state = WorkPoolSnapshotState()
        current_template = {
            "job_configuration": {"env": {"CURRENT": "1"}},
            "variables": {},
        }
        stale_template = {"job_configuration": {"env": {"STALE": "1"}}, "variables": {}}

        state.apply_snapshot(
            worker_channel_snapshot_payload(3, base_job_template=current_template)
        )

        assert (
            state.apply_snapshot(
                worker_channel_snapshot_payload(3, base_job_template=stale_template)
            )
            is None
        )
        assert (
            state.apply_snapshot(
                worker_channel_snapshot_payload(2, base_job_template=stale_template)
            )
            is None
        )
        assert state.work_pool is not None
        assert state.work_pool.base_job_template == current_template

    def test_work_pool_snapshot_state_resets_sequence_tracking_for_reconnect(self):
        state = WorkPoolSnapshotState()
        original_template = {
            "job_configuration": {"env": {"ORIGINAL": "1"}},
            "variables": {},
        }
        reconnected_template = {
            "job_configuration": {"env": {"RECONNECTED": "1"}},
            "variables": {},
        }

        state.apply_snapshot(
            worker_channel_snapshot_payload(5, base_job_template=original_template)
        )
        state.reset_connection_sequence()
        state.apply_snapshot(
            worker_channel_snapshot_payload(1, base_job_template=reconnected_template)
        )

        assert state.last_applied_sequence == 1
        assert state.work_pool is not None
        assert state.work_pool.base_job_template == reconnected_template

    def test_protocol_applies_work_pool_snapshots_through_sequence_state(self):
        consumer_id = uuid7()
        snapshot = Mock()
        protocol = WorkerChannelProtocolHandler(
            consumer_id=consumer_id,
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            classify_closed_connection=lambda exc: WorkerChannelTerminalError(
                "connection_lost", str(exc)
            ),
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )

        protocol.handle_work_pool_snapshot(
            worker_channel_snapshot_payload(
                1,
                base_job_template={
                    "job_configuration": {"env": {"FIRST": "1"}},
                    "variables": {},
                },
            )
        )
        protocol.handle_work_pool_snapshot(
            worker_channel_snapshot_payload(
                3,
                base_job_template={
                    "job_configuration": {"env": {"THIRD": "1"}},
                    "variables": {},
                },
            )
        )
        protocol.handle_work_pool_snapshot(
            worker_channel_snapshot_payload(
                2,
                base_job_template={
                    "job_configuration": {"env": {"STALE": "1"}},
                    "variables": {},
                },
            )
        )

        assert snapshot.call_count == 2
        assert snapshot.call_args_list[-1].args[0].base_job_template[
            "job_configuration"
        ]["env"] == {"THIRD": "1"}

    async def test_transport_connects_with_auth_and_hello_payload(self):
        captured_connect_kwargs: dict[str, Any] = {}

        worker_id = uuid.uuid4()
        consumer_id = uuid7()
        snapshot = Mock()

        async def worker_metadata() -> WorkerMetadata:
            return WorkerMetadata(
                integrations=[Integration(name="prefect-aws", version="1.0.0")],
                custom_field="custom",
            )

        protocol = WorkerChannelProtocolHandler(
            consumer_id=consumer_id,
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=["queue-b", "queue-a"],
            create_pool_if_not_found=True,
            default_base_job_template={"job_configuration": {}, "variables": {}},
            worker_metadata=worker_metadata,
            classify_closed_connection=lambda exc: WorkerChannelTerminalError(
                "connection_lost", str(exc)
            ),
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )
        websocket = FakeWorkerChannelWebSocket(
            [
                {"type": "auth_success"},
                worker_channel_ready_frame(consumer_id, worker_id=worker_id),
            ]
        )
        connect_context = FakeWorkerChannelConnect(websocket)

        def connect_factory(*args: Any, **kwargs: Any) -> FakeWorkerChannelConnect:
            captured_connect_kwargs["args"] = args
            captured_connect_kwargs["kwargs"] = kwargs
            return connect_context

        transport = WorkerChannelTransport(
            api_url="http://localhost:4200/api",
            work_pool_name="test-work-pool",
            logger=logging.getLogger("test-worker-channel"),
            connect_factory=connect_factory,
        )

        session = await transport.connect_once(protocol.handshake)

        assert isinstance(session, WorkerChannelSession)
        assert captured_connect_kwargs["args"] == (
            "ws://localhost:4200/api/work_pools/test-work-pool/workers/connect",
        )
        assert [
            str(protocol)
            for protocol in captured_connect_kwargs["kwargs"]["subprotocols"]
        ] == [WORKER_CHANNEL_SUBPROTOCOL]

        assert websocket.sent[0] == {"type": "auth", "token": None}
        hello = websocket.sent[1]
        assert hello["type"] == "worker.hello.v1"
        assert hello["payload"]["consumer_id"] == str(consumer_id)
        assert hello["payload"]["worker_name"] == "test-worker"
        assert hello["payload"]["worker_type"] == "test"
        assert hello["payload"]["requested_capabilities"] == [
            WORKER_HEARTBEAT_CAPABILITY,
            WORK_POOL_SNAPSHOT_CAPABILITY,
        ]
        assert hello["payload"]["handled_cleanup_kinds"] == []
        assert hello["payload"]["max_cleanup_concurrency"] == 0
        assert hello["payload"]["work_queue_names"] == ["queue-b", "queue-a"]
        assert hello["payload"]["create_pool_if_not_found"] is True
        assert hello["payload"]["default_base_job_template"] == {
            "job_configuration": {},
            "variables": {},
        }
        assert hello["payload"]["worker_metadata"] == {
            "integrations": [{"name": "prefect-aws", "version": "1.0.0"}],
            "custom_field": "custom",
        }
        assert protocol.worker_metadata_sent is True
        assert protocol.worker_id == worker_id
        snapshot.assert_called_once()

        await transport.close_session(session)
        assert connect_context.exited

    async def test_protocol_does_not_record_worker_id_when_none(self):
        """When the server returns worker_id=None (OSS behavior), the protocol
        handler should not invoke the on_worker_id callback."""
        consumer_id = uuid7()
        on_worker_id = Mock()
        snapshot = Mock()

        protocol = WorkerChannelProtocolHandler(
            consumer_id=consumer_id,
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            classify_closed_connection=lambda exc: WorkerChannelTerminalError(
                "connection_lost", str(exc)
            ),
            logger=logging.getLogger("test-worker-channel"),
            on_worker_id=on_worker_id,
            on_work_pool_snapshot=snapshot,
        )
        websocket = FakeWorkerChannelWebSocket(
            [
                {"type": "auth_success"},
                worker_channel_ready_frame(consumer_id, worker_id=None),
            ]
        )
        connect_context = FakeWorkerChannelConnect(websocket)

        transport = WorkerChannelTransport(
            api_url="http://localhost:4200/api",
            work_pool_name="test-work-pool",
            logger=logging.getLogger("test-worker-channel"),
            connect_factory=lambda *args, **kwargs: connect_context,
        )

        await transport.connect_once(protocol.handshake)

        assert protocol.worker_id is None
        on_worker_id.assert_not_called()
        snapshot.assert_called_once()

    async def test_run_session_classifies_heartbeat_connection_close(self, monkeypatch):
        consumer_id = uuid7()
        websocket = FakeWorkerChannelWebSocket([])
        close_error = ConnectionClosedError(
            Close(1008, WorkerChannelCloseReason.AUTHORIZATION_FAILED.value),
            None,
        )
        websocket.send = AsyncMock(side_effect=close_error)

        async def sleep_immediately(delay: float) -> None:
            pass

        monkeypatch.setattr(
            "prefect.workers._worker_channel._protocol.anyio.sleep",
            sleep_immediately,
        )
        transport = WorkerChannelTransport(
            api_url=None,
            work_pool_name="test-work-pool",
            logger=logging.getLogger("test-worker-channel"),
        )
        protocol = WorkerChannelProtocolHandler(
            consumer_id=consumer_id,
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            classify_closed_connection=transport.classify_closed_connection,
            logger=logging.getLogger("test-worker-channel"),
        )
        session = WorkerChannelSession(
            FakeWorkerChannelConnect(websocket),
            websocket,
            WorkerReadyFrame.model_validate(worker_channel_ready_frame(consumer_id)),
        )

        with pytest.raises(WorkerChannelTerminalError) as exc_info:
            await protocol.run_session(session)

        assert exc_info.value.reason == WorkerChannelCloseReason.AUTHORIZATION_FAILED

    @pytest.mark.parametrize(
        "status_code, expected_reason, expected_error",
        [
            (
                401,
                WorkerChannelCloseReason.AUTHENTICATION_FAILED,
                WorkerChannelTerminalError,
            ),
            (
                403,
                WorkerChannelCloseReason.AUTHORIZATION_FAILED,
                WorkerChannelTerminalError,
            ),
            (404, "endpoint_unavailable", WorkerChannelTerminalError),
            (405, "endpoint_unavailable", WorkerChannelTerminalError),
            (400, "endpoint_unavailable", WorkerChannelTerminalError),
            (
                500,
                WorkerChannelCloseReason.TRANSIENT_SERVER_ERROR,
                WorkerChannelRetryableError,
            ),
        ],
    )
    async def test_http_upgrade_auth_statuses_preserve_close_reason(
        self,
        status_code: int,
        expected_reason: str,
        expected_error: type[WorkerChannelError],
    ):
        class FailingConnect:
            def __init__(self, exc: Exception):
                self.exc = exc

            async def __aenter__(self) -> None:
                raise self.exc

            async def __aexit__(self, *exc_info: Any) -> None:
                pass

        class FakeResponse:
            pass

        response = FakeResponse()
        response.status_code = status_code

        transport = WorkerChannelTransport(
            api_url="http://localhost:4200/api",
            work_pool_name="test-work-pool",
            logger=logging.getLogger("test-worker-channel"),
            connect_factory=lambda *args, **kwargs: FailingConnect(
                InvalidStatus(response)
            ),
        )

        with pytest.raises(expected_error) as exc_info:
            await transport.connect_once(AsyncMock())

        assert exc_info.value.reason == expected_reason

    async def test_sync_uses_channel_before_rest_heartbeat(self):
        worker_id = uuid.uuid4()
        snapshot = Mock()
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock()
        channel_by_ref: dict[str, WorkPoolWorkerChannel] = {}

        def connect_factory(*args: Any, **kwargs: Any) -> FakeWorkerChannelConnect:
            channel = channel_by_ref["channel"]
            websocket = FakeWorkerChannelWebSocket(
                [
                    {"type": "auth_success"},
                    worker_channel_ready_frame(
                        channel.consumer_id, worker_id=worker_id
                    ),
                ]
            )
            return FakeWorkerChannelConnect(websocket)

        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
            connect_factory=connect_factory,
        )
        channel_by_ref["channel"] = channel

        async with anyio.create_task_group() as task_group:
            await channel.sync(task_group)
            task_group.cancel_scope.cancel()

        client.read_work_pool.assert_not_awaited()
        client.send_worker_heartbeat.assert_not_awaited()
        snapshot.assert_called_once()
        assert channel.rest_fallback_enabled is False

    async def test_stop_before_run_scope_cancels_started_channel(self):
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock()
        channel_by_ref: dict[str, WorkPoolWorkerChannel] = {}
        connect_context_by_ref: dict[str, FakeWorkerChannelConnect] = {}

        def connect_factory(*args: Any, **kwargs: Any) -> FakeWorkerChannelConnect:
            channel = channel_by_ref["channel"]
            websocket = FakeWorkerChannelWebSocket(
                [
                    {"type": "auth_success"},
                    worker_channel_ready_frame(channel.consumer_id),
                ]
            )
            connect_context = FakeWorkerChannelConnect(websocket)
            connect_context_by_ref["connect_context"] = connect_context
            return connect_context

        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            connect_factory=connect_factory,
        )
        channel_by_ref["channel"] = channel

        async with anyio.create_task_group() as task_group:
            await channel.sync(task_group)
            channel.stop()

            with anyio.fail_after(1):
                while not connect_context_by_ref["connect_context"].exited:
                    await anyio.sleep(0)

            task_group.cancel_scope.cancel()

        client.read_work_pool.assert_not_awaited()
        client.send_worker_heartbeat.assert_not_awaited()

    async def test_sync_skips_rest_when_websocket_is_healthy(self):
        worker_id = uuid.uuid4()
        snapshot = Mock()
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock()
        channel_by_ref: dict[str, WorkPoolWorkerChannel] = {}

        def connect_factory(*args: Any, **kwargs: Any) -> FakeWorkerChannelConnect:
            channel = channel_by_ref["channel"]
            websocket = FakeWorkerChannelWebSocket(
                [
                    {"type": "auth_success"},
                    worker_channel_ready_frame(
                        channel.consumer_id, worker_id=worker_id
                    ),
                ]
            )
            return FakeWorkerChannelConnect(websocket)

        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
            connect_factory=connect_factory,
        )
        channel_by_ref["channel"] = channel

        async with anyio.create_task_group() as task_group:
            await channel.sync(task_group)
            task_group.cancel_scope.cancel()

        client.read_work_pool.assert_not_awaited()
        client.send_worker_heartbeat.assert_not_awaited()
        snapshot.assert_called_once()
        assert channel.rest_fallback_enabled is False

    async def test_sync_times_out_setup_for_rest_fallback(self):
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock(
            return_value=WorkPool(
                name="test-work-pool",
                type="test",
                base_job_template={"job_configuration": {}, "variables": {}},
                default_queue_id=uuid.uuid4(),
            )
        )
        websocket = FakeWorkerChannelWebSocket([{"type": "auth_success"}])
        connect_context = FakeWorkerChannelConnect(websocket)
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            reconnect_base_seconds=0,
            setup_timeout_seconds=0.01,
            connect_factory=lambda *args, **kwargs: connect_context,
        )

        async with anyio.create_task_group() as task_group:
            await channel.sync(task_group)
            task_group.cancel_scope.cancel()

        assert channel.rest_fallback_enabled is True
        client.send_worker_heartbeat.assert_awaited_once()

    async def test_sync_creates_work_pool_and_sends_rest_heartbeat_on_fallback(self):
        worker_id = uuid.uuid4()
        work_pool = WorkPool(
            name="test-work-pool",
            type="test",
            base_job_template={"job_configuration": {}, "variables": {}},
            default_queue_id=uuid.uuid4(),
        )
        snapshot = Mock()
        client = worker_channel_test_client(worker_id=worker_id)
        client.read_work_pool = AsyncMock(side_effect=ObjectNotFound("missing"))
        client.create_work_pool = AsyncMock(return_value=work_pool)
        client.update_work_pool = AsyncMock()
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url=None,
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            base_job_template={"custom": "template"},
            default_base_job_template={"job_configuration": {}, "variables": {}},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )

        await channel.sync(None)

        client.create_work_pool.assert_awaited_once()
        created_work_pool = client.create_work_pool.await_args.kwargs["work_pool"]
        assert created_work_pool.name == "test-work-pool"
        assert created_work_pool.type == "test"
        assert created_work_pool.base_job_template == {"custom": "template"}
        client.update_work_pool.assert_not_awaited()
        client.send_worker_heartbeat.assert_awaited_once()
        snapshot.assert_called_once_with(work_pool)
        assert channel.worker_id == worker_id

    async def test_sync_handles_concurrent_pool_creation_on_rest_fallback(self):
        # When two workers start at the same time, both can see ObjectNotFound
        # from read_work_pool before either has created the pool. One worker's
        # create_work_pool call succeeds, and the other gets ObjectAlreadyExists.
        # The losing worker should re-read the now-existing pool rather than
        # bubble the exception up and fail setup.
        work_pool = WorkPool(
            name="test-work-pool",
            type="test",
            base_job_template={"job_configuration": {}, "variables": {}},
            default_queue_id=uuid.uuid4(),
        )
        snapshot = Mock()
        client = worker_channel_test_client()
        # First read: pool doesn't exist yet.
        # Second read (after the create race lost): pool now exists.
        client.read_work_pool = AsyncMock(
            side_effect=[ObjectNotFound("missing"), work_pool]
        )
        client.create_work_pool = AsyncMock(
            side_effect=ObjectAlreadyExists(http_exc=Mock())
        )
        client.update_work_pool = AsyncMock()
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url=None,
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={"job_configuration": {}, "variables": {}},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )

        await channel.sync(None)

        assert client.read_work_pool.await_count == 2
        client.create_work_pool.assert_awaited_once()
        client.update_work_pool.assert_not_awaited()
        client.send_worker_heartbeat.assert_awaited_once()
        snapshot.assert_called_once_with(work_pool)

    async def test_sync_repairs_missing_rest_work_pool_template(self):
        work_pool = WorkPool(
            name="test-work-pool",
            type="test",
            base_job_template={},
            default_queue_id=uuid.uuid4(),
        )
        snapshot = Mock()
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock(return_value=work_pool)
        client.create_work_pool = AsyncMock()
        client.update_work_pool = AsyncMock()
        default_base_job_template = {"job_configuration": {}, "variables": {}}
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url=None,
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template=default_base_job_template,
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )

        await channel.sync(None)

        client.create_work_pool.assert_not_awaited()
        client.update_work_pool.assert_awaited_once()
        updated_work_pool = client.update_work_pool.await_args.kwargs["work_pool"]
        assert updated_work_pool.base_job_template == default_base_job_template
        assert work_pool.base_job_template == default_base_job_template
        snapshot.assert_called_once_with(work_pool)

    async def test_sync_discards_rest_work_pool_if_snapshot_arrives_during_read(self):
        stale_template = {"job_configuration": {"env": {"STALE": "true"}}}
        fresh_template = {"job_configuration": {"env": {"FRESH": "true"}}}
        stale_work_pool = WorkPool(
            name="test-work-pool",
            type="test",
            base_job_template=stale_template,
            default_queue_id=uuid.uuid4(),
        )
        snapshot = Mock()
        client = worker_channel_test_client()

        async def read_work_pool(work_pool_name: str) -> WorkPool:
            assert work_pool_name == "test-work-pool"
            channel._protocol.handle_work_pool_snapshot(
                worker_channel_snapshot_payload(1, base_job_template=fresh_template)
            )
            channel.state.mark_healthy()
            return stale_work_pool

        client.read_work_pool = AsyncMock(side_effect=read_work_pool)
        client.update_work_pool = AsyncMock()
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )

        await channel.sync(None)

        client.update_work_pool.assert_not_awaited()
        client.send_worker_heartbeat.assert_not_awaited()
        snapshot.assert_called_once()
        assert snapshot.call_args.args[0].base_job_template == fresh_template

    async def test_sync_discards_rest_work_pool_if_snapshot_arrives_during_repair(self):
        fresh_template = {"job_configuration": {"env": {"FRESH": "true"}}}
        work_pool = WorkPool(
            name="test-work-pool",
            type="test",
            base_job_template={},
            default_queue_id=uuid.uuid4(),
        )
        snapshot = Mock()
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock(return_value=work_pool)

        async def update_work_pool(*args: Any, **kwargs: Any) -> None:
            channel._protocol.handle_work_pool_snapshot(
                worker_channel_snapshot_payload(1, base_job_template=fresh_template)
            )
            channel.state.mark_healthy()

        client.update_work_pool = AsyncMock(side_effect=update_work_pool)
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={"job_configuration": {}, "variables": {}},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )

        await channel.sync(None)

        client.update_work_pool.assert_awaited_once()
        client.send_worker_heartbeat.assert_not_awaited()
        snapshot.assert_called_once()
        assert snapshot.call_args.args[0].base_job_template == fresh_template

    async def test_endpoint_unavailable_is_terminal_rest_fallback(self):
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock(
            return_value=WorkPool(
                name="test-work-pool",
                type="test",
                base_job_template={"job_configuration": {}, "variables": {}},
                default_queue_id=uuid.uuid4(),
            )
        )

        def connect_factory(*args: Any, **kwargs: Any):
            raise OSError("endpoint not available")

        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            reconnect_base_seconds=0,
            connect_factory=connect_factory,
        )

        async with anyio.create_task_group() as task_group:
            await channel.sync(task_group)
            task_group.cancel_scope.cancel()

        assert channel.state.terminal is True
        assert channel.state.reason == "endpoint_unavailable"
        assert channel.rest_fallback_enabled is True
        client.send_worker_heartbeat.assert_awaited_once()

    async def test_unhealthy_channel_reconnects_with_rest_fallback_active(self):
        attempts = 0
        channel_by_ref: dict[str, WorkPoolWorkerChannel] = {}
        first_connect: FakeWorkerChannelConnect | None = None

        def connect_factory(*args: Any, **kwargs: Any):
            nonlocal attempts, first_connect
            attempts += 1
            if attempts == 1:
                channel = channel_by_ref["channel"]
                first_websocket = FakeWorkerChannelWebSocket(
                    [
                        {"type": "auth_success"},
                        worker_channel_ready_frame(channel.consumer_id),
                        OSError("connection dropped"),
                    ]
                )
                first_connect = FakeWorkerChannelConnect(first_websocket)
                return first_connect
            raise WorkerChannelTerminalError("stop", "stop")

        channel = WorkPoolWorkerChannel(
            client=worker_channel_test_client(),
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            reconnect_base_seconds=0,
            connect_factory=connect_factory,
        )
        channel_by_ref["channel"] = channel

        async with anyio.create_task_group() as task_group:
            await channel.sync(task_group)
            with anyio.fail_after(1):
                while not channel.state.terminal:
                    await anyio.sleep(0)
            task_group.cancel_scope.cancel()

        assert attempts == 2
        assert first_connect is not None
        assert first_connect.exited
        assert channel.rest_fallback_enabled is True
        assert channel.state.terminal is True

    async def test_channel_sends_rest_heartbeat_while_fallback_is_enabled(self):
        worker_id = uuid.uuid4()
        client = worker_channel_test_client(worker_id=worker_id)
        client.read_work_pool = AsyncMock(
            return_value=WorkPool(
                name="test-work-pool",
                type="test",
                base_job_template={"job_configuration": {}, "variables": {}},
                default_queue_id=uuid.uuid4(),
            )
        )
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url=None,
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
        )

        await channel.sync(None)

        client.send_worker_heartbeat.assert_awaited_once_with(
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            heartbeat_interval_seconds=30,
            get_worker_id=False,
        )
        assert channel.worker_id == worker_id

    async def test_protocol_does_not_repeat_recorded_metadata(self):
        async def worker_metadata() -> WorkerMetadata:
            return WorkerMetadata(
                integrations=[Integration(name="prefect-aws", version="1.0.0")]
            )

        protocol = WorkerChannelProtocolHandler(
            consumer_id=uuid7(),
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=worker_metadata,
            classify_closed_connection=lambda exc: WorkerChannelTerminalError(
                "connection_lost", str(exc)
            ),
            logger=logging.getLogger("test-worker-channel"),
        )

        hello = await protocol.build_hello_frame()
        assert hello.payload.worker_metadata == {
            "integrations": [{"name": "prefect-aws", "version": "1.0.0"}]
        }

        protocol.record_worker_metadata_sent()
        hello = await protocol.build_hello_frame()

        assert protocol.worker_metadata_sent is True
        assert hello.payload.worker_metadata is None

    async def test_healthy_channel_keeps_rest_work_pool_sync_after_initial_snapshot(
        self,
    ):
        rest_work_pool = WorkPool(
            name="test-work-pool",
            type="test",
            base_job_template={"job_configuration": {"env": {"REST": "true"}}},
            default_queue_id=uuid.uuid4(),
        )
        snapshot = Mock()
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock(return_value=rest_work_pool)
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url="http://localhost:4200/api",
            work_pool_is_available=lambda: True,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=True,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
            on_work_pool_snapshot=snapshot,
        )
        channel._protocol.handle_work_pool_snapshot(worker_channel_snapshot_payload(1))
        snapshot.reset_mock()
        channel.state.mark_healthy()

        await channel.sync(None)

        client.read_work_pool.assert_awaited_once_with(work_pool_name="test-work-pool")
        client.send_worker_heartbeat.assert_not_awaited()
        snapshot.assert_called_once_with(rest_work_pool)

    async def test_channel_skips_rest_heartbeat_without_work_pool(self):
        client = worker_channel_test_client()
        client.read_work_pool = AsyncMock(side_effect=ObjectNotFound("missing"))
        channel = WorkPoolWorkerChannel(
            client=client,
            api_url=None,
            work_pool_is_available=lambda: False,
            work_pool_name="test-work-pool",
            worker_name="test-worker",
            worker_type="test",
            heartbeat_interval_seconds=30,
            work_queue_names=[],
            create_pool_if_not_found=False,
            default_base_job_template={},
            worker_metadata=no_worker_channel_metadata,
            logger=logging.getLogger("test-worker-channel"),
        )

        await channel.sync(None)

        client.send_worker_heartbeat.assert_not_awaited()


@pytest.mark.parametrize(
    "work_pool_env, deployment_env, flow_run_env, expected_env",
    [
        (
            {},
            {"test-var": "foo"},
            {"another-var": "boo"},
            {"test-var": "foo", "another-var": "boo"},
        ),
        (
            {"A": "1", "B": "2"},
            {"A": "1", "B": "3"},
            {},
            {"A": "1", "B": "3"},
        ),
        (
            {"A": "1", "B": "2"},
            {"C": "3", "D": "4"},
            {},
            {"A": "1", "B": "2", "C": "3", "D": "4"},
        ),
        (
            {"A": "1", "B": "2"},
            {"C": "42"},
            {"C": "3", "D": "4"},
            {"A": "1", "B": "2", "C": "3", "D": "4"},
        ),
        (
            {"A": "1", "B": "2"},
            {"B": ""},  # empty strings are considered values and will still override
            {},
            {"A": "1", "B": ""},
        ),
    ],
    ids=[
        "flow_run_into_deployment",
        "deployment_into_work_pool_overlap",
        "deployment_into_work_pool_no_overlap",
        "flow_run_into_work_pool",
        "try_overwrite_with_empty_str",
    ],
)
@pytest.mark.parametrize(
    "use_variable_defaults",
    [True, False],
    ids=["with_defaults", "without_defaults"],
)
async def test_env_merge_logic_is_deep(
    prefect_client,
    session,
    flow,
    work_pool,
    work_pool_env,
    deployment_env,
    flow_run_env,
    expected_env,
    use_variable_defaults,
):
    if work_pool_env:
        base_job_template = (
            {
                "job_configuration": {"env": "{{ env }}"},
                "variables": {
                    "properties": {"env": {"type": "object", "default": work_pool_env}}
                },
            }
            if use_variable_defaults
            else {
                "job_configuration": {"env": work_pool_env},
                "variables": {"properties": {"env": {"type": "object"}}},
            }
        )
        await models.workers.update_work_pool(
            session=session,
            work_pool_id=work_pool.id,
            work_pool=ServerWorkPoolUpdate(
                base_job_template=base_job_template,
                description="test",
                is_paused=False,
                concurrency_limit=None,
            ),
        )
        await session.commit()

    deployment = await models.deployments.create_deployment(
        session=session,
        deployment=Deployment(
            name="env-testing",
            tags=["test"],
            flow_id=flow.id,
            path="./subdir",
            entrypoint="/file.py:flow",
            parameter_openapi_schema={"type": "object", "properties": {}},
            job_variables={"env": deployment_env},
            work_queue_id=work_pool.default_queue_id,
        ),
    )
    await session.commit()

    flow_run = await prefect_client.create_flow_run_from_deployment(
        deployment.id,
        state=Pending(),
        job_variables={"env": flow_run_env},
    )

    async with WorkerTestImpl(
        name="test",
        work_pool_name=work_pool.name if work_pool_env else "test-work-pool",
    ) as worker:
        await worker.sync_with_backend()
        config = await worker.job_configuration.resolve_for_flow_run(
            flow_run,
            client=worker.client,
            work_pool=worker.work_pool,
            worker_name=worker.name,
            worker_id=worker.backend_id,
            deployment=schemas.responses.DeploymentResponse.model_validate(deployment),
        )

    for key, value in expected_env.items():
        assert config.env[key] == value


async def test_work_pool_env_from_job_configuration_merges_with_variable_defaults(
    prefect_client, session, flow, work_pool
):
    """
    Test for issue #19256: Work pool env vars should merge from both job_configuration
    and variable defaults, then merge with deployment env vars.

    When a work pool has env vars in BOTH job_configuration.env AND
    variables.properties.env.default, they should all be merged together along with
    deployment env vars.
    """
    # Configure work pool with env vars in BOTH places
    base_job_template = {
        "job_configuration": {
            "env": {
                "WORK_POOL_BASE_VAR": "from-job-config",  # Should NOT be lost
            }
        },
        "variables": {
            "properties": {
                "env": {
                    "type": "object",
                    "default": {"WORK_POOL_DEFAULT_VAR": "from-variable-defaults"},
                }
            }
        },
    }

    await models.workers.update_work_pool(
        session=session,
        work_pool_id=work_pool.id,
        work_pool=ServerWorkPoolUpdate(
            base_job_template=base_job_template,
            description="test",
            is_paused=False,
            concurrency_limit=None,
        ),
    )
    await session.commit()

    # Create deployment with its own env vars
    deployment = await models.deployments.create_deployment(
        session=session,
        deployment=Deployment(
            name="env-testing-merge",
            tags=["test"],
            flow_id=flow.id,
            path="./subdir",
            entrypoint="/file.py:flow",
            parameter_openapi_schema={"type": "object", "properties": {}},
            job_variables={"env": {"DEPLOYMENT_VAR": "from-deployment"}},
            work_queue_id=work_pool.default_queue_id,
        ),
    )
    await session.commit()

    flow_run = await prefect_client.create_flow_run_from_deployment(
        deployment.id,
        state=Pending(),
    )

    async with WorkerTestImpl(
        name="test",
        work_pool_name=work_pool.name,
    ) as worker:
        await worker.sync_with_backend()
        config = await worker.job_configuration.resolve_for_flow_run(
            flow_run,
            client=worker.client,
            work_pool=worker.work_pool,
            worker_name=worker.name,
            worker_id=worker.backend_id,
            deployment=schemas.responses.DeploymentResponse.model_validate(deployment),
        )

    # All env vars should be present: job_configuration + variable defaults + deployment
    assert config.env["WORK_POOL_BASE_VAR"] == "from-job-config"
    assert config.env["WORK_POOL_DEFAULT_VAR"] == "from-variable-defaults"
    assert config.env["DEPLOYMENT_VAR"] == "from-deployment"


async def test_configuration_build_uses_stable_work_pool_copy(
    prefect_client: PrefectClient,
    work_pool: WorkPool,
):
    """A mid-build snapshot apply must not retemplate the configuration the
    worker is currently assembling. Callers deepcopy `self.work_pool` before
    handing it to `BaseJobConfiguration.resolve_for_flow_run`."""

    @flow
    def test_flow():
        pass

    flow_run = await prefect_client.create_flow_run(
        test_flow,
        work_pool_name=work_pool.name,
    )
    initial_template = {
        "job_configuration": {"env": {"SNAPSHOT": "initial"}},
        "variables": {"properties": {}},
    }
    updated_template = {
        "job_configuration": {"env": {"SNAPSHOT": "updated"}},
        "variables": {"properties": {}},
    }
    worker_ref: dict[str, BaseWorker[Any, Any, Any]] = {}
    templates_used: list[dict[str, Any]] = []
    prepared_work_pools: list[WorkPool | None] = []
    worker_type = "stable-snapshot-test"

    class StableSnapshotJobConfiguration(BaseJobConfiguration):
        @classmethod
        async def from_template_and_values(
            cls,
            base_job_template: dict[str, Any],
            values: dict[str, Any],
            client: PrefectClient | None = None,
        ):
            templates_used.append(copy.deepcopy(base_job_template))
            worker_ref["worker"]._record_work_pool_snapshot(
                WorkPool(
                    name=work_pool.name,
                    type=worker_type,
                    base_job_template=updated_template,
                    default_queue_id=work_pool.default_queue_id,
                )
            )
            return await super().from_template_and_values(
                base_job_template=base_job_template,
                values=values,
                client=client,
            )

        def prepare_for_flow_run(
            self,
            flow_run: FlowRun,
            deployment: DeploymentResponse | None = None,
            flow: Flow | None = None,
            work_pool: WorkPool | None = None,
            worker_name: str | None = None,
            worker_id: uuid.UUID | None = None,
        ) -> None:
            prepared_work_pools.append(work_pool)
            return super().prepare_for_flow_run(
                flow_run=flow_run,
                deployment=deployment,
                flow=flow,
                work_pool=work_pool,
                worker_name=worker_name,
                worker_id=worker_id,
            )

    class StableSnapshotWorker(
        BaseWorker[StableSnapshotJobConfiguration, Any, BaseWorkerResult]
    ):
        type = worker_type
        job_configuration = StableSnapshotJobConfiguration

        async def run(
            self,
            flow_run: FlowRun,
            configuration: StableSnapshotJobConfiguration,
            task_status: anyio.abc.TaskStatus[int] | None = None,
        ) -> BaseWorkerResult:
            return BaseWorkerResult(identifier="test", status_code=0)

    async with StableSnapshotWorker(work_pool_name=work_pool.name) as worker:
        worker_ref["worker"] = worker
        worker._work_pool = WorkPool(
            name=work_pool.name,
            type=worker_type,
            base_job_template=initial_template,
            default_queue_id=work_pool.default_queue_id,
        )

        # Mirror the worker's internal call pattern: deepcopy then resolve.
        frozen_work_pool = copy.deepcopy(worker.work_pool)
        config = await worker.job_configuration.resolve_for_flow_run(
            flow_run,
            client=worker.client,
            work_pool=frozen_work_pool,
            worker_name=worker.name,
            worker_id=worker.backend_id,
        )

        assert worker._work_pool.base_job_template == updated_template

    assert templates_used == [initial_template]
    assert prepared_work_pools[0] is not None
    assert prepared_work_pools[0].base_job_template == initial_template
    assert config.env["SNAPSHOT"] == "initial"


class TestBaseWorkerHeartbeat:
    async def test_sync_with_backend_delegates_to_worker_channel(self, work_pool):
        with mock.patch("prefect.workers.base.WorkPoolWorkerChannel") as channel_cls:
            channel = Mock(
                set_client=Mock(),
                sync=AsyncMock(),
                stop=Mock(),
            )
            channel_cls.return_value = channel

            async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
                channel.sync.reset_mock()

                await worker.sync_with_backend()

                channel.sync.assert_awaited_once_with(worker._runs_task_group)

    async def test_sync_with_backend_updates_existing_channel_client(self, work_pool):
        with mock.patch("prefect.workers.base.WorkPoolWorkerChannel") as channel_cls:
            channel = Mock(
                set_client=Mock(),
                sync=AsyncMock(),
                stop=Mock(),
            )
            channel_cls.return_value = channel

            async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
                channel.set_client.reset_mock()
                channel.sync.reset_mock()

                await worker.sync_with_backend()

                channel.set_client.assert_called_once_with(worker._client)
                channel.sync.assert_awaited_once_with(worker._runs_task_group)

    async def test_sync_with_backend_falls_back_to_rest_when_channel_endpoint_is_missing(
        self, prefect_client, work_pool, monkeypatch
    ):
        attempts = 0

        async def endpoint_unavailable(self, handshake):
            nonlocal attempts
            attempts += 1
            raise WorkerChannelTerminalError(
                "endpoint_unavailable",
                "Worker channel endpoint is unavailable",
            )

        monkeypatch.setattr(
            WorkerChannelTransport,
            "connect_once",
            endpoint_unavailable,
        )

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            assert worker._worker_channel is not None
            assert worker._worker_channel.state.terminal is True
            assert worker._worker_channel.state.reason == "endpoint_unavailable"
            assert worker._worker_channel.rest_fallback_enabled is True

            workers = await prefect_client.read_workers_for_work_pool(
                work_pool_name=work_pool.name
            )

        assert attempts == 1
        assert len(workers) == 1
        assert workers[0].name == worker.name

    async def test_sync_with_backend_falls_back_to_rest_when_channel_setup_times_out(
        self, prefect_client, work_pool, monkeypatch
    ):
        attempts = 0

        async def never_ready(self, handshake):
            nonlocal attempts
            attempts += 1
            await anyio.sleep_forever()

        monkeypatch.setattr(
            "prefect.workers._worker_channel._transport.WORKER_CHANNEL_SETUP_TIMEOUT_SECONDS",
            0.01,
        )
        monkeypatch.setattr(
            WorkerChannelTransport,
            "connect_once",
            never_ready,
        )

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            assert worker._worker_channel is not None
            assert worker._worker_channel.rest_fallback_enabled is True

            workers = await prefect_client.read_workers_for_work_pool(
                work_pool_name=work_pool.name
            )

        assert attempts >= 1
        assert len(workers) == 1
        assert workers[0].name == worker.name

    async def test_work_pool_snapshot_fills_default_base_job_template(self, work_pool):
        worker = WorkerTestImpl(work_pool_name=work_pool.name)
        snapshot = work_pool
        snapshot.base_job_template = {}

        worker._record_work_pool_snapshot(snapshot)

        assert worker._work_pool is not None
        assert (
            worker._work_pool.base_job_template
            == WorkerTestImpl.get_default_base_job_template()
        )

    async def test_worker_heartbeat_sends_integrations(
        self, work_pool, hosted_api_server
    ):
        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            await worker.start(run_once=True)
            with (
                mock.patch(
                    "prefect.workers.base.load_prefect_collections"
                ) as mock_load_prefect_collections,
                mock.patch(
                    "prefect.client.orchestration._work_pools.client.WorkPoolAsyncClient.send_worker_heartbeat",
                ) as mock_send_worker_heartbeat_post,
                mock.patch("prefect.workers.base.distributions") as mock_distributions,
            ):
                mock_load_prefect_collections.return_value = {
                    "prefect_aws": "1.0.0",
                }
                mock_distributions.return_value = [
                    mock.MagicMock(
                        metadata={"Name": "prefect-aws"},
                        version="1.0.0",
                    )
                ]

                async with get_client() as client:
                    worker._client = client
                    worker._client.server_type = ServerType.CLOUD
                    await worker.sync_with_backend()

                mock_send_worker_heartbeat_post.assert_called_once_with(
                    work_pool_name=work_pool.name,
                    worker_name=worker.name,
                    heartbeat_interval_seconds=30.0,
                    get_worker_id=True,
                    worker_metadata=WorkerMetadata(
                        integrations=[Integration(name="prefect-aws", version="1.0.0")]
                    ),
                )

            assert worker._worker_channel is not None
            assert worker._worker_channel.worker_metadata_sent

    async def test_custom_worker_can_send_arbitrary_metadata(
        self, work_pool, hosted_api_server
    ):
        class CustomWorker(BaseWorker):
            type: str = "test-custom-metadata"
            job_configuration: Type[BaseJobConfiguration] = BaseJobConfiguration

            async def run(self):
                pass

            async def _worker_metadata(self) -> WorkerMetadata:
                return WorkerMetadata(
                    **{
                        "integrations": [{"name": "prefect-aws", "version": "1.0.0"}],
                        "custom_field": "heya",
                    }
                )

        async with CustomWorker(work_pool_name=work_pool.name) as worker:
            await worker.start(run_once=True)
            with (
                mock.patch(
                    "prefect.workers.base.load_prefect_collections"
                ) as mock_load_prefect_collections,
                mock.patch(
                    "prefect.client.orchestration._work_pools.client.WorkPoolAsyncClient.send_worker_heartbeat",
                ) as mock_send_worker_heartbeat_post,
                mock.patch("prefect.workers.base.distributions") as mock_distributions,
            ):
                mock_load_prefect_collections.return_value = {
                    "prefect_aws": "1.0.0",
                }
                mock_distributions.return_value = [
                    mock.MagicMock(
                        metadata={"Name": "prefect-aws"},
                        version="1.0.0",
                    )
                ]

                async with get_client() as client:
                    worker._client = client
                    worker._client.server_type = ServerType.CLOUD
                    await worker.sync_with_backend()

                mock_send_worker_heartbeat_post.assert_called_once_with(
                    work_pool_name=work_pool.name,
                    worker_name=worker.name,
                    heartbeat_interval_seconds=30.0,
                    get_worker_id=True,
                    worker_metadata=WorkerMetadata(
                        integrations=[Integration(name="prefect-aws", version="1.0.0")],
                        custom_field="heya",
                    ),
                )

            assert worker._worker_channel is not None
            assert worker._worker_channel.worker_metadata_sent


async def test_worker_gives_labels_to_flow_runs_when_using_cloud_api(
    prefect_client: PrefectClient,
    worker_deployment_wq1: Deployment,
    work_pool: WorkPool,
):
    def create_run_with_deployment(state: State):
        return prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id, state=state
        )

    flow_run = await create_run_with_deployment(
        Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1))
    )

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        assert worker._client is not None
        worker._client.server_type = ServerType.CLOUD

        worker._work_pool = work_pool
        worker.run = AsyncMock()

        await worker.get_and_submit_flow_runs()

    flow_run = await prefect_client.read_flow_run(flow_run.id)

    expected_labels = {
        "prefect.worker.name": worker.name,
        "prefect.worker.type": worker.type,
        "prefect.work-pool.name": work_pool.name,
        "prefect.work-pool.id": str(work_pool.id),
    }

    for key, value in expected_labels.items():
        assert flow_run.labels[key] == value


async def test_worker_removes_flow_run_from_submitting_when_not_ready(
    prefect_client: PrefectClient,
    worker_deployment_wq1: Deployment,
    work_pool: WorkPool,
):
    """
    Regression test for https://github.com/PrefectHQ/prefect/issues/16027
    """

    flow_run = await prefect_client.create_flow_run_from_deployment(
        worker_deployment_wq1.id, state=Pending()
    )

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        # Mock _propose_pending_state to return False
        worker._propose_pending_state = AsyncMock(return_value=False)

        await worker.get_and_submit_flow_runs()
        # Verify the flow run was removed from _submitting_flow_run_ids
        assert flow_run.id not in worker._submitting_flow_run_ids


async def test_worker_proposes_submitting_state_before_run(
    prefect_client: PrefectClient,
    worker_deployment_wq1: Deployment,
    work_pool: WorkPool,
):
    flow_run = await prefect_client.create_flow_run_from_deployment(
        worker_deployment_wq1.id,
        state=Scheduled(scheduled_time=now_fn("UTC") - timedelta(days=1)),
    )

    propose_submitting_mock = AsyncMock()

    async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
        worker._propose_submitting_state = propose_submitting_mock
        worker.run = AsyncMock(
            return_value=BaseWorkerResult(status_code=0, identifier="test-run")
        )

        await worker.get_and_submit_flow_runs()

    propose_submitting_mock.assert_called_once()
    call_args = propose_submitting_mock.call_args
    assert call_args[0][0].id == flow_run.id


class TestSubmit:
    @pytest.fixture
    def mock_run_process(self, monkeypatch: pytest.MonkeyPatch):
        mock = AsyncMock()
        monkeypatch.setattr(anyio, "run_process", mock)
        return mock

    @pytest.fixture
    def frozen_uuid(self, monkeypatch: pytest.MonkeyPatch):
        # Freeze the UUID to ensure the same value is used for the duration of the test
        frozen_uuid = uuid.uuid4()
        monkeypatch.setattr(uuid, "uuid4", lambda: frozen_uuid)
        return frozen_uuid

    @pytest.fixture
    async def work_pool(self, prefect_client: PrefectClient):
        UPLOAD_STEP = {
            "prefect_mock.experimental.bundles.upload": {
                "requires": "prefect-mock==0.5.5",
                "bucket": "test-bucket",
                "credentials_block_name": "my-creds",
            }
        }

        EXECUTE_STEP = {
            "prefect_mock.experimental.bundles.execute": {
                "requires": "prefect-mock==0.5.5",
                "bucket": "test-bucket",
                "credentials_block_name": "my-creds",
            }
        }

        result_storage_block = FakeResultStorageBlock(place="test-place")
        block_document_id = await result_storage_block.save(
            name="my-result-storage-block"
        )

        schema = BaseJobConfiguration.model_json_schema()
        for key, value in schema["properties"].items():
            if isinstance(value, dict):
                schema["properties"][key].pop("template", None)
        variables_schema = schema
        variables_schema.pop("title", None)
        base_job_template = {
            "job_configuration": BaseJobConfiguration.json_template(),
            "variables": variables_schema,
        }

        return await prefect_client.create_work_pool(
            WorkPoolCreate(
                name=f"test-{uuid.uuid4()}",
                type="infiltrated",
                storage_configuration=WorkPoolStorageConfiguration(
                    bundle_upload_step=UPLOAD_STEP,
                    bundle_execution_step=EXECUTE_STEP,
                    default_result_storage_block_id=block_document_id,
                ),
                base_job_template=base_job_template,
            )
        )

    @pytest.fixture
    async def work_pool_without_default_result_storage(
        self, prefect_client: PrefectClient
    ):
        UPLOAD_STEP = {
            "prefect_mock.experimental.bundles.upload": {
                "requires": "prefect-mock==0.5.5",
                "bucket": "test-bucket",
                "credentials_block_name": "my-creds",
            }
        }

        EXECUTE_STEP = {
            "prefect_mock.experimental.bundles.execute": {
                "requires": "prefect-mock==0.5.5",
                "bucket": "test-bucket",
                "credentials_block_name": "my-creds",
            }
        }

        schema = BaseJobConfiguration.model_json_schema()
        for key, value in schema["properties"].items():
            if isinstance(value, dict):
                schema["properties"][key].pop("template", None)
        variables_schema = schema
        variables_schema.pop("title", None)
        base_job_template = {
            "job_configuration": BaseJobConfiguration.json_template(),
            "variables": variables_schema,
        }

        return await prefect_client.create_work_pool(
            WorkPoolCreate(
                name=f"test-{uuid.uuid4()}",
                type="infiltrated",
                storage_configuration=WorkPoolStorageConfiguration(
                    bundle_upload_step=UPLOAD_STEP,
                    bundle_execution_step=EXECUTE_STEP,
                ),
                base_job_template=base_job_template,
            )
        )

    @pytest.fixture
    async def work_pool_missing_storage_configuration(
        self, prefect_client: PrefectClient
    ):
        return await prefect_client.create_work_pool(
            WorkPoolCreate(
                name=f"test-{uuid.uuid4()}",
            )
        )

    async def test_basic(
        self,
        work_pool: WorkPool,
        mock_run_process: AsyncMock,
        frozen_uuid: uuid.UUID,
        prefect_client: PrefectClient,
    ):
        spy = MagicMock()
        python_version_info = sys.version_info
        worker_name = "test-worker"

        class CompromisedWorker(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "infiltrated-launcher"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                spy(
                    flow_run=flow_run,
                    configuration=configuration,
                    task_status=task_status,
                )
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def unsuspecting_flow():
            print("I sure hope no spies are listening")

        async with CompromisedWorker(
            work_pool_name=work_pool.name, name=worker_name
        ) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(unsuspecting_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        expected_upload_command = [
            "uv",
            "run",
            "--quiet",
            "--with",
            "prefect-mock==0.5.5",
            "--python",
            f"{python_version_info.major}.{python_version_info.minor}",
            "-m",
            "prefect_mock.experimental.bundles.upload",
            "--bucket",
            "test-bucket",
            "--credentials-block-name",
            "my-creds",
            "--key",
            str(frozen_uuid),
            str(frozen_uuid),
        ]
        mock_run_process.assert_called_once_with(
            expected_upload_command,
            cwd=ANY,
        )
        expected_execute_command = [
            "uv",
            "run",
            "--with",
            "prefect-mock==0.5.5",
            "--python",
            f"{python_version_info.major}.{python_version_info.minor}",
            "-m",
            "prefect_mock.experimental.bundles.execute",
            "--bucket",
            "test-bucket",
            "--credentials-block-name",
            "my-creds",
            "--key",
            str(frozen_uuid),
        ]
        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert flow_run.work_pool_name == work_pool.name
        assert flow_run.work_queue_name == "default"
        assert flow_run.job_variables == {
            "command": command_to_string(expected_execute_command)
        }

        expected_configuration = await BaseJobConfiguration.from_template_and_values(
            work_pool.base_job_template,
            flow_run.job_variables or {},
        )

        expected_configuration.prepare_for_flow_run(
            flow_run=flow_run,
            flow=Flow(id=flow_run.flow_id, name=unsuspecting_flow.name, labels={}),
            work_pool=work_pool,
            worker_name=worker_name,
            worker_id=worker.backend_id,
        )

        spy.assert_called_once_with(
            flow_run=flow_run,
            configuration=expected_configuration,
            task_status=ANY,
        )

    @pytest.mark.windows
    async def test_basic_uses_execution_launcher_override(
        self,
        work_pool: WorkPool,
        mock_run_process: AsyncMock,
        frozen_uuid: uuid.UUID,
        prefect_client: PrefectClient,
    ):
        python_version_info = sys.version_info

        class CompromisedWorker(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "infiltrated"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def unsuspecting_flow():
            print("I sure hope no spies are listening")

        infrastructure_bound_flow = bind_flow_to_infrastructure(
            flow=unsuspecting_flow,
            work_pool=work_pool.name,
            worker_cls=CompromisedWorker,
            launcher={"execution": [r"C:\Program Files\Python\python.exe"]},
        )

        async with CompromisedWorker(work_pool_name=work_pool.name) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(infrastructure_bound_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        expected_upload_command = [
            "uv",
            "run",
            "--quiet",
            "--with",
            "prefect-mock==0.5.5",
            "--python",
            f"{python_version_info.major}.{python_version_info.minor}",
            "-m",
            "prefect_mock.experimental.bundles.upload",
            "--bucket",
            "test-bucket",
            "--credentials-block-name",
            "my-creds",
            "--key",
            str(frozen_uuid),
            str(frozen_uuid),
        ]
        mock_run_process.assert_called_once_with(
            expected_upload_command,
            cwd=ANY,
        )

        expected_execute_command = [
            r"C:\Program Files\Python\python.exe",
            "-m",
            "prefect_mock.experimental.bundles.execute",
            "--bucket",
            "test-bucket",
            "--credentials-block-name",
            "my-creds",
            "--key",
            str(frozen_uuid),
        ]
        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert flow_run.job_variables == {
            "command": command_to_string(expected_execute_command)
        }

    async def test_submission_failed(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
        mock_run_process: AsyncMock,
    ):
        class OverwhelmedWorker(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "overwhelmed"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                raise Exception("I need a vacation")

        @flow
        def test_flow():
            print("I'd like to speak to your supervisor")

        async with OverwhelmedWorker(work_pool_name=work_pool.name) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(test_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert flow_run.state
        assert flow_run.state.is_crashed()

        # Upload step should have been run
        mock_run_process.assert_called_once()

    async def test_bundle_creation_failure_crashes_flow_run(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
        tmp_path: Path,
    ):
        class BundleWorker(BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]):
            type = "bundle-worker"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ) -> BaseWorkerResult:
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def test_flow() -> None:
            pass

        bound_flow = bind_flow_to_infrastructure(
            flow=test_flow,
            work_pool=work_pool.name,
            worker_cls=BundleWorker,
            include_files=["config.yaml"],
            include_files_base_dir=tmp_path / "missing",
        )
        async with BundleWorker(work_pool_name=work_pool.name) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(bound_flow)

        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert flow_run.state is not None
        assert flow_run.state.is_crashed()
        assert flow_run.state.message is not None
        assert "include_files_base_dir" in flow_run.state.message

    async def test_work_pool_is_missing_storage_configuration(
        self,
        work_pool_missing_storage_configuration: WorkPool,
    ):
        spy = MagicMock()

        class UnsupportedWorker(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "unsupported"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                spy(flow_run, configuration, task_status)
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def test_flow():
            print("I've got a bad feeling about this")

        async with UnsupportedWorker(
            work_pool_name=work_pool_missing_storage_configuration.name
        ) as worker:
            with (
                pytest.warns(FutureWarning),
                pytest.raises(
                    Exception, match="Storage is not configured for work pool"
                ),
            ):
                future = await worker.submit(test_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        spy.assert_not_called()

    async def test_non_zero_status_code(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
        mock_run_process: AsyncMock,
    ):
        class OnStrikeWorker(BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]):
            type = "on-strike"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                return BaseWorkerResult(identifier="test", status_code=1)

        @flow
        def test_flow():
            print("I'd like to speak to your supervisor")

        async with OnStrikeWorker(work_pool_name=work_pool.name) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(test_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert flow_run.state
        assert flow_run.state.is_crashed()

        # Upload step should have been run
        mock_run_process.assert_called_once()

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_flow_from_within_flow(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
    ):
        class PlainOlWorker(BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]):
            type = "plain-ol'"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def test_flow():
            print("It ain't much, but it's a living")

        @flow
        async def parent_flow():
            flow_run_ctx = FlowRunContext.get()
            async with PlainOlWorker(work_pool_name=work_pool.name) as worker:
                with pytest.warns(FutureWarning):
                    future = await worker.submit(test_flow)
                    assert isinstance(future, PrefectFlowRunFuture)
                    return flow_run_ctx.flow_run.id, future.flow_run_id

        parent_flow_run_id, child_flow_run_id = await parent_flow()
        parent_flow_run = await prefect_client.read_flow_run(parent_flow_run_id)
        child_flow_run = await prefect_client.read_flow_run(child_flow_run_id)
        parent_task_run = await prefect_client.read_task_run(
            child_flow_run.parent_task_run_id
        )
        assert child_flow_run.parent_task_run_id == parent_task_run.id
        assert parent_task_run.flow_run_id == parent_flow_run.id

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_flow_from_within_flow_propagates_tags(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
    ):
        class AnotherPlainOlWorker(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "another-plain-ol'"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def test_flow():
            print("It ain't much, but it's a living")

        async with AnotherPlainOlWorker(work_pool_name=work_pool.name) as worker:
            with TagsContext(current_tags={"foo", "bar"}):
                with pytest.warns(FutureWarning):
                    future = await worker.submit(test_flow)
                    assert isinstance(future, PrefectFlowRunFuture)

        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert set(flow_run.tags) == {"foo", "bar"}

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_uses_work_pool_result_storage_block(
        self,
        work_pool: WorkPool,
    ):
        class SubmitterOfUnpreparedFlows(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "base-worker-work-pool-result-storage"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                # Need to trick the client into saving the result record
                with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
                    fake_state = Completed(
                        data=ResultRecord(
                            result="Totally legit result",
                            metadata=ResultRecordMetadata(
                                serializer=PickleSerializer(),
                                expiration=None,
                                storage_key="totally-legit-result",
                                storage_block_id=work_pool.storage_configuration.default_result_storage_block_id,
                            ),
                        )
                    )
                    await self.client.set_flow_run_state(
                        flow_run.id,
                        state=fake_state,
                        force=True,
                    )
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def unprepared_flow():
            print("Dang it, I forgot my result storage. Can I borrow yours?")

        async with SubmitterOfUnpreparedFlows(work_pool_name=work_pool.name) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(unprepared_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        # Return value is hardcoded in the FakeResultStorage to ensure it is used as expected
        assert future.result() == "Here you go chief!"

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_uses_server_default_result_storage_block(
        self,
        work_pool_without_default_result_storage: WorkPool,
        prefect_client: PrefectClient,
    ):
        result_storage_block = FakeResultStorageBlock(place="test-place")
        block_document_id = await result_storage_block.save(
            name=f"my-server-default-result-storage-block-{uuid.uuid4()}"
        )
        await prefect_client.update_server_default_result_storage(block_document_id)

        class SubmitterOfUnpreparedFlows(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "base-worker-server-default-result-storage"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
                    fake_state = Completed(
                        data=ResultRecord(
                            result="Totally legit result",
                            metadata=ResultRecordMetadata(
                                serializer=PickleSerializer(),
                                expiration=None,
                                storage_key="totally-legit-result",
                                storage_block_id=block_document_id,
                            ),
                        )
                    )
                    await self.client.set_flow_run_state(
                        flow_run.id,
                        state=fake_state,
                        force=True,
                    )
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def unprepared_flow():
            print("I forgot my result storage. Can I use the server default?")

        try:
            async with SubmitterOfUnpreparedFlows(
                work_pool_name=work_pool_without_default_result_storage.name
            ) as worker:
                with pytest.warns(FutureWarning):
                    future = await worker.submit(unprepared_flow)
                    assert isinstance(future, PrefectFlowRunFuture)

            assert future.result() == "Here you go chief!"
        finally:
            await prefect_client.clear_server_default_result_storage()

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_does_not_override_explicit_flow_result_storage(
        self,
        work_pool: WorkPool,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ):
        resolve_storage_mock = AsyncMock()
        monkeypatch.setattr(
            "prefect.results.aresolve_result_storage", resolve_storage_mock
        )

        @flow(result_storage=tmp_path / "explicit-result-storage")
        def prepared_flow():
            print("I already know where my results should go.")

        async with WorkerTestImpl(work_pool_name=work_pool.name) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(prepared_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        resolve_storage_mock.assert_not_awaited()

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_calls_initiate_run_if_implemented(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
    ):
        @flow
        def a_garden_variety_flow():
            pass

        run_spy = AsyncMock()
        initiate_run_spy = AsyncMock()

        class WorkerThatImplementsInitiateRun(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "worker-that-implements-initiate-run"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                run_spy()
                return BaseWorkerResult(identifier="test", status_code=0)

            async def _initiate_run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
            ):
                initiate_run_spy(
                    flow_run=flow_run,
                    configuration=configuration,
                )

        async with WorkerThatImplementsInitiateRun(
            work_pool_name=work_pool.name, name="test-worker"
        ) as worker:
            with pytest.warns(FutureWarning):
                future = await worker.submit(a_garden_variety_flow)
                assert isinstance(future, PrefectFlowRunFuture)

        assert run_spy.call_count == 0

        flow_run = await prefect_client.read_flow_run(future.flow_run_id)
        assert flow_run.work_pool_name == work_pool.name

        expected_configuration = await BaseJobConfiguration.from_template_and_values(
            work_pool.base_job_template,
            flow_run.job_variables or {},
        )

        expected_configuration.prepare_for_flow_run(
            flow_run=flow_run,
            flow=Flow(id=flow_run.flow_id, name=a_garden_variety_flow.name, labels={}),
            work_pool=work_pool,
            worker_name="test-worker",
            worker_id=worker.backend_id,
        )

        initiate_run_spy.assert_called_once_with(
            flow_run=flow_run,
            configuration=expected_configuration,
        )

        assert initiate_run_spy.call_count == 1

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_with_existing_flow_run_reuses_flow_run_id(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
    ):
        """Test that submit() with an existing flow_run reuses the flow run ID."""

        class RetryableWorker(BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]):
            type = "retryable"
            job_configuration = BaseJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def test_flow():
            return "success"

        async with RetryableWorker(work_pool_name=work_pool.name) as worker:
            # First submit to create a flow run
            with pytest.warns(FutureWarning):
                initial_future = await worker.submit(test_flow)
                assert isinstance(initial_future, PrefectFlowRunFuture)

            initial_flow_run = await prefect_client.read_flow_run(
                initial_future.flow_run_id
            )

            # Now submit again with the existing flow run to retry it
            with pytest.warns(FutureWarning):
                retry_future = await worker.submit(test_flow, flow_run=initial_flow_run)
                assert isinstance(retry_future, PrefectFlowRunFuture)

            # Should reuse the same flow run ID
            assert retry_future.flow_run_id == initial_future.flow_run_id

            # The state should be set to Pending for retry
            retried_flow_run = await prefect_client.read_flow_run(
                retry_future.flow_run_id
            )
            assert retried_flow_run.state is not None
            assert retried_flow_run.state.type == StateType.PENDING

    @pytest.mark.usefixtures("mock_run_process")
    async def test_submit_with_existing_flow_run_sets_state_to_pending(
        self,
        work_pool: WorkPool,
        prefect_client: PrefectClient,
    ):
        """Test that submit() with an existing flow_run sets the state to Pending."""

        class StateTrackingWorker(
            BaseWorker[BaseJobConfiguration, Any, BaseWorkerResult]
        ):
            type = "state-tracking"
            job_configuration = BaseJobConfiguration
            observed_states: list[str] = []

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                # Record the state when the run method is called
                current_run = await self.client.read_flow_run(flow_run.id)
                if current_run.state:
                    self.observed_states.append(current_run.state.type.value)
                return BaseWorkerResult(identifier="test", status_code=0)

        @flow
        def test_flow():
            return "done"

        async with StateTrackingWorker(work_pool_name=work_pool.name) as worker:
            # First submit creates a new flow run
            with pytest.warns(FutureWarning):
                initial_future = await worker.submit(test_flow)

            initial_flow_run = await prefect_client.read_flow_run(
                initial_future.flow_run_id
            )

            # Now submit again with the existing flow run
            with pytest.warns(FutureWarning):
                await worker.submit(test_flow, flow_run=initial_flow_run)

            # The state should have been set to Pending before the retry
            assert "PENDING" in worker.observed_states


class TestBackwardsCompatibility:
    async def test_backwards_compatibility_with_old_prepare_for_flow_run(
        self,
        work_pool: WorkPool,
        worker_deployment_wq1: Deployment,
        prefect_client: PrefectClient,
    ):
        class OldStyleJobConfiguration(BaseJobConfiguration):
            def prepare_for_flow_run(
                self,
                flow_run: FlowRun,
                deployment: Deployment | None = None,
                flow: Flow | None = None,
            ):
                pass

        class InfrastructureResult(BaseWorkerResult):
            pass

        class OldStyleWorker(
            BaseWorker[OldStyleJobConfiguration, Any, InfrastructureResult]
        ):
            type = "old-style"
            job_configuration = OldStyleJobConfiguration

            async def run(
                self,
                flow_run: FlowRun,
                configuration: BaseJobConfiguration,
                task_status: anyio.abc.TaskStatus[int] | None = None,
            ):
                return InfrastructureResult(identifier="test", status_code=0)

        flow_run = await prefect_client.create_flow_run_from_deployment(
            worker_deployment_wq1.id
        )

        # Should warn and not raise an error
        with pytest.warns(PrefectDeprecationWarning):
            async with OldStyleWorker(work_pool_name=work_pool.name) as worker:
                await worker.job_configuration.resolve_for_flow_run(
                    flow_run,
                    client=worker.client,
                    work_pool=worker.work_pool,
                    worker_name=worker.name,
                    worker_id=worker.backend_id,
                )


class TestWorkerCancellationHandling:
    """Tests for worker-side flow run cancellation handling."""

    async def test_cancellation_disabled_by_default(
        self,
        prefect_client: PrefectClient,
    ):
        """Test that cancellation handling is disabled by default."""
        async with WorkerTestImpl(
            work_pool_name="test-pool",
            name="test-worker",
        ) as worker:
            # Should not have set up cancellation observer
            assert worker._cancelling_observer is None

    async def test_cancellation_enabled_with_setting(
        self,
        prefect_client: PrefectClient,
    ):
        """Test that cancellation handling can be enabled via settings."""
        with temporary_settings(updates={PREFECT_WORKER_ENABLE_CANCELLATION: True}):
            async with WorkerTestImpl(
                work_pool_name="test-pool",
                name="test-worker",
            ) as worker:
                # Should have set up cancellation observer
                assert worker._cancelling_observer is not None

    async def test_cancel_run_skips_non_pending_flow_runs(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
    ):
        """Test that _cancel_run skips flow runs that were not pending."""

        @flow
        def test_flow():
            pass

        flow_run = await prefect_client.create_flow_run(
            test_flow, work_pool_name=work_pool.name
        )

        async with WorkerTestImpl(
            work_pool_name=work_pool.name,
            name="test-worker",
        ) as worker:
            # Create a flow run with start_time set (already started)
            flow_run_with_start_time = FlowRun(
                id=flow_run.id,
                flow_id=flow_run.flow_id,
                name=flow_run.name,
                state=Running(),
                start_time=now_fn("UTC"),
            )

            with mock.patch.object(
                worker.client, "read_flow_run", new_callable=AsyncMock
            ) as mock_read:
                mock_read.return_value = flow_run_with_start_time
                with mock.patch.object(worker, "kill_infrastructure") as mock_kill:
                    with mock.patch.object(
                        worker, "_mark_flow_run_as_cancelled"
                    ) as mock_mark:
                        await worker._cancel_run(flow_run.id)
                        mock_kill.assert_not_called()
                        mock_mark.assert_not_called()

    async def test_cancellation_observer_filters_by_work_pool(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
    ):
        """Test that the cancellation observer is configured to filter by work pool ID."""
        with temporary_settings(updates={PREFECT_WORKER_ENABLE_CANCELLATION: True}):
            async with WorkerTestImpl(
                work_pool_name=work_pool.name,
                name="test-worker",
            ) as worker:
                observer = worker._cancelling_observer
                assert observer is not None

                # Verify the event filter includes the work pool ID (not name)
                event_filter = observer._event_filter
                assert event_filter.event is not None
                assert event_filter.event.name == ["prefect.flow-run.Cancelling"]
                assert event_filter.any_resource is not None
                assert event_filter.any_resource.id == [
                    f"prefect.work-pool.{work_pool.id}"
                ]

    async def test_cancel_run_marks_cancelled_when_no_infrastructure(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
    ):
        """Test that flow runs without infrastructure_pid are marked as cancelled."""

        @flow
        def test_flow():
            pass

        flow_run = await prefect_client.create_flow_run(
            test_flow, work_pool_name=work_pool.name
        )
        # No infrastructure_pid and no start_time (pending)

        async with WorkerTestImpl(
            work_pool_name=work_pool.name,
            name="test-worker",
        ) as worker:
            with mock.patch.object(
                worker, "_mark_flow_run_as_cancelled", new_callable=AsyncMock
            ) as mock_mark_cancelled:
                await worker._cancel_run(flow_run.id)
                mock_mark_cancelled.assert_called_once()

    async def test_cancel_run_calls_kill_infrastructure(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
        deployment: DeploymentResponse,
    ):
        """Test that _cancel_run calls kill_infrastructure."""
        flow_run = await prefect_client.create_flow_run_from_deployment(
            deployment_id=deployment.id,
        )
        # Set infrastructure_pid but no start_time (pending)
        await prefect_client.update_flow_run(flow_run.id, infrastructure_pid="test-pid")

        async with WorkerTestImpl(
            work_pool_name=work_pool.name,
            name="test-worker",
        ) as worker:
            with mock.patch.object(
                worker, "kill_infrastructure", new_callable=AsyncMock
            ) as mock_kill:
                with mock.patch.object(
                    worker, "_mark_flow_run_as_cancelled", new_callable=AsyncMock
                ):
                    await worker._cancel_run(flow_run.id)
                    mock_kill.assert_called_once()
                    assert mock_kill.call_args[1]["infrastructure_pid"] == "test-pid"
                    assert mock_kill.call_args[1]["grace_seconds"] == 30

    async def test_cancel_run_handles_not_implemented(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
        deployment: DeploymentResponse,
    ):
        """Test that _cancel_run handles NotImplementedError gracefully by returning early."""
        flow_run = await prefect_client.create_flow_run_from_deployment(
            deployment_id=deployment.id,
        )
        await prefect_client.update_flow_run(flow_run.id, infrastructure_pid="test-pid")

        async with WorkerTestImpl(
            work_pool_name=work_pool.name,
            name="test-worker",
        ) as worker:
            with mock.patch.object(
                worker, "_mark_flow_run_as_cancelled", new_callable=AsyncMock
            ) as mock_mark:
                # kill_infrastructure raises NotImplementedError by default
                await worker._cancel_run(flow_run.id)
                # Should return early without marking as cancelled since worker
                # doesn't support killing infrastructure
                mock_mark.assert_not_called()

    async def test_teardown_cancellation_handling_cleans_up(self):
        """Test that teardown properly cleans up cancellation resources."""
        with temporary_settings(updates={PREFECT_WORKER_ENABLE_CANCELLATION: True}):
            worker = WorkerTestImpl(
                work_pool_name="test-pool",
                name="test-worker",
            )

            async with worker:
                assert worker._cancelling_observer is not None
                consumer_task = worker._cancelling_observer._consumer_task

            # After exit, task should be cancelled or done
            assert consumer_task.cancelled() or consumer_task.done()

    async def test_base_worker_kill_infrastructure_raises_not_implemented(self):
        """Test that base worker kill_infrastructure raises NotImplementedError."""
        worker = WorkerTestImpl(
            work_pool_name="test-pool",
            name="test-worker",
        )

        with pytest.raises(NotImplementedError, match="does not support killing"):
            await worker.kill_infrastructure(
                infrastructure_pid="test-pid",
                configuration=BaseJobConfiguration(),
                grace_seconds=30,
            )

    async def test_websocket_failure_falls_back_to_polling(
        self,
        prefect_client: PrefectClient,
    ):
        """Test that when the WebSocket consumer fails, we fall back to polling."""
        with temporary_settings(updates={PREFECT_WORKER_ENABLE_CANCELLATION: True}):
            async with WorkerTestImpl(
                work_pool_name="test-pool",
                name="test-worker",
            ) as worker:
                observer = worker._cancelling_observer
                assert observer is not None
                assert observer._consumer_task is not None
                assert observer._polling_task is None

                # Simulate WebSocket consumer task failing
                observer._consumer_task.cancel()
                try:
                    await observer._consumer_task
                except asyncio.CancelledError:
                    pass

                # Manually trigger the done callback with an exception
                failed_task = MagicMock()
                failed_task.cancelled.return_value = False
                failed_task.exception.return_value = RuntimeError("WebSocket failed")

                observer._start_polling_task(failed_task)

                # Should have started the polling task
                assert observer._polling_task is not None

    async def test_flow_run_ids_registered_with_observer(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
        deployment: DeploymentResponse,
    ):
        """Test that flow run IDs are registered with the observer when submitted."""
        flow_run = await prefect_client.create_flow_run_from_deployment(
            deployment_id=deployment.id,
            state=Scheduled(scheduled_time=now_fn("UTC")),
        )

        with temporary_settings(updates={PREFECT_WORKER_ENABLE_CANCELLATION: True}):
            async with WorkerTestImpl(
                work_pool_name=work_pool.name,
                name="test-worker",
            ) as worker:
                observer = worker._cancelling_observer
                assert observer is not None

                # Initially no in-flight flow runs
                assert flow_run.id not in observer._in_flight_flow_run_ids

                # Submit the flow run
                await worker.get_and_submit_flow_runs()

                # Flow run should be registered
                # Note: it may be removed quickly after submission completes
                # so we just verify the observer exists and is functioning
                assert observer._in_flight_flow_run_ids is not None


class TestWorkerDebugMode:
    def test_worker_debug_mode_sets_logger_to_debug(self):
        with temporary_settings(updates={PREFECT_WORKER_DEBUG_MODE: True}):
            worker = WorkerTestImpl(
                work_pool_name="test-pool",
                name="test-worker",
            )
            assert worker._logger.level == logging.DEBUG

    def test_worker_debug_mode_off_does_not_force_debug_level(self):
        with mock.patch(
            "prefect.workers.base.get_current_settings"
        ) as mock_get_settings:
            mock_get_settings.return_value.worker.debug_mode = False
            with mock.patch(
                "prefect.workers.base.get_worker_logger"
            ) as mock_get_logger:
                mock_logger = MagicMock()
                mock_get_logger.return_value = mock_logger
                WorkerTestImpl(
                    work_pool_name="test-pool",
                    name="test-worker",
                )
                mock_logger.setLevel.assert_not_called()

    def test_worker_debug_mode_does_not_affect_non_worker_loggers(self):
        with temporary_settings(updates={PREFECT_WORKER_DEBUG_MODE: True}):
            flow_run_logger = logging.getLogger("prefect.flow_runs")
            task_run_logger = logging.getLogger("prefect.task_runs")
            prefect_logger = logging.getLogger("prefect")

            level_before = {
                "flow_runs": flow_run_logger.level,
                "task_runs": task_run_logger.level,
                "prefect": prefect_logger.level,
            }

            worker = WorkerTestImpl(
                work_pool_name="test-pool",
                name="test-worker",
            )

            assert worker._logger.level == logging.DEBUG
            assert flow_run_logger.level == level_before["flow_runs"]
            assert task_run_logger.level == level_before["task_runs"]
            assert prefect_logger.level == level_before["prefect"]
