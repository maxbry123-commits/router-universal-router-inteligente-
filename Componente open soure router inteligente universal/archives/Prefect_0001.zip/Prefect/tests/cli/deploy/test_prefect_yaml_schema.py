"""Tests for the prefect.yaml JSON schema generation."""

import json
import uuid

import pytest
from jsonschema import Draft202012Validator, ValidationError, validate

from prefect import __development_base_path__
from prefect.cli.deploy._models import PrefectYamlModel


@pytest.fixture
def schema():
    """Load the generated JSON schema."""
    schema_path = __development_base_path__ / "schemas" / "prefect.yaml.schema.json"
    if not schema_path.exists():
        pytest.skip(
            "Schema file not generated yet - run generate_prefect_yaml_schema.py"
        )
    with open(schema_path) as f:
        return json.load(f)


class TestPrefectYamlSchema:
    def test_schema_file_exists(self):
        """Verify the schema file exists in the expected location."""
        schema_path = __development_base_path__ / "schemas" / "prefect.yaml.schema.json"
        assert schema_path.exists(), (
            "Schema file should exist at schemas/prefect.yaml.schema.json"
        )

    def test_schema_is_valid_json_schema(self, schema):
        """Verify the generated schema is a valid JSON schema."""
        # This will raise if the schema itself is invalid
        Draft202012Validator.check_schema(schema)

    def test_schema_has_required_metadata(self, schema):
        """Verify the schema has the expected metadata fields."""
        assert schema.get("title") == "Prefect YAML"
        assert "$schema" in schema
        assert "$id" in schema
        assert "prefect.yaml.schema.json" in schema["$id"]

    def test_schema_validates_empty_config(self, schema):
        """An empty config should be valid."""
        validate({}, schema)

    def test_schema_validates_minimal_deployment(self, schema):
        """A minimal deployment config should be valid."""
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        config = {
            "deployments": [
                {
                    "name": deployment_name,
                    "entrypoint": "flows.py:my_flow",
                }
            ]
        }
        validate(config, schema)

    def test_schema_validates_full_deployment(self, schema):
        """A fully-specified deployment config should be valid."""
        project_name = f"my-project-{uuid.uuid4()}"
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        pool_name = f"my-pool-{uuid.uuid4()}"
        config = {
            "name": project_name,
            "prefect-version": "3.0.0",
            "build": [
                {"prefect.deployments.steps.run_shell_script": {"script": "echo hello"}}
            ],
            "push": [],
            "pull": [
                {
                    "prefect.deployments.steps.git_clone": {
                        "repository": "https://github.com/org/repo"
                    }
                }
            ],
            "deployments": [
                {
                    "name": deployment_name,
                    "version": "1.0.0",
                    "tags": ["prod", "critical"],
                    "description": "A test deployment",
                    "entrypoint": "flows.py:my_flow",
                    "parameters": {"param1": "value1"},
                    "work_pool": {
                        "name": pool_name,
                        "work_queue_name": "default",
                        "job_variables": {"cpu": 2},
                    },
                    "schedules": [
                        {"cron": "0 0 * * *", "timezone": "America/New_York"},
                    ],
                }
            ],
        }
        validate(config, schema)

    def test_schema_rejects_invalid_deployments_type(self, schema):
        """deployments must be a list, not a string."""
        config = {"deployments": "not a list"}
        with pytest.raises(ValidationError) as exc_info:
            validate(config, schema)
        assert "not of type 'array'" in str(exc_info.value)

    def test_schema_matches_pydantic_model(self, schema):
        """The generated schema should match what PrefectYamlModel produces."""
        model_schema = PrefectYamlModel.model_json_schema()
        # Check that key definitions exist in both
        assert "DeploymentConfig" in schema.get("$defs", {})
        assert "DeploymentConfig" in model_schema.get("$defs", {})


class TestActionMappingNormalization:
    @pytest.mark.parametrize("action_field", ["build", "push", "pull"])
    def test_top_level_single_action_mapping_is_wrapped(self, action_field: str):
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        step_mapping = {
            "prefect.deployments.steps.run_shell_script": {"script": "echo hi"}
        }
        raw_data = {
            "name": f"my-project-{uuid.uuid4()}",
            "deployments": [
                {
                    "name": deployment_name,
                    "entrypoint": "flows.py:my_flow",
                }
            ],
            action_field: step_mapping,
        }

        model = PrefectYamlModel.model_validate(raw_data)

        assert getattr(model, action_field) == [step_mapping]

    def test_deployment_override_single_action_mapping_is_wrapped(self):
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        step_mapping = {
            "prefect.deployments.steps.run_shell_script": {"script": "echo hi"}
        }
        raw_data = {
            "deployments": [
                {
                    "name": deployment_name,
                    "entrypoint": "flows.py:my_flow",
                    "pull": step_mapping,
                }
            ]
        }

        model = PrefectYamlModel.model_validate(raw_data)

        assert model.deployments[0].pull == [step_mapping]

    def test_action_mapping_lists_are_preserved(self):
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        build_steps = [
            {"prefect.deployments.steps.run_shell_script": {"script": "echo hi"}}
        ]
        pull_steps = [
            {"prefect.deployments.steps.run_shell_script": {"script": "echo bye"}}
        ]
        raw_data = {
            "build": build_steps,
            "deployments": [
                {
                    "name": deployment_name,
                    "entrypoint": "flows.py:my_flow",
                    "pull": pull_steps,
                }
            ],
        }

        model = PrefectYamlModel.model_validate(raw_data)

        assert model.build == build_steps
        assert model.deployments[0].pull == pull_steps

    def test_null_action_mappings_remain_none_and_omitted_fields_stay_none(self):
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        raw_data = {
            "build": None,
            "deployments": [
                {
                    "name": deployment_name,
                    "entrypoint": "flows.py:my_flow",
                }
            ],
        }

        model = PrefectYamlModel.model_validate(raw_data)

        assert model.build is None
        assert model.push is None
        assert model.pull is None
        assert model.deployments[0].build is None
        assert model.deployments[0].push is None
        assert model.deployments[0].pull is None

    def test_empty_action_mappings_remain_dicts(self):
        deployment_name = f"my-deployment-{uuid.uuid4()}"
        raw_data = {
            "build": {},
            "deployments": [
                {
                    "name": deployment_name,
                    "entrypoint": "flows.py:my_flow",
                    "pull": {},
                }
            ],
        }

        model = PrefectYamlModel.model_validate(raw_data)

        assert model.build == {}
        assert model.deployments[0].pull == {}
