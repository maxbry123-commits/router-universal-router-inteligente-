import json
import sys
import uuid
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import AsyncMock

import httpx
import pytest
import readchar

from prefect import flow as flow_decorator
from prefect.cli.work_pool import work_pool_storage_configure_app
from prefect.client.orchestration import PrefectClient
from prefect.client.schemas.actions import (
    BlockSchemaCreate,
    BlockTypeCreate,
    WorkPoolCreate,
    WorkPoolStorageConfiguration,
    WorkPoolUpdate,
)
from prefect.client.schemas.objects import BlockDocument, WorkPool
from prefect.context import get_settings_context
from prefect.exceptions import ObjectNotFound, PrefectHTTPStatusError
from prefect.infrastructure import provisioners
from prefect.server.schemas.actions import BlockDocumentCreate, BlockDocumentUpdate
from prefect.settings import (
    PREFECT_DEFAULT_WORK_POOL_NAME,
    PREFECT_UI_URL,
    load_profile,
    temporary_settings,
)
from prefect.states import Pending, Running
from prefect.testing.cli import invoke_and_assert
from prefect.utilities.asyncutils import run_sync_in_worker_thread
from prefect.workers.base import BaseWorker
from prefect.workers.process import ProcessWorker

pytestmark = pytest.mark.clear_db

MOCK_PREFECT_UI_URL = "https://api.prefect.io"

FAKE_DEFAULT_BASE_JOB_TEMPLATE = {
    "job_configuration": {
        "fake": "{{ fake_var }}",
    },
    "variables": {
        "type": "object",
        "properties": {
            "fake_var": {
                "type": "string",
                "default": "fake",
            }
        },
    },
}


@pytest.fixture
def interactive_console(monkeypatch):
    import prefect.cli._app as _app_mod

    monkeypatch.setattr(_app_mod, "is_interactive", lambda: True)

    # `readchar` does not like the fake stdin provided by typer isolation so we provide
    # a version that does not require a fd to be attached
    def readchar():
        sys.stdin.flush()
        position = sys.stdin.tell()
        if not sys.stdin.read():
            print("TEST ERROR: CLI is attempting to read input but stdin is empty.")
            raise SystemExit(-2)
        else:
            sys.stdin.seek(position)
        return sys.stdin.read(1)

    monkeypatch.setattr("readchar._posix_read.readchar", readchar)


class TestCreate:
    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool(self, prefect_client):
        pool_name = "my-pool"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} -t fake",
        )
        assert res.exit_code == 0
        assert f"Created work pool {pool_name!r}" in res.output
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.name == pool_name
        assert client_res.base_job_template == FAKE_DEFAULT_BASE_JOB_TEMPLATE
        assert isinstance(client_res, WorkPool)

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool_with_base_job_template(
        self, prefect_client, mock_collection_registry
    ):
        pool_name = "my-olympic-pool"

        with temporary_settings({PREFECT_UI_URL: MOCK_PREFECT_UI_URL}):
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "create",
                    pool_name,
                    "--type",
                    "process",
                    "--base-job-template",
                    Path(__file__).parent
                    / "base-job-templates"
                    / "process-worker.json",
                ],
                expected_code=0,
                expected_output_contains=[
                    "Created work pool 'my-olympic-pool'",
                    "/work-pools/work-pool/",
                ],
            )

        client_res = await prefect_client.read_work_pool(pool_name)
        assert isinstance(client_res, WorkPool)
        assert client_res.name == pool_name
        assert client_res.base_job_template == {
            "job_configuration": {"command": "{{ command }}", "name": "{{ name }}"},
            "variables": {
                "properties": {
                    "command": {
                        "description": "Command to run.",
                        "title": "Command",
                        "type": "string",
                    },
                    "name": {
                        "description": "Description.",
                        "title": "Name",
                        "type": "string",
                    },
                },
                "type": "object",
            },
        }

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool_with_empty_name(
        self, prefect_client, mock_collection_registry
    ):
        await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool create '' -t process",
            expected_code=1,
            expected_output_contains=["name cannot be empty"],
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool_name_conflict(
        self, prefect_client, mock_collection_registry
    ):
        pool_name = "my-pool"
        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} -t process",
            expected_code=0,
            expected_output_contains=[f"Created work pool {pool_name!r}"],
        )
        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} -t process",
            expected_code=1,
            expected_output_contains=[
                f"Work pool named {pool_name!r} already exists. Use --overwrite to update it."
            ],
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_default_template(self, prefect_client):
        pool_name = "my-pool"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} -t fake",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.base_job_template == FAKE_DEFAULT_BASE_JOB_TEMPLATE

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_default_paused(self, prefect_client):
        pool_name = "my-pool"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} -t process",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.is_paused is False

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_paused_true(self, prefect_client):
        pool_name = "my-pool"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --paused -t process",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.is_paused is True

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool_from_registry(self, prefect_client):
        pool_name = "fake-work"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --type fake",
        )
        assert res.exit_code == 0
        assert f"Created work pool {pool_name!r}" in res.output
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.name == pool_name
        assert client_res.base_job_template == FAKE_DEFAULT_BASE_JOB_TEMPLATE
        assert client_res.type == "fake"
        assert isinstance(client_res, WorkPool)

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_process_work_pool(self, prefect_client):
        pool_name = "process-work"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --type process",
        )
        assert res.exit_code == 0
        assert f"Created work pool {pool_name!r}" in res.output
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.name == pool_name
        assert (
            client_res.base_job_template
            == ProcessWorker.get_default_base_job_template()
        )
        assert client_res.type == "process"
        assert isinstance(client_res, WorkPool)

    @pytest.mark.usefixtures("mock_collection_registry")
    def test_create_with_unsupported_type(self, monkeypatch):
        # Pin the local worker registry so types leaked by other tests
        # (e.g. UnsupportedWorker in test_base_worker.py) cannot make
        # "unsupported" a valid type.
        monkeypatch.setattr(
            BaseWorker,
            "get_all_available_worker_types",
            staticmethod(lambda: ["process"]),
        )
        invoke_and_assert(
            ["work-pool", "create", "my-pool", "--type", "unsupported"],
            expected_code=1,
            expected_output_contains=(
                "Unknown work pool type 'unsupported'. Please choose from "
            ),
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    def test_create_non_interactive_missing_args(self):
        invoke_and_assert(
            ["work-pool", "create", "no-type"],
            expected_code=1,
            expected_output=(
                "When not using an interactive terminal, you must supply a `--type`"
                " value."
            ),
        )

    @pytest.mark.usefixtures("interactive_console", "mock_collection_registry")
    async def test_create_interactive_first_type(self, prefect_client):
        work_pool_name = "test-interactive"
        await run_sync_in_worker_thread(
            invoke_and_assert,
            ["work-pool", "create", work_pool_name],
            expected_code=0,
            user_input=readchar.key.ENTER,
            expected_output_contains=[f"Created work pool {work_pool_name!r}"],
        )
        client_res = await prefect_client.read_work_pool(work_pool_name)
        assert client_res.name == work_pool_name
        assert client_res.type == "fake"
        assert isinstance(client_res, WorkPool)

    @pytest.mark.usefixtures("interactive_console", "mock_collection_registry")
    async def test_create_interactive_second_type(self, prefect_client):
        work_pool_name = "test-interactive"
        await run_sync_in_worker_thread(
            invoke_and_assert,
            ["work-pool", "create", work_pool_name],
            expected_code=0,
            user_input=readchar.key.DOWN + readchar.key.ENTER,
            expected_output_contains=[f"Created work pool {work_pool_name!r}"],
        )
        client_res = await prefect_client.read_work_pool(work_pool_name)
        assert client_res.name == work_pool_name
        assert client_res.type == "cloud-run:push"
        assert isinstance(client_res, WorkPool)

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_set_as_default(self, prefect_client):
        settings_context = get_settings_context()
        assert (
            settings_context.profile.settings.get(PREFECT_DEFAULT_WORK_POOL_NAME)
            is None
        )
        pool_name = "my-pool"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} -t process --set-as-default",
            expected_output_contains=[
                f"Created work pool {pool_name!r}",
                (
                    f"Set {pool_name!r} as default work pool for profile"
                    f" {settings_context.profile.name!r}\n"
                ),
            ],
        )
        assert res.exit_code == 0
        assert f"Created work pool {pool_name!r}" in res.output
        client_res = await prefect_client.read_work_pool(pool_name)
        assert client_res.name == pool_name
        assert isinstance(client_res, WorkPool)

        # reload the profile to pick up change
        profile = load_profile(settings_context.profile.name)
        assert profile.settings.get(PREFECT_DEFAULT_WORK_POOL_NAME) == pool_name

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_with_provision_infra(self, monkeypatch):
        mock_provision = AsyncMock()

        class MockProvisioner:
            def __init__(self):
                self._console = None

            @property
            def console(self):
                return self._console

            @console.setter
            def console(self, value):
                self._console = value

            async def provision(self, *args, **kwargs):
                await mock_provision(*args, **kwargs)
                return FAKE_DEFAULT_BASE_JOB_TEMPLATE

        monkeypatch.setattr(
            provisioners,
            "get_infrastructure_provisioner_for_work_pool_type",
            lambda *args: MockProvisioner(),
        )

        pool_name = "fake-work"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --type fake --provision-infra",
        )
        assert res.exit_code == 0

        assert mock_provision.await_count == 1

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_with_provision_infra_unsupported(self):
        pool_name = "fake-work"
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --type fake --provision-infra",
        )
        assert res.exit_code == 0
        assert (
            "Automatic infrastructure provisioning is not supported for 'fake' work"
            " pools." in res.output
        )

    @pytest.mark.usefixtures("interactive_console", "mock_collection_registry")
    async def test_create_prompt_table_only_displays_push_pool_types_using_provision_infra_flag(
        self, prefect_client, monkeypatch
    ):
        mock_provision = AsyncMock()

        class MockProvisioner:
            def __init__(self):
                self._console = None

            @property
            def console(self):
                return self._console

            @console.setter
            def console(self, value):
                self._console = value

            async def provision(self, *args, **kwargs):
                await mock_provision(*args, **kwargs)
                return FAKE_DEFAULT_BASE_JOB_TEMPLATE

        monkeypatch.setattr(
            provisioners,
            "get_infrastructure_provisioner_for_work_pool_type",
            lambda *args: MockProvisioner(),
        )

        await run_sync_in_worker_thread(
            invoke_and_assert,
            ["work-pool", "create", "test-interactive", "--provision-infra"],
            expected_code=0,
            user_input=readchar.key.ENTER,
            expected_output_contains=[
                "What type of work pool infrastructure would you like to use?",
                "Prefect Cloud Run: Push",
            ],
            expected_output_does_not_contain=[
                "Prefect Fake",
                "Prefect Agent",
            ],
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool_with_overwrite(self, prefect_client):
        pool_name = "overwrite-pool"

        # Create initial work pool
        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --type process",
            expected_code=0,
            expected_output_contains=[f"Created work pool {pool_name!r}"],
        )

        initial_pool = await prefect_client.read_work_pool(pool_name)
        assert initial_pool.name == pool_name
        assert not initial_pool.is_paused

        # Attempt to overwrite the work pool (updating is_paused)
        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --paused --overwrite",
            expected_code=0,
            expected_output_contains=[f"Updated work pool {pool_name!r}"],
        )

        updated_pool = await prefect_client.read_work_pool(pool_name)
        assert updated_pool.name == pool_name
        assert updated_pool.id == initial_pool.id
        assert updated_pool.is_paused

        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool create {pool_name} --paused",
            expected_code=1,
            expected_output_contains=[
                f"Work pool named {pool_name!r} already exists. Use --overwrite to update it."
            ],
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_create_work_pool_http_error_displays_detail(self, monkeypatch):
        """Test that HTTP errors with detail messages are displayed nicely."""
        error_detail = (
            "You have reached the maximum number of work pools for your workspace: 4."
        )

        mock_request = httpx.Request("POST", "https://api.prefect.cloud/work_pools/")
        mock_response = httpx.Response(
            status_code=403,
            json={"detail": error_detail},
            request=mock_request,
        )
        http_error = httpx.HTTPStatusError(
            "Client error '403 Forbidden'",
            request=mock_request,
            response=mock_response,
        )
        prefect_error = PrefectHTTPStatusError.from_httpx_error(http_error)

        async def mock_create_work_pool(*args, **kwargs):
            raise prefect_error

        monkeypatch.setattr(
            "prefect.client.orchestration.PrefectClient.create_work_pool",
            mock_create_work_pool,
        )

        await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool create test-pool --type process",
            expected_code=1,
            expected_output_contains=[error_detail],
        )


class TestInspect:
    async def test_inspect(self, prefect_client, work_pool):
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool inspect {work_pool.name!r}",
        )
        assert res.exit_code == 0
        assert work_pool.name in res.output
        assert work_pool.type in res.output
        assert str(work_pool.id) in res.output

    async def test_inspect_with_json_output(self, prefect_client, work_pool):
        """Test work-pool inspect command with JSON output flag."""
        import json

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool inspect {work_pool.name!r} --output json",
        )
        assert res.exit_code == 0

        # Parse JSON output and verify it's valid JSON
        output_data = json.loads(res.output.strip())

        # Verify key fields are present
        assert "id" in output_data
        assert "name" in output_data
        assert "type" in output_data
        assert output_data["id"] == str(work_pool.id)
        assert output_data["name"] == work_pool.name


class TestPause:
    async def test_pause(self, prefect_client, work_pool):
        assert work_pool.is_paused is False
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool pause {work_pool.name}",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.is_paused is True


class TestSetConcurrencyLimit:
    async def test_set_concurrency_limit(self, prefect_client, work_pool):
        assert work_pool.concurrency_limit is None
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool set-concurrency-limit {work_pool.name} 10",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.concurrency_limit == 10


class TestClearConcurrencyLimit:
    async def test_clear_concurrency_limit(self, prefect_client, work_pool):
        await prefect_client.update_work_pool(
            work_pool_name=work_pool.name,
            work_pool=WorkPoolUpdate(concurrency_limit=10),
        )
        work_pool = await prefect_client.read_work_pool(work_pool.name)
        assert work_pool.concurrency_limit == 10

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool clear-concurrency-limit {work_pool.name}",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.concurrency_limit is None


class TestResume:
    async def test_resume(self, prefect_client, work_pool):
        assert work_pool.is_paused is False

        # set paused
        await prefect_client.update_work_pool(
            work_pool_name=work_pool.name,
            work_pool=WorkPoolUpdate(is_paused=True),
        )
        work_pool = await prefect_client.read_work_pool(work_pool.name)
        assert work_pool.is_paused is True

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool resume {work_pool.name}",
        )
        assert res.exit_code == 0
        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.is_paused is False


class TestDelete:
    async def test_delete(self, prefect_client, work_pool):
        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool delete {work_pool.name}",
            user_input="y",
            expected_code=0,
        )
        with pytest.raises(ObjectNotFound):
            await prefect_client.read_work_pool(work_pool.name)

    async def test_delete_non_existent(self, prefect_client):
        await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool delete non-existent",
            expected_code=1,
            expected_output_contains="Work pool 'non-existent' does not exist.",
            expected_output_does_not_contain="Are you sure you want to delete work pool with name 'non-existent'?",
        )


class TestLS:
    async def test_ls(self, prefect_client, work_pool):
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool ls",
        )
        assert res.exit_code == 0

    async def test_verbose(self, prefect_client, work_pool):
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool ls --verbose",
        )
        assert res.exit_code == 0

    async def test_ls_with_zero_concurrency_limit(self, prefect_client, work_pool):
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool set-concurrency-limit {work_pool.name} 0",
        )
        assert res.exit_code == 0
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool ls",
        )
        assert "None" not in res.output

    async def test_ls_json_output(self, prefect_client, work_pool):
        """Test work-pool ls command with JSON output flag."""

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "ls", "-o", "json"],
        )
        assert res.exit_code == 0

        output_data = json.loads(res.stdout.strip())
        assert isinstance(output_data, list)
        assert len(output_data) >= 1

        output_ids = {item["id"] for item in output_data}
        assert str(work_pool.id) in output_ids

    async def test_ls_json_output_empty(self, prefect_client):
        """Test work-pool ls with JSON output when no work pools exist."""

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "ls", "-o", "json"],
        )
        assert res.exit_code == 0

        output_data = json.loads(res.stdout.strip())
        assert output_data == []

    async def test_ls_invalid_output_format(self, prefect_client, work_pool):
        """Test work-pool ls with invalid output format."""
        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "ls", "-o", "xml"],
            expected_code=1,
            expected_output_contains="Only 'json' output format is supported.",
        )


class TestUpdate:
    async def test_update_description(self, prefect_client, work_pool):
        assert work_pool.description is None
        assert work_pool.type is not None
        assert work_pool.base_job_template is not None
        assert work_pool.is_paused is not None
        assert work_pool.concurrency_limit is None

        metamorphosis = (
            "One morning, as Gregor Samsa was waking up from anxious dreams, he"
            " discovered that in bed he had been changed into a monstrous verminous"
            " bug."
        )

        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=[
                "work-pool",
                "update",
                work_pool.name,
                "--description",
                metamorphosis,
            ],
            expected_code=0,
            expected_output=f"Updated work pool '{work_pool.name}'",
        )

        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.description == metamorphosis
        # assert all other fields unchanged
        assert client_res.name == work_pool.name
        assert client_res.type == work_pool.type
        assert client_res.base_job_template == work_pool.base_job_template
        assert client_res.is_paused == work_pool.is_paused
        assert client_res.concurrency_limit == work_pool.concurrency_limit

    async def test_update_concurrency_limit(self, prefect_client, work_pool):
        assert work_pool.description is None
        assert work_pool.type is not None
        assert work_pool.base_job_template is not None
        assert work_pool.is_paused is not None
        assert work_pool.concurrency_limit is None

        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=[
                "work-pool",
                "update",
                work_pool.name,
                "--concurrency-limit",
                123456,
            ],
            expected_code=0,
            expected_output=f"Updated work pool '{work_pool.name}'",
        )

        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.concurrency_limit == 123456
        # assert all other fields unchanged
        assert client_res.name == work_pool.name
        assert client_res.description == work_pool.description
        assert client_res.type == work_pool.type
        assert client_res.base_job_template == work_pool.base_job_template
        assert client_res.is_paused == work_pool.is_paused

        # Verify that the concurrency limit is unmodified when changing another
        # setting
        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=[
                "work-pool",
                "update",
                work_pool.name,
                "--description",
                "Hello world lorem ipsum",
            ],
            expected_code=0,
            expected_output=f"Updated work pool '{work_pool.name}'",
        )

        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.concurrency_limit == 123456
        assert client_res.description == "Hello world lorem ipsum"
        # assert all other fields unchanged
        assert client_res.name == work_pool.name
        assert client_res.type == work_pool.type
        assert client_res.base_job_template == work_pool.base_job_template
        assert client_res.is_paused == work_pool.is_paused

    async def test_update_base_job_template(self, prefect_client, work_pool):
        assert work_pool.description is None
        assert work_pool.type is not None
        assert work_pool.base_job_template is not None
        assert work_pool.is_paused is not None
        assert work_pool.concurrency_limit is None

        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=[
                "work-pool",
                "update",
                work_pool.name,
                "--base-job-template",
                Path(__file__).parent / "base-job-templates" / "process-worker.json",
            ],
            expected_code=0,
            expected_output=f"Updated work pool '{work_pool.name}'",
        )

        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.base_job_template != work_pool.base_job_template
        assert client_res.base_job_template == {
            "job_configuration": {"command": "{{ command }}", "name": "{{ name }}"},
            "variables": {
                "type": "object",
                "properties": {
                    "name": {
                        "title": "Name",
                        "description": "Description.",
                        "type": "string",
                    },
                    "command": {
                        "title": "Command",
                        "description": "Command to run.",
                        "type": "string",
                    },
                },
            },
        }
        # assert all other fields unchanged
        assert client_res.name == work_pool.name
        assert client_res.description == work_pool.description
        assert client_res.type == work_pool.type
        assert client_res.is_paused == work_pool.is_paused
        assert client_res.concurrency_limit == work_pool.concurrency_limit

    async def test_update_multi(self, prefect_client, work_pool):
        assert work_pool.description is None
        assert work_pool.type is not None
        assert work_pool.base_job_template is not None
        assert work_pool.is_paused is not None
        assert work_pool.concurrency_limit is None

        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=[
                "work-pool",
                "update",
                work_pool.name,
                "--description",
                "Foo bar baz",
                "--concurrency-limit",
                300,
            ],
            expected_code=0,
            expected_output=f"Updated work pool '{work_pool.name}'",
        )

        client_res = await prefect_client.read_work_pool(work_pool.name)
        assert client_res.description == "Foo bar baz"
        assert client_res.concurrency_limit == 300
        # assert all other fields unchanged
        assert client_res.name == work_pool.name
        assert client_res.type == work_pool.type
        assert client_res.base_job_template == work_pool.base_job_template
        assert client_res.is_paused == work_pool.is_paused


class TestPreview:
    async def test_preview(self, prefect_client, work_pool):
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool preview {work_pool.name}",
        )
        assert res.exit_code == 0

    async def test_preview_json_output(self, prefect_client, work_pool):
        result = await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "preview", work_pool.name, "--output", "json"],
            expected_code=0,
        )

        payload = json.loads(result.stdout)
        assert isinstance(payload, list)

    async def test_preview_json_output_short_flag(self, prefect_client, work_pool):
        result = await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "preview", work_pool.name, "-o", "json"],
            expected_code=0,
        )

        payload = json.loads(result.stdout)
        assert isinstance(payload, list)

    async def test_preview_invalid_output_format(self, prefect_client, work_pool):
        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "preview", work_pool.name, "--output", "xml"],
            expected_code=1,
            expected_output_contains="Only 'json' output format is supported.",
        )


class TestGetDefaultBaseJobTemplate:
    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_unknown_type(self, monkeypatch):
        def available():
            return ["process"]

        monkeypatch.setattr(BaseWorker, "get_all_available_worker_types", available)

        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "get-default-base-job-template", "--type", "foobar"],
            expected_code=1,
            expected_output_contains=(
                "Unknown work pool type 'foobar'. Please choose from "
            ),
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_stdout(self):
        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=["work-pool", "get-default-base-job-template", "--type", "fake"],
            expected_code=0,
            expected_output_contains="fake_var",
        )

    @pytest.mark.usefixtures("mock_collection_registry")
    async def test_file(self, tmp_path):
        file = tmp_path / "out.json"
        await run_sync_in_worker_thread(
            invoke_and_assert,
            command=[
                "work-pool",
                "get-default-base-job-template",
                "--type",
                "fake",
                "--file",
                file,
            ],
            expected_code=0,
        )

        contents = file.read_text()
        assert "job_configuration" in contents
        assert len(contents) == 211


class TestProvisionInfrastructure:
    async def test_provision_infra(self, monkeypatch, push_work_pool, prefect_client):
        client_res = await prefect_client.read_work_pool(push_work_pool.name)
        assert client_res.base_job_template != FAKE_DEFAULT_BASE_JOB_TEMPLATE

        mock_provision = AsyncMock()

        class MockProvisioner:
            def __init__(self):
                self._console = None

            @property
            def console(self):
                return self._console

            @console.setter
            def console(self, value):
                self._console = value

            async def provision(self, *args, **kwargs):
                await mock_provision(*args, **kwargs)
                return FAKE_DEFAULT_BASE_JOB_TEMPLATE

        monkeypatch.setattr(
            provisioners,
            "get_infrastructure_provisioner_for_work_pool_type",
            lambda *args: MockProvisioner(),
        )

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool provision-infra {push_work_pool.name}",
        )
        assert res.exit_code == 0

        assert mock_provision.await_count == 1

        # ensure work pool base job template was updated
        client_res = await prefect_client.read_work_pool(push_work_pool.name)
        assert client_res.base_job_template == FAKE_DEFAULT_BASE_JOB_TEMPLATE

    async def test_provision_infra_unsupported(self, push_work_pool):
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool provision-infrastructure {push_work_pool.name}",
        )
        assert res.exit_code == 0
        assert (
            "Automatic infrastructure provisioning is not supported for"
            " 'push-work-pool:push' work pools." in res.output
        )


class TestStorageInspect:
    async def test_storage_inspect_no_config(self, work_pool: WorkPool):
        """Test inspecting a work pool with no storage configuration."""
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool storage inspect {work_pool.name}",
            expected_code=0,
            expected_output_contains=[
                f"No storage configuration found for work pool {work_pool.name!r}"
            ],
        )
        assert res.exit_code == 0

    async def test_storage_inspect_with_s3_config(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
    ):
        """Test inspecting a work pool with S3 storage configuration."""
        # First configure S3 storage
        await prefect_client.update_work_pool(
            work_pool_name=work_pool.name,
            work_pool=WorkPoolUpdate(
                storage_configuration=WorkPoolStorageConfiguration(
                    bundle_upload_step={
                        "prefect_aws.experimental.bundles.upload": {
                            "requires": "prefect-aws",
                            "bucket": "test-bucket",
                            "aws_credentials_block_name": "test-credentials",
                        }
                    }
                )
            ),
        )

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool storage inspect {work_pool.name}",
            expected_code=0,
            expected_output_contains=[
                "Storage Configuration",
                work_pool.name[:10],  # name is long and might wrap
                "type",
                "S3",
                "bucket",
                "test-bucket",
                "aws_credentials_block_name",
                "test-credentials",
            ],
        )
        assert res.exit_code == 0

    async def test_storage_inspect_with_json_output_includes_execution_launcher(
        self,
        prefect_client: PrefectClient,
        work_pool: WorkPool,
    ):
        """Test JSON output includes execution-only storage settings."""
        await prefect_client.update_work_pool(
            work_pool_name=work_pool.name,
            work_pool=WorkPoolUpdate(
                storage_configuration=WorkPoolStorageConfiguration(
                    bundle_upload_step={
                        "prefect_aws.experimental.bundles.upload": {
                            "requires": "prefect-aws",
                            "bucket": "test-bucket",
                            "aws_credentials_block_name": "test-credentials",
                        }
                    },
                    bundle_execution_step={
                        "prefect_aws.experimental.bundles.execute": {
                            "bucket": "test-bucket",
                            "aws_credentials_block_name": "test-credentials",
                            "launcher": ["python", "-X", "utf8"],
                        }
                    },
                )
            ),
        )

        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool storage inspect {work_pool.name} --output json",
        )
        assert res.exit_code == 0
        assert json.loads(res.output.strip()) == {
            "type": "S3",
            "upload": {
                "requires": "prefect-aws",
                "bucket": "test-bucket",
                "aws_credentials_block_name": "test-credentials",
            },
            "execution": {
                "bucket": "test-bucket",
                "aws_credentials_block_name": "test-credentials",
                "launcher": ["python", "-X", "utf8"],
            },
        }

    async def test_storage_inspect_nonexistent_pool(self):
        """Test inspecting a nonexistent work pool."""
        res = await run_sync_in_worker_thread(
            invoke_and_assert,
            "work-pool storage inspect nonexistent-pool",
            expected_code=1,
            expected_output_contains=["Work pool 'nonexistent-pool' does not exist"],
        )
        assert res.exit_code == 1


@pytest.fixture
async def aws_credentials(prefect_client: PrefectClient) -> BlockDocument:
    aws_credentials_type = await prefect_client.create_block_type(
        block_type=BlockTypeCreate(
            name="AWS Credentials",
            slug="aws-credentials",
        )
    )

    aws_credentials_schema = await prefect_client.create_block_schema(
        block_schema=BlockSchemaCreate(
            block_type_id=aws_credentials_type.id,
            fields={"properties": {"aws_access_key_id": {"type": "string"}}},
        )
    )

    return await prefect_client.create_block_document(
        block_document=BlockDocumentCreate(
            name="my-creds",
            block_type_id=aws_credentials_type.id,
            block_schema_id=aws_credentials_schema.id,
            data={"aws_access_key_id": "AKIA1234"},
        )
    )


@pytest.fixture
async def s3_bucket_block_definition(prefect_client: PrefectClient):
    s3_bucket_block_definition_type = await prefect_client.create_block_type(
        block_type=BlockTypeCreate(
            name="S3 Bucket",
            slug="s3-bucket",
        )
    )

    await prefect_client.create_block_schema(
        block_schema=BlockSchemaCreate(
            block_type_id=s3_bucket_block_definition_type.id,
            fields={"properties": {"bucket": {"type": "string"}}},
        )
    )


@pytest.fixture
async def gcs_credentials(prefect_client: PrefectClient) -> BlockDocument:
    gcs_credentials_type = await prefect_client.create_block_type(
        block_type=BlockTypeCreate(
            name="GCP Credentials",
            slug="gcp-credentials",
        )
    )

    gcs_credentials_schema = await prefect_client.create_block_schema(
        block_schema=BlockSchemaCreate(
            block_type_id=gcs_credentials_type.id,
            fields={"properties": {"service_account_info": {"type": "object"}}},
        )
    )

    return await prefect_client.create_block_document(
        block_document=BlockDocumentCreate(
            name="my-gcs-creds",
            block_type_id=gcs_credentials_type.id,
            block_schema_id=gcs_credentials_schema.id,
            data={
                "service_account_info": {
                    "type": "service_account",
                    "project_id": "test-project",
                    "private_key": "test-private-key",
                    "client_email": "test-client-email",
                    "private_key_id": "test-private-key-id",
                    "client_id": "test-client-id",
                }
            },
        )
    )


@pytest.fixture
async def gcs_bucket_block_definition(prefect_client: PrefectClient):
    gcs_bucket_block_definition_type = await prefect_client.create_block_type(
        block_type=BlockTypeCreate(
            name="GCS Bucket",
            slug="gcs-bucket",
        )
    )

    await prefect_client.create_block_schema(
        block_schema=BlockSchemaCreate(
            block_type_id=gcs_bucket_block_definition_type.id,
            fields={
                "properties": {
                    "bucket": {"type": "string"},
                    "bucket_folder": {"type": "string"},
                    "gcp_credentials": {"type": "object"},
                }
            },
        )
    )


@pytest.fixture
async def azure_blob_storage_credentials(
    prefect_client: PrefectClient,
) -> BlockDocument:
    azure_blob_storage_credentials_type = await prefect_client.create_block_type(
        block_type=BlockTypeCreate(
            name="Azure Blob Storage Credentials",
            slug="azure-blob-storage-credentials",
        )
    )

    azure_blob_storage_credentials_schema = await prefect_client.create_block_schema(
        block_schema=BlockSchemaCreate(
            block_type_id=azure_blob_storage_credentials_type.id,
            fields={"properties": {"account_url": {"type": "string"}}},
        )
    )

    return await prefect_client.create_block_document(
        block_document=BlockDocumentCreate(
            name="my-azure-blob-storage-creds",
            block_type_id=azure_blob_storage_credentials_type.id,
            block_schema_id=azure_blob_storage_credentials_schema.id,
            data={"account_url": "https://test-account.blob.core.windows.net"},
        )
    )


@pytest.fixture
async def azure_blob_storage_container_block_definition(
    prefect_client: PrefectClient,
):
    azure_blob_storage_container_block_definition_type = (
        await prefect_client.create_block_type(
            block_type=BlockTypeCreate(
                name="Azure Blob Storage Container",
                slug="azure-blob-storage-container",
            )
        )
    )

    await prefect_client.create_block_schema(
        block_schema=BlockSchemaCreate(
            block_type_id=azure_blob_storage_container_block_definition_type.id,
            fields={"properties": {"container_name": {"type": "string"}}},
        )
    )


class TestStorageConfigure:
    def test_storage_configure_s3_help_includes_launcher_flags(self):
        stdout = StringIO()
        stderr = StringIO()

        with pytest.raises(SystemExit) as exc:
            with redirect_stdout(stdout), redirect_stderr(stderr):
                work_pool_storage_configure_app(["s3", "--help"], exit_on_error=False)

        assert exc.value.code == 0
        output = stdout.getvalue()
        assert stderr.getvalue() == ""
        assert "Launchers" in output
        assert "--launcher" in output
        assert "--launcher-arg" in output
        assert "--upload-launcher" in output
        assert "--upload-launcher-arg" in output
        assert "--execution-launcher" in output
        assert "Shared executable or path for upload and" in output
        assert "Append one argv token to the shared launcher." in output
        assert "Append one upload-only argv token." in output
        assert "Append one execution-only argv token." in output
        assert "shared launcher." in output
        assert "Example: use Python for upload and execution:" in output
        assert "--launcher python" in output
        assert "--launcher-arg -X" in output
        assert "--launcher-arg utf8" in output
        assert "--empty-launcher-arg" not in output

    class TestS3:
        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            """Test configuring S3 storage for a work pool."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                ],
                expected_code=0,
                expected_output_contains=[
                    f"Configured S3 storage for work pool {work_pool.name!r}"
                ],
            )

            # Verify the configuration was saved
            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_aws.experimental.bundles.upload": {
                    "requires": "prefect-aws",
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_aws.experimental.bundles.execute": {
                    "requires": "prefect-aws",
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                }
            }
            block_document = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert block_document.data == {
                "bucket_name": "test-bucket",
                "bucket_folder": "results",
                "credentials": aws_credentials.data,
            }

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_uppercase_work_pool_name(
            self,
            prefect_client: PrefectClient,
            aws_credentials: BlockDocument,
        ):
            """Work pool names with uppercase letters should produce valid block names."""
            pool_name = f"ECS-Push-OIDC-{uuid.uuid4()}"
            await prefect_client.create_work_pool(
                work_pool=WorkPoolCreate(name=pool_name, type="test-type")
            )

            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    pool_name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                ],
                expected_code=0,
                expected_output_contains=[
                    f"Configured S3 storage for work pool {pool_name!r}"
                ],
            )

            block_document = await prefect_client.read_block_document_by_name(
                name=f"default-{pool_name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert block_document.data["bucket_name"] == "test-bucket"

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_with_launcher(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                    "--launcher",
                    "poetry",
                    "--launcher-arg",
                    "run",
                    "--launcher-arg",
                    "python",
                ],
                expected_code=0,
            )

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_aws.experimental.bundles.upload": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": ["poetry", "run", "python"],
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_aws.experimental.bundles.execute": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": ["poetry", "run", "python"],
                }
            }

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        @pytest.mark.parametrize(
            ("launcher_option", "expected_message"),
            [
                ("--launcher", "--launcher cannot be empty."),
                ("--upload-launcher", "--upload-launcher cannot be empty."),
                ("--execution-launcher", "--execution-launcher cannot be empty."),
            ],
        )
        async def test_storage_configure_rejects_empty_launcher_executable(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
            launcher_option: str,
            expected_message: str,
        ):
            res = await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                    launcher_option,
                    "",
                ],
                expected_code=1,
                expected_output_contains=[expected_message],
            )
            assert res.exit_code == 1

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step is None
            assert client_res.storage_configuration.bundle_execution_step is None

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        @pytest.mark.parametrize(
            ("command_suffix", "expected_message"),
            [
                (
                    ["--launcher", "python", "--launcher-arg", ""],
                    "--launcher-arg cannot be empty.",
                ),
                (
                    ["--launcher", "python", "--upload-launcher-arg", ""],
                    "--upload-launcher-arg cannot be empty.",
                ),
                (
                    ["--launcher", "python", "--execution-launcher-arg", ""],
                    "--execution-launcher-arg cannot be empty.",
                ),
            ],
        )
        async def test_storage_configure_rejects_empty_launcher_arg(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
            command_suffix: list[str],
            expected_message: str,
        ):
            res = await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                    *command_suffix,
                ],
                expected_code=1,
                expected_output_contains=[expected_message],
            )
            assert res.exit_code == 1

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step is None
            assert client_res.storage_configuration.bundle_execution_step is None

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        @pytest.mark.windows
        async def test_storage_configure_with_windows_launcher(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                    "--launcher",
                    r"C:\Program Files\Python\python.exe",
                    "--launcher-arg",
                    "-X",
                    "--launcher-arg",
                    "utf8",
                ],
                expected_code=0,
            )

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_aws.experimental.bundles.upload": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": [r"C:\Program Files\Python\python.exe", "-X", "utf8"],
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_aws.experimental.bundles.execute": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": [r"C:\Program Files\Python\python.exe", "-X", "utf8"],
                }
            }

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_launcher_overrides(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                    "--launcher",
                    "python",
                    "--launcher-arg",
                    "-X",
                    "--execution-launcher",
                    "poetry",
                    "--execution-launcher-arg",
                    "run",
                    "--execution-launcher-arg",
                    "python",
                ],
                expected_code=0,
            )

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_aws.experimental.bundles.upload": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": ["python", "-X"],
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_aws.experimental.bundles.execute": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": ["poetry", "run", "python"],
                }
            }

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_launcher_args_extend_default_launcher(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                    "--launcher",
                    "python",
                    "--launcher-arg",
                    "-X",
                    "--launcher-arg",
                    "utf8",
                    "--execution-launcher-arg",
                    "-u",
                ],
                expected_code=0,
            )

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_aws.experimental.bundles.upload": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": ["python", "-X", "utf8"],
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_aws.experimental.bundles.execute": {
                    "bucket": "test-bucket",
                    "aws_credentials_block_name": aws_credentials.name,
                    "launcher": ["python", "-X", "utf8", "-u"],
                }
            }

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_nonexistent_pool(
            self, aws_credentials: BlockDocument
        ):
            """Test configuring S3 storage for a nonexistent work pool."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    "nonexistent-pool",
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                ],
                expected_code=1,
                expected_output_contains=[
                    "Work pool 'nonexistent-pool' does not exist"
                ],
            )

        async def test_storage_configure_s3_nonexistent_credentials(
            self, work_pool: WorkPool
        ):
            """Test configuring S3 storage with nonexistent credentials block."""
            res = await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    "nonexistent-credentials",
                ],
                expected_code=1,
                expected_output_contains=[
                    "AWS credentials block 'nonexistent-credentials' does not exist",
                    "or omit --aws-credentials-block-name",
                ],
            )
            assert res.exit_code == 1

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_without_credentials_block(
            self, prefect_client: PrefectClient, work_pool: WorkPool
        ):
            """Omitting --aws-credentials-block-name wires the bundle's ambient-auth path.

            No credentials block document is created or referenced. The bundle
            step config omits aws_credentials_block_name so the upload/execute
            functions hit their `else: AwsCredentials()` branch, and the
            result-storage block omits `credentials` so S3Bucket's
            default_factory supplies an empty AwsCredentials on load.
            """
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                expected_code=0,
                expected_output_contains=[
                    f"Configured S3 storage for work pool {work_pool.name!r}"
                ],
            )

            # No auto-created credentials block exists.
            with pytest.raises(ObjectNotFound):
                await prefect_client.read_block_document_by_name(
                    name=f"default-{work_pool.name}-aws-credentials",
                    block_type_slug="aws-credentials",
                )

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_aws.experimental.bundles.upload": {
                    "requires": "prefect-aws",
                    "bucket": "test-bucket",
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_aws.experimental.bundles.execute": {
                    "requires": "prefect-aws",
                    "bucket": "test-bucket",
                }
            }
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert storage.data == {
                "bucket_name": "test-bucket",
                "bucket_folder": "results",
                "credentials": {},
            }

        @pytest.mark.usefixtures("s3_bucket_block_definition")
        async def test_storage_configure_migrates_from_named_to_ambient_credentials(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            """Reconfiguring without the flag must clear the prior credential ref.

            Otherwise the bundle steps move to ambient auth while the result-
            storage block keeps pointing at the old aws-credentials block.
            """
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--aws-credentials-block-name",
                    aws_credentials.name,
                ],
                expected_code=0,
            )
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert storage.data["credentials"] == aws_credentials.data

            # Reconfigure without the flag — credential reference must be cleared.
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                expected_code=0,
            )

            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert storage.data["credentials"] == {}

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert (
                "aws_credentials_block_name"
                not in client_res.storage_configuration.bundle_upload_step[
                    "prefect_aws.experimental.bundles.upload"
                ]
            )
            assert (
                "aws_credentials_block_name"
                not in client_res.storage_configuration.bundle_execution_step[
                    "prefect_aws.experimental.bundles.execute"
                ]
            )

        @pytest.mark.usefixtures(
            "interactive_console",
            "s3_bucket_block_definition",
        )
        async def test_storage_configure_interactive_prompts_for_credentials_block(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            aws_credentials: BlockDocument,
        ):
            """Interactive mode prompts for a credentials block when the flag is omitted.

            Typing an existing block name at the prompt uses that block (the
            pre-relaxation behavior, preserved so an operator re-running the
            command interactively does not silently clear configured auth).
            """
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                user_input=f"{aws_credentials.name}\n",
                expected_code=0,
                expected_output_contains=[
                    "Enter the name of the AWS credentials block to use",
                    f"Configured S3 storage for work pool {work_pool.name!r}",
                ],
            )
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert storage.data["credentials"] == aws_credentials.data

        @pytest.mark.usefixtures(
            "interactive_console",
            "s3_bucket_block_definition",
        )
        async def test_storage_configure_interactive_enter_selects_ambient_auth(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
        ):
            """Pressing Enter at the interactive prompt opts into ambient auth."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "s3",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                user_input="\n",
                expected_code=0,
                expected_output_contains=[
                    "press Enter to use default credentials",
                ],
            )
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="s3-bucket",
            )
            assert storage.data["credentials"] == {}

    class TestGCS:
        @pytest.mark.usefixtures("gcs_bucket_block_definition")
        async def test_storage_configure(
            self,
            work_pool: WorkPool,
            gcs_credentials: BlockDocument,
            prefect_client: PrefectClient,
        ):
            """Test configuring GCS storage for a work pool."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--gcp-credentials-block-name",
                    gcs_credentials.name,
                ],
                expected_code=0,
                expected_output_contains=[
                    f"Configured GCS storage for work pool {work_pool.name!r}"
                ],
            )

            # Verify the configuration was saved
            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_gcp.experimental.bundles.upload": {
                    "requires": "prefect-gcp",
                    "bucket": "test-bucket",
                    "gcp_credentials_block_name": gcs_credentials.name,
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_gcp.experimental.bundles.execute": {
                    "requires": "prefect-gcp",
                    "bucket": "test-bucket",
                    "gcp_credentials_block_name": gcs_credentials.name,
                }
            }
            block_document = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="gcs-bucket",
            )
            assert block_document.data == {
                "bucket": "test-bucket",
                "bucket_folder": "results",
                "gcp_credentials": gcs_credentials.data,
            }

        @pytest.mark.usefixtures("gcs_bucket_block_definition")
        async def test_storage_configure_nonexistent_pool(
            self, gcs_credentials: BlockDocument
        ):
            """Test configuring GCS storage for a nonexistent work pool."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    "nonexistent-pool",
                    "--bucket",
                    "test-bucket",
                    "--gcp-credentials-block-name",
                    gcs_credentials.name,
                ],
                expected_code=1,
                expected_output_contains=[
                    "Work pool 'nonexistent-pool' does not exist"
                ],
            )

        async def test_storage_configure_gcs_nonexistent_credentials(
            self, work_pool: WorkPool
        ):
            """Test configuring GCS storage with nonexistent credentials block."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--gcp-credentials-block-name",
                    "nonexistent-credentials",
                ],
                expected_code=1,
                expected_output_contains=[
                    "GCS credentials block 'nonexistent-credentials' does not exist",
                    "or omit --gcp-credentials-block-name",
                ],
            )

        @pytest.mark.usefixtures("gcs_bucket_block_definition")
        async def test_storage_configure_without_credentials_block(
            self, prefect_client: PrefectClient, work_pool: WorkPool
        ):
            """Omitting --gcp-credentials-block-name wires the bundle's ambient-auth path.

            No credentials block document is created or referenced. The bundle
            step config omits gcp_credentials_block_name so the upload/execute
            functions hit their `else: GcpCredentials()` branch, and the
            result-storage block omits `gcp_credentials` so GcsBucket's
            default_factory supplies an empty GcpCredentials on load.
            """
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                expected_code=0,
                expected_output_contains=[
                    f"Configured GCS storage for work pool {work_pool.name!r}"
                ],
            )

            # No auto-created credentials block exists.
            with pytest.raises(ObjectNotFound):
                await prefect_client.read_block_document_by_name(
                    name=f"default-{work_pool.name}-gcp-credentials",
                    block_type_slug="gcp-credentials",
                )

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_gcp.experimental.bundles.upload": {
                    "requires": "prefect-gcp",
                    "bucket": "test-bucket",
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_gcp.experimental.bundles.execute": {
                    "requires": "prefect-gcp",
                    "bucket": "test-bucket",
                }
            }
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="gcs-bucket",
            )
            assert storage.data == {
                "bucket": "test-bucket",
                "bucket_folder": "results",
                "gcp_credentials": {},
            }

        @pytest.mark.usefixtures("gcs_bucket_block_definition")
        async def test_storage_configure_migrates_from_named_to_ambient_credentials(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            gcs_credentials: BlockDocument,
        ):
            """Reconfiguring without the flag must clear the prior credential ref.

            Otherwise the bundle steps move to ADC while the result-storage
            block keeps pointing at the old gcp-credentials block.
            """
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                    "--gcp-credentials-block-name",
                    gcs_credentials.name,
                ],
                expected_code=0,
            )
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="gcs-bucket",
            )
            assert storage.data["gcp_credentials"] == gcs_credentials.data

            # Reconfigure without the flag — credential reference must be cleared.
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                expected_code=0,
            )

            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="gcs-bucket",
            )
            assert storage.data["gcp_credentials"] == {}

            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert (
                "gcp_credentials_block_name"
                not in client_res.storage_configuration.bundle_upload_step[
                    "prefect_gcp.experimental.bundles.upload"
                ]
            )
            assert (
                "gcp_credentials_block_name"
                not in client_res.storage_configuration.bundle_execution_step[
                    "prefect_gcp.experimental.bundles.execute"
                ]
            )

        @pytest.mark.usefixtures(
            "interactive_console",
            "gcs_bucket_block_definition",
        )
        async def test_storage_configure_interactive_prompts_for_credentials_block(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            gcs_credentials: BlockDocument,
        ):
            """Interactive mode prompts for a credentials block when the flag is omitted.

            Typing an existing block name at the prompt uses that block (the
            pre-relaxation behavior, preserved so an operator re-running the
            command interactively does not silently clear configured auth).
            """
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                user_input=f"{gcs_credentials.name}\n",
                expected_code=0,
                expected_output_contains=[
                    "Enter the name of the Google Cloud credentials block",
                    f"Configured GCS storage for work pool {work_pool.name!r}",
                ],
            )
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="gcs-bucket",
            )
            assert storage.data["gcp_credentials"] == gcs_credentials.data

        @pytest.mark.usefixtures(
            "interactive_console",
            "gcs_bucket_block_definition",
        )
        async def test_storage_configure_interactive_enter_selects_ambient_auth(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
        ):
            """Pressing Enter at the interactive prompt opts into ambient auth."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "gcs",
                    work_pool.name,
                    "--bucket",
                    "test-bucket",
                ],
                user_input="\n",
                expected_code=0,
                expected_output_contains=[
                    "press Enter to use default credentials",
                ],
            )
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="gcs-bucket",
            )
            assert storage.data["gcp_credentials"] == {}

    class TestAzureBlobStorage:
        @pytest.mark.usefixtures("azure_blob_storage_container_block_definition")
        async def test_storage_configure(
            self,
            work_pool: WorkPool,
            azure_blob_storage_credentials: BlockDocument,
            prefect_client: PrefectClient,
        ):
            """Test configuring Azure Blob Storage for a work pool."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "azure-blob-storage",
                    work_pool.name,
                    "--container",
                    "test-container",
                    "--azure-blob-storage-credentials-block-name",
                    azure_blob_storage_credentials.name,
                ],
                expected_code=0,
                expected_output_contains=[
                    f"Configured Azure Blob Storage for work pool {work_pool.name!r}"
                ],
            )

            # Verify the configuration was saved
            client_res = await prefect_client.read_work_pool(work_pool.name)
            assert client_res.storage_configuration.bundle_upload_step == {
                "prefect_azure.experimental.bundles.upload": {
                    "requires": "prefect-azure",
                    "container": "test-container",
                    "azure_blob_storage_credentials_block_name": azure_blob_storage_credentials.name,
                }
            }
            assert client_res.storage_configuration.bundle_execution_step == {
                "prefect_azure.experimental.bundles.execute": {
                    "requires": "prefect-azure",
                    "container": "test-container",
                    "azure_blob_storage_credentials_block_name": azure_blob_storage_credentials.name,
                }
            }
            block_document = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="azure-blob-storage-container",
            )
            assert block_document.data == {
                "container_name": "test-container",
                "credentials": azure_blob_storage_credentials.data,
            }

        @pytest.mark.usefixtures("azure_blob_storage_container_block_definition")
        async def test_storage_configure_nonexistent_pool(
            self, azure_blob_storage_credentials: BlockDocument
        ):
            """Test configuring Azure Blob Storage for a nonexistent work pool."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "azure-blob-storage",
                    "nonexistent-pool",
                    "--container",
                    "test-container",
                    "--azure-blob-storage-credentials-block-name",
                    azure_blob_storage_credentials.name,
                ],
                expected_code=1,
                expected_output_contains=[
                    "Work pool 'nonexistent-pool' does not exist"
                ],
            )

        async def test_storage_configure_azure_blob_storage_nonexistent_credentials(
            self, work_pool: WorkPool
        ):
            """Test configuring Azure Blob Storage with nonexistent credentials block."""
            await run_sync_in_worker_thread(
                invoke_and_assert,
                command=[
                    "work-pool",
                    "storage",
                    "configure",
                    "azure-blob-storage",
                    work_pool.name,
                    "--container",
                    "test-container",
                    "--azure-blob-storage-credentials-block-name",
                    "nonexistent-credentials",
                ],
                expected_code=1,
                expected_output_contains=[
                    "Azure Blob Storage credentials block 'nonexistent-credentials' does not exist"
                ],
            )

        @pytest.mark.usefixtures("azure_blob_storage_container_block_definition")
        async def test_storage_configure_preserves_existing_result_storage_fields(
            self,
            prefect_client: PrefectClient,
            work_pool: WorkPool,
            azure_blob_storage_credentials: BlockDocument,
        ):
            """Reconfiguring must not drop fields the CLI does not resend.

            The Azure CLI only sends container_name and credentials, so any
            fields the user has added to the auto-created result-storage block
            (e.g. base_folder) must be preserved on re-run.
            """
            base_command = [
                "work-pool",
                "storage",
                "configure",
                "azure-blob-storage",
                work_pool.name,
                "--container",
                "test-container",
                "--azure-blob-storage-credentials-block-name",
                azure_blob_storage_credentials.name,
            ]
            await run_sync_in_worker_thread(
                invoke_and_assert, command=base_command, expected_code=0
            )

            # Simulate a user adding base_folder to the auto-created block.
            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="azure-blob-storage-container",
            )
            await prefect_client.update_block_document(
                block_document_id=storage.id,
                block_document=BlockDocumentUpdate(
                    data={"base_folder": "custom/prefix"},
                    merge_existing_data=True,
                ),
            )

            # Reconfigure; base_folder must survive.
            await run_sync_in_worker_thread(
                invoke_and_assert, command=base_command, expected_code=0
            )

            storage = await prefect_client.read_block_document_by_name(
                name=f"default-{work_pool.name.lower()}-result-storage",
                block_type_slug="azure-blob-storage-container",
            )
            assert storage.data["base_folder"] == "custom/prefix"
            assert storage.data["container_name"] == "test-container"


class TestFormatDuration:
    @pytest.mark.parametrize(
        "seconds,expected",
        [
            (45, "45s"),
            (125, "2m 5s"),
            (3725, "1h 2m"),
            (0, "0s"),
            (None, "N/A"),
        ],
    )
    def test_format_duration(self, seconds, expected):
        from prefect.cli.work_pool import _format_duration

        assert _format_duration(seconds) == expected


class TestConcurrencyStyle:
    @pytest.mark.parametrize(
        "active,limit,expected",
        [
            (5, None, "blue"),
            (0, 0, "red"),
            (3, 10, "green"),
            (7, 10, "yellow"),
            (9, 10, "red"),
            (10, 10, "red"),
        ],
    )
    def test_concurrency_style(self, active, limit, expected):
        from prefect.cli.work_pool import _concurrency_style

        assert _concurrency_style(active, limit) == expected


class TestWorkPoolSlots:
    @staticmethod
    async def _create_pool_with_slot_holders(prefect_client):
        """Create a work pool with a concurrency limit and running flow runs."""
        pool_name = f"slots-pool-{uuid.uuid4().hex[:8]}"
        pool = await prefect_client.create_work_pool(
            WorkPoolCreate(name=pool_name, type="test", concurrency_limit=10)
        )
        foo = flow_decorator(lambda: None, name="foo")
        flow_id = await prefect_client.create_flow(foo)
        deployment_id = await prefect_client.create_deployment(
            flow_id=flow_id,
            name="test-deployment",
            work_pool_name=pool.name,
        )
        # Create two RUNNING flow runs
        for _ in range(2):
            fr = await prefect_client.create_flow_run_from_deployment(deployment_id)
            await prefect_client.set_flow_run_state(fr.id, Running(), force=True)
        # Create one PENDING flow run
        fr = await prefect_client.create_flow_run_from_deployment(deployment_id)
        await prefect_client.set_flow_run_state(fr.id, Pending(), force=True)
        return pool

    async def test_slots_table_output(self, prefect_client):
        pool = await self._create_pool_with_slot_holders(prefect_client)
        await run_sync_in_worker_thread(
            invoke_and_assert,
            f"work-pool slots {pool.name!r}",
            expected_code=0,
            expected_output_contains=[
                pool.name,
                "3 / 10",
                "Running",
            ],
        )

    async def test_slots_json_output(self, prefect_client):
        """Verify JSON output via the client method directly."""
        pool = await self._create_pool_with_slot_holders(prefect_client)
        status = await prefect_client.read_work_pool_concurrency_status(
            work_pool_name=pool.name
        )
        assert status.active_slots == 3
        assert status.concurrency_limit == 10
        assert len(status.queues) >= 1

    async def test_slots_not_found(self, prefect_client):
        """Verify 404 handling via the client method directly."""
        with pytest.raises(ObjectNotFound):
            await prefect_client.read_work_pool_concurrency_status(
                work_pool_name="nonexistent-pool"
            )
