from uuid import UUID, uuid4

import anyio
import pytest

from prefect.runner._limit_manager import LimitManager

pytestmark = pytest.mark.clear_db


class TestLimitManagerNoLimit:
    """Tests for limit=None behavior (sentinel path)."""

    def test_no_limit_acquire_returns_uuid(self):
        lm = LimitManager(limit=None)
        result = lm.acquire()
        assert isinstance(result, UUID)

    def test_no_limit_release_is_noop(self):
        lm = LimitManager(limit=None)
        token = lm.acquire()
        lm.release(token)  # should not raise

    def test_no_limit_has_slots_available_returns_true(self):
        lm = LimitManager(limit=None)
        assert lm.has_slots_available() is True


class TestLimitManagerGuard:
    def test_acquire_raises_before_aenter_when_limit_set(self):
        lm = LimitManager(limit=2)
        with pytest.raises(RuntimeError, match="async context manager"):
            lm.acquire()

    async def test_acquire_raises_after_aexit_when_limit_set(self):
        lm = LimitManager(limit=2)
        async with lm:
            pass
        with pytest.raises(RuntimeError, match="async context manager"):
            lm.acquire()


class TestLimitManagerLifecycle:
    async def test_aenter_creates_limiter_when_limit_set(self):
        async with LimitManager(limit=3) as lm:
            assert isinstance(lm._limiter, anyio.CapacityLimiter)

    async def test_aenter_no_limiter_when_limit_none(self):
        async with LimitManager(limit=None) as lm:
            assert lm._limiter is None

    async def test_aexit_clears_limiter(self):
        lm = LimitManager(limit=2)
        async with lm:
            assert lm._limiter is not None
        assert lm._limiter is None


class TestLimitManagerAcquireRelease:
    async def test_acquire_returns_uuid_token(self):
        async with LimitManager(limit=2) as lm:
            token = lm.acquire()
            assert isinstance(token, UUID)

    async def test_acquire_borrows_from_limiter(self):
        async with LimitManager(limit=2) as lm:
            lm.acquire()
            assert lm._limiter.borrowed_tokens == 1

    async def test_release_frees_slot(self):
        async with LimitManager(limit=2) as lm:
            token = lm.acquire()
            lm.release(token)
            assert lm._limiter.borrowed_tokens == 0

    async def test_multiple_tokens_are_distinct(self):
        async with LimitManager(limit=3) as lm:
            token1 = lm.acquire()
            token2 = lm.acquire()
            assert token1 != token2
            assert lm._limiter.borrowed_tokens == 2


class TestLimitManagerCapacityExhaustion:
    async def test_acquire_raises_would_block_at_capacity(self):
        async with LimitManager(limit=1) as lm:
            lm.acquire()  # fills the one slot
            with pytest.raises(anyio.WouldBlock):
                lm.acquire()


class TestLimitManagerHasSlotsAvailable:
    async def test_has_slots_available_true_when_capacity_exists(self):
        async with LimitManager(limit=2) as lm:
            assert lm.has_slots_available() is True

    async def test_has_slots_available_false_when_at_capacity(self):
        async with LimitManager(limit=1) as lm:
            lm.acquire()
            assert lm.has_slots_available() is False

    async def test_has_slots_available_true_after_release(self):
        async with LimitManager(limit=1) as lm:
            token = lm.acquire()
            lm.release(token)
            assert lm.has_slots_available() is True


class TestLimitManagerAcquireForFlowRun:
    """Tests for the flow-run-id-based acquire/release API."""

    async def test_acquire_for_flow_run_returns_true_on_success(self):
        async with LimitManager(limit=2) as lm:
            flow_run_id = uuid4()
            assert lm.acquire_for_flow_run(flow_run_id) is True

    async def test_acquire_for_flow_run_returns_true_when_no_limit(self):
        lm = LimitManager(limit=None)
        assert lm.acquire_for_flow_run(uuid4()) is True

    async def test_acquire_for_flow_run_returns_false_at_capacity(self):
        async with LimitManager(limit=1) as lm:
            fid1 = uuid4()
            assert lm.acquire_for_flow_run(fid1) is True
            fid2 = uuid4()
            assert lm.acquire_for_flow_run(fid2) is False

    async def test_acquire_for_flow_run_returns_false_on_duplicate(self):
        async with LimitManager(limit=2) as lm:
            fid = uuid4()
            assert lm.acquire_for_flow_run(fid) is True
            # Same flow_run_id again -> duplicate borrower
            assert lm.acquire_for_flow_run(fid) is False

    async def test_release_for_flow_run_frees_slot(self):
        async with LimitManager(limit=1) as lm:
            fid = uuid4()
            lm.acquire_for_flow_run(fid)
            lm.release_for_flow_run(fid)
            assert lm.has_slots_available() is True

    async def test_release_for_flow_run_noop_when_no_limit(self):
        lm = LimitManager(limit=None)
        lm.release_for_flow_run(uuid4())  # should not raise
