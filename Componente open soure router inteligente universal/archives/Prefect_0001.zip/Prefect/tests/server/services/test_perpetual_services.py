"""Tests for the perpetual services registry and scheduling."""

from datetime import timedelta

import pytest
from docket import Perpetual
from docket.dependencies import get_single_dependency_parameter_of_type

from prefect.server.services.perpetual_services import (
    _PERPETUAL_SERVICES,
    PerpetualServiceConfig,
    get_enabled_perpetual_services,
    get_perpetual_services,
)
from prefect.settings.context import get_current_settings

pytestmark = pytest.mark.clear_db


@pytest.fixture
def orphan_vacuum_config() -> PerpetualServiceConfig:
    return next(
        config
        for config in _PERPETUAL_SERVICES
        if config.function.__name__ == "schedule_orphan_vacuum_tasks"
    )


def test_db_vacuum_service_registered():
    """Test that db vacuum perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "schedule_vacuum_tasks" in service_names


def test_db_vacuum_disabled_by_default():
    """Test that flow_runs vacuum is disabled by default (not in the enabled set)."""
    config = next(
        c for c in _PERPETUAL_SERVICES if c.function.__name__ == "schedule_vacuum_tasks"
    )
    assert config.enabled_getter() is False


def test_event_vacuum_service_registered():
    """Test that event vacuum perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "schedule_event_vacuum_tasks" in service_names


def test_orphan_vacuum_service_registered():
    """Test that the orphan vacuum service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "schedule_orphan_vacuum_tasks" in service_names


def test_orphan_vacuum_runs_daily_by_default(
    orphan_vacuum_config: PerpetualServiceConfig,
):
    """Expensive orphan scans run less often than the hourly vacuum cycle."""
    perpetual = get_single_dependency_parameter_of_type(
        orphan_vacuum_config.function, Perpetual
    )
    assert perpetual is not None
    assert perpetual.every == timedelta(days=1)


def test_orphan_vacuum_disabled_by_default(
    orphan_vacuum_config: PerpetualServiceConfig,
):
    """Test that orphan scans stay off when flow run vacuum is disabled."""
    assert orphan_vacuum_config.enabled_getter() is False


def test_orphan_vacuum_enabled_when_requested(
    monkeypatch: pytest.MonkeyPatch,
    orphan_vacuum_config: PerpetualServiceConfig,
):
    """Test that operators can enable orphan cleanup independently."""
    settings = get_current_settings()
    monkeypatch.setattr(settings.server.services.db_vacuum, "enabled", {"orphans"})

    assert orphan_vacuum_config.enabled_getter() is True


def test_orphan_vacuum_enabled_with_flow_run_vacuum(
    monkeypatch: pytest.MonkeyPatch,
    orphan_vacuum_config: PerpetualServiceConfig,
):
    """Flow run cleanup retains automatic orphan reconciliation."""
    settings = get_current_settings()
    monkeypatch.setattr(
        settings.server.services.db_vacuum, "enabled", {"events", "flow_runs"}
    )

    assert orphan_vacuum_config.enabled_getter() is True


def test_event_vacuum_enabled_by_default(monkeypatch: pytest.MonkeyPatch):
    """Test that event vacuum is enabled by default when event persister is also enabled."""
    settings = get_current_settings()
    # The test suite disables event_persister globally; restore the production
    # default so we can verify that event vacuum is enabled when both settings
    # are at their defaults.
    monkeypatch.setattr(settings.server.services.event_persister, "enabled", True)

    config = next(
        c
        for c in _PERPETUAL_SERVICES
        if c.function.__name__ == "schedule_event_vacuum_tasks"
    )
    assert config.enabled_getter() is True


def test_event_vacuum_disabled_when_not_in_enabled_set(
    monkeypatch: pytest.MonkeyPatch,
):
    """Test that event vacuum is disabled when 'events' is not in the enabled set."""
    settings = get_current_settings()
    monkeypatch.setattr(settings.server.services.event_persister, "enabled", True)
    monkeypatch.setattr(settings.server.services.db_vacuum, "enabled", set())

    config = next(
        c
        for c in _PERPETUAL_SERVICES
        if c.function.__name__ == "schedule_event_vacuum_tasks"
    )
    assert config.enabled_getter() is False


def test_event_vacuum_disabled_when_event_persister_disabled(
    monkeypatch: pytest.MonkeyPatch,
):
    """Test that event vacuum is disabled when event persister is disabled.

    Operators who opted out of event processing via
    PREFECT_SERVER_SERVICES_EVENT_PERSISTER_ENABLED=false should not see
    unexpected trimming on upgrade.
    """
    settings = get_current_settings()
    monkeypatch.setattr(settings.server.services.event_persister, "enabled", False)

    config = next(
        c
        for c in _PERPETUAL_SERVICES
        if c.function.__name__ == "schedule_event_vacuum_tasks"
    )
    assert config.enabled_getter() is False


def test_flow_runs_vacuum_enabled_when_in_enabled_set(
    monkeypatch: pytest.MonkeyPatch,
):
    """Test that flow_runs vacuum is enabled when 'flow_runs' is in the enabled set."""
    settings = get_current_settings()
    monkeypatch.setattr(
        settings.server.services.db_vacuum, "enabled", {"events", "flow_runs"}
    )

    config = next(
        c for c in _PERPETUAL_SERVICES if c.function.__name__ == "schedule_vacuum_tasks"
    )
    assert config.enabled_getter() is True


def test_event_vacuum_runs_in_ephemeral_mode():
    """Test that event vacuum runs in ephemeral mode (replacing EventPersister.trim())."""
    config = next(
        c
        for c in _PERPETUAL_SERVICES
        if c.function.__name__ == "schedule_event_vacuum_tasks"
    )
    assert config.run_in_ephemeral is True


def test_cancellation_cleanup_services_registered():
    """Test that cancellation cleanup perpetual services are registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "ensure_cancelling_timeout_checks" in service_names
    assert "monitor_cancelled_flow_runs" in service_names
    assert "monitor_subflow_runs" in service_names


def test_pause_expirations_service_registered():
    """Test that pause expirations perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "monitor_expired_pauses" in service_names


def test_late_runs_service_registered():
    """Test that late runs perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "monitor_late_runs" in service_names


def test_repossessor_service_registered():
    """Test that repossessor perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "monitor_expired_leases" in service_names


def test_cleanup_reconciler_service_registered():
    """Test that cleanup reconciler perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "reconcile_cleanup_delivery" in service_names


def test_foreman_service_registered():
    """Test that foreman perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "monitor_worker_health" in service_names


def test_telemetry_service_registered():
    """Test that telemetry perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "send_telemetry_heartbeat" in service_names


def test_telemetry_runs_in_all_modes():
    """Test that telemetry is configured to run in ephemeral and webserver modes."""
    config = next(
        c
        for c in _PERPETUAL_SERVICES
        if c.function.__name__ == "send_telemetry_heartbeat"
    )
    assert config.run_in_ephemeral is True
    assert config.run_in_webserver is True


def test_scheduler_services_registered():
    """Test that scheduler perpetual services are registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "schedule_deployments" in service_names
    assert "schedule_recent_deployments" in service_names


def test_proactive_triggers_service_registered():
    """Test that proactive triggers perpetual service is registered."""
    service_names = [config.function.__name__ for config in _PERPETUAL_SERVICES]
    assert "evaluate_proactive_triggers_periodic" in service_names


def test_get_perpetual_services_returns_all_in_default_mode():
    """Test that get_perpetual_services returns all services in default mode."""
    services = get_perpetual_services(ephemeral=False, webserver_only=False)
    service_names = [config.function.__name__ for config in services]
    assert "monitor_cancelled_flow_runs" in service_names
    assert "monitor_subflow_runs" in service_names


def test_get_perpetual_services_filters_ephemeral_mode():
    """Test that ephemeral mode filters services correctly."""
    services = get_perpetual_services(ephemeral=True, webserver_only=False)
    # Cancellation cleanup services are not marked for ephemeral mode
    service_names = [config.function.__name__ for config in services]
    assert "monitor_cancelled_flow_runs" not in service_names
    assert "monitor_subflow_runs" not in service_names
    # Proactive triggers and event vacuum ARE marked for ephemeral mode
    assert "evaluate_proactive_triggers_periodic" in service_names
    assert "schedule_event_vacuum_tasks" in service_names


def test_get_perpetual_services_filters_webserver_mode():
    """Test that webserver mode filters services correctly."""
    services = get_perpetual_services(ephemeral=False, webserver_only=True)
    # Cancellation cleanup services are not marked for webserver mode
    service_names = [config.function.__name__ for config in services]
    assert "monitor_cancelled_flow_runs" not in service_names
    assert "monitor_subflow_runs" not in service_names


def test_get_enabled_perpetual_services_respects_settings(
    monkeypatch: pytest.MonkeyPatch,
):
    """Test that get_enabled_perpetual_services respects the enabled setting."""
    settings = get_current_settings()

    # Enable cancellation cleanup
    monkeypatch.setattr(settings.server.services.cancellation_cleanup, "enabled", True)

    services = get_enabled_perpetual_services(ephemeral=False, webserver_only=False)
    service_names = [config.function.__name__ for config in services]
    assert "monitor_cancelled_flow_runs" in service_names
    assert "monitor_subflow_runs" in service_names

    # Disable cancellation cleanup
    monkeypatch.setattr(settings.server.services.cancellation_cleanup, "enabled", False)

    services = get_enabled_perpetual_services(ephemeral=False, webserver_only=False)
    service_names = [config.function.__name__ for config in services]
    assert "monitor_cancelled_flow_runs" not in service_names
    assert "monitor_subflow_runs" not in service_names


def test_all_perpetual_services_use_automatic_true():
    """All perpetual services must use automatic=True so the docket worker
    reschedules them after a Redis disruption."""
    for config in _PERPETUAL_SERVICES:
        perpetual = get_single_dependency_parameter_of_type(config.function, Perpetual)
        assert perpetual is not None, (
            f"{config.function.__name__} has no Perpetual dependency"
        )
        assert perpetual.automatic is True, (
            f"{config.function.__name__} uses automatic=False; "
            "all perpetual services must use automatic=True for Redis recovery"
        )
