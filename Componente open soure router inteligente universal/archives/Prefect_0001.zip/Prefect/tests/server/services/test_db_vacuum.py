"""Tests for the database vacuum docket task functions."""

from __future__ import annotations

import asyncio
import datetime
import uuid
from datetime import timedelta
from types import SimpleNamespace

import pytest
import sqlalchemy as sa

from prefect.server import models, schemas
from prefect.server.database import PrefectDBInterface, provide_database_interface
from prefect.server.database.configurations import (
    AioSqliteConfiguration,
    AsyncPostgresConfiguration,
)
from prefect.server.events.schemas.events import ReceivedEvent, Resource
from prefect.server.events.storage.database import write_events
from prefect.server.schemas.actions import LogCreate
from prefect.server.services import db_vacuum
from prefect.server.services.db_vacuum import (
    _maintenance_database_config,
    _maintenance_session,
    schedule_orphan_vacuum_tasks,
    schedule_vacuum_tasks,
    vacuum_events_with_retention_overrides,
    vacuum_old_events,
    vacuum_old_flow_runs,
    vacuum_orphaned_artifacts,
    vacuum_orphaned_logs,
    vacuum_stale_artifact_collections,
)
from prefect.settings.context import get_current_settings
from prefect.types._datetime import now

pytestmark = pytest.mark.clear_db


@pytest.fixture(autouse=True)
def enable_db_vacuum(monkeypatch: pytest.MonkeyPatch) -> None:
    """Enable the vacuum service and set short retention for testing."""
    settings = get_current_settings()
    monkeypatch.setattr(
        settings.server.services.db_vacuum, "enabled", {"events", "flow_runs"}
    )
    monkeypatch.setattr(
        settings.server.services.db_vacuum,
        "retention_period",
        timedelta(days=1),
    )
    monkeypatch.setattr(settings.server.services.db_vacuum, "batch_size", 100)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

OLD = now("UTC") - timedelta(days=30)
RECENT = now("UTC") - timedelta(hours=1)


async def _create_flow_run(
    session,
    flow,
    *,
    state=None,
    end_time=None,
    parent_task_run_id=None,
):
    if state is None:
        state = schemas.states.Completed()
    flow_run = await models.flow_runs.create_flow_run(
        session=session,
        flow_run=schemas.core.FlowRun(
            flow_id=flow.id,
            state=state,
            end_time=end_time,
            parent_task_run_id=parent_task_run_id,
        ),
    )
    await session.commit()
    return flow_run


async def _create_task_run(session, flow_run):
    task_run = await models.task_runs.create_task_run(
        session=session,
        task_run=schemas.actions.TaskRunCreate(
            flow_run_id=flow_run.id,
            task_key=f"task-{uuid.uuid4()}",
            dynamic_key="0",
        ),
    )
    await session.commit()
    return task_run


async def _create_log(session, flow_run_id=None, task_run_id=None):
    await models.logs.create_logs(
        session=session,
        logs=[
            LogCreate(
                name="prefect.test",
                level=20,
                message="test log",
                timestamp=now("UTC"),
                flow_run_id=flow_run_id,
                task_run_id=task_run_id,
            ),
        ],
    )
    await session.commit()


async def _create_artifact(session, flow_run_id=None, key=None):
    artifact = await models.artifacts.create_artifact(
        session=session,
        artifact=schemas.core.Artifact(
            key=key,
            data=1,
            flow_run_id=flow_run_id,
        ),
    )
    await session.commit()
    return artifact


async def _count(session, db: PrefectDBInterface, model) -> int:
    result = await session.execute(sa.select(sa.func.count(model.id)))
    return result.scalar_one()


async def _create_event(
    db: PrefectDBInterface,
    event_type: str,
    occurred: datetime.datetime,
) -> ReceivedEvent:
    """Create an event + its resource row in the database."""
    event = ReceivedEvent(
        occurred=occurred,
        event=event_type,
        resource=Resource.model_validate(
            {"prefect.resource.id": f"prefect.flow-run.{uuid.uuid4()}"}
        ),
        payload={},
        id=uuid.uuid4(),
    )
    async with db.session_context(begin_transaction=True) as session:
        await write_events(session, [event])
    return event


async def _count_events(db: PrefectDBInterface) -> int:
    async with db.session_context() as session:
        result = await session.execute(sa.select(sa.func.count(db.Event.id)))
        return result.scalar_one()


async def _count_event_resources(db: PrefectDBInterface) -> int:
    async with db.session_context() as session:
        result = await session.execute(sa.select(sa.func.count(db.EventResource.id)))
        return result.scalar_one()


# ---------------------------------------------------------------------------
# Test classes
# ---------------------------------------------------------------------------


class TestVacuumOldFlowRuns:
    async def test_deletes_old_completed_flow_runs(self, session, flow):
        """Old terminal flow runs should be deleted."""
        db = provide_database_interface()
        await _create_flow_run(session, flow, end_time=OLD)

        assert await _count(session, db, db.FlowRun) == 1
        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0

    async def test_preserves_recent_flow_runs(self, session, flow):
        """Flow runs within the retention period should not be deleted."""
        db = provide_database_interface()
        await _create_flow_run(session, flow, end_time=RECENT)

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 1

    async def test_preserves_running_flow_runs(self, session, flow):
        """Non-terminal flow runs should never be deleted."""
        db = provide_database_interface()
        await _create_flow_run(
            session,
            flow,
            state=schemas.states.Running(),
            end_time=None,
        )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 1

    async def test_cascade_deletes_task_runs(self, session, flow):
        """Task runs belonging to a deleted flow run should be cascade-deleted."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=OLD)
        await _create_task_run(session, flow_run)

        assert await _count(session, db, db.TaskRun) == 1
        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0
            assert await _count(new_session, db, db.TaskRun) == 0

    async def test_subflow_cleaned_up_with_parent(self, session, flow):
        """Old subflows are cleaned up when their parent is deleted (same vacuum run)."""
        db = provide_database_interface()
        parent = await _create_flow_run(session, flow, end_time=OLD)
        parent_task = await _create_task_run(session, parent)

        # Subflow: old, terminal, has parent_task_run_id
        await _create_flow_run(
            session,
            flow,
            end_time=OLD,
            parent_task_run_id=parent_task.id,
        )

        assert await _count(session, db, db.FlowRun) == 2

        # Parent deletion cascades SET NULL on subflow's parent_task_run_id,
        # making it top-level. The batch loop's next iteration picks it up.
        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0

    async def test_recent_subflow_survives_parent_deletion(self, session, flow):
        """A recent subflow survives even after its parent is deleted."""
        db = provide_database_interface()
        parent = await _create_flow_run(session, flow, end_time=OLD)
        parent_task = await _create_task_run(session, parent)

        # Subflow: recent end_time, so not eligible for deletion
        subflow = await _create_flow_run(
            session,
            flow,
            end_time=RECENT,
            parent_task_run_id=parent_task.id,
        )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            # Parent deleted, but subflow survives (too recent)
            result = await new_session.execute(
                sa.select(db.FlowRun).where(db.FlowRun.id == subflow.id)
            )
            remaining = result.scalar_one_or_none()
            assert remaining is not None
            assert remaining.parent_task_run_id is None  # SET NULL by cascade

    async def test_deletes_all_terminal_states(self, session, flow):
        """All terminal state types should be eligible for deletion."""
        db = provide_database_interface()
        for state_cls in (
            schemas.states.Completed,
            schemas.states.Failed,
            schemas.states.Cancelled,
            schemas.states.Crashed,
        ):
            await _create_flow_run(session, flow, state=state_cls(), end_time=OLD)

        assert await _count(session, db, db.FlowRun) == 4
        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0

    async def test_preserves_terminal_run_without_end_time(self, session, flow):
        """Terminal flow runs with end_time=None should not be deleted."""
        db = provide_database_interface()
        await _create_flow_run(
            session, flow, state=schemas.states.Completed(), end_time=None
        )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 1

    async def test_preserves_scheduled_flow_runs(self, session, flow):
        """Scheduled (non-terminal) flow runs should not be deleted."""
        db = provide_database_interface()
        await _create_flow_run(
            session, flow, state=schemas.states.Scheduled(), end_time=None
        )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 1

    async def test_preserves_cancelling_flow_runs(self, session, flow):
        """CANCELLING is non-terminal and should not be deleted."""
        db = provide_database_interface()
        await _create_flow_run(
            session, flow, state=schemas.states.Cancelling(), end_time=OLD
        )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 1

    async def test_deletes_logs_and_artifacts_with_the_run(self, session, flow):
        """Logs and artifacts are deleted by flow_run_id in the same batch."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=OLD)
        task_run = await _create_task_run(session, flow_run)
        await _create_log(session, flow_run_id=flow_run.id)
        await _create_log(session, flow_run_id=flow_run.id, task_run_id=task_run.id)
        await _create_artifact(session, flow_run_id=flow_run.id)

        assert await _count(session, db, db.Log) == 2
        assert await _count(session, db, db.Artifact) == 1

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0
            assert await _count(new_session, db, db.Log) == 0
            assert await _count(new_session, db, db.Artifact) == 0

    async def test_preserves_children_of_surviving_runs(self, session, flow):
        """Logs and artifacts of runs within the retention period survive."""
        db = provide_database_interface()
        old_run = await _create_flow_run(session, flow, end_time=OLD)
        recent_run = await _create_flow_run(session, flow, end_time=RECENT)
        await _create_log(session, flow_run_id=old_run.id)
        await _create_log(session, flow_run_id=recent_run.id)
        await _create_log(session, flow_run_id=None)
        await _create_artifact(session, flow_run_id=recent_run.id)

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 1
            # The recent run's log and the log with no flow_run_id remain
            assert await _count(new_session, db, db.Log) == 2
            assert await _count(new_session, db, db.Artifact) == 1

    async def test_children_are_deleted_in_bounded_batches(
        self, session, flow, monkeypatch
    ):
        """A run with more children than `batch_size` still loses all of them."""
        settings = get_current_settings()
        monkeypatch.setattr(settings.server.services.db_vacuum, "batch_size", 2)

        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=OLD)
        for _ in range(5):
            await _create_log(session, flow_run_id=flow_run.id)
        for index in range(3):
            await _create_artifact(
                session, flow_run_id=flow_run.id, key=f"report-{index}"
            )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0
            assert await _count(new_session, db, db.Log) == 0
            assert await _count(new_session, db, db.Artifact) == 0

    async def test_batching_deletes_children_across_batches(
        self, session, flow, monkeypatch
    ):
        """Every batch cleans up its own runs' logs, not just the first."""
        settings = get_current_settings()
        monkeypatch.setattr(settings.server.services.db_vacuum, "batch_size", 2)

        db = provide_database_interface()
        for _ in range(5):
            flow_run = await _create_flow_run(session, flow, end_time=OLD)
            await _create_log(session, flow_run_id=flow_run.id)

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0
            assert await _count(new_session, db, db.Log) == 0

    async def test_locked_run_is_skipped(self, session, flow):
        """A locked state change prevents vacuum from selecting the run."""
        db = provide_database_interface()
        if db.dialect.name != "postgresql":
            pytest.skip("Row-level locking is PostgreSQL-only")

        flow_run = await _create_flow_run(session, flow, end_time=OLD)
        async with db.session_context(
            begin_transaction=True, with_for_update=True
        ) as update_session:
            await models.flow_runs.set_flow_run_state(
                session=update_session,
                flow_run_id=flow_run.id,
                state=schemas.states.Running(),
                force=True,
            )
            await asyncio.wait_for(vacuum_old_flow_runs(db=db), timeout=5)

        async with db.session_context() as read_session:
            surviving_run = await read_session.get(db.FlowRun, flow_run.id)
            assert surviving_run is not None
            assert surviving_run.state_type == schemas.states.StateType.RUNNING

    async def test_deletes_run_before_starting_child_cleanup(
        self, session, flow, monkeypatch
    ):
        """Child cleanup cannot delete data from a run that still exists."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=OLD)
        await _create_log(session, flow_run_id=flow_run.id)
        original_batch_delete = db_vacuum._batch_delete

        async def assert_run_was_deleted_before_children(*args, **kwargs):
            async with db.session_context() as read_session:
                assert await read_session.get(db.FlowRun, flow_run.id) is None
            return await original_batch_delete(*args, **kwargs)

        monkeypatch.setattr(
            db_vacuum, "_batch_delete", assert_run_was_deleted_before_children
        )

        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as read_session:
            assert await _count(read_session, db, db.Log) == 0

    async def test_reconciles_collections_of_deleted_artifacts(self, session, flow):
        """Collections left stale by inline artifact deletion are reconciled."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=OLD)
        await _create_artifact(session, flow_run_id=flow_run.id, key="my-report")

        assert await _count(session, db, db.ArtifactCollection) == 1

        await vacuum_old_flow_runs(db=db)
        await vacuum_stale_artifact_collections(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Artifact) == 0
            assert await _count(new_session, db, db.ArtifactCollection) == 0


async def test_flow_run_vacuum_schedules_only_expected_cleanup_tasks():
    scheduled: list[tuple[object, str | None]] = []

    class FakeDocket:
        def add(self, function, key=None):
            scheduled.append((function, key))

            async def enqueue():
                return None

            return enqueue

    await schedule_vacuum_tasks(docket=FakeDocket())

    assert scheduled == [
        (vacuum_old_flow_runs, "db-vacuum:old-flow-runs"),
    ]


async def test_orphan_reconciliation_schedules_cleanup_tasks():
    scheduled: list[tuple[object, str | None]] = []

    class FakeDocket:
        def add(self, function, key=None):
            scheduled.append((function, key))

            async def enqueue():
                return None

            return enqueue

    await schedule_orphan_vacuum_tasks(docket=FakeDocket())

    assert scheduled == [
        (vacuum_orphaned_logs, "db-vacuum:orphaned-logs"),
        (vacuum_orphaned_artifacts, "db-vacuum:orphaned-artifacts"),
        (vacuum_stale_artifact_collections, "db-vacuum:stale-collections"),
    ]


class TestVacuumOrphanedLogs:
    async def test_deletes_orphaned_logs(self, session, flow):
        """Logs referencing a non-existent flow run should be deleted."""
        db = provide_database_interface()
        # Create a log pointing to a flow_run_id that doesn't exist
        fake_flow_run_id = uuid.uuid4()
        await _create_log(session, flow_run_id=fake_flow_run_id)

        assert await _count(session, db, db.Log) == 1
        await vacuum_orphaned_logs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Log) == 0

    async def test_preserves_logs_with_existing_flow_run(self, session, flow):
        """Logs tied to an existing flow run should not be deleted."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=RECENT)
        await _create_log(session, flow_run_id=flow_run.id)

        await vacuum_orphaned_logs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Log) == 1

    async def test_preserves_logs_with_null_flow_run_id(self, session, flow):
        """Logs with flow_run_id=NULL (e.g. task-run-only) should not be deleted."""
        db = provide_database_interface()
        await _create_log(session, flow_run_id=None)

        await vacuum_orphaned_logs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Log) == 1


class TestVacuumOrphanedArtifacts:
    async def test_deletes_orphaned_artifacts(self, session, flow):
        """Artifacts referencing a non-existent flow run should be deleted."""
        db = provide_database_interface()
        fake_flow_run_id = uuid.uuid4()
        await _create_artifact(session, flow_run_id=fake_flow_run_id)

        assert await _count(session, db, db.Artifact) == 1
        await vacuum_orphaned_artifacts(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Artifact) == 0

    async def test_preserves_artifacts_with_existing_flow_run(self, session, flow):
        """Artifacts tied to an existing flow run should not be deleted."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=RECENT)
        await _create_artifact(session, flow_run_id=flow_run.id)

        await vacuum_orphaned_artifacts(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Artifact) == 1

    async def test_preserves_artifacts_with_null_flow_run_id(self, session, flow):
        """Artifacts with flow_run_id=NULL should not be deleted."""
        db = provide_database_interface()
        await _create_artifact(session, flow_run_id=None)

        await vacuum_orphaned_artifacts(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Artifact) == 1


class TestVacuumArtifactCollections:
    async def test_deletes_stale_artifact_collections(self, session, flow):
        """Artifact collections pointing to deleted artifacts should be removed."""
        db = provide_database_interface()
        # Create an artifact with a key -> this also creates an artifact_collection
        fake_flow_run_id = uuid.uuid4()
        await _create_artifact(session, flow_run_id=fake_flow_run_id, key="my-report")

        assert await _count(session, db, db.ArtifactCollection) == 1

        # First vacuum orphaned artifacts, then stale collections
        await vacuum_orphaned_artifacts(db=db)
        await vacuum_stale_artifact_collections(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.Artifact) == 0
            assert await _count(new_session, db, db.ArtifactCollection) == 0

    async def test_repoints_collection_to_next_latest_version(self, session, flow):
        """When the latest artifact is orphaned but an older version exists,
        the collection should be re-pointed to the older version."""
        db = provide_database_interface()
        # Older artifact version — tied to an existing flow run
        live_run = await _create_flow_run(session, flow, end_time=RECENT)
        older_artifact = await _create_artifact(
            session, flow_run_id=live_run.id, key="my-report"
        )

        # Newer artifact version (same key) — orphaned flow run
        fake_flow_run_id = uuid.uuid4()
        await _create_artifact(session, flow_run_id=fake_flow_run_id, key="my-report")

        # Collection should point to the newer (orphaned) artifact
        assert await _count(session, db, db.ArtifactCollection) == 1

        await vacuum_orphaned_artifacts(db=db)
        await vacuum_stale_artifact_collections(db=db)

        async with db.session_context() as new_session:
            # Orphaned artifact deleted, but collection survives re-pointed
            assert await _count(new_session, db, db.Artifact) == 1
            assert await _count(new_session, db, db.ArtifactCollection) == 1

            # Verify collection now points to the older (surviving) artifact
            result = await new_session.execute(
                sa.select(db.ArtifactCollection).where(
                    db.ArtifactCollection.key == "my-report"
                )
            )
            collection = result.scalar_one()
            assert collection.latest_id == older_artifact.id

    async def test_deletes_standalone_stale_collection(self, session):
        """A stale collection row (e.g. left over from a previous crash)
        should be deleted even without artifact cleanup in the same cycle."""
        db = provide_database_interface()
        # Directly insert a collection row with a dangling latest_id
        async with db.session_context(begin_transaction=True) as s:
            await s.execute(
                sa.insert(db.ArtifactCollection).values(
                    id=uuid.uuid4(),
                    key="stale-key",
                    latest_id=uuid.uuid4(),  # points to nothing
                )
            )

        async with db.session_context() as s:
            assert await _count(s, db, db.ArtifactCollection) == 1

        await vacuum_stale_artifact_collections(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.ArtifactCollection) == 0

    async def test_preserves_valid_artifact_collections(self, session, flow):
        """Artifact collections pointing to existing artifacts should be preserved."""
        db = provide_database_interface()
        flow_run = await _create_flow_run(session, flow, end_time=RECENT)
        await _create_artifact(session, flow_run_id=flow_run.id, key="my-report")

        await vacuum_stale_artifact_collections(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.ArtifactCollection) == 1


class TestVacuumHeartbeatEvents:
    async def test_deletes_old_heartbeat_events(self):
        """Old heartbeat events and their resources should be deleted."""
        db = provide_database_interface()
        await _create_event(db, "prefect.flow-run.heartbeat", OLD)

        assert await _count_events(db) == 1
        assert await _count_event_resources(db) >= 1

        await vacuum_events_with_retention_overrides(db=db)

        assert await _count_events(db) == 0
        assert await _count_event_resources(db) == 0

    async def test_preserves_recent_heartbeat_events(self):
        """Recent heartbeat events should not be deleted."""
        db = provide_database_interface()
        await _create_event(db, "prefect.flow-run.heartbeat", RECENT)

        await vacuum_events_with_retention_overrides(db=db)

        assert await _count_events(db) == 1
        assert await _count_event_resources(db) >= 1

    async def test_preserves_non_heartbeat_events(self):
        """Old non-heartbeat events should not be deleted by this task."""
        db = provide_database_interface()
        await _create_event(db, "prefect.flow-run.completed", OLD)

        await vacuum_events_with_retention_overrides(db=db)

        assert await _count_events(db) == 1
        assert await _count_event_resources(db) >= 1

    async def test_respects_events_retention_period(self, monkeypatch):
        """Heartbeat retention should not exceed the general events retention period."""
        db = provide_database_interface()
        settings = get_current_settings()

        # Set general events retention to 12 hours (shorter than heartbeat default of 7 days)
        monkeypatch.setattr(
            settings.server.events,
            "retention_period",
            timedelta(hours=12),
        )

        # Create a heartbeat event 18 hours ago (past 12h, within 7 days)
        eighteen_hours_ago = now("UTC") - timedelta(hours=18)
        await _create_event(db, "prefect.flow-run.heartbeat", eighteen_hours_ago)

        await vacuum_events_with_retention_overrides(db=db)

        # Should be deleted because events retention (12h) is shorter
        assert await _count_events(db) == 0

    async def test_uses_event_retention_override(self, monkeypatch):
        """Should use per-type retention from event_retention_overrides."""
        db = provide_database_interface()
        settings = get_current_settings()

        # Set a custom short retention for heartbeat events (2 hours)
        monkeypatch.setattr(
            settings.server.services.db_vacuum,
            "event_retention_overrides",
            {"prefect.flow-run.heartbeat": timedelta(hours=2)},
        )

        # Create a heartbeat event 4 hours ago (past 2h override)
        four_hours_ago = now("UTC") - timedelta(hours=4)
        await _create_event(db, "prefect.flow-run.heartbeat", four_hours_ago)

        await vacuum_events_with_retention_overrides(db=db)

        # Should be deleted because heartbeat override (2h) is shorter than age (4h)
        assert await _count_events(db) == 0

    async def test_skips_types_without_override(self, monkeypatch):
        """Without an override, events are left for vacuum_old_events to handle."""
        db = provide_database_interface()
        settings = get_current_settings()

        # Remove the heartbeat override
        monkeypatch.setattr(
            settings.server.services.db_vacuum,
            "event_retention_overrides",
            {},
        )
        await _create_event(db, "prefect.flow-run.heartbeat", OLD)

        await vacuum_events_with_retention_overrides(db=db)

        # Event is NOT deleted — no override means no action from this task
        assert await _count_events(db) == 1

    async def test_deletes_associated_event_resources(self):
        """Resources for deleted heartbeat events should be removed."""
        db = provide_database_interface()
        event = await _create_event(db, "prefect.flow-run.heartbeat", OLD)

        # Verify the resource was created
        async with db.session_context() as session:
            result = await session.execute(
                sa.select(sa.func.count(db.EventResource.id)).where(
                    db.EventResource.event_id == event.id
                )
            )
            assert result.scalar_one() >= 1

        await vacuum_events_with_retention_overrides(db=db)

        async with db.session_context() as session:
            result = await session.execute(
                sa.select(sa.func.count(db.EventResource.id)).where(
                    db.EventResource.event_id == event.id
                )
            )
            assert result.scalar_one() == 0


class TestVacuumOldEvents:
    async def test_deletes_old_events(self, monkeypatch):
        """Events and resources past the events retention period should be deleted."""
        db = provide_database_interface()
        # events.retention_period defaults to 7 days; our OLD is 30 days ago
        await _create_event(db, "prefect.flow-run.completed", OLD)

        assert await _count_events(db) == 1
        assert await _count_event_resources(db) >= 1

        await vacuum_old_events(db=db)

        assert await _count_events(db) == 0
        assert await _count_event_resources(db) == 0

    async def test_preserves_recent_events(self):
        """Recent events should not be deleted."""
        db = provide_database_interface()
        await _create_event(db, "prefect.flow-run.completed", RECENT)

        await vacuum_old_events(db=db)

        assert await _count_events(db) == 1
        assert await _count_event_resources(db) >= 1

    async def test_uses_events_retention_period(self, monkeypatch):
        """Should use settings.server.events.retention_period, not db_vacuum.retention_period."""
        db = provide_database_interface()
        settings = get_current_settings()

        # Set events retention to 60 days (longer than our 30-day-old event)
        monkeypatch.setattr(
            settings.server.events,
            "retention_period",
            timedelta(days=60),
        )

        await _create_event(db, "prefect.flow-run.completed", OLD)

        await vacuum_old_events(db=db)

        # The 30-day-old event should survive because retention is 60 days
        assert await _count_events(db) == 1


class TestVacuumBatching:
    async def test_batching_deletes_all_records(self, session, flow, monkeypatch):
        """With batch_size=5, all 12 old flow runs should eventually be deleted."""
        settings = get_current_settings()
        monkeypatch.setattr(settings.server.services.db_vacuum, "batch_size", 5)

        db = provide_database_interface()
        for _ in range(12):
            await _create_flow_run(session, flow, end_time=OLD)

        assert await _count(session, db, db.FlowRun) == 12
        await vacuum_old_flow_runs(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0

    async def test_large_configured_batch_chunks_delete_parameters(
        self, session, flow, monkeypatch
    ):
        """A configured batch over SQLite's legacy limit still bounds each DELETE."""
        db = provide_database_interface()
        if db.dialect.name != "sqlite":
            pytest.skip("SQLite query-parameter regression")

        settings = get_current_settings()
        monkeypatch.setattr(settings.server.services.db_vacuum, "batch_size", 1_001)
        monkeypatch.setattr(db_vacuum, "get_max_query_parameters", lambda: 4)

        for _ in range(5):
            await _create_flow_run(session, flow, end_time=OLD)

        delete_parameter_counts: list[int] = []
        engine = await db.engine()

        def record_delete_parameters(
            _conn, _cursor, statement, parameters, _context, _executemany
        ):
            if statement.lstrip().upper().startswith("DELETE FROM"):
                delete_parameter_counts.append(len(parameters))

        sa.event.listen(
            engine.sync_engine, "before_cursor_execute", record_delete_parameters
        )
        try:
            await vacuum_old_flow_runs(db=db)
        finally:
            sa.event.remove(
                engine.sync_engine,
                "before_cursor_execute",
                record_delete_parameters,
            )

        assert delete_parameter_counts
        assert max(delete_parameter_counts) <= 4
        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0


class TestVacuumIdempotency:
    async def test_second_run_is_noop(self, session, flow):
        """Running vacuum tasks twice should produce zero changes on the second run."""
        db = provide_database_interface()
        await _create_flow_run(session, flow, end_time=OLD)
        fake_flow_run_id = uuid.uuid4()
        await _create_log(session, flow_run_id=fake_flow_run_id)
        await _create_artifact(session, flow_run_id=fake_flow_run_id, key="report")
        await _create_event(db, "prefect.flow-run.heartbeat", OLD)
        await _create_event(db, "prefect.flow-run.completed", OLD)

        await vacuum_orphaned_logs(db=db)
        await vacuum_orphaned_artifacts(db=db)
        await vacuum_stale_artifact_collections(db=db)
        await vacuum_old_flow_runs(db=db)
        await vacuum_events_with_retention_overrides(db=db)
        await vacuum_old_events(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0
            assert await _count(new_session, db, db.Log) == 0
            assert await _count(new_session, db, db.Artifact) == 0
            assert await _count(new_session, db, db.ArtifactCollection) == 0
        assert await _count_events(db) == 0
        assert await _count_event_resources(db) == 0

        # Second run should be a no-op
        await vacuum_orphaned_logs(db=db)
        await vacuum_orphaned_artifacts(db=db)
        await vacuum_stale_artifact_collections(db=db)
        await vacuum_old_flow_runs(db=db)
        await vacuum_events_with_retention_overrides(db=db)
        await vacuum_old_events(db=db)

        async with db.session_context() as new_session:
            assert await _count(new_session, db, db.FlowRun) == 0
            assert await _count(new_session, db, db.Log) == 0
            assert await _count(new_session, db, db.Artifact) == 0
            assert await _count(new_session, db, db.ArtifactCollection) == 0
        assert await _count_events(db) == 0
        assert await _count_event_resources(db) == 0


class TestNoOp:
    async def test_empty_database_does_not_error(self):
        """Running vacuum tasks on an empty database should complete without error."""
        db = provide_database_interface()
        await vacuum_orphaned_logs(db=db)
        await vacuum_orphaned_artifacts(db=db)
        await vacuum_stale_artifact_collections(db=db)
        await vacuum_old_flow_runs(db=db)
        await vacuum_events_with_retention_overrides(db=db)
        await vacuum_old_events(db=db)


class TestMaintenanceSession:
    """The maintenance session opts vacuum queries out of the API statement
    timeout on Postgres, where bulk deletes that scan large tables would
    otherwise be killed by asyncpg's `command_timeout`.
    """

    def setup_method(self) -> None:
        db_vacuum._MAINTENANCE_CONFIGS.clear()

    def test_postgres_config_disables_statement_timeout(self) -> None:
        base = AsyncPostgresConfiguration(
            connection_url="postgresql+asyncpg://u:p@host/db", timeout=10.0
        )
        db = SimpleNamespace(database_config=base)

        config = _maintenance_database_config(db)

        assert config is not None
        assert config is not base
        assert config.timeout is None
        assert config.sqlalchemy_pool_size == 1
        assert config.sqlalchemy_max_overflow == 0

    def test_postgres_config_is_cached_per_url(self) -> None:
        db = SimpleNamespace(
            database_config=AsyncPostgresConfiguration(
                connection_url="postgresql+asyncpg://u:p@host/db"
            )
        )

        first = _maintenance_database_config(db)
        second = _maintenance_database_config(db)

        assert first is second

    def test_non_postgres_returns_none(self) -> None:
        db = SimpleNamespace(
            database_config=AioSqliteConfiguration(
                connection_url="sqlite+aiosqlite:///:memory:"
            )
        )

        assert _maintenance_database_config(db) is None

    async def test_maintenance_session_is_usable(self):
        """The maintenance session yields a working transactional session
        regardless of backend (falls back to the default on non-Postgres)."""
        db = provide_database_interface()

        async with _maintenance_session(db) as session:
            assert await session.execute(sa.select(sa.literal(1))) is not None

    async def test_flow_run_vacuum_uses_immediate_sqlite_transaction(self):
        """The selection lock requests an immediate SQLite write transaction."""
        db = provide_database_interface()
        if db.dialect.name != "sqlite":
            pytest.skip("SQLite transaction-mode regression")

        begin_statements: list[str] = []
        engine = await db.engine()

        def record_begin_statement(
            _conn, _cursor, statement, _parameters, _context, _executemany
        ):
            if statement.lstrip().upper().startswith("BEGIN"):
                begin_statements.append(statement.strip().upper())

        sa.event.listen(
            engine.sync_engine, "before_cursor_execute", record_begin_statement
        )
        try:
            await vacuum_old_flow_runs(db=db)
        finally:
            sa.event.remove(
                engine.sync_engine,
                "before_cursor_execute",
                record_begin_statement,
            )

        assert "BEGIN IMMEDIATE" in begin_statements
