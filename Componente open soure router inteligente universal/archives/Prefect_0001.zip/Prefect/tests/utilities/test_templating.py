import uuid
from types import SimpleNamespace
from typing import Any, Dict

import pytest

import prefect.exceptions
from prefect.blocks.core import Block
from prefect.blocks.system import Secret
from prefect.blocks.webhook import Webhook
from prefect.client.orchestration import PrefectClient
from prefect.utilities.annotations import NotSet
from prefect.utilities.templating import (
    PlaceholderType,
    apply_values,
    find_placeholders,
    resolve_block_document_references,
    resolve_variables,
)


class TestFindPlaceholders:
    def test_empty_template(self):
        template = ""
        placeholders = find_placeholders(template)
        assert len(placeholders) == 0

    def test_single_placeholder(self):
        template = "Hello {{name}}!"
        placeholders = find_placeholders(template)
        assert len(placeholders) == 1
        assert placeholders.pop().name == "name"

    def test_multiple_placeholders(self):
        template = "Hello {{first_name}} {{last_name}}!"
        placeholders = find_placeholders(template)
        assert len(placeholders) == 2
        names = set(p.name for p in placeholders)
        assert names == {"first_name", "last_name"}

    def test_nested_placeholders(self):
        template = {"greeting": "Hello {{name}}!", "message": "{{greeting}}"}
        placeholders = find_placeholders(template)
        assert len(placeholders) == 2
        names = set(p.name for p in placeholders)
        assert names == {"name", "greeting"}

    def test_mixed_template(self):
        template = "Hello {{name}}! Your balance is ${{balance}}."
        placeholders = find_placeholders(template)
        assert len(placeholders) == 2
        names = set(p.name for p in placeholders)
        assert names == {"name", "balance"}

    def test_invalid_template(self):
        template = ("{{name}}!",)
        with pytest.raises(ValueError):
            find_placeholders(template)

    def test_nested_templates(self):
        template = {"greeting": "Hello {{name}}!", "message": {"text": "{{greeting}}"}}
        placeholders = find_placeholders(template)
        assert len(placeholders) == 2
        names = set(p.name for p in placeholders)
        assert names == {"name", "greeting"}

    def test_template_with_duplicates(self):
        template = "{{x}}{{x}}"
        placeholders = find_placeholders(template)
        assert len(placeholders) == 1
        assert placeholders.pop().name == "x"

    def test_template_with_unconventional_spacing(self):
        template = "Hello {{    first_name }} {{ last_name }}!"
        placeholders = find_placeholders(template)
        assert len(placeholders) == 2
        names = set(p.name for p in placeholders)
        assert names == {"first_name", "last_name"}

    def test_finds_block_document_placeholders(self):
        template = "Hello {{prefect.blocks.document.name}}!"
        placeholders = find_placeholders(template)
        assert len(placeholders) == 1
        placeholder = placeholders.pop()
        assert placeholder.name == "prefect.blocks.document.name"
        assert placeholder.type is PlaceholderType.BLOCK_DOCUMENT

    def test_finds_env_var_placeholders(self, monkeypatch):
        monkeypatch.setenv("MY_ENV_VAR", "VALUE")
        template = "Hello {{$MY_ENV_VAR}}!"
        placeholders = find_placeholders(template)
        assert len(placeholders) == 1
        placeholder = placeholders.pop()
        assert placeholder.name == "$MY_ENV_VAR"
        assert placeholder.type is PlaceholderType.ENV_VAR

    def test_apply_values_clears_placeholder_for_missing_env_vars(self):
        template = "{{ $MISSING_ENV_VAR }}"
        values = {"ANOTHER_ENV_VAR": "test_value"}
        result = apply_values(template, values)
        assert result == ""

    def test_finds_nested_env_var_placeholders(self, monkeypatch):
        monkeypatch.setenv("GREETING", "VALUE")
        template = {"greeting": "Hello {{name}}!", "message": {"text": "{{$GREETING}}"}}
        placeholders = find_placeholders(template)
        assert len(placeholders) == 2
        names = set(p.name for p in placeholders)
        assert names == {"name", "$GREETING"}

        types = set(p.type for p in placeholders)
        assert types == {PlaceholderType.STANDARD, PlaceholderType.ENV_VAR}

    @pytest.mark.parametrize(
        "template,expected",
        [
            (
                '{"greeting": "Hello {{name}}!", "message": {"text": "{{$$}}"}}',
                '{"greeting": "Hello Dan!", "message": {"text": ""}}',
            ),
            (
                '{"greeting": "Hello {{name}}!", "message": {"text": "{{$GREETING}}"}}',
                '{"greeting": "Hello Dan!", "message": {"text": ""}}',
            ),
        ],
    )
    def test_invalid_env_var_placeholder(self, template, expected):
        values = {"name": "Dan"}
        result = apply_values(template, values)
        assert result == expected


class TestApplyValues:
    def test_apply_values_simple_string_with_one_placeholder(self):
        assert apply_values("Hello, {{name}}!", {"name": "Alice"}) == "Hello, Alice!"

    def test_apply_values_simple_string_with_multiple_placeholders(self):
        assert (
            apply_values(
                "Hello, {{first_name}} {{last_name}}!",
                {"first_name": "Alice", "last_name": "Smith"},
            )
            == "Hello, Alice Smith!"
        )

    def test_apply_values_dictionary_with_placeholders(self):
        template = {"name": "{{first_name}} {{last_name}}", "age": "{{age}}"}
        values = {"first_name": "Alice", "last_name": "Smith", "age": 30}
        assert apply_values(template, values) == {"name": "Alice Smith", "age": 30}

    def test_apply_values_dictionary_with_unset_value(self):
        template = {"last_name": "{{last_name}}", "age": "{{age}}"}
        values = {"first_name": "Alice", "age": 30}
        assert apply_values(template, values) == {"age": 30}

    def test_apply_values_dictionary_with_null(self):
        template = {"last_name": None, "age": "{{age}}"}
        values = {"first_name": "Alice", "age": 30}
        assert apply_values(template, values) == {"last_name": None, "age": 30}

    def test_apply_values_nested_dictionary_with_placeholders(self):
        template = {
            "name": {"first_name": "{{ first_name }}", "last_name": "{{ last_name }}"},
            "age": "{{age}}",
        }
        values = {"first_name": "Alice", "last_name": "Smith", "age": 30}
        assert apply_values(template, values) == {
            "name": {"first_name": "Alice", "last_name": "Smith"},
            "age": 30,
        }

    def test_apply_values_dictionary_with_notset_value_removed(self):
        template = {"name": NotSet, "age": "{{age}}"}
        values = {"age": 30}
        assert apply_values(template, values) == {"age": 30}

    def test_apply_values_dictionary_with_NotSet_value_not_removed(self):
        template = {"name": NotSet, "age": "{{age}}"}
        values = {"age": 30}
        assert apply_values(template, values, remove_notset=False) == {
            "name": NotSet,
            "age": 30,
        }

    def test_apply_values_string_with_missing_value_not_removed(self):
        template = {"name": "Bob {{last_name}}", "age": "{{age}}"}
        values = {"age": 30}
        assert apply_values(template, values, remove_notset=False) == {
            "name": "Bob {{last_name}}",
            "age": 30,
        }

    def test_apply_values_nested_with_NotSet_value_not_removed(self):
        template = [{"top_key": {"name": NotSet, "age": "{{age}}"}}]
        values = {"age": 30}
        assert apply_values(template, values, remove_notset=False) == [
            {
                "top_key": {
                    "name": NotSet,
                    "age": 30,
                }
            }
        ]

    def test_apply_values_list_with_placeholders(self):
        template = [
            "Hello, {{first_name}} {{last_name}}!",
            {"name": "{{first_name}} {{last_name}}"},
        ]
        values = {"first_name": "Alice", "last_name": "Smith"}
        assert apply_values(template, values) == [
            "Hello, Alice Smith!",
            {"name": "Alice Smith"},
        ]

    def test_apply_values_integer_input(self):
        assert apply_values(123, {"name": "Alice"}) == 123

    def test_apply_values_float_input(self):
        assert apply_values(3.14, {"pi": 3.14}) == 3.14

    def test_apply_values_boolean_input(self):
        assert apply_values(True, {"flag": False}) is True

    def test_apply_values_none_input(self):
        assert apply_values(None, {"key": "value"}) is None

    def test_does_not_apply_values_to_block_document_placeholders(self):
        template = "Hello {{prefect.blocks.document.name}}!"
        assert apply_values(template, {"name": "Alice"}) == template

    def test_apply_values_with_dot_delimited_placeholder_str(self):
        template = "Hello {{ person.name }}!"
        assert apply_values(template, {"person": {"name": "Arthur"}}) == "Hello Arthur!"

    def test_apply_values_with_dot_delimited_placeholder_str_with_list(self):
        template = "Hello {{ people[0].name }}!"
        assert (
            apply_values(template, {"people": [{"name": "Arthur"}]}) == "Hello Arthur!"
        )

    def test_apply_values_with_dot_delimited_placeholder_dict(self):
        template = {"right now we need": "{{ people.superman }}"}
        values = {"people": {"superman": {"first_name": "Superman", "age": 30}}}
        assert apply_values(template, values) == {
            "right now we need": {"first_name": "Superman", "age": 30}
        }

    def test_apply_values_with_dot_delimited_placeholder_with_list(self):
        template = {"right now we need": "{{ people[0] }}"}
        values = {"people": [{"first_name": "Superman", "age": 30}]}
        assert apply_values(template, values) == {
            "right now we need": {"first_name": "Superman", "age": 30}
        }

    def test_apply_values_warns_on_notset_value(self, caplog: pytest.LogCaptureFixture):
        template = "{{name}}"
        apply_values(template, values={}, warn_on_notset=True)
        assert (
            "Value for placeholder 'name' not found in provided values." in caplog.text
        )

    def test_apply_values_warns_on_notset_value_dict(
        self, caplog: pytest.LogCaptureFixture
    ):
        template = {"name": "{{name}}"}
        apply_values(template, values={}, warn_on_notset=True)
        assert (
            "Value for placeholder 'name' not found in provided values." in caplog.text
        )

    def test_apply_values_skip_prefixes_single_placeholder(self):
        """Skipped placeholder as entire value is left intact."""
        template = "{{ ctx.flow.name }}"
        result = apply_values(
            template, values={}, remove_notset=True, skip_prefixes=["ctx."]
        )
        assert result == "{{ ctx.flow.name }}"

    def test_apply_values_skip_prefixes_embedded_placeholder(self):
        """Skipped placeholder embedded in text is left intact."""
        template = "job-{{ ctx.flow.name }}/{{ ctx.flow_run.name }}"
        result = apply_values(
            template, values={}, remove_notset=True, skip_prefixes=["ctx."]
        )
        assert result == "job-{{ ctx.flow.name }}/{{ ctx.flow_run.name }}"

    def test_apply_values_skip_prefixes_mixed_placeholders(self):
        """Skipped and non-skipped placeholders coexist correctly."""
        template = "{{ ctx.flow.name }}-{{ version }}"
        result = apply_values(
            template,
            values={"version": "1.0"},
            remove_notset=True,
            skip_prefixes=["ctx."],
        )
        assert result == "{{ ctx.flow.name }}-1.0"

    def test_apply_values_skip_prefixes_does_not_affect_other_placeholders(self):
        """Non-matching placeholders are still resolved or removed normally."""
        template = {"name": "{{ ctx.flow.name }}", "image": "{{ build.image }}"}
        result = apply_values(
            template,
            values={"build": {"image": "my-image:latest"}},
            remove_notset=True,
            skip_prefixes=["ctx."],
        )
        assert result == {"name": "{{ ctx.flow.name }}", "image": "my-image:latest"}

    def test_apply_values_skip_prefixes_in_nested_structures(self):
        """skip_prefixes works recursively through dicts and lists."""
        template = {
            "work_pool": {
                "job_variables": {
                    "name": "{{ ctx.flow.name }}",
                    "image": "{{ build-image.image }}",
                }
            },
            "tags": ["{{ ctx.flow_run.name }}", "{{ version }}"],
        }
        result = apply_values(
            template,
            values={"build-image": {"image": "img:latest"}, "version": "v1"},
            remove_notset=True,
            skip_prefixes=["ctx."],
        )
        assert result == {
            "work_pool": {
                "job_variables": {
                    "name": "{{ ctx.flow.name }}",
                    "image": "img:latest",
                }
            },
            "tags": ["{{ ctx.flow_run.name }}", "v1"],
        }

    def test_apply_values_skip_prefixes_warns_only_for_non_skipped(
        self, caplog: pytest.LogCaptureFixture
    ):
        """Skipped placeholders do not produce warnings."""
        template = {"a": "{{ ctx.flow.name }}", "b": "{{ missing }}"}
        apply_values(
            template,
            values={},
            warn_on_notset=True,
            skip_prefixes=["ctx."],
        )
        assert "ctx.flow.name" not in caplog.text
        assert "missing" in caplog.text


class TestResolveBlockDocumentReferences:
    @pytest.fixture(autouse=True)
    def ignore_deprecation_warnings(self, ignore_prefect_deprecation_warnings):
        """Remove references to deprecated blocks when deprecation period is over."""
        pass

    @pytest.fixture()
    async def block_document_id(self):
        # Use unique slug and doc name to avoid conflicts in parallel tests
        unique_id = uuid.uuid4().hex[:8]
        slug = f"arbitraryblock-{unique_id}"
        doc_name = f"arbitrary-block-{unique_id}"

        # Create a unique class to avoid block registry conflicts
        ArbitraryBlock = type(
            f"ArbitraryBlock{unique_id}",
            (Block,),
            {
                "_block_type_slug": slug,
                "__annotations__": {"a": int, "b": str},
            },
        )

        block_document_id = await ArbitraryBlock(a=1, b="hello").save(
            name=doc_name, overwrite=True
        )
        return {"id": block_document_id, "slug": slug, "name": doc_name}

    async def test_resolve_block_document_references_with_no_block_document_references(
        self,
    ):
        assert await resolve_block_document_references({"key": "value"}) == {
            "key": "value"
        }

    async def test_resolve_block_document_references_with_one_block_document_reference(
        self, prefect_client, block_document_id
    ):
        assert {
            "key": {"a": 1, "b": "hello"}
        } == await resolve_block_document_references(
            {"key": {"$ref": {"block_document_id": block_document_id["id"]}}},
            client=prefect_client,
        )

    async def test_resolve_block_document_references_with_nested_block_document_references(
        self, prefect_client, block_document_id
    ):
        template = {
            "key": {
                "nested_key": {"$ref": {"block_document_id": block_document_id["id"]}},
                "other_nested_key": {
                    "$ref": {"block_document_id": block_document_id["id"]}
                },
            }
        }
        block_document = await prefect_client.read_block_document(
            block_document_id["id"]
        )

        result = await resolve_block_document_references(
            template, client=prefect_client
        )

        assert result == {
            "key": {
                "nested_key": block_document.data,
                "other_nested_key": block_document.data,
            }
        }

    async def test_resolve_block_document_references_with_list_of_block_document_references(
        self, prefect_client, block_document_id
    ):
        template = [{"$ref": {"block_document_id": block_document_id["id"]}}]
        block_document = await prefect_client.read_block_document(
            block_document_id["id"]
        )

        result = await resolve_block_document_references(
            template, client=prefect_client
        )

        assert result == [block_document.data]

    async def test_resolve_block_document_references_caches_block_document_refs_by_id(
        self,
    ):
        """Repeated block document ID references only trigger one API read."""
        block_document_id = uuid.uuid4()
        calls: list[uuid.UUID] = []

        class FakeClient:
            async def read_block_document(
                self, block_document_id: uuid.UUID
            ) -> SimpleNamespace:
                calls.append(block_document_id)
                return SimpleNamespace(data={"nested": {"value": "hello"}})

        template = {
            "first": {"$ref": {"block_document_id": block_document_id}},
            "second": {"$ref": {"block_document_id": block_document_id}},
        }

        result = await resolve_block_document_references(template, client=FakeClient())

        assert result == {
            "first": {"nested": {"value": "hello"}},
            "second": {"nested": {"value": "hello"}},
        }
        assert calls == [block_document_id]
        assert result["first"] is not result["second"]

    async def test_resolve_block_document_references_with_dot_delimited_syntax(
        self, prefect_client, block_document_id
    ):
        slug = block_document_id["slug"]
        doc_name = block_document_id["name"]
        template = {"key": f"{{{{ prefect.blocks.{slug}.{doc_name} }}}}"}

        block_document = await prefect_client.read_block_document(
            block_document_id["id"]
        )

        result = await resolve_block_document_references(
            template, client=prefect_client
        )

        assert result == {"key": block_document.data}

    async def test_resolve_block_document_references_caches_block_document_refs_by_name(
        self,
    ):
        """Repeated named block placeholders only trigger one API read."""
        calls: list[tuple[str, str]] = []

        class FakeClient:
            async def read_block_document_by_name(
                self, name: str, block_type_slug: str
            ) -> SimpleNamespace:
                calls.append((block_type_slug, name))
                return SimpleNamespace(data={"a": 1, "b": "hello"})

        template = {
            "full": "{{ prefect.blocks.arbitraryblock.my-block }}",
            "inline": "prefix-{{ prefect.blocks.arbitraryblock.my-block.b }}-suffix",
            "nested": {
                "repeat": "{{ prefect.blocks.arbitraryblock.my-block }}",
            },
        }

        result = await resolve_block_document_references(template, client=FakeClient())

        assert result == {
            "full": {"a": 1, "b": "hello"},
            "inline": "prefix-hello-suffix",
            "nested": {
                "repeat": {"a": 1, "b": "hello"},
            },
        }
        assert calls == [("arbitraryblock", "my-block")]
        assert result["full"] is not result["nested"]["repeat"]

    async def test_resolve_block_document_references_allows_inline_substitution(
        self, prefect_client, block_document_id
    ):
        slug = block_document_id["slug"]
        doc_name = block_document_id["name"]
        template = {
            "key": f"prefix-{{{{ prefect.blocks.{slug}.{doc_name}.b }}}}-suffix"
        }

        result = await resolve_block_document_references(
            template, client=prefect_client
        )

        assert result == {"key": "prefix-hello-suffix"}

    async def test_resolve_block_document_references_allows_inline_substitution_for_system_blocks(
        self, prefect_client
    ):
        secret_name = f"secret-block-{uuid.uuid4().hex[:8]}"
        await Secret(value="my-private-repo.com").save(name=secret_name, overwrite=True)

        template = {
            "key": f"{{{{ prefect.blocks.secret.{secret_name}.value }}}}/my-image-name"
        }
        result = await resolve_block_document_references(
            template, client=prefect_client
        )

        assert result == {"key": "my-private-repo.com/my-image-name"}

    async def test_resolve_block_document_references_allows_mixed_placeholders_in_string(
        self, prefect_client, block_document_id
    ):
        slug = block_document_id["slug"]
        doc_name = block_document_id["name"]
        template = {
            "key": (
                f"{{{{ standard_placeholder }}}}/{{{{ prefect.blocks.{slug}.{doc_name}.b }}}}"
            )
        }

        result = await resolve_block_document_references(
            template, client=prefect_client
        )

        # Standard placeholders should be left intact for later resolution.
        assert result == {"key": "{{ standard_placeholder }}/hello"}

    async def test_resolve_block_document_references_raises_on_inline_non_scalar_value(
        self, prefect_client, block_document_id
    ):
        slug = block_document_id["slug"]
        doc_name = block_document_id["name"]
        template = {"key": f"{{{{ prefect.blocks.{slug}.{doc_name} }}}} extra text"}

        with pytest.raises(
            ValueError,
            match="cannot be used for inline string substitution",
        ):
            await resolve_block_document_references(template, client=prefect_client)

    async def test_resolve_block_document_references_does_not_change_standard_placeholders(
        self,
    ):
        template = {"key": "{{ standard_placeholder }}"}

        result = await resolve_block_document_references(template)

        assert result == template

    async def test_resolve_block_document_resolves_block_attribute(self):
        doc_name = f"webhook-block-{uuid.uuid4().hex[:8]}"
        await Webhook(url="https://example.com").save(name=doc_name)

        template = {
            "block_attribute": f"{{{{ prefect.blocks.webhook.{doc_name}.url }}}}",
        }
        result = await resolve_block_document_references(template)

        assert result == {
            "block_attribute": "https://example.com",
        }

    async def test_resolve_block_document_references_raises_helpful_error_for_missing_block_by_name(
        self, prefect_client
    ):
        """Test that missing blocks raise helpful error messages."""
        template = {
            "block_ref": "{{ prefect.blocks.aws-credentials.nonexistent-block }}"
        }

        with pytest.raises(prefect.exceptions.ObjectNotFound) as exc_info:
            await resolve_block_document_references(template, client=prefect_client)

        error_msg = str(exc_info.value)
        assert "Block not found: 'nonexistent-block'" in error_msg
        assert "aws-credentials" in error_msg
        assert "no longer exists" in error_msg

    async def test_resolve_block_document_references_raises_helpful_error_for_missing_block_by_id(
        self, prefect_client
    ):
        """Test that missing blocks by ID raise helpful error messages."""
        import uuid

        fake_id = uuid.uuid4()
        template = {"block_ref": {"$ref": {"block_document_id": fake_id}}}

        with pytest.raises(prefect.exceptions.ObjectNotFound) as exc_info:
            await resolve_block_document_references(template, client=prefect_client)

        error_msg = str(exc_info.value)
        assert "Block not found" in error_msg
        assert str(fake_id) in error_msg
        assert "no longer exists" in error_msg


class TestResolveVariables:
    @pytest.fixture
    async def variable_1(self, prefect_client: PrefectClient):
        res = await prefect_client._client.post(
            "/variables/",
            json={"name": f"test_variable_{uuid.uuid4().hex}", "value": "test_value_1"},
        )
        return res.json()

    @pytest.fixture
    async def variable_2(self, prefect_client: PrefectClient):
        res = await prefect_client._client.post(
            "/variables/",
            json={"name": f"test_variable_{uuid.uuid4().hex}", "value": "test_value_2"},
        )
        return res.json()

    async def test_resolve_string_no_placeholders(self, prefect_client: PrefectClient):
        template = "This is a simple string."
        result = await resolve_variables(template, client=prefect_client)
        assert result == template

    async def test_resolve_string_with_standard_placeholder(
        self, variable_1, prefect_client: PrefectClient
    ):
        template = (
            "This is a string with a placeholder: {{"
            f" prefect.variables.{variable_1['name']} }}}}."
        )
        expected = "This is a string with a placeholder: test_value_1."
        result = await resolve_variables(template, client=prefect_client)
        assert result == expected

    async def test_resolve_string_with_multiple_standard_placeholders(
        self, variable_1, variable_2, prefect_client: PrefectClient
    ):
        template = (
            f"{{{{ prefect.variables.{variable_1['name']} }}}} - {{{{"
            f" prefect.variables.{variable_2['name']} }}}}"
        )
        expected = "test_value_1 - test_value_2"
        result = await resolve_variables(template, client=prefect_client)
        assert result == expected

    async def test_resolve_dict(self, variable_1, prefect_client: PrefectClient):
        template: Dict[str, Any] = {
            "key1": "value1",
            "key2": f"{{{{ prefect.variables.{variable_1['name']} }}}}",
        }
        expected = {"key1": "value1", "key2": "test_value_1"}
        result = await resolve_variables(template, client=prefect_client)
        assert result == expected

    async def test_resolve_nested_dict(
        self, variable_1, variable_2, prefect_client: PrefectClient
    ):
        template: Dict[str, Any] = {
            "key1": "value1",
            "key2": f"{{{{ prefect.variables.{variable_1['name']} }}}}",
            "key3": {"key4": f"{{{{ prefect.variables.{variable_2['name']} }}}}"},
        }
        expected = {
            "key1": "value1",
            "key2": "test_value_1",
            "key3": {"key4": "test_value_2"},
        }
        result = await resolve_variables(template, client=prefect_client)
        assert result == expected

    async def test_resolve_list(self, variable_1, prefect_client: PrefectClient):
        template = ["value1", f"{{{{ prefect.variables.{variable_1['name']} }}}}", 42]
        expected = ["value1", "test_value_1", 42]
        result = await resolve_variables(template, client=prefect_client)
        assert result == expected

    async def test_resolve_non_string_types(self, prefect_client: PrefectClient):
        template = 42
        result = await resolve_variables(template, client=prefect_client)
        assert result == template

    async def test_resolve_does_not_template_other_placeholder_types(
        self, prefect_client: PrefectClient
    ):
        template = {
            "key": "{{ another_placeholder }}",
            "key2": "{{ prefect.blocks.arbitraryblock.arbitrary-block }}",
            "key3": "{{ $another_placeholder }}",
        }
        result = await resolve_variables(template, client=prefect_client)
        assert result == template

    async def test_resolve_clears_placeholder_for_missing_variable(
        self, prefect_client: PrefectClient
    ):
        template = "{{ prefect.variables.missing_variable }}"
        result = await resolve_variables(template, client=prefect_client)
        assert result == ""

    async def test_resolve_clears_placeholders_for_missing_variables(
        self, prefect_client: PrefectClient
    ):
        template = (
            "{{ prefect.variables.missing_variable_1 }} - {{"
            " prefect.variables.missing_variable_2 }}"
        )
        result = await resolve_variables(template, client=prefect_client)
        assert result == " - "

    async def test_resolve_caches_variable_reads_within_single_call(self):
        """Repeated variable placeholders only trigger one API read per name."""
        from unittest.mock import AsyncMock

        from prefect.client.schemas.objects import Variable

        calls: list[str] = []
        existing_var = Variable(
            name="my_var",
            value={"key": "val"},
            tags=[],
        )

        async def fake_read_variable_by_name(name: str) -> Variable | None:
            calls.append(name)
            if name == "my_var":
                return existing_var
            return None

        fake_client = AsyncMock()
        fake_client.read_variable_by_name = fake_read_variable_by_name

        template: Dict[str, Any] = {
            "full": "{{ prefect.variables.my_var }}",
            "inline": "prefix-{{ prefect.variables.my_var }}-suffix",
            "missing_full": "{{ prefect.variables.gone }}",
            "missing_inline": "x{{ prefect.variables.gone }}y",
            "nested": {
                "repeat": "{{ prefect.variables.my_var }}",
                "other": "{{ prefect.variables.gone }}",
            },
        }

        result = await resolve_variables(template, client=fake_client)

        assert result == {
            "full": {"key": "val"},
            "inline": "prefix-{'key': 'val'}-suffix",
            "missing_full": "",
            "missing_inline": "xy",
            "nested": {
                "repeat": {"key": "val"},
                "other": "",
            },
        }

        assert calls.count("my_var") == 1
        assert calls.count("gone") == 1
        assert len(calls) == 2


class TestInvalidBlockPlaceholderValidation:
    """Tests for clear error messages on malformed block placeholder format."""

    def test_find_prefect_placeholders_detects_malformed_block(self):
        """Malformed block placeholder (missing document name) is still parsed."""

        placeholders = find_placeholders("{{ prefect.blocks.my-block }}")
        assert len(placeholders) > 0

    async def test_resolve_block_document_references_raises_on_malformed_placeholder(
        self,
    ):
        """Malformed block placeholder raises ValueError with actionable message."""

        with pytest.raises(ValueError, match="Invalid block placeholder format"):
            await resolve_block_document_references(
                {"key": "{{ prefect.blocks.only-type }}"}
            )
