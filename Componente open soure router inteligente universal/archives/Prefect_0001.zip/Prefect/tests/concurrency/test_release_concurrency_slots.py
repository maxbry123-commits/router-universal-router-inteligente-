import uuid
from unittest import mock

import pytest
from httpx import Response

from prefect.client.schemas.responses import MinimalConcurrencyLimitResponse
from prefect.concurrency._asyncio import arelease_concurrency_slots

pytestmark = pytest.mark.clear_db


async def test_calls_release_client_method():
    limits = [
        MinimalConcurrencyLimitResponse(id=uuid.uuid4(), name=f"test-{i}", limit=i)
        for i in range(1, 3)
    ]

    with mock.patch(
        "prefect.client.orchestration.PrefectClient.release_concurrency_slots"
    ) as client_release_concurrency_slots:
        response = Response(
            200, json=[limit.model_dump(mode="json") for limit in limits]
        )
        client_release_concurrency_slots.return_value = response

        await arelease_concurrency_slots(
            names=["test-1", "test-2"], slots=1, occupancy_seconds=1.0
        )
        client_release_concurrency_slots.assert_called_once_with(
            names=["test-1", "test-2"],
            slots=1,
            occupancy_seconds=1.0,
        )


async def test_returns_minimal_concurrency_limit():
    limits = [
        MinimalConcurrencyLimitResponse(id=uuid.uuid4(), name=f"test-{i}", limit=i)
        for i in range(1, 3)
    ]

    with mock.patch(
        "prefect.client.orchestration.PrefectClient.release_concurrency_slots"
    ) as client_release_concurrency_slots:
        response = Response(
            200, json=[limit.model_dump(mode="json") for limit in limits]
        )
        client_release_concurrency_slots.return_value = response

        result = await arelease_concurrency_slots(["test-1", "test-2"], 1, 1.0)
        assert result == limits
