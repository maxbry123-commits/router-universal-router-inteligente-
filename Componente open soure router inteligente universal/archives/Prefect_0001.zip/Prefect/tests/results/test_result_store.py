import uuid
from datetime import timedelta
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

import prefect.exceptions
import prefect.results
import prefect.types._datetime
from prefect import flow, task
from prefect.client.base import ServerType
from prefect.client.schemas.objects import ServerDefaultResultStorage
from prefect.context import FlowRunContext, get_run_context
from prefect.filesystems import LocalFileSystem, WritableFileSystem
from prefect.locking.memory import MemoryLockManager
from prefect.results import (
    ResultRecord,
    ResultStore,
    _get_default_persist_result,
    _result_storage_is_configured_for_remote_retrieval,
    should_persist_result,
)
from prefect.serializers import JSONSerializer, PickleSerializer
from prefect.settings import (
    PREFECT_DEFAULT_RESULT_STORAGE_BLOCK,
    PREFECT_LOCAL_STORAGE_PATH,
    PREFECT_RESULTS_DEFAULT_SERIALIZER,
    PREFECT_RESULTS_PERSIST_BY_DEFAULT,
    PREFECT_TASKS_DEFAULT_PERSIST_RESULT,
    temporary_settings,
)
from prefect.testing.utilities import assert_blocks_equal
from prefect.transactions import IsolationLevel

DEFAULT_SERIALIZER = PickleSerializer


def DEFAULT_STORAGE():
    return LocalFileSystem(basepath=PREFECT_LOCAL_STORAGE_PATH.value())


@pytest.fixture
def default_persistence_off():
    """
    Many tests return result factories, which aren't serialiable.
    When we switched the default persistence setting to True, this caused tests to fail.
    """
    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: False}):
        yield


@pytest.fixture
async def store(prefect_client):
    return ResultStore()


async def test_create_result_record(store):
    record = store.create_result_record({"foo": "bar"})
    assert isinstance(record, ResultRecord)
    assert record.metadata.serializer.type == store.serializer.type
    assert record.metadata.storage_block_id == store.result_storage_block_id
    assert record.result == {"foo": "bar"}


def test_root_flow_default_result_store():
    @flow
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is False
    assert result_store.cache_result_in_memory is True
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())
    assert result_store.result_storage_block_id is None


def test_root_flow_default_result_serializer_can_be_overriden_by_setting():
    @flow(persist_result=False)
    def foo():
        return get_run_context().result_store

    with temporary_settings({PREFECT_RESULTS_DEFAULT_SERIALIZER: "json"}):
        result_store = foo()
    assert result_store.serializer == JSONSerializer()


def test_root_flow_default_persist_result_can_be_overriden_by_setting():
    @flow
    def foo():
        return should_persist_result()

    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
        persist_result = foo()
    assert persist_result is True


def test_root_flow_can_opt_out_when_persist_result_default_is_overriden_by_setting():
    @flow(persist_result=False)
    def foo():
        return should_persist_result()

    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
        persist_result = foo()

    assert persist_result is False


@pytest.mark.parametrize("toggle", [True, False])
def test_root_flow_custom_persist_setting(toggle):
    @flow(persist_result=toggle)
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is toggle
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())


def test_root_flow_persists_results_when_flow_uses_feature():
    @flow(cache_result_in_memory=False, persist_result=True)
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is True
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())


def test_root_flow_can_opt_out_of_persistence_when_flow_uses_feature():
    result_store = None
    persist_result = None

    @flow(cache_result_in_memory=False, persist_result=False)
    def foo():
        nonlocal result_store
        nonlocal persist_result
        persist_result = should_persist_result()
        result_store = get_run_context().result_store

    foo()
    assert persist_result is False
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())
    assert result_store.result_storage_block_id is None


@pytest.mark.parametrize("toggle", [True, False])
def test_root_flow_custom_cache_setting(toggle, default_persistence_off):
    result_store = None

    @flow(cache_result_in_memory=toggle)
    def foo():
        nonlocal result_store
        result_store = get_run_context().result_store

    foo()
    assert result_store.cache_result_in_memory is toggle
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())


def test_root_flow_custom_serializer_by_type_string():
    @flow(result_serializer="json", persist_result=False)
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is False
    assert result_store.serializer == JSONSerializer()
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())
    assert result_store.result_storage_block_id is None


def test_root_flow_custom_serializer_by_instance(default_persistence_off):
    @flow(persist_result=False, result_serializer=JSONSerializer(jsonlib="orjson"))
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is False
    assert result_store.serializer == JSONSerializer(jsonlib="orjson")
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())
    assert result_store.result_storage_block_id is None


async def test_root_flow_custom_storage_by_slug(tmp_path, default_persistence_off):
    storage = LocalFileSystem(basepath=tmp_path / "test")
    block_name = f"test-{uuid.uuid4()}"
    storage_id = await storage.save(block_name)

    @flow(result_storage=f"local-file-system/{block_name}")
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is True  # inferred from the storage
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(result_store.result_storage, storage)
    assert result_store.result_storage_block_id == storage_id


async def test_root_flow_custom_storage_by_instance_presaved(
    tmp_path, default_persistence_off
):
    storage = LocalFileSystem(basepath=tmp_path / "test")
    block_name = f"test-{uuid.uuid4()}"
    storage_id = await storage.save(block_name)

    @flow(result_storage=storage)
    def foo():
        return get_run_context().result_store, should_persist_result()

    result_store, persist_result = foo()
    assert persist_result is True  # inferred from the storage
    assert result_store.serializer == DEFAULT_SERIALIZER()
    assert result_store.result_storage == storage
    assert result_store.result_storage._is_anonymous is False
    assert result_store.result_storage_block_id == storage_id


def test_child_flow_inherits_default_result_settings(default_persistence_off):
    @flow
    def foo():
        child_store, persist_result = bar()
        return child_store, persist_result

    @flow
    def bar():
        return get_run_context().result_store, should_persist_result()

    child_store, persist_result = foo()
    assert persist_result is False
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(child_store.result_storage, DEFAULT_STORAGE())
    assert child_store.result_storage_block_id is None


def test_child_flow_default_result_serializer_can_be_overriden_by_setting(
    default_persistence_off,
):
    @flow
    def foo():
        return get_run_context().result_store, bar()

    @flow
    def bar():
        return get_run_context().result_store

    with temporary_settings({PREFECT_RESULTS_DEFAULT_SERIALIZER: "json"}):
        _, child_store = foo()

    assert child_store.serializer == JSONSerializer()


def test_child_flow_default_persist_result_can_be_overriden_by_setting():
    @flow
    def foo():
        return bar()

    @flow
    def bar():
        return get_run_context().result_store, should_persist_result()

    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
        child_store, persist_result = foo()

    assert persist_result is True


def test_child_flow_can_opt_out_when_persist_result_default_is_overriden_by_setting():
    @flow
    def foo():
        return bar()

    @flow(persist_result=False)
    def bar():
        return get_run_context().result_store, should_persist_result()

    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
        child_store, persist_result = foo()

    assert persist_result is False


def test_child_flow_custom_persist_setting(default_persistence_off):
    @flow
    def foo():
        child_store, persist_result = bar()
        return (
            get_run_context().result_store,
            should_persist_result(),
            child_store,
            persist_result,
        )

    @flow(persist_result=True)
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, parent_persist_result, child_store, child_persist_result = foo()
    assert parent_persist_result is False
    assert child_persist_result is True
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(child_store.result_storage, DEFAULT_STORAGE())


@pytest.mark.parametrize("toggle", [True, False])
def test_child_flow_custom_cache_setting(toggle, default_persistence_off):
    child_store = None

    @flow
    def foo():
        bar(return_state=True)
        return get_run_context().result_store

    @flow(cache_result_in_memory=toggle)
    def bar():
        nonlocal child_store
        child_store = get_run_context().result_store

    parent_store = foo()
    assert parent_store.cache_result_in_memory is True
    assert child_store.cache_result_in_memory is toggle
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(child_store.result_storage, DEFAULT_STORAGE())


def test_child_flow_can_opt_out_of_result_persistence_when_parent_uses_feature(
    default_persistence_off,
):
    @flow(retries=3)
    def foo():
        child_store, child_persist_result = bar()
        return (
            get_run_context().result_store,
            should_persist_result(),
            child_persist_result,
            child_store,
        )

    @flow(persist_result=False)
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, parent_persist_result, child_persist_result, child_store = foo()
    assert parent_persist_result is False
    assert child_persist_result is False
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(child_store.result_storage, DEFAULT_STORAGE())
    assert child_store.result_storage_block_id is None


def test_child_flow_inherits_custom_serializer(default_persistence_off):
    @flow(persist_result=False, result_serializer="json")
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @flow(persist_result=False, result_serializer="json")
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, child_persist_result, child_store = foo()
    assert child_persist_result is False
    assert child_store.serializer == parent_store.serializer
    assert_blocks_equal(child_store.result_storage, DEFAULT_STORAGE())
    assert child_store.result_storage_block_id is None


async def test_child_flow_inherits_custom_storage(tmp_path, default_persistence_off):
    storage = LocalFileSystem(basepath=tmp_path / "test")
    block_name = f"test-{uuid.uuid4()}"
    storage_id = await storage.save(block_name)

    @flow(result_storage=f"local-file-system/{block_name}")
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @flow
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, child_persist_result, child_store = foo()
    assert child_persist_result is True
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert child_store.result_storage == parent_store.result_storage
    assert child_store.result_storage_block_id == storage_id


async def test_child_flow_custom_storage(tmp_path, default_persistence_off):
    storage = LocalFileSystem(basepath=tmp_path / "test")
    block_name = f"test-{uuid.uuid4()}"
    storage_id = await storage.save(block_name)

    @flow()
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @flow(result_storage=f"local-file-system/{block_name}")
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, child_persist_result, child_store = foo()
    assert_blocks_equal(parent_store.result_storage, DEFAULT_STORAGE())
    assert child_persist_result is True  # inferred from the storage
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(child_store.result_storage, storage)
    assert child_store.result_storage_block_id == storage_id


def test_task_inherits_default_result_settings():
    @flow
    def foo():
        return bar()

    @task
    def bar():
        return get_run_context().result_store, should_persist_result()

    task_store, task_persist_result = foo()
    assert task_persist_result is False
    assert task_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(task_store.result_storage, DEFAULT_STORAGE())
    assert task_store.result_storage_block_id is None


def test_task_default_result_serializer_can_be_overriden_by_setting():
    @task(persist_result=False)
    def bar():
        return get_run_context().result_store

    with temporary_settings({PREFECT_RESULTS_DEFAULT_SERIALIZER: "json"}):
        task_store = bar()

    assert task_store.serializer == JSONSerializer()


def test_task_default_persist_result_can_be_overriden_by_setting():
    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):

        @flow
        def foo():
            return bar()

        @task
        def bar():
            return should_persist_result()

        persist_result = foo()

    assert persist_result is True

    with temporary_settings({PREFECT_TASKS_DEFAULT_PERSIST_RESULT: True}):
        persist_result = bar()

    assert persist_result is True


async def test_task_can_opt_out_of_result_persistence_with_setting():
    with temporary_settings({PREFECT_TASKS_DEFAULT_PERSIST_RESULT: True}):

        @task(persist_result=False)
        def bar():
            return should_persist_result()

        persist_result = bar()
        assert persist_result is False

        async def abar():
            return should_persist_result()

        persist_result = await abar()
        assert persist_result is False


async def test_can_opt_out_of_result_persistence_with_setting_when_flow_uses_feature():
    with temporary_settings({PREFECT_TASKS_DEFAULT_PERSIST_RESULT: False}):

        @flow(persist_result=True)
        def foo():
            return bar()

        @task
        def bar():
            return should_persist_result()

        persist_result = foo()

        assert persist_result is False

        @flow(persist_result=True)
        async def afoo():
            return await abar()

        @task
        async def abar():
            return should_persist_result()

        persist_result = await afoo()
        assert persist_result is False


def test_nested_flow_custom_persist_setting():
    @flow(persist_result=True)
    def foo():
        child_store, child_persist_result = bar()
        return should_persist_result(), child_persist_result, child_store

    @flow(persist_result=False)
    def bar():
        return get_run_context().result_store, should_persist_result()

    flow_persist_result, task_persist_result, task_store = foo()
    assert flow_persist_result is True
    assert task_persist_result is False
    assert task_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(task_store.result_storage, DEFAULT_STORAGE())
    assert task_store.result_storage_block_id is None


@pytest.mark.parametrize("toggle", [True, False])
def test_task_custom_cache_setting(toggle):
    task_store = None

    @flow
    def foo():
        bar()
        return get_run_context().result_store

    @task(cache_result_in_memory=toggle)
    def bar():
        nonlocal task_store
        task_store = get_run_context().result_store

    flow_store = foo()
    assert flow_store.cache_result_in_memory is True
    assert task_store.cache_result_in_memory is toggle
    assert task_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(task_store.result_storage, DEFAULT_STORAGE())


def test_task_can_opt_out_of_result_persistence_when_flow_uses_feature(
    default_persistence_off,
):
    @flow(retries=3)
    def foo():
        child_store, child_persist_result = bar()
        return should_persist_result(), child_persist_result, child_store

    @flow(persist_result=False)
    def bar():
        return get_run_context().result_store, should_persist_result()

    flow_persist_result, task_persist_result, task_store = foo()
    assert flow_persist_result is False
    assert task_persist_result is False
    assert task_store.serializer == DEFAULT_SERIALIZER()
    assert_blocks_equal(task_store.result_storage, DEFAULT_STORAGE())
    assert task_store.result_storage_block_id is None


def test_task_can_opt_out_when_persist_result_default_is_overriden_by_setting():
    @flow
    def foo():
        return bar()

    @task(persist_result=False)
    def bar():
        return should_persist_result()

    with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
        persist_result = foo()

    assert persist_result is False


def test_task_inherits_custom_serializer(default_persistence_off):
    @flow(result_serializer="json", persist_result=False)
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @flow()
    def bar():
        return get_run_context().result_store, should_persist_result()

    flow_store, task_persist_result, task_store = foo()
    assert task_persist_result is False
    assert task_store.serializer == flow_store.serializer
    assert_blocks_equal(task_store.result_storage, DEFAULT_STORAGE())
    assert task_store.result_storage_block_id is None


async def test_task_inherits_custom_storage(tmp_path):
    storage = LocalFileSystem(basepath=tmp_path / "test")
    block_name = f"test-{uuid.uuid4()}"
    storage_id = await storage.save(block_name)

    @flow(result_storage=f"local-file-system/{block_name}", persist_result=True)
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @task(persist_result=True)
    def bar():
        return get_run_context().result_store, should_persist_result()

    flow_store, task_persist_result, task_store = foo()
    assert task_persist_result is True
    assert task_store.serializer == DEFAULT_SERIALIZER()
    assert task_store.result_storage == flow_store.result_storage
    assert task_store.result_storage_block_id == storage_id


def test_task_custom_serializer(default_persistence_off):
    @flow
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @flow(result_serializer="json", persist_result=False)
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, child_persist_result, child_store = foo()
    assert parent_store.serializer == DEFAULT_SERIALIZER()
    assert child_persist_result is False
    assert child_store.serializer == JSONSerializer()
    assert_blocks_equal(child_store.result_storage, DEFAULT_STORAGE())
    assert child_store.result_storage_block_id is None


async def test_nested_flow_custom_storage(tmp_path):
    storage = LocalFileSystem(basepath=tmp_path / "test")
    block_name = f"test-{uuid.uuid4()}"
    storage_id = await storage.save(block_name)

    @flow(persist_result=True)
    def foo():
        child_store, child_persist_result = bar()
        return get_run_context().result_store, child_persist_result, child_store

    @flow(result_storage=f"local-file-system/{block_name}", persist_result=True)
    def bar():
        return get_run_context().result_store, should_persist_result()

    parent_store, child_persist_result, child_store = foo()
    assert_blocks_equal(parent_store.result_storage, DEFAULT_STORAGE())
    assert_blocks_equal(child_store.result_storage, storage)
    assert child_persist_result is True
    assert child_store.serializer == DEFAULT_SERIALIZER()
    assert child_store.result_storage_block_id == storage_id


async def _verify_default_storage_creation_with_persistence(
    prefect_client,
    result_store: prefect.results.ResultStore,
):
    # check that the default block was created
    assert result_store.result_storage is not None
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())

    # verify storage settings are correctly set
    assert result_store.result_storage_block_id is None


async def _verify_default_storage_creation_without_persistence(
    result_store: prefect.results.ResultStore,
):
    # check that the default block was created
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())

    # verify storage settings are correctly set
    assert result_store.result_storage_block_id is None


async def test_default_storage_creation_for_flow_with_persistence_features(
    prefect_client,
):
    @flow(persist_result=True)
    def foo():
        return get_run_context().result_store

    result_store = foo()
    await _verify_default_storage_creation_with_persistence(
        prefect_client, result_store
    )


async def test_default_storage_creation_for_flow_without_persistence_features():
    @flow(persist_result=False)
    def foo():
        return get_run_context().result_store

    result_store = foo()
    await _verify_default_storage_creation_without_persistence(result_store)


async def test_default_storage_creation_for_task_with_persistence_features(
    prefect_client,
):
    @task(persist_result=True)
    def my_task_1():
        return get_run_context().result_store

    @flow(retries=2, persist_result=True)
    def my_flow_1():
        return my_task_1()

    result_store = my_flow_1()
    await _verify_default_storage_creation_with_persistence(
        prefect_client, result_store
    )

    @task(cache_key_fn=lambda *_: "always", persist_result=True)
    def my_task_2():
        return get_run_context().result_store

    @flow(persist_result=True)
    def my_flow_2():
        return my_task_2()

    result_store = my_flow_2()
    await _verify_default_storage_creation_with_persistence(
        prefect_client, result_store
    )


async def test_default_storage_creation_for_task_without_persistence_features():
    @task(persist_result=False)
    def my_task():
        return get_run_context().result_store

    @flow()
    def my_flow():
        return my_task()

    result_store = my_flow()
    await _verify_default_storage_creation_without_persistence(result_store)


@pytest.mark.parametrize(
    "options,expected",
    [
        (
            {
                "persist_result": True,
                "cache_result_in_memory": False,
                "result_serializer": "json",
            },
            {
                "persist_result": True,
                "cache_result_in_memory": False,
                "serializer": JSONSerializer(),
            },
        ),
        (
            {
                "persist_result": False,
                "cache_result_in_memory": True,
                "result_serializer": "json",
            },
            {
                "persist_result": False,
                "cache_result_in_memory": True,
                "serializer": JSONSerializer(),
            },
        ),
    ],
)
async def test_result_store_from_task_with_no_flow_run_context(options, expected):
    @task(**options)
    def my_task():
        pass

    assert FlowRunContext.get() is None

    result_store = await ResultStore().update_for_task(task=my_task)

    assert result_store.cache_result_in_memory == expected["cache_result_in_memory"]
    assert result_store.serializer == expected["serializer"]
    assert_blocks_equal(result_store.result_storage, DEFAULT_STORAGE())


@pytest.mark.parametrize("persist_result", [True, False])
async def test_result_store_from_task_loads_persist_result_from_flow_store(
    persist_result,
):
    @task
    def my_task():
        return should_persist_result()

    @flow(persist_result=persist_result)
    def foo():
        return my_task()

    persist_result = foo()

    assert persist_result is persist_result


@pytest.mark.parametrize("persist_result", [True, False])
async def test_result_store_from_task_takes_precedence_from_task(persist_result):
    @task(persist_result=persist_result)
    def my_task():
        return should_persist_result()

    @flow(persist_result=not persist_result)
    def foo():
        return my_task()

    persist_result = foo()

    assert persist_result is persist_result


async def test_result_store_read_and_write_with_metadata_storage(tmp_path):
    metadata_storage = LocalFileSystem(basepath=tmp_path / "metadata")
    result_storage = LocalFileSystem(basepath=tmp_path / "results")
    result_store = ResultStore(
        metadata_storage=metadata_storage, result_storage=result_storage
    )

    key = "test"
    value = "test"
    await result_store.awrite(key=key, obj=value)
    read_value = await result_store.aread(key=key)
    assert read_value.result == value

    # Check that the result is written to the result storage
    assert (
        result_store.serializer.loads((tmp_path / "results" / key).read_bytes())
        == value
    )

    # Check that the metadata is written to the metadata storage
    assert (
        tmp_path / "metadata" / key
    ).read_text() == read_value.metadata.model_dump_json(serialize_as_any=True)


async def test_result_store_exists_with_metadata_storage(tmp_path):
    metadata_storage = LocalFileSystem(basepath=tmp_path / "metadata")
    result_storage = LocalFileSystem(basepath=tmp_path / "results")
    result_store = ResultStore(
        metadata_storage=metadata_storage, result_storage=result_storage
    )

    key = "test"
    value = "test"
    await result_store.awrite(key=key, obj=value)

    assert await result_store.aexists(key=key)
    assert not await result_store.aexists(key="nonexistent")
    assert result_store.exists(key=key)
    assert not result_store.exists(key="nonexistent")

    # Remove the metadata file and check that the result is not found
    (tmp_path / "metadata" / key).unlink()
    assert not await result_store.aexists(key=key)
    assert not result_store.exists(key=key)


async def test_default_result_store_exists_resolves_default_storage(tmp_path: Path):
    with temporary_settings({PREFECT_LOCAL_STORAGE_PATH: tmp_path}):
        writer = ResultStore()
        writer.write(obj="test", key="test")

        reader = ResultStore()

        assert reader.exists(key="test")
        assert await reader.aexists(key="test")


async def test_result_store_exists_with_no_metadata_storage(tmp_path):
    result_storage = LocalFileSystem(basepath=tmp_path / "results")
    result_store = ResultStore(result_storage=result_storage)

    key = "test"
    value = "test"
    await result_store.awrite(key=key, obj=value)
    assert await result_store.aexists(key=key)
    assert result_store.exists(key=key)

    # Remove the result file and check that the result is not found
    (tmp_path / "results" / key).unlink()
    assert not await result_store.aexists(key=key)
    assert not result_store.exists(key=key)


async def test_supports_isolation_level():
    store_with_lock_manager = ResultStore(lock_manager=MemoryLockManager())
    store_without_lock_manager = ResultStore()

    assert store_with_lock_manager.supports_isolation_level(
        IsolationLevel.READ_COMMITTED
    )
    assert store_with_lock_manager.supports_isolation_level(IsolationLevel.SERIALIZABLE)

    assert store_without_lock_manager.supports_isolation_level(
        IsolationLevel.READ_COMMITTED
    )
    assert not store_without_lock_manager.supports_isolation_level(
        IsolationLevel.SERIALIZABLE
    )


class TestInMemoryCacheExpiration:
    """Tests for in-memory cache expiration in ResultStore._read and _aread."""

    async def test_read_returns_cached_result_before_expiration(self, tmp_path):
        result_storage = LocalFileSystem(basepath=tmp_path)
        store = ResultStore(result_storage=result_storage, cache_result_in_memory=True)

        key = "test-not-expired"
        expiration = prefect.types._datetime.now("UTC") + timedelta(seconds=60)
        record = store.create_result_record(
            "cached_value", key=key, expiration=expiration
        )
        store.persist_result_record(record)

        # Warm the in-memory cache
        first_read = store.read(key=key)
        assert first_read.result == "cached_value"

        # Second read should still return from cache (not expired)
        second_read = store.read(key=key)
        assert second_read.result == "cached_value"

    async def test_read_evicts_expired_result_from_cache(self, tmp_path, advance_time):
        result_storage = LocalFileSystem(basepath=tmp_path)
        store = ResultStore(result_storage=result_storage, cache_result_in_memory=True)

        key = "test-expired"
        expiration = prefect.types._datetime.now("UTC") + timedelta(seconds=1)
        record = store.create_result_record("old_value", key=key, expiration=expiration)
        store.persist_result_record(record)

        # Warm the in-memory cache
        first_read = store.read(key=key)
        assert first_read.result == "old_value"

        resolved_key = store._resolved_key_path(key)
        assert resolved_key in store.cache

        # Advance time past expiration
        advance_time(timedelta(seconds=2))

        # Write a new value to storage to simulate re-execution
        new_record = store.create_result_record("new_value", key=key)
        store.persist_result_record(new_record)

        # Read should evict expired entry and return from storage
        result = store.read(key=key)
        assert result.result == "new_value"

        # The expired entry should have been evicted from cache
        # and the new value should now be cached
        assert resolved_key in store.cache
        assert store.cache[resolved_key].result == "new_value"

    async def test_aread_evicts_expired_result_from_cache(self, tmp_path, advance_time):
        result_storage = LocalFileSystem(basepath=tmp_path)
        store = ResultStore(result_storage=result_storage, cache_result_in_memory=True)

        key = "test-expired-async"
        expiration = prefect.types._datetime.now("UTC") + timedelta(seconds=1)
        record = store.create_result_record("old_value", key=key, expiration=expiration)
        await store.apersist_result_record(record)

        # Warm the in-memory cache
        first_read = await store.aread(key=key)
        assert first_read.result == "old_value"

        resolved_key = store._resolved_key_path(key)
        assert resolved_key in store.cache

        # Advance time past expiration
        advance_time(timedelta(seconds=2))

        # Write a new value to storage
        new_record = store.create_result_record("new_value", key=key)
        await store.apersist_result_record(new_record)

        # Async read should evict expired entry and return from storage
        result = await store.aread(key=key)
        assert result.result == "new_value"

    async def test_read_returns_result_with_no_expiration(self, tmp_path):
        """Results without expiration should always be returned from cache."""
        result_storage = LocalFileSystem(basepath=tmp_path)
        store = ResultStore(result_storage=result_storage, cache_result_in_memory=True)

        key = "test-no-expiration"
        record = store.create_result_record("permanent_value", key=key)
        store.persist_result_record(record)

        # Warm the in-memory cache
        first_read = store.read(key=key)
        assert first_read.result == "permanent_value"
        assert first_read.metadata.expiration is None

        # Should still return from cache (no expiration means never expires)
        second_read = store.read(key=key)
        assert second_read.result == "permanent_value"


class TestAsyncDispatch:
    """Tests for async_dispatch behavior of ResultStore methods."""

    async def test_update_for_flow_dispatches_to_async_in_async_context(self):
        """Test that update_for_flow dispatches to aupdate_for_flow in async context."""

        @flow
        async def my_flow():
            pass

        store = ResultStore()
        # In async context, calling update_for_flow should return a coroutine
        result = store.update_for_flow(my_flow)
        # Should be a coroutine that we can await
        assert hasattr(result, "__await__")
        updated_store = await result
        assert isinstance(updated_store, ResultStore)

    async def test_update_for_task_dispatches_to_async_in_async_context(self):
        """Test that update_for_task dispatches to aupdate_for_task in async context."""

        @task
        async def my_task():
            pass

        store = ResultStore()
        # In async context, calling update_for_task should return a coroutine
        result = store.update_for_task(my_task)
        # Should be a coroutine that we can await
        assert hasattr(result, "__await__")
        updated_store = await result
        assert isinstance(updated_store, ResultStore)

    def test_update_for_flow_returns_sync_in_sync_context(self):
        """Test that update_for_flow returns directly in sync context."""

        @flow
        def my_flow():
            pass

        store = ResultStore()
        # In sync context, calling update_for_flow should return directly
        result = store.update_for_flow(my_flow)
        # Should not be a coroutine
        assert not hasattr(result, "__await__")
        assert isinstance(result, ResultStore)

    def test_update_for_task_returns_sync_in_sync_context(self):
        """Test that update_for_task returns directly in sync context."""

        @task
        def my_task():
            pass

        store = ResultStore()
        # In sync context, calling update_for_task should return directly
        result = store.update_for_task(my_task)
        # Should not be a coroutine
        assert not hasattr(result, "__await__")
        assert isinstance(result, ResultStore)


class TestDefaultResultStorageResolution:
    @pytest.fixture(autouse=True)
    def clear_default_storage_cache(self):
        prefect.results._default_storages.clear()
        yield
        prefect.results._default_storages.clear()

    @pytest.mark.parametrize("server_type", [ServerType.SERVER, ServerType.CLOUD])
    def test_uses_server_default_result_storage_sync(
        self, monkeypatch: pytest.MonkeyPatch, server_type: ServerType
    ):
        block_document_id = uuid.uuid4()
        expected_storage = MagicMock(spec=WritableFileSystem)
        client = MagicMock()
        client.server_type = server_type
        client.read_server_default_result_storage = MagicMock(
            return_value=ServerDefaultResultStorage(
                default_result_storage_block_id=block_document_id
            )
        )

        monkeypatch.setattr(
            "prefect.client.orchestration.get_client", lambda **_: client
        )
        monkeypatch.setattr(
            "prefect.results.resolve_result_storage",
            MagicMock(return_value=expected_storage),
        )

        storage = prefect.results.get_default_result_storage()

        assert storage is expected_storage

    def test_should_persist_result_does_not_read_server_default_storage(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setattr(
            "prefect.results._read_server_default_result_storage_block_id",
            MagicMock(side_effect=AssertionError("server default should not be read")),
        )

        assert should_persist_result() is False

    def test_configured_default_result_storage_enables_default_persistence(self):
        with temporary_settings(
            {PREFECT_DEFAULT_RESULT_STORAGE_BLOCK: "local-file-system/my-results"}
        ):
            assert _get_default_persist_result() is True

    def test_block_backed_storage_does_not_enable_default_persistence_by_itself(self):
        storage = LocalFileSystem(basepath="/tmp/results")
        storage._block_document_id = uuid.uuid4()
        result_store = ResultStore(result_storage=storage)

        assert result_store.result_storage_block_id == storage._block_document_id
        assert _get_default_persist_result() is False

    async def test_configured_default_result_storage_does_not_override_parent_opt_out(
        self, tmp_path: Path
    ):
        block_name = f"parent-result-storage-{uuid.uuid4()}"
        await LocalFileSystem(basepath=str(tmp_path)).save(block_name)

        @task
        def my_task():
            return should_persist_result()

        @flow(
            persist_result=False,
            result_storage=f"local-file-system/{block_name}",
        )
        def my_flow():
            return my_task()

        with temporary_settings(
            {PREFECT_DEFAULT_RESULT_STORAGE_BLOCK: "local-file-system/my-results"}
        ):
            assert my_flow() is False

    def test_local_persist_setting_does_not_need_default_result_storage(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setattr(
            "prefect.results._read_server_default_result_storage_block_id",
            MagicMock(side_effect=AssertionError("server default should not be read")),
        )

        with temporary_settings({PREFECT_RESULTS_PERSIST_BY_DEFAULT: True}):
            assert should_persist_result() is True

    def test_task_default_persistence_does_not_read_default_result_storage(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        monkeypatch.setattr(
            "prefect.results._read_server_default_result_storage_block_id",
            MagicMock(side_effect=AssertionError("server default should not be read")),
        )

        assert prefect.results.get_default_persist_setting_for_tasks() is False

    def test_explicit_task_persistence_setting_overrides_default_persistence(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setattr(
            "prefect.results._read_server_default_result_storage_block_id",
            MagicMock(side_effect=AssertionError("server default should not be read")),
        )

        with temporary_settings(
            {
                PREFECT_RESULTS_PERSIST_BY_DEFAULT: True,
                PREFECT_TASKS_DEFAULT_PERSIST_RESULT: False,
            }
        ):
            assert prefect.results.get_default_persist_setting_for_tasks() is False

    def test_local_default_result_storage_is_resolved_before_enabling_persistence(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        read_server_default = MagicMock(
            side_effect=AssertionError("server default should not be read")
        )
        monkeypatch.setattr(
            "prefect.results._read_server_default_result_storage_block_id",
            read_server_default,
        )

        with temporary_settings(
            {PREFECT_DEFAULT_RESULT_STORAGE_BLOCK: "local-file-system/my-results"}
        ):
            assert should_persist_result() is False

    @pytest.mark.parametrize("server_type", [ServerType.SERVER, ServerType.CLOUD])
    async def test_uses_server_default_result_storage_async(
        self, monkeypatch: pytest.MonkeyPatch, server_type: ServerType
    ):
        block_document_id = uuid.uuid4()
        expected_storage = MagicMock(spec=WritableFileSystem)
        client = MagicMock()
        client.server_type = server_type
        client.read_server_default_result_storage = AsyncMock(
            return_value=ServerDefaultResultStorage(
                default_result_storage_block_id=block_document_id
            )
        )

        monkeypatch.setattr(
            "prefect.client.orchestration.get_client", lambda **_: client
        )
        monkeypatch.setattr(
            "prefect.results.aresolve_result_storage",
            AsyncMock(return_value=expected_storage),
        )

        storage = await prefect.results.aget_default_result_storage()

        assert storage is expected_storage

    def test_falls_back_to_local_storage_when_server_default_cannot_be_read_sync(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ):
        monkeypatch.setattr(
            "prefect.client.orchestration.get_client",
            MagicMock(side_effect=ValueError("No Prefect API URL provided")),
        )
        monkeypatch.setattr(
            "prefect.results.resolve_result_storage",
            MagicMock(side_effect=AssertionError("should not be called")),
        )

        with temporary_settings({PREFECT_LOCAL_STORAGE_PATH: tmp_path}):
            storage = prefect.results.get_default_result_storage()

        assert isinstance(storage, LocalFileSystem)
        assert storage.basepath == str(tmp_path)

    async def test_falls_back_to_local_storage_when_server_default_cannot_be_read_async(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ):
        monkeypatch.setattr(
            "prefect.client.orchestration.get_client",
            MagicMock(side_effect=ValueError("No Prefect API URL provided")),
        )
        monkeypatch.setattr(
            "prefect.results.aresolve_result_storage",
            AsyncMock(side_effect=AssertionError("should not be called")),
        )

        with temporary_settings({PREFECT_LOCAL_STORAGE_PATH: tmp_path}):
            storage = await prefect.results.aget_default_result_storage()

        assert isinstance(storage, LocalFileSystem)
        assert storage.basepath == str(tmp_path)


class TestRemoteResultStorageConfiguration:
    def test_returns_true_for_explicit_flow_storage(self, tmp_path: Path):
        explicit_storage = tmp_path / "explicit"
        current_storage = LocalFileSystem(basepath=tmp_path / "current")

        is_configured = _result_storage_is_configured_for_remote_retrieval(
            explicit_storage,
            current_storage,
        )

        assert is_configured is True

    def test_returns_true_for_non_local_current_result_store_storage(self):
        current_storage = MagicMock(spec=WritableFileSystem)

        is_configured = _result_storage_is_configured_for_remote_retrieval(
            None,
            current_storage,
        )

        assert is_configured is True

    def test_returns_false_for_local_current_result_store_storage(self, tmp_path: Path):
        current_storage = LocalFileSystem(basepath=tmp_path / "current")

        is_configured = _result_storage_is_configured_for_remote_retrieval(
            None,
            current_storage,
        )

        assert is_configured is False

    def test_returns_false_when_no_result_storage_is_configured(self):
        is_configured = _result_storage_is_configured_for_remote_retrieval(None, None)

        assert is_configured is False
