"""Compresr guardrail — query-aware, recoverable context compression.

Compresses bulky message content (tool outputs by default) through the
Compresr API before the request reaches the LLM. Each compressed message
carries a hash marker; a ``compresr_retrieve`` tool is injected so the model
can fetch the original content back through the agentic loop when the
compressed version is not enough — making compression recoverable instead
of lossy.

Unlike gateway-side compressors that operate on whole message lists, each
target is compressed *query-aware*: the query sent to Compresr is the intent
of the tool call that produced the message (``name + arguments``, resolved
via ``tool_call_id``), falling back to the last user message.
"""

from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import time
from collections import Counter, OrderedDict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Final, Literal, TypeGuard
from urllib.parse import urlparse

import httpx
from fastapi import HTTPException
from httpx import Response as HttpxResponse

import litellm
from litellm._logging import verbose_proxy_logger
from litellm.constants import PRE_CALL_EXECUTED_GUARDRAILS_KEY
from litellm.integrations.custom_guardrail import (
    CustomGuardrail,
    log_guardrail_information,
)
from litellm.litellm_core_utils.prompt_templates.factory import (
    get_attribute_or_key,
    get_tool_calls_from_response,
    has_tool_with_name,
)
from litellm.llms.custom_httpx.http_handler import (
    get_async_httpx_client,  # pyright: ignore[reportUnknownVariableType]  # helper is untyped in http_handler
    httpxSpecialProvider,
)
from litellm.proxy._types import UserAPIKeyAuth
from litellm.proxy.guardrails.guardrail_hooks.content_text import (
    assistant_text_from_response,
    content_to_text,
    is_all_text_parts,
    merge_rewritten_text_parts,
)
from litellm.secret_managers.main import get_secret_str
from litellm.types.guardrails import GuardrailEventHooks, Mode
from litellm.types.integrations.custom_logger import (
    AgenticLoopPlan,
    AgenticLoopRequestPatch,
)
from litellm.types.utils import GenericGuardrailAPIInputs

if TYPE_CHECKING:
    from litellm.litellm_core_utils.litellm_logging import (
        Logging as LiteLLMLoggingObj,
    )
    from litellm.types.proxy.guardrails.guardrail_hooks.base import (
        GuardrailConfigModel,
    )

BYPASS_HEADER: Final = "x-compresr-bypass"
COMPRESR_RETRIEVE_TOOL_NAME: Final = "compresr_retrieve"
DEFAULT_API_BASE: Final = "https://api.compresr.ai"
DEFAULT_COMPRESSION_MODEL: Final = "latte_v2"
DEFAULT_TARGET_COMPRESSION_RATIO: Final = 0.5
DEFAULT_MIN_CHARS_TO_COMPRESS: Final = 500
_ORIGINALS_TTL_SECONDS: Final = 15 * 60
_NO_SCOPE_WARNING_INTERVAL_SECONDS: Final = 15 * 60
_MAX_TRACKED_CALLS: Final = 256
_DEFAULT_MAX_BYTES_PER_CALL: Final = 10 * 1024 * 1024
# Aggregate ceiling across all recovery-store entries. max_bytes_per_call only
# bounds a single call; this caps the whole store so many calls cannot exhaust it.
_MAX_TOTAL_STORE_BYTES: Final = 256 * 1024 * 1024
# Max compresr_retrieve calls expanded into a single follow-up (repeats deduped).
_MAX_RETRIEVALS_PER_LOOP: Final = 8
# The shared client's 600s read timeout is far too long for an on-request
# guardrail; bound the compress call so a stall hits the fail policy quickly.
_COMPRESS_TIMEOUT_SECONDS: Final = 60.0
_SOURCE_TAG: Final = "integration:litellm"
# Request-content fields the compression_params passthrough must never
# override — they carry the actual message content/queries being compressed.
_RESERVED_COMPRESSION_PARAM_KEYS: Final = frozenset({"context", "query", "inputs"})
_BLOCKED_METADATA_HOSTS: Final = frozenset(
    {
        "metadata.google.internal",
        "metadata.goog",
        "metadata.azure.com",
        "metadata.azure.internal",
    }
)
_BLOCKED_METADATA_IPS: Final = frozenset(
    ipaddress.ip_address(ip) for ip in ("169.254.169.254", "fd00:ec2::254", "100.100.100.200", "168.63.129.16")
)


def _parse_ip_literal(host: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address | None:
    """Parse ``host`` as an IP literal, covering the alternate spellings the
    socket layer accepts (decimal/hex single-integer IPv4, IPv4-mapped IPv6)
    so a blocked address cannot be smuggled past a string comparison."""
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        try:
            addr = ipaddress.ip_address(int(host, 0))
        except (TypeError, ValueError):
            return None
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped is not None:
        return addr.ipv4_mapped
    return addr


def _validate_api_base(url: str) -> str:
    """Return ``url`` if it passes basic outbound-target checks, else raise.

    Best-effort defense in depth for a mis/maliciously-configured ``api_base``:
    rejects non-http(s) schemes and cloud-metadata IPs/hosts (incl. alternate IP
    encodings); private ranges are allowed for on-prem deployments. NOT a complete
    SSRF control — no DNS resolution, and the shared client follows redirects and
    re-resolves DNS (TOCTOU / rebinding); ``api_base`` is trusted operator config,
    so this is an accepted limitation.
    """
    parsed: Final = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Compresr guardrail api_base must be http or https, got scheme={parsed.scheme!r}")
    host: Final = (parsed.hostname or "").lower()
    if not host:
        raise ValueError("Compresr guardrail api_base has no host")
    ip_literal: Final = _parse_ip_literal(host)
    if host in _BLOCKED_METADATA_HOSTS or (ip_literal is not None and ip_literal in _BLOCKED_METADATA_IPS):
        raise ValueError(f"Compresr guardrail api_base {host!r} is a blocked cloud-metadata host")
    return url


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:  # guard-ok: isinstance narrows correctly; predicate is trivially correct  # fmt: skip
    return isinstance(value, dict)


def _is_object_list(value: object) -> TypeGuard[list[object]]:  # guard-ok: isinstance narrows correctly; predicate is trivially correct  # fmt: skip
    return isinstance(value, list)


def _replace_text_in_content(content: object, new_text: str) -> object:
    """Write ``new_text`` back into a ``content`` value, preserving shape.

    ``str`` content is replaced directly. An all-text part list collapses to a
    single part carrying the last declared cache_control breakpoint. Anything
    else is returned unchanged: breakpoints are positional, so one compressed
    string cannot be written back across a non-text part without moving text
    to the other side of it.
    """
    if isinstance(content, str):
        return new_text
    if _is_object_list(content) and is_all_text_parts(content):
        return merge_rewritten_text_parts(content, new_text)
    return content


def _render_tool_intent(fn: dict[str, object]) -> str:
    name: Final = str(fn.get("name") or "").strip()
    args: Final = fn.get("arguments")
    if isinstance(args, dict):
        try:
            args_str = json.dumps(args, separators=(",", ":"))
        except (TypeError, ValueError):
            args_str = str(args)
    else:
        args_str = str(args).strip() if args is not None else ""
    if name and args_str:
        return f"{name}: {args_str}"
    return name or args_str


def _query_for_target(messages: list[dict[str, object]], target_idx: int, fallback: str) -> str:
    """Query used to compress ``messages[target_idx]``.

    Tool/function outputs are compressed against the intent of the tool call
    that produced them (found via ``tool_call_id`` on a prior assistant
    message); everything else uses the last user message.
    """
    msg: Final = messages[target_idx]
    if msg.get("role") not in ("tool", "function"):
        return fallback

    tool_call_id: Final = msg.get("tool_call_id")
    fn_name: Final = msg.get("name")
    for j in range(target_idx - 1, -1, -1):
        prev = messages[j]
        if prev.get("role") != "assistant":
            continue
        tool_calls = prev.get("tool_calls")
        if isinstance(tool_calls, list):
            for tc in tool_calls:
                if not isinstance(tc, dict):
                    continue
                if tool_call_id and tc.get("id") == tool_call_id:
                    fn = tc.get("function")
                    intent = _render_tool_intent(fn if isinstance(fn, dict) else {})
                    if intent:
                        return intent
        # Legacy function_call fallback: require a name match, else an earlier
        # function_call turn would attribute the wrong intent.
        fc = prev.get("function_call")
        if isinstance(fc, dict) and fn_name and fc.get("name") == fn_name:
            intent = _render_tool_intent(fc)
            if intent:
                return intent
    return fallback


def _safe_int(value: object) -> int:
    """Parse a token-stat field defensively.

    A malformed-but-200 response must not raise here: ``_call_compress`` has
    already returned successfully, so the fail_open/fail_closed decision is
    behind us. A bare ``int()`` on a non-numeric field would surface as an
    unhandled 500 even when ``fail_open`` is configured.
    """
    try:
        return int(value) if value is not None else 0
    except (TypeError, ValueError):
        return 0


def _safe_response_text(response: object, limit: int = 500) -> str:
    """Read a response body for error logging without letting the read itself
    raise. A corrupt ``Content-Encoding`` makes ``httpx``'s ``.text`` raise a
    ``DecodingError``; if that happened while building a failure detail it would
    turn an already-handled error into an unhandled 500."""
    try:
        text: Final = getattr(response, "text", "")
    except httpx.DecodingError:
        return "<undecodable response body>"
    return (text or "")[:limit]


def _content_hash(text: str) -> str:
    # surrogatepass so a lone surrogate in untrusted content (valid via a JSON
    # \uXXXX escape) hashes instead of raising past the fail policy.
    return hashlib.sha256(text.encode("utf-8", "surrogatepass")).hexdigest()[:24]


def _entry_bytes(originals: dict[str, str]) -> int:
    """UTF-8 byte size of one recovery-store entry (surrogatepass, like _content_hash)."""
    return sum(len(value.encode("utf-8", "surrogatepass")) for value in originals.values())


def _display_hash(hash_value: str) -> str:
    """Bound a model-supplied hash for logs/fallback text. A real marker hash is
    24 hex chars; a prompt-injected ``compresr_retrieve`` call could pass a huge
    or control-character-laden string, so strip non-printables (no forged log
    lines / ANSI escapes) and cap length before echoing into logs and the
    conversation."""
    printable: Final = "".join(ch for ch in hash_value if ch.isprintable())
    return printable if len(printable) <= 32 else f"{printable[:32]}…"


def _recovery_marker(hash_value: str) -> str:
    return (
        f"\n\n[compresr hash={hash_value}: parts of this content were compressed "
        f"away. If you need the full original, call the "
        f"{COMPRESR_RETRIEVE_TOOL_NAME} tool with this hash.]"
    )


def _build_compresr_retrieve_tool() -> dict[str, object]:
    return {
        "type": "function",
        "function": {
            "name": COMPRESR_RETRIEVE_TOOL_NAME,
            "description": (
                "Retrieve the original, uncompressed content behind a Compresr "
                "compression marker. Call this when a compression marker's hash "
                "points at content you need in full."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "hash": {
                        "type": "string",
                        "description": "The 24-character hex hash from the compression marker.",
                    },
                },
                "required": ["hash"],
            },
        },
    }


def has_compresr_retrieve_tool(tools: object) -> bool:
    return has_tool_with_name(tools, COMPRESR_RETRIEVE_TOOL_NAME)


def _merge_retrieve_tool(existing_tools: object) -> list[object] | None:
    """The request's tools plus the retrieve tool, or None when the incoming
    shape is not a list (leave the caller's tools untouched; markers stay
    inert text)."""
    if existing_tools is not None and not isinstance(existing_tools, list):
        return None
    retrieve_tool: Final = _build_compresr_retrieve_tool()
    if existing_tools is None:
        return [retrieve_tool]
    if has_compresr_retrieve_tool(existing_tools):
        return list(existing_tools)
    return list(existing_tools) + [retrieve_tool]


def _extract_compresr_tool_calls(response: object) -> list[dict[str, object]]:
    return [
        {"id": tc.get("id"), "type": "function", "name": tc.get("name"), "arguments": tc.get("arguments", {})}
        for tc in get_tool_calls_from_response(response)
        if tc.get("name") == COMPRESR_RETRIEVE_TOOL_NAME
    ]


def _resolve_call_id(logging_obj: object) -> str | None:
    """The call id from the framework logging object.

    This value ultimately derives from the client-settable ``x-litellm-call-id``
    header and is echoed back in responses, so it is NOT a trust boundary on its
    own — ``_scoped_store_key`` prefixes it with the caller's virtual-key hash to
    partition the recovery store per tenant. Request-body/kwargs call ids are
    deliberately not consulted here.
    """
    logging_call_id: Final = getattr(logging_obj, "litellm_call_id", None)
    if isinstance(logging_call_id, str) and logging_call_id:
        return logging_call_id
    return None


def _caller_scope(logging_obj: object) -> str:
    """The caller's virtual-key hash, used to partition the recovery store.

    Trust is anchored on the ``UserAPIKeyAuth`` object the proxy sets
    server-side (``metadata.user_api_key_auth``, litellm_pre_call_utils). Its
    ``api_key`` is the hash of the authenticated key. Both metadata spellings
    are scanned (``/v1/messages`` and ``/v1/responses`` carry it under
    ``litellm_metadata``), but the bare ``user_api_key`` *string* is never
    trusted on its own: a JSON request body can place one in the client-supplied
    ``metadata`` field, which is only sanitized on the route's canonical
    container. Returns "" when the proxy runs without per-key auth, in which case
    all traffic is a single trust domain and the call id alone suffices.
    """
    details: Final = getattr(logging_obj, "model_call_details", None)
    if not _is_str_object_dict(details):
        return ""
    litellm_params: Final = details.get("litellm_params")
    for container in (litellm_params, details):
        if not _is_str_object_dict(container):
            continue
        for meta_key in ("metadata", "litellm_metadata"):
            metadata = container.get(meta_key)
            if not _is_str_object_dict(metadata):
                continue
            auth = metadata.get("user_api_key_auth")
            if isinstance(auth, UserAPIKeyAuth) and isinstance(auth.api_key, str) and auth.api_key:
                return auth.api_key
    return ""


def _scoped_store_key(logging_obj: object) -> str | None:
    """Key for the recovery store: caller identity plus framework call id.

    Keying on the call id alone is unsafe: it comes from the client-settable
    ``x-litellm-call-id`` header and is echoed back in responses, so one caller
    could read or evict another's originals by reusing the id. Prefixing the
    unforgeable virtual-key hash binds each entry to the tenant that created it.
    Returns None when there is no call id, which disables recovery for the call.
    """
    call_id: Final = _resolve_call_id(logging_obj)
    if call_id is None:
        return None
    scope: Final = _caller_scope(logging_obj)
    return f"{scope}\x00{call_id}" if scope else call_id


def _is_responses_api_response(response: object) -> bool:
    return isinstance(get_attribute_or_key(response, "output", None), list)


def _is_anthropic_messages_response(response: object) -> bool:
    return isinstance(get_attribute_or_key(response, "content", None), list)


def _build_assistant_message_from_response(
    response: object,
    retrieved: list[tuple[dict[str, object], str]],
) -> dict[str, object]:
    """Rebuild the chat-completions assistant turn for the retrieval follow-up.

    Only the ``compresr_retrieve`` calls are echoed, each answered by a tool
    result below. Other tool calls made in the same turn are omitted on purpose:
    the follow-up re-runs the model with the recovered content so it re-plans
    them. Echoing them would leave tool_calls with no matching tool result and
    the provider would reject the request.
    """
    return {
        "role": "assistant",
        "content": assistant_text_from_response(response),
        "tool_calls": [
            {
                "id": tool_call.get("id"),
                "type": "function",
                "function": {
                    "name": tool_call.get("name"),
                    "arguments": json.dumps(tool_call.get("arguments", {})),
                },
            }
            for tool_call, _ in retrieved
        ],
    }


def _build_anthropic_followup_messages(
    response: object,
    retrieved: list[tuple[dict[str, object], str]],
) -> list[dict[str, object]]:
    """Anthropic requires the tool_use block echoed back in an assistant
    message paired with a tool_result block keyed by the same tool_use_id. The
    assistant text is preserved; non-retrieve tool calls are re-planned by the
    follow-up (see _build_assistant_message_from_response)."""
    assistant_content: Final[list[dict[str, object]]] = []
    text: Final = assistant_text_from_response(response)
    if text:
        assistant_content.append({"type": "text", "text": text})
    assistant_content.extend(
        {
            "type": "tool_use",
            "id": tool_call.get("id"),
            "name": tool_call.get("name"),
            "input": tool_call.get("arguments", {}),
        }
        for tool_call, _ in retrieved
    )
    assistant_message: Final[dict[str, object]] = {"role": "assistant", "content": assistant_content}
    user_message: Final[dict[str, object]] = {
        "role": "user",
        "content": [
            {"type": "tool_result", "tool_use_id": tool_call.get("id"), "content": content}
            for tool_call, content in retrieved
        ],
    }
    return [assistant_message, user_message]


def _build_responses_followup_items(
    response: object,
    retrieved: list[tuple[dict[str, object], str]],
) -> list[dict[str, object]]:
    """The Responses API requires the model's function_call echoed back paired
    with a function_call_output keyed by the same call_id. The assistant text is
    preserved; non-retrieve tool calls are re-planned by the follow-up."""
    items: Final[list[dict[str, object]]] = []
    text: Final = assistant_text_from_response(response)
    if text:
        items.append({"role": "assistant", "content": text})
    for tool_call, content in retrieved:
        call_id = tool_call.get("id")
        items.append(
            {
                "type": "function_call",
                "call_id": call_id,
                "name": tool_call.get("name"),
                "arguments": json.dumps(tool_call.get("arguments", {})),
            }
        )
        items.append({"type": "function_call_output", "call_id": call_id, "output": content})
    return items


@dataclass
class _CompressionResult:
    """Outcome of applying compression results to a message list."""

    compressed_messages: list[dict[str, object]]
    originals: dict[str, str] = field(default_factory=dict)
    # original text -> compressed text, plus the machinery the Responses `texts`
    # mirror needs to replace only where it is unambiguous.
    text_replacements: dict[str, str] = field(default_factory=dict)
    replaced_text_counts: dict[str, int] = field(default_factory=dict)
    ambiguous_texts: set[str] = field(default_factory=set)
    messages_compressed: int = 0
    tokens_before: int = 0
    tokens_after: int = 0


class CompresrGuardrail(CustomGuardrail):
    def __init__(
        self,
        api_base: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        target_compression_ratio: float | None = None,
        coarse: bool | None = None,
        min_chars_to_compress: int | None = None,
        compress_tool_outputs: bool | None = None,
        compress_system: bool | None = None,
        compress_history: bool | None = None,
        compress_last_user: bool | None = None,
        enable_retrieval: bool | None = None,
        guardrail_name: str | None = None,
        event_hook: GuardrailEventHooks | list[GuardrailEventHooks] | Mode | None = None,
        default_on: bool = False,
        unreachable_fallback: str | None = None,
        max_bytes_per_call: int | None = None,
        allow_bypass_header: bool | None = None,
        dynamic: bool | None = None,
        dynamic_min_ratio: float | None = None,
        dynamic_max_ratio: float | None = None,
        compression_params: dict[str, object] | None = None,
    ):
        raw_api_base: Final = (api_base or get_secret_str("COMPRESR_API_BASE") or DEFAULT_API_BASE).rstrip("/")
        self.compresr_api_base = _validate_api_base(raw_api_base)
        self.compresr_api_key = api_key or get_secret_str("COMPRESR_API_KEY")
        if not self.compresr_api_key:
            raise ValueError(
                "Compresr guardrail requires an API key. Set `api_key` in the "
                "guardrail config or the COMPRESR_API_KEY env var."
            )
        self.compression_model = model or DEFAULT_COMPRESSION_MODEL
        self.target_compression_ratio = (
            DEFAULT_TARGET_COMPRESSION_RATIO if target_compression_ratio is None else target_compression_ratio
        )
        self.coarse = True if coarse is None else coarse
        self.min_chars_to_compress = (
            DEFAULT_MIN_CHARS_TO_COMPRESS if min_chars_to_compress is None else min_chars_to_compress
        )
        self.compress_tool_outputs = True if compress_tool_outputs is None else compress_tool_outputs
        self.compress_system = False if compress_system is None else compress_system
        self.compress_history = False if compress_history is None else compress_history
        self.compress_last_user = False if compress_last_user is None else compress_last_user
        self.enable_retrieval = True if enable_retrieval is None else enable_retrieval
        self.unreachable_fallback: Literal["fail_closed", "fail_open"] = (
            "fail_open" if unreachable_fallback == "fail_open" else "fail_closed"
        )
        self.max_bytes_per_call = _DEFAULT_MAX_BYTES_PER_CALL if max_bytes_per_call is None else max_bytes_per_call
        if self.max_bytes_per_call < 0:
            raise ValueError("max_bytes_per_call must be >= 0 (0 disables the cap; positive values enforce it)")
        self.allow_bypass_header = False if allow_bypass_header is None else allow_bypass_header
        # Dynamic (adaptive) compression — latte_v2 only, on by default: the server
        # picks the ratio per input instead of honoring target_compression_ratio.
        self.dynamic = True if dynamic is None else dynamic
        self.dynamic_min_ratio = dynamic_min_ratio
        self.dynamic_max_ratio = dynamic_max_ratio
        # Passthrough of extra compression params forwarded verbatim, so a new
        # Compresr feature works without changing this guardrail. Named fields win;
        # request-content fields are stripped.
        reserved_keys: Final = _RESERVED_COMPRESSION_PARAM_KEYS.intersection(compression_params or {})
        if reserved_keys:
            verbose_proxy_logger.warning(
                "Compresr: ignoring reserved compression_params keys %s", sorted(reserved_keys)
            )
        self.compression_params: dict[str, object] = {
            k: v for k, v in (compression_params or {}).items() if k not in _RESERVED_COMPRESSION_PARAM_KEYS
        }
        self.async_handler = get_async_httpx_client(
            llm_provider=httpxSpecialProvider.GuardrailCallback,
        )
        self._originals_by_call_id: OrderedDict[str, tuple[dict[str, str], float]] = OrderedDict()
        # Running byte size of the store, kept in sync to enforce the global cap cheaply.
        self._store_total_bytes = 0
        # Rate-limits the "recovery skipped, no auth scope" warning so an ongoing
        # misconfiguration stays visible without flooding hot-path logs.
        self._no_scope_warning_expiry = 0.0
        if self.enable_retrieval:
            verbose_proxy_logger.warning(
                "Compresr: enable_retrieval is on; the recovery store is per-process. "
                "For multi-worker deployments, set enable_retrieval=false or run with --workers 1."
            )
        super().__init__(  # pyright: ignore[reportUnknownMemberType]  # CustomGuardrail.__init__ is untyped
            guardrail_name=guardrail_name,
            event_hook=event_hook,
            default_on=default_on,
        )

    def _should_bypass(self, request_data: dict) -> bool:
        if not self.allow_bypass_header:
            return False
        psr: Final = request_data.get("proxy_server_request")
        if not _is_str_object_dict(psr):
            return False
        headers: Final = psr.get("headers")
        if not _is_str_object_dict(headers):
            return False
        return str(headers.get(BYPASS_HEADER)).lower() == "true"

    def _request_headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.compresr_api_key or "",
        }

    def _handle_compress_failure(self, error: str, log_detail: dict[str, object]) -> None:
        """fail_open logs and returns (caller forwards uncompressed);
        fail_closed raises. ``log_detail`` may include upstream response bodies
        and is written only to server logs; the raised ``HTTPException`` carries
        a generic message so a malicious ``api_base`` cannot exfiltrate response
        bytes through the client-visible error."""
        if self.unreachable_fallback == "fail_open":
            verbose_proxy_logger.warning(
                "Compresr: %s; fail_open configured, forwarding request uncompressed. detail=%s",
                error,
                log_detail,
            )
            return
        verbose_proxy_logger.error("Compresr: %s. detail=%s", error, log_detail)
        raise HTTPException(status_code=502, detail={"error": error})

    def _evict_oldest(self) -> None:
        """Drop the front (oldest) entry and decrement the running byte total."""
        _key, (evicted, _expiry) = self._originals_by_call_id.popitem(last=False)
        self._store_total_bytes -= _entry_bytes(evicted)

    def _prune_originals(self) -> None:
        # Insertion order == expiry order (shared TTL); prune from the front.
        now: Final = time.monotonic()
        store: Final = self._originals_by_call_id
        while store and store[next(iter(store))][1] <= now:
            self._evict_oldest()
        while len(store) > _MAX_TRACKED_CALLS:
            self._evict_oldest()
        # Global byte budget; keep the most-recent entry so the current call's
        # originals survive (a single call is already bounded by max_bytes_per_call).
        while len(store) > 1 and self._store_total_bytes > _MAX_TOTAL_STORE_BYTES:
            self._evict_oldest()

    def _existing_originals(self, store_key: str | None) -> dict[str, str]:
        """Originals already stored under this key, so the per-call byte budget
        can account for an earlier turn that reused the store key."""
        if store_key is None:
            return {}
        return self._originals_by_call_id.get(store_key, ({}, 0.0))[0]

    def _store_originals(self, store_key: str, originals: dict[str, str]) -> None:
        existing, _ = self._originals_by_call_id.get(store_key, ({}, 0.0))
        merged: Final = self._bound_call_bytes({**existing, **originals})
        # Keep the running total in sync: drop the overwritten entry, add the new one.
        self._store_total_bytes += _entry_bytes(merged) - _entry_bytes(existing)
        self._originals_by_call_id[store_key] = (
            merged,
            time.monotonic() + _ORIGINALS_TTL_SECONDS,
        )
        self._originals_by_call_id.move_to_end(store_key)
        self._prune_originals()

    def _bound_call_bytes(self, merged: dict[str, str]) -> dict[str, str]:
        """Drop oldest entries (dict insertion order) until the aggregate byte
        size fits ``self.max_bytes_per_call``. Prevents one call with many
        large tool outputs from growing proxy memory without bound."""
        if self.max_bytes_per_call <= 0:
            return merged
        total = _entry_bytes(merged)
        if total <= self.max_bytes_per_call:
            return merged
        bounded: Final = dict(merged)
        for key in list(bounded.keys()):
            if total <= self.max_bytes_per_call:
                break
            total -= len(bounded[key].encode("utf-8", "surrogatepass"))
            del bounded[key]
            verbose_proxy_logger.warning("Compresr: originals-store byte cap hit, evicted hash=%s", key)
        return bounded

    def _retrieve_original(self, store_key: str | None, hash_value: str) -> str | None:
        """Stored original for a marker hash, or None if not issued for this
        request (unknown, expired, or from another caller's scope)."""
        if store_key:
            originals, expiry = self._originals_by_call_id.get(store_key, ({}, 0.0))
            if expiry > time.monotonic() and hash_value in originals:
                return originals[hash_value]
            verbose_proxy_logger.warning(
                "Compresr retrieve: rejecting hash=%s (not issued for this request, or expired)",
                _display_hash(hash_value),
            )
        return None

    def _resolve_retrievals(
        self, store_key: str | None, tool_calls: list[dict[str, object]]
    ) -> tuple[list[tuple[dict[str, object], str]], bool]:
        """Resolve compresr_retrieve calls to (call, result_text) pairs, deduping
        repeated hashes and capping the count so the follow-up cannot be amplified.
        The bool is True iff at least one call resolved to real stored content."""
        retrieved: Final[list[tuple[dict[str, object], str]]] = []
        seen: Final[set[str]] = set()
        resolved_any = False
        for idx, tc in enumerate(tool_calls):
            arguments = tc.get("arguments", {})
            hash_value = str(arguments.get("hash", "")) if isinstance(arguments, dict) else ""
            if idx >= _MAX_RETRIEVALS_PER_LOOP:
                result = "[compresr: retrieval limit reached for this turn]"
            elif hash_value in seen:
                result = "[compresr: already retrieved above for this hash]"
            else:
                content = self._retrieve_original(store_key, hash_value)
                if content is None:
                    result = f"[compresr: hash={_display_hash(hash_value)} not found, expired, or not issued for this request]"
                else:
                    seen.add(hash_value)
                    resolved_any = True
                    result = content
            verbose_proxy_logger.debug("Compresr retrieve: hash=%s -> %d chars", _display_hash(hash_value), len(result))
            retrieved.append((tc, result))
        return retrieved, resolved_any

    async def _call_compress(
        self,
        contexts: list[str],
        queries: list[str],
    ) -> list[dict[str, object]] | None:
        """Compress ``contexts`` (query-aware). Returns one result dict per
        context, or None when the service failed and fail_open applies."""
        common: Final[dict[str, object]] = {
            # Passthrough first so the named fields below always win on collision.
            **self.compression_params,
            "compression_model_name": self.compression_model,
            "target_compression_ratio": self.target_compression_ratio,
            "coarse": self.coarse,
            "dynamic": self.dynamic,
            "source": _SOURCE_TAG,
        }
        # Only send the bounds the operator actually set; otherwise let the
        # server apply its own floor/ceiling.
        if self.dynamic_min_ratio is not None:
            common["dynamic_min_ratio"] = self.dynamic_min_ratio
        if self.dynamic_max_ratio is not None:
            common["dynamic_max_ratio"] = self.dynamic_max_ratio
        if len(contexts) == 1:
            url = f"{self.compresr_api_base}/api/compress/question-specific/"
            payload: dict[str, object] = {
                "context": contexts[0],
                "query": queries[0],
                **common,
            }
        else:
            url = f"{self.compresr_api_base}/api/compress/question-specific/batch"
            payload = {
                "inputs": [{"context": ctx, "query": q} for ctx, q in zip(contexts, queries)],
                **common,
            }

        try:
            raw_response: HttpxResponse = await self.async_handler.post(  # pyright: ignore[reportUnknownMemberType]  # AsyncHTTPHandler.post is untyped
                url=url,
                json=payload,
                headers=self._request_headers(),
                timeout=_COMPRESS_TIMEOUT_SECONDS,
            )
        except asyncio.CancelledError:
            raise
        except httpx.HTTPStatusError as e:
            # The shared handler calls raise_for_status(), so a non-2xx reply arrives
            # here as an error carrying the upstream body + our API key header; route
            # it through the fail policy so none of that reaches the client.
            resp: Final = getattr(e, "response", None)
            self._handle_compress_failure(
                "Compresr compression service returned an error",
                {
                    "status_code": getattr(resp, "status_code", None),
                    "body": _safe_response_text(resp),
                },
            )
            return None
        except (httpx.RequestError, litellm.Timeout) as e:
            # Every request-side httpx failure is a RequestError; route the whole
            # class through the fail policy so none escapes as a 500 under fail_open.
            # (HTTPStatusError is handled above and is not a RequestError.)
            self._handle_compress_failure(
                "Compresr compression service request failed",
                {"detail": str(e)},
            )
            return None
        if not 200 <= raw_response.status_code < 300:
            self._handle_compress_failure(
                "Compresr compression service returned an error",
                {
                    "status_code": raw_response.status_code,
                    "body": _safe_response_text(raw_response),
                },
            )
            return None

        try:
            body: Final[object] = raw_response.json()
        except (ValueError, httpx.DecodingError, RecursionError):
            # RecursionError: a deeply nested JSON body overflows the parser;
            # route it through the fail policy rather than let it escape as a 500.
            self._handle_compress_failure(
                "Compresr compression service returned an unreadable response",
                {"body": _safe_response_text(raw_response)},
            )
            return None
        if not _is_str_object_dict(body) or not _is_str_object_dict(body.get("data")):
            self._handle_compress_failure(
                "Compresr compression service returned unexpected response shape",
                {"body": _safe_response_text(raw_response)},
            )
            return None
        data: dict[str, object] = body["data"]  # pyright: ignore[reportAssignmentType]  # dict-guarded above; subscript does not narrow

        if len(contexts) == 1:
            return [data]
        results: Final = data.get("results")
        if (
            not _is_object_list(results)
            or len(results) != len(contexts)
            or not all(_is_str_object_dict(r) for r in results)
        ):
            # Anything but a 1:1 dict-per-context mapping would misalign
            # results with their target messages.
            self._handle_compress_failure(
                "Compresr batch response missing or mismatched 'results'",
                {"expected": len(contexts), "got": len(results) if _is_object_list(results) else None},
            )
            return None
        return results  # pyright: ignore[reportReturnType]  # every element dict-checked above; list[object] does not narrow

    def _select_targets(self, messages: list[dict[str, object]], query_idx: int | None) -> list[int]:
        """Indices of messages whose text content should be compressed."""
        targets: Final[list[int]] = []
        for idx, msg in enumerate(messages):
            if idx == query_idx and not self.compress_last_user:
                continue
            role = msg.get("role")
            if role in ("tool", "function"):
                if not self.compress_tool_outputs:
                    continue
            elif role == "system":
                if not self.compress_system:
                    continue
            elif role == "user":
                if idx != query_idx and not self.compress_history:
                    continue
            else:
                continue
            content = msg.get("content")
            if _is_object_list(content) and not is_all_text_parts(content):
                continue
            if len(content_to_text(content)) < self.min_chars_to_compress:
                continue
            targets.append(idx)
        return targets

    @staticmethod
    def _extract_fallback_query(
        messages: list[dict[str, object]],
    ) -> tuple[str, int | None]:
        for idx in range(len(messages) - 1, -1, -1):
            if messages[idx].get("role") == "user":
                return content_to_text(messages[idx].get("content")), idx
        return "", None

    def _apply_compression_results(
        self,
        messages: list[dict[str, object]],
        targets: list[int],
        contexts: list[str],
        results: list[dict[str, object]],
        recovery_enabled: bool,
        existing_originals: dict[str, str] | None = None,
    ) -> _CompressionResult:
        """Write each compression result into a copy of ``messages``.

        A result is a real compression only when it is a non-empty string that
        differs from the original; identical text is treated as a no-op so an
        untouched request is not needlessly rewritten downstream.
        """
        out: Final = _CompressionResult(compressed_messages=list(messages))
        existing: Final = existing_originals or {}
        cap: Final = self.max_bytes_per_call
        # Seed with what is already stored under this store key: markers are
        # attached only while the store (existing + this call's originals) stays
        # within the cap, so _store_originals never has to evict a hash this call
        # just shipped a marker for -- including on a later turn that reuses the
        # store key. A hash already stored (or repeated here) costs no new bytes.
        recovery_bytes = _entry_bytes(existing)
        for target_idx, original_text, result in zip(targets, contexts, results):
            compressed_text = result.get("compressed_context")
            if not isinstance(compressed_text, str) or not compressed_text or compressed_text == original_text:
                continue
            out.messages_compressed += 1
            if recovery_enabled:
                hash_value = _content_hash(original_text)
                already_stored = hash_value in existing or hash_value in out.originals
                new_bytes = 0 if already_stored else len(original_text.encode("utf-8", "surrogatepass"))
                if cap <= 0 or recovery_bytes + new_bytes <= cap:
                    recovery_bytes += new_bytes
                    out.originals[hash_value] = original_text
                    compressed_text += _recovery_marker(hash_value)
            previous = out.text_replacements.get(original_text)
            if previous is not None and previous != compressed_text:
                # Two targets with identical text but different query-specific
                # compressions; a value-keyed replacement cannot tell them apart.
                out.ambiguous_texts.add(original_text)
            else:
                out.text_replacements[original_text] = compressed_text
            out.replaced_text_counts[original_text] = out.replaced_text_counts.get(original_text, 0) + 1
            original_msg = out.compressed_messages[target_idx]
            out.compressed_messages[target_idx] = {
                **original_msg,
                "content": _replace_text_in_content(original_msg.get("content"), compressed_text),
            }
            out.tokens_before += _safe_int(result.get("original_tokens"))
            out.tokens_after += _safe_int(result.get("compressed_tokens"))
        return out

    @staticmethod
    def _mirror_texts_channel(input_texts: object, applied: _CompressionResult) -> list[object] | None:
        """Compressed content mirrored into the Responses `texts` channel.

        The chat/Anthropic handlers round-trip ``structured_messages``; the
        Responses translation cannot rebuild its input from chat messages and
        instead writes back through ``texts``. This matches by value, so a
        replacement is applied only when it is unambiguous: one compression per
        text, and every occurrence in ``texts`` accounted for by a compressed
        target. Anything else is left uncompressed rather than risk a wrong or
        out-of-policy replacement. Returns None when nothing safe applies.
        """
        if not applied.text_replacements or not isinstance(input_texts, list):
            return None
        counts: Final = Counter(text for text in input_texts if isinstance(text, str))
        safe: Final = {
            text: replacement
            for text, replacement in applied.text_replacements.items()
            if text not in applied.ambiguous_texts and counts.get(text) == applied.replaced_text_counts.get(text)
        }
        if not safe:
            return None
        return [safe.get(text, text) if isinstance(text, str) else text for text in input_texts]

    @log_guardrail_information
    async def apply_guardrail(
        self,
        inputs: GenericGuardrailAPIInputs,
        request_data: dict,
        input_type: Literal["request", "response"],
        logging_obj: LiteLLMLoggingObj | None = None,
    ) -> GenericGuardrailAPIInputs:
        if input_type != "request":
            return inputs

        if self._should_bypass(request_data):
            verbose_proxy_logger.debug("Compresr: %s header set; skipping compression", BYPASS_HEADER)
            return inputs

        structured_messages: Final = inputs.get("structured_messages")
        if not _is_object_list(structured_messages) or not structured_messages:
            return inputs
        messages: Final = [m for m in structured_messages if _is_str_object_dict(m)]
        if len(messages) != len(structured_messages):
            return inputs

        fallback_query, query_idx = self._extract_fallback_query(messages)
        targets: Final[list[int]] = []
        queries: Final[list[str]] = []
        for idx in self._select_targets(messages, query_idx):
            query = _query_for_target(messages, idx, fallback_query)
            # latte models require a non-empty query; leave targets we cannot
            # derive one for uncompressed rather than erroring.
            if not query.strip():
                continue
            targets.append(idx)
            queries.append(query)
        if not targets:
            verbose_proxy_logger.debug("Compresr: no messages eligible for compression")
            return inputs

        contexts: Final = [content_to_text(messages[idx].get("content")) for idx in targets]

        start_time: Final = time.monotonic()
        results: Final = await self._call_compress(contexts=contexts, queries=queries)
        end_time: Final = time.monotonic()
        if results is None:  # service failed, fail_open configured
            return inputs

        # Recovery needs a per-tenant scope; without per-key auth the key would fall
        # back to the client-settable call id (cross-tenant reads), so skip it.
        store_key: Final = _scoped_store_key(logging_obj)
        scope: Final = _caller_scope(logging_obj)
        recovery_enabled: Final = self.enable_retrieval and store_key is not None and bool(scope)
        if self.enable_retrieval and not scope and time.monotonic() >= self._no_scope_warning_expiry:
            # Surface the silent no-recovery case (compressed, but no auth scope
            # to inject the retrieve tool), re-warning once per interval.
            self._no_scope_warning_expiry = time.monotonic() + _NO_SCOPE_WARNING_INTERVAL_SECONDS
            verbose_proxy_logger.warning(
                "Compresr: enable_retrieval is on but this request has no per-key auth scope; "
                "compressing without recovery (compresr_retrieve tool not injected). "
                "Configure virtual-key auth to enable recovery."
            )

        existing_originals: Final = self._existing_originals(store_key)
        applied: Final = self._apply_compression_results(
            messages, targets, contexts, results, recovery_enabled, existing_originals
        )
        if applied.messages_compressed == 0:
            # Nothing replaced: return the original inputs object (handlers detect
            # edits by identity; a fresh list forces write-back that strips Anthropic
            # cache_control from thinking blocks).
            verbose_proxy_logger.debug("Compresr: service returned no compressed content; request unchanged")
            return inputs

        stats: Final[dict[str, object]] = {
            "messages_compressed": applied.messages_compressed,
            "tokens_before": applied.tokens_before,
            "tokens_after": applied.tokens_after,
            "tokens_saved": applied.tokens_before - applied.tokens_after,
            "compression_model": self.compression_model,
        }
        verbose_proxy_logger.debug(
            "Compresr: compressed %s message(s), %s -> %s tokens",
            applied.messages_compressed,
            applied.tokens_before,
            applied.tokens_after,
        )
        self.add_standard_logging_guardrail_information_to_request_data(
            guardrail_json_response=stats,
            request_data=request_data,
            guardrail_status="success",
            guardrail_provider="compresr",
            start_time=start_time,
            end_time=end_time,
            duration=end_time - start_time,
        )

        compressed_inputs: Final[dict[str, object]] = {**inputs, "structured_messages": applied.compressed_messages}
        mirrored_texts: Final = self._mirror_texts_channel(inputs.get("texts"), applied)
        if mirrored_texts is not None:
            compressed_inputs["texts"] = mirrored_texts

        originals: Final = applied.originals
        if not recovery_enabled or not originals or store_key is None:
            return compressed_inputs  # pyright: ignore[reportReturnType]  # plain dicts satisfy AllMessageValues at runtime

        self._store_originals(store_key, originals)

        merged_tools: Final = _merge_retrieve_tool(inputs.get("tools"))
        if merged_tools is not None:
            compressed_inputs["tools"] = merged_tools
        return compressed_inputs  # pyright: ignore[reportReturnType]  # plain dicts satisfy AllMessageValues at runtime

    async def async_should_run_agentic_loop(
        self,
        response: Any,
        model: str,
        messages: list[dict],
        tools: list[dict] | None,
        stream: bool,
        custom_llm_provider: str,
        kwargs: dict,
    ) -> tuple[bool, dict]:
        if not has_compresr_retrieve_tool(tools):
            return False, {}
        tool_calls: Final = _extract_compresr_tool_calls(response)
        if not tool_calls:
            return False, {}
        return True, {"tool_calls": tool_calls}

    async def async_build_agentic_loop_plan(
        self,
        tools: dict,
        model: str,
        messages: list[dict],
        response: Any,
        anthropic_messages_provider_config: Any,
        anthropic_messages_optional_request_params: dict,
        logging_obj: LiteLLMLoggingObj | None,
        stream: bool,
        kwargs: dict,
    ) -> AgenticLoopPlan:
        tool_calls: list[dict[str, object]] = tools.get("tool_calls", [])  # pyright: ignore[reportAssignmentType]  # gate hook builds this dict with list values only

        self._prune_originals()
        store_key: Final = _scoped_store_key(logging_obj)
        retrieved, resolved_any = self._resolve_retrievals(store_key, tool_calls)
        if not resolved_any:
            # Nothing this guardrail stored resolved; skip the extra provider round-trip.
            return AgenticLoopPlan(run_agentic_loop=False)

        if _is_responses_api_response(response):
            follow_up_messages = list(messages) + _build_responses_followup_items(response, retrieved)
        elif _is_anthropic_messages_response(response):
            follow_up_messages = list(messages) + _build_anthropic_followup_messages(response, retrieved)
        else:
            assistant_message: Final = _build_assistant_message_from_response(response, retrieved)
            tool_results: Final = [
                {"role": "tool", "tool_call_id": tc.get("id"), "content": content} for tc, content in retrieved
            ]
            follow_up_messages = list(messages) + [assistant_message] + tool_results

        anthropic_max: Final = anthropic_messages_optional_request_params.get("max_tokens")
        max_tokens: Final[int | None] = anthropic_max if anthropic_max is not None else kwargs.get("max_tokens")
        optional_params_without_max_tokens: Final = {
            k: v for k, v in anthropic_messages_optional_request_params.items() if k != "max_tokens"
        }

        full_model_name = model
        if logging_obj is not None:
            agentic_params: Final = getattr(logging_obj, "model_call_details", {}).get("agentic_loop_params", {})
            candidate: Final = agentic_params.get("model", model)
            if isinstance(candidate, str) and candidate:
                full_model_name = candidate

        return AgenticLoopPlan(
            run_agentic_loop=True,
            request_patch=AgenticLoopRequestPatch(
                model=full_model_name,
                messages=follow_up_messages,
                max_tokens=max_tokens,
                optional_params=optional_params_without_max_tokens,
                kwargs=self._sanitized_follow_up_kwargs(kwargs),
            ),
            metadata={"tool_type": "compresr_retrieve"},
        )

    def _sanitized_follow_up_kwargs(self, kwargs: dict) -> dict[str, object]:
        """Copy of the request kwargs for the retrieval follow-up with other
        guardrails' pre-call-executed markers stripped, so input guardrails
        re-inspect the restored originals; only this guardrail's own marker is
        kept, to avoid recompressing what it just retrieved."""
        out: Final[dict[str, object]] = {
            k: v for k, v in kwargs.items() if not k.startswith("_compresr") and k != "litellm_logging_obj"
        }
        own_marker: Final = self._pre_call_marker()
        for meta_key in ("metadata", "litellm_metadata"):
            meta = out.get(meta_key)
            if not isinstance(meta, dict):
                continue
            executed = meta.get(PRE_CALL_EXECUTED_GUARDRAILS_KEY)
            if not isinstance(executed, list):
                continue
            kept = [m for m in executed if own_marker is not None and m == own_marker]
            out[meta_key] = (
                {**meta, PRE_CALL_EXECUTED_GUARDRAILS_KEY: kept}
                if kept
                else {k: v for k, v in meta.items() if k != PRE_CALL_EXECUTED_GUARDRAILS_KEY}
            )
        return out

    @staticmethod
    def get_config_model() -> type[GuardrailConfigModel[object]] | None:
        from litellm.types.proxy.guardrails.guardrail_hooks.compresr import (
            CompresrGuardrailConfigModel,
        )

        return CompresrGuardrailConfigModel
