"""Video endpoints module."""
