from __future__ import annotations as _annotations

import json
import os
import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from functools import cached_property
from typing import TYPE_CHECKING, Annotated, Any, Literal, TypeVar, cast
from unittest.mock import AsyncMock, MagicMock

if TYPE_CHECKING:
    from vcr.cassette import Cassette

import httpx2
import pytest
from pydantic import BaseModel, Field

from pydantic_ai import (
    Agent,
    BinaryContent,
    CachePoint,
    DocumentUrl,
    FinalResultEvent,
    ImageUrl,
    ModelAPIError,
    ModelHTTPError,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    ModelRetry,
    NativeToolCallPart,
    NativeToolReturnPart,
    PartDeltaEvent,
    PartEndEvent,
    PartStartEvent,
    RetryPromptPart,
    RunContext,
    SystemPromptPart,
    TextContent,
    TextPart,
    TextPartDelta,
    ThinkingPart,
    ThinkingPartDelta,
    Tool,
    ToolCallPart,
    ToolCallPartDelta,
    ToolDefinition,
    ToolFailed,
    ToolReturnPart,
    UsageLimitExceeded,
    UserPromptPart,
)
from pydantic_ai._agent_graph import ModelRequestNode
from pydantic_ai._utils import PeekableAsyncStream
from pydantic_ai.capabilities import Capability, NativeTool, ToolSearch
from pydantic_ai.exceptions import UnexpectedModelBehavior, UserError
from pydantic_ai.messages import (
    CompactionPart,
    InstructionPart,
    ToolAvailabilityDeltaPart,
    ToolSearchCallPart,
    ToolSearchReturnPart,
    UploadedFile,
)
from pydantic_ai.models import ModelRequestParameters
from pydantic_ai.native_tools import (
    SUPPORTED_NATIVE_TOOLS,
    AdvisorTool,
    CodeExecutionTool,
    MCPServerTool,
    MemoryTool,
    WebFetchTool,
    WebSearchTool,
)
from pydantic_ai.native_tools._tool_search import ToolSearchTool
from pydantic_ai.output import NativeOutput, PromptedOutput, TextOutput, ToolOutput
from pydantic_ai.result import RunUsage
from pydantic_ai.settings import ModelSettings
from pydantic_ai.toolsets import FunctionToolset
from pydantic_ai.usage import RequestUsage, UsageLimits
from pydantic_graph import End

from .._inline_snapshot import snapshot
from ..cassette_utils import single_request_body
from ..conftest import (
    IsDatetime,
    IsInstance,
    IsNow,
    IsStr,
    TestEnv,
    iter_message_parts,
    message,
    raise_if_exception,
    try_import,
)
from ..parts_from_messages import part_types_from_messages
from .conftest import AnthropicModelFactory, RequestCapture, cache_breakpoints, content_blocks, message_shape
from .mock_async_stream import MockAsyncStream

with try_import() as imports_successful:
    from anthropic import (
        NOT_GIVEN,
        APIConnectionError,
        APIStatusError,
        AsyncAnthropic,
        AsyncAnthropicBedrock,
        AsyncAnthropicBedrockMantle,
        AsyncAnthropicFoundry,
        AsyncAnthropicVertex,
        AsyncStream,
        omit as OMIT,
    )
    from anthropic.lib.tools import BetaAbstractMemoryTool
    from anthropic.resources.beta import AsyncBeta
    from anthropic.types.beta import (
        BetaAdvisorMessageIterationUsage,
        BetaAdvisorRedactedResultBlock,
        BetaAdvisorResultBlock,
        BetaAdvisorToolResultBlock,
        BetaAdvisorToolResultError,
        BetaCodeExecutionResultBlock,
        BetaCodeExecutionToolResultBlock,
        BetaCompactionBlock,
        BetaCompactionContentBlockDelta,
        BetaCompactionIterationUsage,
        BetaContentBlock,
        BetaDirectCaller,
        BetaInputJSONDelta,
        BetaMemoryTool20250818CreateCommand,
        BetaMemoryTool20250818DeleteCommand,
        BetaMemoryTool20250818InsertCommand,
        BetaMemoryTool20250818RenameCommand,
        BetaMemoryTool20250818StrReplaceCommand,
        BetaMemoryTool20250818ViewCommand,
        BetaMessage,
        BetaMessageDeltaUsage,
        BetaMessageIterationUsage,
        BetaMessageTokensCount,
        BetaOutputTokensDetails,
        BetaRawContentBlockDeltaEvent,
        BetaRawContentBlockStartEvent,
        BetaRawContentBlockStopEvent,
        BetaRawMessageDeltaEvent,
        BetaRawMessageStartEvent,
        BetaRawMessageStopEvent,
        BetaRawMessageStreamEvent,
        BetaServerToolUseBlock,
        BetaTextBlock,
        BetaTextDelta,
        BetaToolUseBlock,
        BetaUsage,
        BetaWebSearchResultBlock,
        BetaWebSearchToolResultBlock,
    )
    from anthropic.types.beta.beta_container import BetaContainer
    from anthropic.types.beta.beta_container_params import BetaContainerParams
    from anthropic.types.beta.beta_raw_message_delta_event import Delta
    from anthropic.types.beta.beta_refusal_stop_details import BetaRefusalStopDetails

    from pydantic_ai.models.anthropic import (
        AnthropicCodeExecutionToolVersion,
        AnthropicCompaction,
        AnthropicModel,
        AnthropicModelSettings,
        AnthropicStreamedResponse,
        _map_usage,  # pyright: ignore[reportPrivateUsage]
    )
    from pydantic_ai.models.openai import OpenAIResponsesModel, OpenAIResponsesModelSettings
    from pydantic_ai.profiles.anthropic import anthropic_model_profile
    from pydantic_ai.providers.anthropic import AnthropicProvider
    from pydantic_ai.providers.openai import OpenAIProvider

    MockAnthropicMessage = BetaMessage | Exception
    MockRawMessageStreamEvent = BetaRawMessageStreamEvent | Exception

if not imports_successful():  # pragma: lax no cover
    AsyncAnthropicBedrock = AsyncAnthropicBedrockMantle = AsyncAnthropicVertex = AsyncAnthropicFoundry = None

pytestmark = [
    pytest.mark.skipif(not imports_successful(), reason='anthropic not installed'),
    pytest.mark.anyio,
    pytest.mark.vcr,
    pytest.mark.filterwarnings(
        "ignore:The model 'claude-sonnet-4-0' is deprecated and will reach end-of-life.*:DeprecationWarning"
    ),
]

# Type variable for generic AsyncStream
T = TypeVar('T')


def test_init():
    provider = AnthropicProvider(api_key='foobar')
    m = AnthropicModel('claude-haiku-4-5', provider=provider)
    assert isinstance(m.client, AsyncAnthropic)
    assert m.client is provider.client
    assert m.client.api_key == 'foobar'
    assert m.model_name == 'claude-haiku-4-5'
    assert m.system == 'anthropic'
    assert m.base_url == 'https://api.anthropic.com'


@dataclass
class _BrokenClosableStream:
    closed: bool = False

    def __aiter__(self) -> _BrokenClosableStream:
        return self

    async def __anext__(self) -> BetaRawMessageStreamEvent:
        raise httpx2.ReadError('stream closed')

    async def close(self) -> None:
        self.closed = True


def _peekable_broken_stream(
    stream: _BrokenClosableStream,
) -> PeekableAsyncStream[BetaRawMessageStreamEvent, AsyncStream[BetaRawMessageStreamEvent]]:
    return cast(
        PeekableAsyncStream[BetaRawMessageStreamEvent, AsyncStream[BetaRawMessageStreamEvent]],
        PeekableAsyncStream(stream),
    )


async def test_anthropic_cancelled_read_error_is_suppressed():
    stream = _BrokenClosableStream()
    response = AnthropicStreamedResponse(
        model_request_parameters=ModelRequestParameters(),
        _model_name='claude-haiku-4-5',
        _response=_peekable_broken_stream(stream),
        _provider_name='anthropic',
        _model_id_namespace='anthropic',
        _provider_url='https://api.anthropic.com',
        _enabled_server_tool_names=frozenset(),
    )

    await response.cancel()
    assert stream.closed is True
    assert response.cancelled is True

    events = [event async for event in response]
    assert events == []


async def test_anthropic_read_error_is_raised_when_not_cancelled():
    response = AnthropicStreamedResponse(
        model_request_parameters=ModelRequestParameters(),
        _model_name='claude-haiku-4-5',
        _response=_peekable_broken_stream(_BrokenClosableStream()),
        _provider_name='anthropic',
        _model_id_namespace='anthropic',
        _provider_url='https://api.anthropic.com',
        _enabled_server_tool_names=frozenset(),
    )

    with pytest.raises(httpx2.ReadError):
        async for _event in response:
            pass


@dataclass
class MockAnthropic:
    messages_: MockAnthropicMessage | Sequence[MockAnthropicMessage] | None = None
    stream: Sequence[MockRawMessageStreamEvent] | Sequence[Sequence[MockRawMessageStreamEvent]] | None = None
    index = 0
    chat_completion_kwargs: list[dict[str, Any]] = field(default_factory=list[dict[str, Any]])
    base_url: str = 'https://api.anthropic.com'

    @cached_property
    def beta(self) -> AsyncBeta:
        return cast(AsyncBeta, self)

    @cached_property
    def messages(self) -> Any:
        return type('Messages', (), {'create': self.messages_create, 'count_tokens': self.messages_count_tokens})

    @classmethod
    def create_mock(cls, messages_: MockAnthropicMessage | Sequence[MockAnthropicMessage]) -> AsyncAnthropic:
        return cast(AsyncAnthropic, cls(messages_=messages_))

    @classmethod
    def create_stream_mock(
        cls, stream: Sequence[MockRawMessageStreamEvent] | Sequence[Sequence[MockRawMessageStreamEvent]]
    ) -> AsyncAnthropic:
        return cast(AsyncAnthropic, cls(stream=stream))

    async def messages_create(
        self, *_args: Any, stream: bool = False, **kwargs: Any
    ) -> BetaMessage | MockAsyncStream[MockRawMessageStreamEvent]:
        self.chat_completion_kwargs.append({k: v for k, v in kwargs.items() if v is not NOT_GIVEN})

        if stream:
            assert self.stream is not None, 'you can only use `stream=True` if `stream` is provided'
            if isinstance(self.stream[0], Sequence):
                response = MockAsyncStream(iter(cast(list[MockRawMessageStreamEvent], self.stream[self.index])))
            else:
                response = MockAsyncStream(iter(cast(list[MockRawMessageStreamEvent], self.stream)))
        else:
            assert self.messages_ is not None, '`messages` must be provided'
            if isinstance(self.messages_, Sequence):
                raise_if_exception(self.messages_[self.index])
                response = cast(BetaMessage, self.messages_[self.index])
            else:
                raise_if_exception(self.messages_)
                response = cast(BetaMessage, self.messages_)
        self.index += 1
        return response

    async def messages_count_tokens(self, *_args: Any, **kwargs: Any) -> BetaMessageTokensCount:
        # check if we are configured to raise an exception
        if self.messages_ is not None:
            raise_if_exception(self.messages_ if not isinstance(self.messages_, Sequence) else self.messages_[0])

        # record the kwargs used
        self.chat_completion_kwargs.append({k: v for k, v in kwargs.items() if v is not NOT_GIVEN})

        return BetaMessageTokensCount(input_tokens=10)


def completion_message(content: list[BetaContentBlock], usage: BetaUsage) -> BetaMessage:
    return BetaMessage(
        id='123',
        content=content,
        model='claude-3-5-haiku-123',
        role='assistant',
        stop_reason='end_turn',
        type='message',
        usage=usage,
    )


async def test_sync_request_text_response(allow_model_requests: None):
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('hello')
    assert result.output == 'world'
    assert result.usage == snapshot(
        RunUsage(
            requests=1,
            input_tokens=5,
            output_tokens=10,
            details={'input_tokens': 5, 'output_tokens': 10},
            cost=Decimal('0.000044'),
        )
    )
    # reset the index so we get the same response again
    mock_client.index = 0  # pyright: ignore[reportAttributeAccessIssue]

    result = await agent.run('hello', message_history=result.new_messages())
    assert result.output == 'world'
    assert result.usage == snapshot(
        RunUsage(
            requests=1,
            input_tokens=5,
            output_tokens=10,
            details={'input_tokens': 5, 'output_tokens': 10},
            cost=Decimal('0.000044'),
        )
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='hello', timestamp=IsNow(tz=timezone.utc))],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='world')],
                usage=RequestUsage(
                    input_tokens=5,
                    output_tokens=10,
                    details={'input_tokens': 5, 'output_tokens': 10},
                    cost=Decimal('0.000044'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsNow(tz=timezone.utc),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[UserPromptPart(content='hello', timestamp=IsNow(tz=timezone.utc))],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='world')],
                usage=RequestUsage(
                    input_tokens=5,
                    output_tokens=10,
                    details={'input_tokens': 5, 'output_tokens': 10},
                    cost=Decimal('0.000044'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsNow(tz=timezone.utc),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_async_request_prompt_caching(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='world', type='text')],
        usage=BetaUsage(
            input_tokens=3,
            output_tokens=5,
            cache_creation_input_tokens=4,
            cache_read_input_tokens=6,
        ),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('hello')
    assert result.output == 'world'
    assert result.usage == snapshot(
        RunUsage(
            requests=1,
            input_tokens=13,
            cache_write_tokens=4,
            cache_read_tokens=6,
            output_tokens=5,
            details={
                'input_tokens': 3,
                'output_tokens': 5,
                'cache_creation_input_tokens': 4,
                'cache_read_input_tokens': 6,
            },
            cost=Decimal('0.00002688'),
        )
    )
    last_message = message(result.all_messages(), ModelResponse, index=-1)
    assert last_message.cost().total_price == snapshot(Decimal('0.00002688'))


async def test_async_request_thinking_tokens(allow_model_requests: None):
    """Anthropic reports reasoning tokens at `usage.output_tokens_details.thinking_tokens`.

    They are billed within `output_tokens`, so the detail is a readable subset of the output total
    and must not be added to it.
    """
    c = completion_message(
        [BetaTextBlock(text='world', type='text')],
        usage=BetaUsage(
            input_tokens=3,
            output_tokens=100,
            output_tokens_details=BetaOutputTokensDetails(thinking_tokens=40),
        ),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('hello')
    assert result.usage == snapshot(
        RunUsage(
            requests=1,
            input_tokens=3,
            output_tokens=100,
            details={'input_tokens': 3, 'output_tokens': 100, 'thinking_tokens': 40},
            cost=Decimal('0.0004024'),
        )
    )
    assert result.usage.total_tokens == snapshot(103)


async def test_cache_point_adds_cache_control(allow_model_requests: None):
    """Test that CachePoint correctly adds cache_control to content blocks.

    By default, CachePoint uses ttl='5m'.
    """
    c = completion_message(
        [BetaTextBlock(text='response', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # Test with CachePoint after text content (default ttl='5m')
    await agent.run(['Some context to cache', CachePoint(), 'Now the question'])

    # Verify cache_control was added with default ttl='5m'
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']
    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {
                        'text': 'Some context to cache',
                        'type': 'text',
                        'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
                    },
                    {'text': 'Now the question', 'type': 'text'},
                ],
            }
        ]
    )


async def test_cache_point_multiple_markers(allow_model_requests: None):
    """Test multiple CachePoint markers in a single prompt."""
    c = completion_message(
        [BetaTextBlock(text='response', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    await agent.run(['First chunk', CachePoint(), 'Second chunk', CachePoint(), 'Question'])

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    content = completion_kwargs['messages'][0]['content']

    # Default ttl='5m'
    assert content == snapshot(
        [
            {'text': 'First chunk', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}},
            {'text': 'Second chunk', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}},
            {'text': 'Question', 'type': 'text'},
        ]
    )


async def test_cache_point_as_first_content_raises_error(allow_model_requests: None):
    """Test that CachePoint as first content raises UserError."""
    c = completion_message(
        [BetaTextBlock(text='response', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    with pytest.raises(
        UserError,
        match=re.escape(
            'CachePoint cannot be the first content in a user message - there must be previous content to attach the CachePoint to.'
        ),
    ):
        await agent.run([CachePoint(), 'This should fail'])


async def test_cache_point_with_image_content(allow_model_requests: None):
    """Test CachePoint works with image content."""
    c = completion_message(
        [BetaTextBlock(text='response', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    await agent.run(
        [
            ImageUrl('https://example.com/image.jpg'),
            CachePoint(),
            'What is in this image?',
        ]
    )

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    content = completion_kwargs['messages'][0]['content']

    # Default ttl='5m'
    assert content == snapshot(
        [
            {
                'source': {'type': 'url', 'url': 'https://example.com/image.jpg'},
                'type': 'image',
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            },
            {'text': 'What is in this image?', 'type': 'text'},
        ]
    )


async def test_cache_point_in_otel_message_parts(allow_model_requests: None):
    """Test that CachePoint is handled correctly in otel message parts conversion."""
    from pydantic_ai.agent import InstrumentationSettings
    from pydantic_ai.messages import UserPromptPart

    # Create a UserPromptPart with CachePoint
    part = UserPromptPart(content=['text before', CachePoint(), 'text after'])

    # Convert to otel message parts
    settings = InstrumentationSettings(include_content=True)
    otel_parts = part.otel_message_parts(settings)

    # Should have 2 text parts, CachePoint is skipped
    assert otel_parts == snapshot(
        [{'type': 'text', 'content': 'text before'}, {'type': 'text', 'content': 'text after'}]
    )


def test_cache_control_unsupported_param_type():
    """Test that cache control raises error for unsupported param types."""
    from unittest.mock import MagicMock

    from pydantic_ai.exceptions import UserError
    from pydantic_ai.models.anthropic import AnthropicModel

    # Create a mock model instance
    mock_client = MagicMock()
    mock_client.__class__.__name__ = 'AsyncAnthropic'
    mock_client.base_url = 'https://api.anthropic.com'
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    # Create a list with an unsupported param type (thinking)
    params: list[dict[str, Any]] = [{'type': 'thinking', 'source': {'data': 'test'}}]

    with pytest.raises(UserError, match='Cache control not supported for param type: thinking'):
        m._add_cache_control_to_last_param(params)  # type: ignore[arg-type]  # Testing internal method


def test_cache_control_last_cacheable_param_allows_empty_params():
    """Empty-params guard for the cache-control walk — a defensive branch no real API response reaches, so it's a unit test, not VCR."""
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key='test-key'))
    params: list[Any] = []

    m._add_cache_control_to_last_cacheable_param(params)  # pyright: ignore[reportPrivateUsage]

    assert params == []


def test_build_cache_control_includes_ttl():
    """Test that _build_cache_control includes TTL for all clients, including Bedrock."""
    from unittest.mock import MagicMock

    from anthropic import AsyncAnthropicBedrock

    mock_bedrock_client = MagicMock(spec=AsyncAnthropicBedrock)
    mock_bedrock_client.base_url = 'https://bedrock.amazonaws.com'

    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_bedrock_client))

    cache_control = m._build_cache_control('5m')  # pyright: ignore[reportPrivateUsage]
    assert cache_control == {'type': 'ephemeral', 'ttl': '5m'}

    cache_control_1h = m._build_cache_control('1h')  # pyright: ignore[reportPrivateUsage]
    assert cache_control_1h == {'type': 'ephemeral', 'ttl': '1h'}


def _mock_anthropic_client(client_cls: Any, base_url: str) -> Any:
    from unittest.mock import MagicMock

    client = MagicMock(spec=client_cls)
    client.base_url = base_url
    return client


@pytest.mark.parametrize(
    'model_name',
    [
        'anthropic.claude-haiku-4-5',
        'anthropic.claude-haiku-4-5-20251001-v1:0',
        'us.anthropic.claude-haiku-4-5-20251001-v1:0',
    ],
)
@pytest.mark.parametrize(
    'client_cls,base_url',
    [
        pytest.param(AsyncAnthropicBedrock, 'https://bedrock-runtime.us-east-1.amazonaws.com', id='bedrock'),
        pytest.param(AsyncAnthropicBedrockMantle, 'https://bedrock-mantle.us-east-1.api.aws', id='bedrock-mantle'),
    ],
)
def test_anthropic_model_resolves_profile_for_bedrock_model_ids(model_name: str, client_cls: Any, base_url: str):
    """A Bedrock-shaped model id resolves to the right capability profile, while the full id still goes on the wire."""
    m = AnthropicModel(
        model_name, provider=AnthropicProvider(anthropic_client=_mock_anthropic_client(client_cls, base_url))
    )
    assert m.model_name == model_name
    assert m.profile.get('supports_json_schema_output', False) is True
    assert ToolSearchTool in m.profile.get('supported_native_tools', SUPPORTED_NATIVE_TOOLS)


def _tool_search_param(client_cls: Any, base_url: str, tool: ToolSearchTool) -> dict[str, Any]:
    m = AnthropicModel(
        'claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=_mock_anthropic_client(client_cls, base_url))
    )
    tools, _, _ = m._add_native_tools(  # pyright: ignore[reportPrivateUsage]
        [], ModelRequestParameters(native_tools=[tool]), AnthropicModelSettings()
    )
    return cast('dict[str, Any]', next(t for t in tools if str(t.get('name', '')).startswith('tool_search_tool_')))


def test_anthropic_tool_search_defaults_to_regex_on_legacy_bedrock():
    """The legacy Bedrock InvokeModel API doesn't support `bm25`, so the default strategy is `regex` there."""
    base_url = 'https://bedrock-runtime.us-east-1.amazonaws.com'
    param = _tool_search_param(AsyncAnthropicBedrock, base_url, ToolSearchTool())
    assert param == {'type': 'tool_search_tool_regex_20251119', 'name': 'tool_search_tool_regex'}
    # An explicit `regex` is honored.
    param = _tool_search_param(AsyncAnthropicBedrock, base_url, ToolSearchTool(strategy='regex'))
    assert param == {'type': 'tool_search_tool_regex_20251119', 'name': 'tool_search_tool_regex'}


def test_anthropic_tool_search_bm25_rejected_on_legacy_bedrock():
    """An explicit `bm25` strategy on the legacy Bedrock InvokeModel API is a `UserError`, not an opaque 400."""
    m = AnthropicModel(
        'claude-haiku-4-5',
        provider=AnthropicProvider(
            anthropic_client=_mock_anthropic_client(
                AsyncAnthropicBedrock, 'https://bedrock-runtime.us-east-1.amazonaws.com'
            )
        ),
    )
    with pytest.raises(
        UserError, match="ToolSearch\\(strategy='bm25'\\) is not supported by the `AsyncAnthropicBedrock` client"
    ):
        m._add_native_tools(  # pyright: ignore[reportPrivateUsage]
            [], ModelRequestParameters(native_tools=[ToolSearchTool(strategy='bm25')]), AnthropicModelSettings()
        )


def test_anthropic_tool_search_defaults_to_bm25_on_non_legacy_bedrock_clients():
    """`bm25` stays the default on clients not in `_BM25_TOOL_SEARCH_UNSUPPORTED_CLIENTS` —
    e.g. the (Messages-API-based) Bedrock Mantle client, like the direct Anthropic API."""
    param = _tool_search_param(
        AsyncAnthropicBedrockMantle, 'https://bedrock-mantle.us-east-1.api.aws', ToolSearchTool()
    )
    assert param == {'type': 'tool_search_tool_bm25_20251119', 'name': 'tool_search_tool_bm25'}


@pytest.mark.parametrize(
    'cache_value,expected_ttl',
    [
        pytest.param(True, '5m', id='default-5m'),
        pytest.param('1h', '1h', id='custom-1h'),
    ],
)
@pytest.mark.parametrize(
    'client_cls,base_url',
    [
        pytest.param(AsyncAnthropicBedrock, 'https://bedrock.amazonaws.com', id='bedrock'),
        pytest.param(AsyncAnthropicVertex, 'https://us-central1-aiplatform.googleapis.com', id='vertex'),
    ],
)
async def test_anthropic_cache_fallback_on_unsupported_clients(
    allow_model_requests: None,
    cache_value: bool | Literal['1h'],
    expected_ttl: str,
    client_cls: type[Any],
    base_url: str,
):
    """Test that anthropic_cache falls back to per-block caching on Bedrock and Vertex.

    On these platforms the top-level cache_control parameter is not supported,
    so per-block cache_control is applied to the last user message instead.
    """
    from unittest.mock import AsyncMock, MagicMock

    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))

    mock_client = MagicMock()
    mock_client.__class__ = client_cls
    mock_client.base_url = base_url
    mock_client.beta.messages.create = AsyncMock(return_value=c)

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model, model_settings=AnthropicModelSettings(anthropic_cache=cache_value))

    result = await agent.run('Hello')
    assert result.output == 'Response'

    call_kwargs = mock_client.beta.messages.create.call_args.kwargs
    assert call_kwargs['cache_control'] is OMIT
    last_user_msg = call_kwargs['messages'][-1]
    content = last_user_msg['content']
    assert content[-1]['cache_control'] == {'type': 'ephemeral', 'ttl': expected_ttl}


@pytest.mark.parametrize(
    'cache_value,expected_ttl',
    [
        pytest.param(True, '5m', id='default-5m'),
        pytest.param('1h', '1h', id='custom-1h'),
    ],
)
async def test_anthropic_cache_messages_uses_per_block_cache_control(
    allow_model_requests: None,
    cache_value: bool | Literal['1h'],
    expected_ttl: str,
):
    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model, model_settings=AnthropicModelSettings(anthropic_cache_messages=cache_value))

    result = await agent.run('Hello')
    assert result.output == 'Response'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['cache_control'] is OMIT
    assert completion_kwargs['messages'] == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {
                        'text': 'Hello',
                        'type': 'text',
                        'cache_control': {'type': 'ephemeral', 'ttl': expected_ttl},
                    }
                ],
            }
        ]
    )


async def test_anthropic_cache_messages_preserves_existing_cache_point(allow_model_requests: None):
    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model, model_settings=AnthropicModelSettings(anthropic_cache_messages=True))

    result = await agent.run(['Some context', CachePoint(ttl='1h')])
    assert result.output == 'Response'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    content = completion_kwargs['messages'][-1]['content']
    assert content == snapshot(
        [{'text': 'Some context', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '1h'}}]
    )


async def test_anthropic_code_execution_files_with_message_cache(allow_model_requests: None):
    """Pins that the non-cacheable `container_upload` block doesn't capture the cache breakpoint (it lands on the text instead).

    Not a VCR test: cassette matchers aren't sensitive to `cache_control` placement in the request body, so this asserts the built payload via the mock client.
    """
    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        model,
        capabilities=[
            NativeTool(
                CodeExecutionTool(
                    files=[
                        UploadedFile(file_id='file_anthropic', provider_name='anthropic'),
                        UploadedFile(file_id='file_openai', provider_name='openai'),
                    ]
                )
            )
        ],
        model_settings=AnthropicModelSettings(anthropic_cache_messages=True),
    )

    result = await agent.run('Use the attached file.')
    assert result.output == 'Response'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert 'files-api-2025-04-14' in completion_kwargs['betas']
    assert completion_kwargs['messages'] == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {
                        'text': 'Use the attached file.',
                        'type': 'text',
                        'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
                    },
                    {'file_id': 'file_anthropic', 'type': 'container_upload'},
                ],
            }
        ]
    )


async def test_anthropic_code_execution_files_append_to_first_user_message(allow_model_requests: None):
    """Pins the internal `_map_message` placement: uploads attach to the *first* user message (keeping the cacheable prefix byte-identical as history grows), not a later one, and none are added when history has no user message.

    Not a VCR test: the first-vs-later placement and the no-user-message branch can't be reached through a single agent run, so it taps `_map_message` directly.
    """
    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
    mock_client = MockAnthropic.create_mock(c)
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    parameters = ModelRequestParameters(
        native_tools=[
            CodeExecutionTool(files=[UploadedFile(file_id='file_anthropic', provider_name='anthropic')]),
        ]
    )

    _, messages = await model._map_message(  # pyright: ignore[reportPrivateUsage]
        [
            ModelRequest(parts=[UserPromptPart(content='Use the attached file.')]),
            ModelResponse(parts=[TextPart(content='Previous response')]),
            ModelRequest(parts=[UserPromptPart(content='And now summarize it.')]),
        ],
        parameters,
        AnthropicModelSettings(),
    )

    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {'text': 'Use the attached file.', 'type': 'text'},
                    {'file_id': 'file_anthropic', 'type': 'container_upload'},
                ],
            },
            {'role': 'assistant', 'content': [{'text': 'Previous response', 'type': 'text'}]},
            {'role': 'user', 'content': [{'text': 'And now summarize it.', 'type': 'text'}]},
        ]
    )

    _, messages = await model._map_message(  # pyright: ignore[reportPrivateUsage]
        [ModelResponse(parts=[TextPart(content='Previous response')])],
        parameters,
        AnthropicModelSettings(),
    )

    assert messages == snapshot([{'role': 'assistant', 'content': [{'text': 'Previous response', 'type': 'text'}]}])


async def test_anthropic_cache_and_cache_messages_conflict(allow_model_requests: None):
    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        model,
        model_settings=AnthropicModelSettings(anthropic_cache=True, anthropic_cache_messages=True),
    )

    with pytest.raises(UserError, match='`anthropic_cache` and `anthropic_cache_messages` cannot both be enabled'):
        await agent.run('Hello')


async def test_anthropic_cache_fallback_preserves_existing_cache_control(allow_model_requests: None):
    """Test that per-block fallback does not overwrite explicit CachePoint cache_control on Bedrock."""
    from unittest.mock import AsyncMock, MagicMock

    from anthropic import AsyncAnthropicBedrock

    c = completion_message([BetaTextBlock(text='Response', type='text')], BetaUsage(input_tokens=10, output_tokens=5))

    mock_client = MagicMock()
    mock_client.__class__ = AsyncAnthropicBedrock  # pyright: ignore[reportAttributeAccessIssue]
    mock_client.base_url = 'https://bedrock.amazonaws.com'
    mock_client.beta.messages.create = AsyncMock(return_value=c)

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model, model_settings=AnthropicModelSettings(anthropic_cache=True))

    # CachePoint(ttl='1h') attaches to the preceding block, making it the last content block
    # with cache_control already set. The fallback should preserve the user's '1h' TTL.
    result = await agent.run(['Some context', CachePoint(ttl='1h')])
    assert result.output == 'Response'

    call_kwargs = mock_client.beta.messages.create.call_args.kwargs
    last_user_msg = call_kwargs['messages'][-1]
    content = last_user_msg['content']
    assert content[-1]['cache_control'] == {'type': 'ephemeral', 'ttl': '1h'}


def test_build_cache_control_standard_client_includes_ttl():
    """Test that _build_cache_control includes TTL for standard Anthropic clients."""
    from unittest.mock import MagicMock

    # Create a mock client that looks like standard AsyncAnthropic
    mock_client = MagicMock()
    mock_client.__class__.__name__ = 'AsyncAnthropic'
    mock_client.base_url = 'https://api.anthropic.com'

    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    # Verify cache_control includes TTL for standard clients
    cache_control = m._build_cache_control('5m')  # pyright: ignore[reportPrivateUsage]
    assert cache_control == {'type': 'ephemeral', 'ttl': '5m'}

    cache_control_1h = m._build_cache_control('1h')  # pyright: ignore[reportPrivateUsage]
    assert cache_control_1h == {'type': 'ephemeral', 'ttl': '1h'}


async def test_cache_point_with_5m_ttl(allow_model_requests: None):
    """Test that CachePoint with explicit ttl='5m' includes the ttl field."""
    c = completion_message(
        [BetaTextBlock(text='response', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # Test with explicit CachePoint(ttl='5m')
    await agent.run(['Some context to cache', CachePoint(ttl='5m'), 'Now the question'])

    # Verify cache_control was added with 5m ttl
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']
    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {
                        'text': 'Some context to cache',
                        'type': 'text',
                        'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
                    },
                    {'text': 'Now the question', 'type': 'text'},
                ],
            }
        ]
    )


async def test_cache_point_with_1h_ttl(allow_model_requests: None):
    """Test that CachePoint with ttl='1h' correctly sets the TTL."""
    c = completion_message(
        [BetaTextBlock(text='response', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # Test with CachePoint(ttl='1h')
    await agent.run(['Some context to cache', CachePoint(ttl='1h'), 'Now the question'])

    # Verify cache_control was added with 1h ttl
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']
    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {
                        'text': 'Some context to cache',
                        'type': 'text',
                        'cache_control': {'type': 'ephemeral', 'ttl': '1h'},
                    },
                    {'text': 'Now the question', 'type': 'text'},
                ],
            }
        ]
    )


async def test_anthropic_cache_tools(allow_model_requests: None):
    """Test that anthropic_cache_tool_definitions adds cache_control to last tool."""
    c = completion_message(
        [BetaTextBlock(text='Tool result', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='Test system prompt',
        model_settings=AnthropicModelSettings(anthropic_cache_tool_definitions=True),
    )

    @agent.tool_plain
    def tool_one() -> str:  # pragma: no cover
        return 'one'

    @agent.tool_plain
    def tool_two() -> str:  # pragma: no cover
        return 'two'

    await agent.run('test prompt')

    # Verify cache_control was added to the last tool
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    tools = completion_kwargs['tools']
    has_strict_tools = any('strict' in tool for tool in tools)  # we only ever set strict: True
    assert has_strict_tools is False  # ensure strict is not set for haiku-4-5
    assert tools == snapshot(
        [
            {
                'name': 'tool_one',
                'description': '',
                'input_schema': {'additionalProperties': False, 'properties': {}, 'type': 'object'},
            },
            {
                'name': 'tool_two',
                'description': '',
                'input_schema': {'additionalProperties': False, 'properties': {}, 'type': 'object'},
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            },
        ]
    )


async def test_anthropic_eager_input_streaming(allow_model_requests: None):
    """Test that anthropic_eager_input_streaming sets eager_input_streaming on all tools."""
    c = completion_message(
        [BetaTextBlock(text='Tool result', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='Test system prompt',
        model_settings=AnthropicModelSettings(anthropic_eager_input_streaming=True),
    )

    @agent.tool_plain
    def tool_one() -> str:  # pragma: no cover
        return 'one'

    @agent.tool_plain
    def tool_two() -> str:  # pragma: no cover
        return 'two'

    await agent.run('test prompt')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    tools = completion_kwargs['tools']
    assert tools == snapshot(
        [
            {
                'name': 'tool_one',
                'description': '',
                'input_schema': {'additionalProperties': False, 'properties': {}, 'type': 'object'},
                'eager_input_streaming': True,
            },
            {
                'name': 'tool_two',
                'description': '',
                'input_schema': {'additionalProperties': False, 'properties': {}, 'type': 'object'},
                'eager_input_streaming': True,
            },
        ]
    )


async def test_anthropic_cache_instructions(allow_model_requests: None):
    """Test that anthropic_cache_instructions adds cache_control to system prompt."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='This is a test system prompt with instructions.',
        model_settings=AnthropicModelSettings(anthropic_cache_instructions=True),
    )

    await agent.run('test prompt')

    # Verify system is a list with cache_control on last block
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    system = completion_kwargs['system']
    assert system == snapshot(
        [
            {
                'type': 'text',
                'text': 'This is a test system prompt with instructions.',
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            }
        ]
    )


async def test_anthropic_cache_tools_and_instructions(allow_model_requests: None):
    """Test that both cache settings work together."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='System instructions to cache.',
        model_settings=AnthropicModelSettings(
            anthropic_cache_tool_definitions=True,
            anthropic_cache_instructions=True,
        ),
    )

    @agent.tool_plain
    def my_tool(value: str) -> str:  # pragma: no cover
        return f'Result: {value}'

    await agent.run('test prompt')

    # Verify both have cache_control
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    tools = completion_kwargs['tools']
    system = completion_kwargs['system']
    has_strict_tools = any('strict' in tool for tool in tools)  # we only ever set strict: True
    assert has_strict_tools is False  # ensure strict is not set for haiku-4-5
    assert tools == snapshot(
        [
            {
                'name': 'my_tool',
                'description': '',
                'input_schema': {
                    'additionalProperties': False,
                    'properties': {'value': {'type': 'string'}},
                    'required': ['value'],
                    'type': 'object',
                },
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            }
        ]
    )
    assert system == snapshot(
        [{'type': 'text', 'text': 'System instructions to cache.', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}}]
    )


async def test_anthropic_cache_with_custom_ttl(allow_model_requests: None):
    """Test that cache settings support custom TTL values ('5m' or '1h')."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='System instructions to cache.',
        model_settings=AnthropicModelSettings(
            anthropic_cache_tool_definitions='1h',  # Custom 1h TTL
            anthropic_cache_instructions='5m',  # Explicit 5m TTL
        ),
    )

    @agent.tool_plain
    def my_tool(value: str) -> str:  # pragma: no cover
        return f'Result: {value}'

    await agent.run('test prompt')

    # Verify custom TTL values are applied
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    tools = completion_kwargs['tools']
    system = completion_kwargs['system']

    # Tool definitions should have 1h TTL
    assert tools[0]['cache_control'] == snapshot({'type': 'ephemeral', 'ttl': '1h'})
    # System instructions should have 5m TTL
    assert system[0]['cache_control'] == snapshot({'type': 'ephemeral', 'ttl': '5m'})


async def test_anthropic_cache_instructions_mixed_static_dynamic(allow_model_requests: None):
    """Test that cache_control is placed after the last static instruction when mixed with dynamic."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        instructions='Static instructions that should be cached.',
        model_settings=AnthropicModelSettings(anthropic_cache_instructions=True),
    )

    @agent.instructions
    def dynamic_context() -> str:
        return 'Dynamic context that changes per run.'

    await agent.run('test prompt')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    system = completion_kwargs['system']
    # Should have 2 blocks: static (with cache_control) and dynamic (without)
    assert system == snapshot(
        [
            {
                'type': 'text',
                'text': 'Static instructions that should be cached.',
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            },
            {
                'type': 'text',
                'text': 'Dynamic context that changes per run.',
            },
        ]
    )


async def test_anthropic_cache_instructions_all_dynamic(allow_model_requests: None):
    """Test that when all instructions are dynamic, no cache_control is placed on instructions."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='A static system prompt.',
        model_settings=AnthropicModelSettings(anthropic_cache_instructions=True),
    )

    @agent.instructions
    def dynamic_instructions() -> str:
        return 'Dynamic instructions only.'

    await agent.run('test prompt')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    system = completion_kwargs['system']
    # System prompt block gets cache_control (it's static), dynamic instructions don't
    assert system == snapshot(
        [
            {
                'type': 'text',
                'text': 'A static system prompt.',
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            },
            {
                'type': 'text',
                'text': 'Dynamic instructions only.',
            },
        ]
    )


async def test_anthropic_cache_instructions_all_static_with_toolset(allow_model_requests: None):
    """Test all-static cache placement with multiple instruction sources."""
    from pydantic_ai import FunctionToolset

    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    toolset = FunctionToolset(instructions='Use the tools wisely.')
    agent = Agent(
        m,
        instructions='You are a helpful assistant.',
        toolsets=[toolset],
        model_settings=AnthropicModelSettings(anthropic_cache_instructions=True),
    )

    await agent.run('test prompt')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    system = completion_kwargs['system']
    # All instruction parts are static — cache_control on the last block
    assert system == snapshot(
        [
            {
                'type': 'text',
                'text': 'You are a helpful assistant.',
            },
            {
                'type': 'text',
                'text': 'Use the tools wisely.',
                'cache_control': {'type': 'ephemeral', 'ttl': '5m'},
            },
        ]
    )


async def test_anthropic_cache_instructions_all_dynamic_no_system_prompt(allow_model_requests: None):
    """Test all-dynamic instructions with no system prompt — no cache_control at all."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        model_settings=AnthropicModelSettings(anthropic_cache_instructions=True),
    )

    @agent.instructions
    def dynamic_only() -> str:
        return 'Dynamic instructions.'

    await agent.run('test prompt')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    system = completion_kwargs['system']
    # No system prompt, all dynamic → no cache_control
    assert system == snapshot(
        [
            {
                'type': 'text',
                'text': 'Dynamic instructions.',
            },
        ]
    )


async def test_anthropic_cache_instructions_no_instructions(allow_model_requests: None):
    """Test that cache_instructions with no actual instructions works gracefully."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        model_settings=AnthropicModelSettings(anthropic_cache_instructions=True),
    )

    await agent.run('test prompt')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    # No system prompts or instructions — system param is omitted
    assert 'system' not in completion_kwargs or not completion_kwargs['system']


async def test_anthropic_incompatible_schema_disables_auto_strict(allow_model_requests: None):
    """Ensure strict mode is disabled when Anthropic cannot enforce the tool schema."""
    c = completion_message(
        [BetaTextBlock(text='Done', type='text')],
        usage=BetaUsage(input_tokens=8, output_tokens=3),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    @agent.tool_plain
    def constrained_tool(value: Annotated[str, Field(min_length=2)]) -> str:  # pragma: no cover
        return value

    await agent.run('hello')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert 'strict' not in completion_kwargs['tools'][0]


async def test_beta_header_merge_builtin_tools_and_native_output(allow_model_requests: None):
    """Verify beta headers merge from custom headers, builtin tools, and native output."""
    c = completion_message(
        [BetaTextBlock(text='{"city": "Mexico City", "country": "Mexico"}', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    class CityLocation(BaseModel):
        """A city and its country."""

        city: str
        country: str

    model = AnthropicModel(
        'claude-sonnet-4-5',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(extra_headers={'anthropic-beta': 'custom-feature-1, custom-feature-2'}),
    )

    agent = Agent(
        model,
        capabilities=[NativeTool(MemoryTool())],
        output_type=NativeOutput(CityLocation),
    )

    @agent.tool_plain
    def memory(**command: Any) -> Any:  # pragma: no cover
        return 'memory response'

    await agent.run('What is the capital of France?')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    betas = completion_kwargs['betas']

    assert betas == snapshot(
        [
            'context-management-2025-06-27',
            'custom-feature-1',
            'custom-feature-2',
        ]
    )


async def test_model_settings_reusable_with_beta_headers(allow_model_requests: None):
    """Verify that model_settings with extra_headers can be reused across multiple runs.

    This test ensures that the beta header extraction doesn't mutate the original model_settings,
    allowing the same settings to be used for multiple agent runs.
    """
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model_settings = AnthropicModelSettings(extra_headers={'anthropic-beta': 'custom-feature-1, custom-feature-2'})

    model = AnthropicModel(
        'claude-sonnet-4-5',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=model_settings,
    )

    agent = Agent(model)

    # First run
    await agent.run('Hello')

    # Verify the original model_settings is not mutated
    assert model_settings.get('extra_headers') == {'anthropic-beta': 'custom-feature-1, custom-feature-2'}

    # Second run should work with the same beta headers
    await agent.run('Hello again')

    # Verify again after second run
    assert model_settings.get('extra_headers') == {'anthropic-beta': 'custom-feature-1, custom-feature-2'}

    # Verify both runs had the correct betas
    all_kwargs = get_mock_chat_completion_kwargs(mock_client)
    assert len(all_kwargs) == 2
    for completion_kwargs in all_kwargs:
        betas = completion_kwargs['betas']
        assert 'custom-feature-1' in betas
        assert 'custom-feature-2' in betas


@pytest.mark.vcr()
async def test_anthropic_sampling_settings_reach_the_wire(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """Sampling settings still reach the API on models that honor them.

    `anthropic>=1` dropped `temperature`/`top_p`/`top_k` from `messages.create()`'s signature, so
    Pydantic AI sends them through `extra_body` instead. Asserted on the wire rather than on the SDK
    call: `extra_body` arriving at the client says nothing about the request body it then builds.

    `top_p` is left out because the model rejects it alongside `temperature` with "`temperature` and
    `top_p` cannot both be specified for this model" — all three settings travel the same path, so
    one of the pair is enough to pin it.
    """
    agent = Agent(anthropic_model('claude-haiku-4-5', capture=True))

    await agent.run('hello', model_settings=ModelSettings(temperature=0.2, top_k=40))

    body = request_capture.body('/v1/messages')
    assert {key: value for key, value in body.items() if key in ('temperature', 'top_p', 'top_k')} == snapshot(
        {'temperature': 0.2, 'top_k': 40}
    )


async def test_anthropic_betas_setting(allow_model_requests: None):
    """Verify anthropic_betas setting adds betas to the API request."""
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel(
        'claude-sonnet-4-5',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_betas=['interleaved-thinking-2025-05-14'],
        ),
    )
    agent = Agent(model)

    await agent.run('Hello')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    betas = completion_kwargs['betas']
    assert 'interleaved-thinking-2025-05-14' in betas


async def test_anthropic_betas_merge_with_other_sources(allow_model_requests: None):
    """Verify anthropic_betas merges with auto-added betas and extra_headers anthropic-beta."""
    c = completion_message(
        [BetaTextBlock(text='{"city": "Paris", "country": "France"}', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    class CityLocation(BaseModel):
        city: str
        country: str

    model = AnthropicModel(
        'claude-sonnet-4-5',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_betas=['interleaved-thinking-2025-05-14'],
            extra_headers={'anthropic-beta': 'custom-feature-1'},
        ),
    )
    agent = Agent(model, output_type=NativeOutput(CityLocation))

    await agent.run('What is the capital of France?')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    betas = completion_kwargs['betas']
    assert 'interleaved-thinking-2025-05-14' in betas
    assert 'custom-feature-1' in betas


async def test_anthropic_native_output_decimal_strict(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))

    class Payment(BaseModel):
        amount: Decimal

    agent = Agent(m, output_type=NativeOutput(Payment, strict=True))

    result = await agent.run('Return exactly this payment amount: 12.34')
    assert result.output == snapshot(Payment(amount=Decimal('12.34')))


async def test_anthropic_task_budget_adds_output_config_and_beta(
    allow_model_requests: None, anthropic_api_key: str, vcr: Cassette
):
    m = AnthropicModel('claude-opus-4-7', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(
        m,
        model_settings=AnthropicModelSettings(
            anthropic_task_budget={'type': 'tokens', 'total': 20_000, 'remaining': 500},
        ),
    )

    result = await agent.run('What is 2+2?')
    assert result.output

    assert single_request_body(vcr)['output_config'] == snapshot(
        {'task_budget': {'type': 'tokens', 'total': 20_000, 'remaining': 500}}
    )


async def test_anthropic_task_budget_merges_with_other_beta_sources(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel(
        'claude-opus-4-7',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_task_budget={'type': 'tokens', 'total': 2_000},
            anthropic_betas=['interleaved-thinking-2025-05-14'],
            extra_headers={'anthropic-beta': 'custom-feature-1'},
        ),
    )
    agent = Agent(model)

    await agent.run('Hello')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert set(completion_kwargs['betas']) >= {
        'task-budgets-2026-03-13',
        'interleaved-thinking-2025-05-14',
        'custom-feature-1',
    }


async def test_anthropic_task_budget_rejects_unsupported_model(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel(
        'claude-opus-4-6',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_task_budget={'type': 'tokens', 'total': 2_000},
        ),
    )
    agent = Agent(model)

    with pytest.raises(UserError, match='does not support `anthropic_task_budget`'):
        await agent.run('Hello')


@pytest.mark.parametrize('effort', ['xhigh', 'max'])
async def test_anthropic_opus_5_rejects_top_effort_when_thinking_disabled(
    allow_model_requests: None, effort: Literal['xhigh', 'max']
):
    """Claude Opus 5 caps effort at `high` once thinking is explicitly disabled.

    Verified live: `claude-opus-5` returns a 400 (`output_config.effort 'xhigh' is not supported
    when thinking is disabled on this model`) for `xhigh` and `max`, while `claude-opus-4-8`
    accepts the same combination. We surface it as a `UserError` before sending the request.
    """
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    settings = AnthropicModelSettings(
        anthropic_thinking={'type': 'disabled'},
        anthropic_effort=effort,
    )
    model = AnthropicModel('claude-opus-5', provider=AnthropicProvider(anthropic_client=mock_client), settings=settings)

    with pytest.raises(UserError, match='does not support `anthropic_effort='):
        await Agent(model).run('Hello')

    # Opus 4.8 has the flag off, so the same settings go through untouched.
    allowed = AnthropicModel(
        'claude-opus-4-8', provider=AnthropicProvider(anthropic_client=mock_client), settings=settings
    )
    assert (await Agent(allowed).run('Hello')).output == 'Hello!'


async def test_anthropic_task_budget_remaining_rejects_server_side_compaction(allow_model_requests: None):
    """`task_budget.remaining` and `AnthropicCompaction` are mutually exclusive.

    Anthropic's API rejects requests that combine `output_config.task_budget.remaining`
    with server-side `AnthropicCompaction`; we surface this as a `UserError` before
    sending the request so users see a clear message instead of an opaque 400.
    """
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel(
        'claude-opus-4-7',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_task_budget={'type': 'tokens', 'total': 50_000, 'remaining': 10_000},
        ),
    )
    agent = Agent(model, capabilities=[AnthropicCompaction(token_threshold=50_000)])

    with pytest.raises(UserError, match='cannot be combined with `AnthropicCompaction`'):
        await agent.run('Hello')


async def test_anthropic_task_budget_remaining_allows_non_compact_context_management(allow_model_requests: None):
    """`task_budget.remaining` is allowed alongside non-`compact_20260112` context-management edits."""
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel(
        'claude-opus-4-7',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_task_budget={'type': 'tokens', 'total': 50_000, 'remaining': 10_000},
            anthropic_context_management={'edits': [{'type': 'clear_tool_uses_20250919'}]},
        ),
    )
    agent = Agent(model)

    result = await agent.run('Hello')
    assert result.output == 'Hello!'


async def test_anthropic_task_budget_remaining_rejects_compaction_part_in_history(allow_model_requests: None):
    """`task_budget.remaining` is rejected when history contains a `CompactionPart`.

    `_add_compaction_params` auto-generates a `compact_20260112` config when messages contain
    `CompactionPart`s even without explicit `anthropic_context_management`, so the validator
    must run after that step to still surface a `UserError` instead of an opaque 400.

    Regression test for PR #5140 review feedback (validation ordering).
    https://github.com/pydantic/pydantic-ai/pull/5140
    """
    c = completion_message(
        [BetaTextBlock(text='Hello!', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)

    model = AnthropicModel(
        'claude-opus-4-7',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(
            anthropic_task_budget={'type': 'tokens', 'total': 50_000, 'remaining': 10_000},
        ),
    )
    agent = Agent(model)

    message_history: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='Earlier turn.')]),
        ModelResponse(
            parts=[CompactionPart(content='Summary of earlier turn.', provider_name='anthropic')],
            provider_name='anthropic',
        ),
    ]

    with pytest.raises(UserError, match='cannot be combined with `AnthropicCompaction`'):
        await agent.run('Hello', message_history=message_history)


async def test_anthropic_mixed_strict_tool_run(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """Exercise both strict=True and strict=False tool definitions against the live API."""
    m = anthropic_model('claude-sonnet-4-5', capture=True)
    agent = Agent(
        m,
        system_prompt='Always call `country_source` first, then call `capital_lookup` with that result before replying.',
    )

    @agent.tool_plain(strict=True)
    async def country_source() -> str:
        return 'Japan'

    capital_called = {'value': False}

    @agent.tool_plain(strict=False)
    async def capital_lookup(country: str) -> str:
        capital_called['value'] = True
        if country == 'Japan':
            return 'Tokyo'
        return f'Unknown capital for {country}'  # pragma: no cover

    result = await agent.run('Use the registered tools and respond exactly as `Capital: <city>`.')
    assert content_blocks(request_capture.body(), 'tool_result') == snapshot([])
    assert capital_called['value'] is True
    assert result.output.startswith('Capital:')
    assert any(
        isinstance(part, ToolCallPart) and part.tool_name == 'capital_lookup'
        for message in result.all_messages()
        if isinstance(message, ModelResponse)
        for part in message.parts
    )


async def test_limit_cache_points_with_cache_messages(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        system_prompt='System instructions.',
        model_settings=AnthropicModelSettings(
            anthropic_cache_messages=True,
        ),
    )

    await agent.run(
        [
            'Context 1',
            CachePoint(),  # oldest, trimmed because total cache points (4 explicit + 1 from cache_messages) exceeds the budget of 4
            'Context 2',
            CachePoint(),
            'Context 3',
            CachePoint(),
            'Context 4',
            CachePoint(),
            'Question',
        ]
    )

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']
    assert completion_kwargs['cache_control'] is OMIT

    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {'text': 'Context 1', 'type': 'text'},
                    {'text': 'Context 2', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}},
                    {'text': 'Context 3', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}},
                    {'text': 'Context 4', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}},
                    {'text': 'Question', 'type': 'text', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}},
                ],
            }
        ]
    )


async def test_limit_cache_points_all_settings(allow_model_requests: None):
    """Test cache point limiting with all cache settings enabled."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    agent = Agent(
        m,
        system_prompt='System instructions.',
        model_settings=AnthropicModelSettings(
            anthropic_cache_instructions=True,  # 1 cache point
            anthropic_cache_tool_definitions=True,  # 1 cache point
        ),
    )

    @agent.tool_plain
    def my_tool() -> str:  # pragma: no cover
        return 'result'

    # Add 3 CachePoint markers (total would be 5: 2 from settings + 3 from markers)
    # Only 2 CachePoint markers should be kept
    await agent.run(
        [
            'Context 1',
            CachePoint(),  # Oldest, should be removed
            'Context 2',
            CachePoint(),  # Should be kept
            'Context 3',
            CachePoint(),  # Should be kept
            'Question',
        ]
    )

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']

    # Count cache_control in messages (excluding system and tools)
    cache_count = 0
    for msg in messages:
        for block in msg['content']:
            if 'cache_control' in block:
                cache_count += 1

    # Should have exactly 2 cache points in messages
    # (4 total - 1 system - 1 tool = 2 available for messages)
    assert cache_count == 2


@pytest.mark.parametrize(
    'setting,expected_ttl',
    [
        pytest.param(True, '5m', id='default-5m'),
        pytest.param('5m', '5m', id='explicit-5m'),
        pytest.param('1h', '1h', id='custom-1h'),
    ],
)
async def test_anthropic_cache(allow_model_requests: None, setting: bool | Literal['5m', '1h'], expected_ttl: str):
    """Test that anthropic_cache passes top-level cache_control with the correct TTL."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        model,
        system_prompt='System instructions.',
        model_settings=AnthropicModelSettings(anthropic_cache=setting),
    )

    await agent.run('User message')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['cache_control'] == {'type': 'ephemeral', 'ttl': expected_ttl}

    # System prompt should remain a plain string (no per-block cache_control added)
    assert completion_kwargs['system'] == 'System instructions.'


async def test_anthropic_cache_with_explicit_breakpoints(allow_model_requests: None):
    """Test combining automatic caching with explicit cache breakpoints."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        model,
        system_prompt='System instructions.',
        model_settings=AnthropicModelSettings(
            anthropic_cache=True,
            anthropic_cache_instructions=True,
            anthropic_cache_tool_definitions=True,
        ),
    )

    @agent.tool_plain
    def my_tool() -> str:  # pragma: no cover
        return 'result'

    await agent.run('User message')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]

    # Top-level cache_control for automatic caching
    assert completion_kwargs['cache_control'] == snapshot({'type': 'ephemeral', 'ttl': '5m'})

    # Explicit breakpoints on system and tools should also be present
    assert completion_kwargs['system'] == snapshot(
        [{'type': 'text', 'text': 'System instructions.', 'cache_control': {'type': 'ephemeral', 'ttl': '5m'}}]
    )
    tools = completion_kwargs['tools']
    assert tools[-1]['cache_control'] == snapshot({'type': 'ephemeral', 'ttl': '5m'})


async def test_limit_cache_points_with_cache(allow_model_requests: None):
    """Test that automatic caching reduces explicit cache point budget from 4 to 3."""
    c = completion_message(
        [BetaTextBlock(text='Response', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        model,
        system_prompt='System instructions.',
        model_settings=AnthropicModelSettings(
            anthropic_cache=True,
        ),
    )

    # Add 4 CachePoint markers; with automatic caching, budget is 3, so 1 should be removed
    await agent.run(
        [
            'Context 1',
            CachePoint(),  # Oldest, should be removed
            'Context 2',
            CachePoint(),  # Should be kept
            'Context 3',
            CachePoint(),  # Should be kept
            'Context 4',
            CachePoint(),  # Should be kept (newest, but auto caching targets this block server-side)
            'Question',
        ]
    )

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']

    cache_count = 0
    for msg in messages:
        for block in msg['content']:
            if 'cache_control' in block:
                cache_count += 1

    # Budget is 3 (4 - 1 reserved for automatic caching), so only 3 explicit points kept
    assert cache_count == 3


async def test_async_request_text_response(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='world', type='text')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('hello')
    assert result.output == 'world'
    assert result.usage == snapshot(
        RunUsage(
            requests=1,
            input_tokens=3,
            output_tokens=5,
            details={'input_tokens': 3, 'output_tokens': 5},
            cost=Decimal('0.0000224'),
        )
    )


async def test_request_stream_fallback_for_high_max_tokens(
    allow_model_requests: None, anthropic_api_key: str, vcr: Any
):
    """When the Anthropic SDK raises ValueError for high max_tokens, request() falls back to streaming."""
    # https://github.com/anthropics/anthropic-sdk-python/blob/49d639a671cb0ac30c767e8e1e68fdd5925205d5/src/anthropic/_base_client.py#L726
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    result = await agent.run(
        'What is 1+1? Answer with just the number.', model_settings=ModelSettings(max_tokens=32_000)
    )

    # Verify the fallback used streaming — the only request recorded should have stream=true
    assert len(vcr.requests) == 1
    request_body = json.loads(vcr.requests[0].body)
    assert request_body['stream'] is True
    assert request_body['max_tokens'] == 32_000

    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='What is 1+1? Answer with just the number.', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='2')],
                usage=RequestUsage(
                    input_tokens=20,
                    output_tokens=5,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 20,
                        'output_tokens': 5,
                    },
                    cost=Decimal('0.000135'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )
    assert result.output == snapshot('2')


async def test_request_structured_response(allow_model_requests: None):
    c = completion_message(
        [BetaToolUseBlock(id='123', input={'response': [1, 2, 3]}, name='final_result', type='tool_use')],
        usage=BetaUsage(input_tokens=3, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, output_type=list[int])

    result = await agent.run('hello')
    assert result.output == [1, 2, 3]
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='hello', timestamp=IsNow(tz=timezone.utc))],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name='final_result',
                        args={'response': [1, 2, 3]},
                        tool_call_id='123',
                    )
                ],
                usage=RequestUsage(
                    input_tokens=3,
                    output_tokens=5,
                    details={'input_tokens': 3, 'output_tokens': 5},
                    cost=Decimal('0.0000224'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsNow(tz=timezone.utc),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='final_result',
                        content='Final result processed.',
                        tool_call_id='123',
                        timestamp=IsNow(tz=timezone.utc),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_request_tool_call(allow_model_requests: None):
    responses = [
        completion_message(
            [BetaToolUseBlock(id='1', input={'loc_name': 'San Francisco'}, name='get_location', type='tool_use')],
            usage=BetaUsage(input_tokens=2, output_tokens=1),
        ),
        completion_message(
            [BetaToolUseBlock(id='2', input={'loc_name': 'London'}, name='get_location', type='tool_use')],
            usage=BetaUsage(input_tokens=3, output_tokens=2),
        ),
        completion_message(
            [BetaTextBlock(text='final response', type='text')],
            usage=BetaUsage(input_tokens=3, output_tokens=5),
        ),
    ]

    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, instructions='this is the system prompt')

    @agent.tool_plain
    async def get_location(loc_name: str) -> str:
        if loc_name == 'London':
            return json.dumps({'lat': 51, 'lng': 0})
        else:
            raise ModelRetry('Wrong location, please try again')

    result = await agent.run('hello')
    assert result.output == 'final response'
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(content='hello', timestamp=IsNow(tz=timezone.utc)),
                ],
                instructions='this is the system prompt',
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name='get_location',
                        args={'loc_name': 'San Francisco'},
                        tool_call_id='1',
                    )
                ],
                usage=RequestUsage(
                    input_tokens=2,
                    output_tokens=1,
                    details={'input_tokens': 2, 'output_tokens': 1},
                    cost=Decimal('0.0000056'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsNow(tz=timezone.utc),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    RetryPromptPart(
                        content='Wrong location, please try again',
                        tool_name='get_location',
                        tool_call_id='1',
                        timestamp=IsNow(tz=timezone.utc),
                    )
                ],
                instructions='this is the system prompt',
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name='get_location',
                        args={'loc_name': 'London'},
                        tool_call_id='2',
                    )
                ],
                usage=RequestUsage(
                    input_tokens=3,
                    output_tokens=2,
                    details={'input_tokens': 3, 'output_tokens': 2},
                    cost=Decimal('0.0000104'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsNow(tz=timezone.utc),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_location',
                        content='{"lat": 51, "lng": 0}',
                        tool_call_id='2',
                        timestamp=IsNow(tz=timezone.utc),
                    )
                ],
                instructions='this is the system prompt',
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='final response')],
                usage=RequestUsage(
                    input_tokens=3,
                    output_tokens=5,
                    details={'input_tokens': 3, 'output_tokens': 5},
                    cost=Decimal('0.0000224'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsNow(tz=timezone.utc),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_tool_failed_maps_to_anthropic_error_tool_result(allow_model_requests: None):
    responses = [
        completion_message(
            [BetaToolUseBlock(id='1', input={'city': 'London'}, name='get_weather', type='tool_use')],
            usage=BetaUsage(input_tokens=2, output_tokens=1),
        ),
        completion_message(
            [BetaTextBlock(text='weather unavailable', type='text')],
            usage=BetaUsage(input_tokens=3, output_tokens=5),
        ),
    ]

    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    @agent.tool_plain
    async def get_weather(city: str) -> str:
        raise ToolFailed(f'Weather service is unavailable for {city}.')

    await agent.run('hello')

    assert get_mock_chat_completion_kwargs(mock_client)[1]['messages'][2]['content'][0] == snapshot(
        {
            'tool_use_id': '1',
            'type': 'tool_result',
            'content': [{'text': 'Weather service is unavailable for London.', 'type': 'text'}],
            'is_error': True,
        }
    )


def get_mock_chat_completion_kwargs(async_anthropic: AsyncAnthropic) -> list[dict[str, Any]]:
    if isinstance(async_anthropic, MockAnthropic):
        return async_anthropic.chat_completion_kwargs
    else:  # pragma: no cover
        raise RuntimeError('Not a MockOpenAI instance')


@pytest.mark.parametrize('parallel_tool_calls', [True, False])
async def test_parallel_tool_calls(allow_model_requests: None, parallel_tool_calls: bool) -> None:
    responses = [
        completion_message(
            [BetaToolUseBlock(id='1', input={'loc_name': 'San Francisco'}, name='get_location', type='tool_use')],
            usage=BetaUsage(input_tokens=2, output_tokens=1),
        ),
        completion_message(
            [BetaTextBlock(text='final response', type='text')],
            usage=BetaUsage(input_tokens=3, output_tokens=5),
        ),
    ]

    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=ModelSettings(parallel_tool_calls=parallel_tool_calls))

    @agent.tool_plain
    async def get_location(loc_name: str) -> str:
        if loc_name == 'London':
            return json.dumps({'lat': 51, 'lng': 0})  # pragma: no cover
        else:
            raise ModelRetry('Wrong location, please try again')

    await agent.run('hello')
    assert get_mock_chat_completion_kwargs(mock_client)[0]['tool_choice']['disable_parallel_tool_use'] == (
        not parallel_tool_calls
    )


async def test_multiple_parallel_tool_calls(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    async def retrieve_entity_info(name: str) -> str:
        """Get the knowledge about the given entity."""
        data = {
            'alice': "alice is bob's wife",
            'bob': "bob is alice's husband",
            'charlie': "charlie is alice's son",
            'daisy': "daisy is bob's daughter and charlie's younger sister",
        }
        return data[name.lower()]

    system_prompt = """
    Use the `retrieve_entity_info` tool to get information about a specific person.
    If you need to use `retrieve_entity_info` to get information about multiple people, try
    to call them in parallel as much as possible.
    Think step by step and then provide a single most probable concise answer.
    """

    agent = Agent(
        anthropic_model('claude-haiku-4-5', capture=True),
        system_prompt=system_prompt,
        tools=[retrieve_entity_info],
    )

    result = await agent.run('Alice, Bob, Charlie and Daisy are a family. Who is the youngest?')
    assert content_blocks(request_capture.body(), 'tool_result') == snapshot([])
    assert 'Daisy is the youngest' in result.output

    all_messages = result.all_messages()
    first_response = all_messages[1]
    second_request = all_messages[2]
    assert first_response.parts == snapshot(
        [
            TextPart(
                content="I'll help you find out who is the youngest by retrieving information about each family member. I'll retrieve their entity information to compare their ages.",
                part_kind='text',
            ),
            ToolCallPart(
                tool_name='retrieve_entity_info', args={'name': 'Alice'}, tool_call_id=IsStr(), part_kind='tool-call'
            ),
            ToolCallPart(
                tool_name='retrieve_entity_info', args={'name': 'Bob'}, tool_call_id=IsStr(), part_kind='tool-call'
            ),
            ToolCallPart(
                tool_name='retrieve_entity_info', args={'name': 'Charlie'}, tool_call_id=IsStr(), part_kind='tool-call'
            ),
            ToolCallPart(
                tool_name='retrieve_entity_info', args={'name': 'Daisy'}, tool_call_id=IsStr(), part_kind='tool-call'
            ),
        ]
    )
    assert second_request.parts == snapshot(
        [
            ToolReturnPart(
                tool_name='retrieve_entity_info',
                content="alice is bob's wife",
                tool_call_id=IsStr(),
                timestamp=IsDatetime(),
                part_kind='tool-return',
            ),
            ToolReturnPart(
                tool_name='retrieve_entity_info',
                content="bob is alice's husband",
                tool_call_id=IsStr(),
                timestamp=IsDatetime(),
                part_kind='tool-return',
            ),
            ToolReturnPart(
                tool_name='retrieve_entity_info',
                content="charlie is alice's son",
                tool_call_id=IsStr(),
                timestamp=IsDatetime(),
                part_kind='tool-return',
            ),
            ToolReturnPart(
                tool_name='retrieve_entity_info',
                content="daisy is bob's daughter and charlie's younger sister",
                tool_call_id=IsStr(),
                timestamp=IsDatetime(),
                part_kind='tool-return',
            ),
        ]
    )

    # Ensure the tool call IDs match between the tool calls and the tool returns
    tool_call_part_ids = [part.tool_call_id for part in first_response.parts if part.part_kind == 'tool-call']
    tool_return_part_ids = [part.tool_call_id for part in second_request.parts if part.part_kind == 'tool-return']
    assert len(set(tool_call_part_ids)) == 4  # ensure they are all unique
    assert tool_call_part_ids == tool_return_part_ids


async def test_anthropic_specific_metadata(allow_model_requests: None) -> None:
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('hello', model_settings=AnthropicModelSettings(anthropic_metadata={'user_id': '123'}))
    assert result.output == 'world'
    assert get_mock_chat_completion_kwargs(mock_client)[0]['metadata']['user_id'] == '123'


@pytest.mark.parametrize('speed', ['fast', 'standard', None])
async def test_anthropic_speed_setting(allow_model_requests: None, speed: Literal['fast', 'standard'] | None) -> None:
    c = completion_message([BetaTextBlock(text='hi', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-opus-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    settings = AnthropicModelSettings(anthropic_betas=['custom-beta'])
    if speed is not None:
        settings['anthropic_speed'] = speed
    await agent.run('hello', model_settings=settings)
    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]

    if speed is not None:
        assert kwargs['speed'] == speed
    else:
        assert kwargs.get('speed') is OMIT
    betas = kwargs.get('betas')
    assert isinstance(betas, (list, tuple))
    assert ('fast-mode-2026-02-01' in betas) is (speed == 'fast')


@pytest.mark.parametrize(
    'speed,expected_warning',
    [
        ('fast', "anthropic_speed='fast' is not supported"),
        ('standard', None),
    ],
)
async def test_anthropic_speed_ignored_on_unsupported_model(
    allow_model_requests: None,
    speed: Literal['fast', 'standard'],
    expected_warning: str | None,
) -> None:
    """On models without fast-mode support, `anthropic_speed` is omitted; `'fast'` also warns."""
    c = completion_message([BetaTextBlock(text='hi', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)
    settings = AnthropicModelSettings(anthropic_speed=speed, anthropic_betas=['custom-beta'])

    if expected_warning is not None:
        with pytest.warns(UserWarning, match=expected_warning):
            await agent.run('hello', model_settings=settings)
    else:
        await agent.run('hello', model_settings=settings)

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs.get('speed') is OMIT
    betas = kwargs.get('betas')
    assert isinstance(betas, (list, tuple))
    assert 'fast-mode-2026-02-01' not in betas


@pytest.mark.parametrize(
    'client_cls',
    [
        pytest.param(AsyncAnthropicBedrock, id='bedrock'),
        pytest.param(AsyncAnthropicVertex, id='vertex'),
        pytest.param(AsyncAnthropicFoundry, id='foundry'),
    ],
)
async def test_anthropic_speed_omitted_on_non_direct_clients(allow_model_requests: None, client_cls: type) -> None:
    """Fast mode is only available on the direct Anthropic API; Bedrock/Vertex/Foundry clients get `speed` omitted and warn."""
    c = completion_message([BetaTextBlock(text='hi', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MagicMock()
    mock_client.__class__ = client_cls
    mock_client.beta.messages.create = AsyncMock(return_value=c)

    m = AnthropicModel('claude-opus-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=AnthropicModelSettings(anthropic_speed='fast', anthropic_betas=['custom-beta']))
    with pytest.warns(UserWarning, match='anthropic_speed=.fast. is not supported'):
        await agent.run('hello')

    call_kwargs = mock_client.beta.messages.create.call_args.kwargs
    assert call_kwargs['speed'] is OMIT
    assert 'fast-mode-2026-02-01' not in call_kwargs['betas']


async def test_stream_structured(allow_model_requests: None):
    """Test streaming structured responses with Anthropic's API.

    This test simulates how Anthropic streams tool calls:
    1. Message start
    2. Tool block start with initial data
    3. Tool block delta with additional data
    4. Tool block stop
    5. Update usage
    6. Message stop
    """
    stream = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_123',
                model='claude-3-5-haiku-123',
                role='assistant',
                type='message',
                content=[],
                stop_reason=None,
                usage=BetaUsage(input_tokens=20, output_tokens=0),
            ),
        ),
        # Start tool block with initial data
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=0,
            content_block=BetaToolUseBlock(type='tool_use', id='tool_1', name='my_tool', input={}),
        ),
        # Add more data through an incomplete JSON delta
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaInputJSONDelta(type='input_json_delta', partial_json='{"first": "One'),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaInputJSONDelta(type='input_json_delta', partial_json='", "second": "Two"'),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaInputJSONDelta(type='input_json_delta', partial_json='}'),
        ),
        # Mark tool block as complete
        BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
        # Update the top-level message with usage
        BetaRawMessageDeltaEvent(
            type='message_delta',
            delta=Delta(stop_reason='end_turn'),
            usage=BetaMessageDeltaUsage(input_tokens=20, output_tokens=5),
        ),
        # Mark message as complete
        BetaRawMessageStopEvent(type='message_stop'),
    ]

    done_stream = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_123',
                model='claude-3-5-haiku-123',
                role='assistant',
                type='message',
                content=[],
                stop_reason=None,
                usage=BetaUsage(input_tokens=0, output_tokens=0),
            ),
        ),
        # Text block with final data
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=0,
            content_block=BetaTextBlock(type='text', text='FINAL_PAYLOAD'),
        ),
        BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
        BetaRawMessageDeltaEvent(
            type='message_delta',
            delta=Delta(stop_reason='end_turn'),
            usage=BetaMessageDeltaUsage(input_tokens=0, output_tokens=0),
        ),
        BetaRawMessageStopEvent(type='message_stop'),
    ]

    mock_client = MockAnthropic.create_stream_mock([stream, done_stream])
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    tool_called = False

    @agent.tool_plain
    async def my_tool(first: str, second: str) -> int:
        nonlocal tool_called
        tool_called = True
        return len(first) + len(second)

    async with agent.run_stream('') as result:
        assert not result.is_complete
        chunks = [c async for c in result.stream_output(debounce_by=None)]

        # The tool output doesn't echo any content to the stream, so we only get the final payload once when
        # the block starts and once when it ends.
        assert chunks == snapshot(['FINAL_PAYLOAD', 'FINAL_PAYLOAD'])
        assert result.is_complete
        assert result.usage == snapshot(
            RunUsage(
                requests=2,
                input_tokens=20,
                output_tokens=5,
                tool_calls=1,
                details={'input_tokens': 20, 'output_tokens': 5},
                cost=Decimal('0.000036'),
            )
        )
        assert tool_called
        async for response in result.stream_response(debounce_by=None):
            assert response == snapshot(
                ModelResponse(
                    parts=[TextPart(content='FINAL_PAYLOAD')],
                    usage=RequestUsage(details={'input_tokens': 0, 'output_tokens': 0}),
                    model_name='claude-3-5-haiku-123',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                    provider_url='https://api.anthropic.com',
                    provider_details={'finish_reason': 'end_turn'},
                    provider_response_id='msg_123',
                    finish_reason='stop',
                )
            )


async def test_text_content_input(allow_model_requests: None, anthropic_api_key: str):
    """Test that _map_message correctly maps a user message with TextContent."""
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    messages = [
        ModelRequest(
            parts=[
                SystemPromptPart(content='System instructions.'),
                UserPromptPart(
                    content=[
                        'Hello Pydantic AI!',
                        TextContent(content='This is awesome', metadata={'font': 'bold'}),
                        TextContent(content='', metadata={'font': 'italic'}),  # Empty content would be filtered out
                    ]
                ),
            ],
        ),
        ModelResponse(
            parts=[TextPart(content='Hello Human!')],
        ),
    ]
    m = await model._map_message(  # pyright: ignore[reportPrivateUsage]
        messages,
        ModelRequestParameters(),
        {},
    )
    assert m == snapshot(
        (
            'System instructions.',
            [
                {
                    'role': 'user',
                    'content': [
                        {'text': 'Hello Pydantic AI!', 'type': 'text'},
                        {'text': 'This is awesome', 'type': 'text'},
                    ],
                },
                {'role': 'assistant', 'content': [{'text': 'Hello Human!', 'type': 'text'}]},
            ],
        )
    )


async def test_image_url_input(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    result = await agent.run(
        [
            'What is this vegetable?',
            ImageUrl(url='https://t3.ftcdn.net/jpg/00/85/79/92/360_F_85799278_0BBGV9OAdQDTLnKwAPBCcg1J7QtiieJY.jpg'),
        ]
    )
    assert result.output == snapshot(
        "This is a potato. It's a yellow/golden-colored potato with a smooth, slightly bumpy skin typical of many potato varieties. The potato appears to be a whole, unpeeled tuber with a classic oblong or oval shape. Potatoes are starchy root vegetables that are widely consumed around the world and can be prepared in many ways, such as boiling, baking, frying, or mashing."
    )


async def test_image_url_input_force_download(
    allow_model_requests: None, anthropic_api_key: str, disable_ssrf_protection_for_vcr: None
):
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    result = await agent.run(
        [
            'What is this vegetable?',
            ImageUrl(
                url='https://t3.ftcdn.net/jpg/00/85/79/92/360_F_85799278_0BBGV9OAdQDTLnKwAPBCcg1J7QtiieJY.jpg',
                force_download=True,
            ),
        ]
    )
    assert result.output == snapshot(
        """\
This is a **potato**, specifically a yellow or gold potato variety. You can identify it by its characteristic features:

- **Oval/round shape** with smooth skin
- **Golden-yellow color** with small dark spots or eyes
- **Starchy appearance** typical of potatoes

This appears to be a russet or similar yellow potato variety commonly used for cooking, baking, or making mashed potatoes.\
"""
    )


async def test_extra_headers(allow_model_requests: None, anthropic_api_key: str):
    # This test doesn't do anything, it's just here to ensure that calls with `extra_headers` don't cause errors, including type.
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(
        m,
        model_settings=AnthropicModelSettings(
            anthropic_metadata={'user_id': '123'}, extra_headers={'Extra-Header-Key': 'Extra-Header-Value'}
        ),
    )
    await agent.run('hello')


async def test_image_url_input_invalid_mime_type(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    result = await agent.run(
        [
            'What animal is this?',
            ImageUrl(
                url='https://lh3.googleusercontent.com/proxy/YngsuS8jQJysXxeucAgVBcSgIdwZlSQ-HvsNxGjHS0SrUKXI161bNKh6SOcMsNUGsnxoOrS3AYX--MT4T3S3SoCgSD1xKrtBwwItcgexaX_7W-qHo-VupmYgjjzWO-BuORLp9-pj8Kjr'
            ),
        ]
    )
    assert result.output == snapshot(
        'This is a Great Horned Owl (Bubo virginianus), a large and powerful owl species native to the Americas. The image shows the owl perched on a log or branch, surrounded by soft yellow and green vegetation. The owl has distinctive ear tufts (the "horns"), large yellow eyes, and a mottled gray-brown plumage that provides excellent camouflage in woodland and grassland environments. Great Horned Owls are known for their impressive size, sharp talons, and nocturnal hunting habits. They are formidable predators that can hunt animals as large as skunks, rabbits, and even other birds of prey.'
    )


async def test_image_url_force_download() -> None:
    """Test that force_download=True calls download_item for ImageUrl."""
    from unittest.mock import AsyncMock, patch

    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key='test-key'))

    with patch('pydantic_ai.models.anthropic.download_item', new_callable=AsyncMock) as mock_download:
        mock_download.return_value = {
            'data': b'\x89PNG\r\n\x1a\n fake image data',
            'content_type': 'image/png',
        }

        messages = [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content=[
                            'Test image',
                            ImageUrl(
                                url='https://example.com/image.png',
                                media_type='image/png',
                                force_download=True,
                            ),
                        ]
                    )
                ]
            )
        ]

        await m._map_message(messages, ModelRequestParameters(), {})  # pyright: ignore[reportPrivateUsage,reportArgumentType]

        mock_download.assert_called_once()
        assert mock_download.call_args[0][0].url == 'https://example.com/image.png'


async def test_image_url_no_force_download() -> None:
    """Test that force_download=False does not call download_item for ImageUrl."""
    from unittest.mock import AsyncMock, patch

    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key='test-key'))

    with patch('pydantic_ai.models.anthropic.download_item', new_callable=AsyncMock) as mock_download:
        messages = [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content=[
                            'Test image',
                            ImageUrl(
                                url='https://example.com/image.png',
                                media_type='image/png',
                                force_download=False,
                            ),
                        ]
                    )
                ]
            )
        ]

        await m._map_message(messages, ModelRequestParameters(), {})  # pyright: ignore[reportPrivateUsage,reportArgumentType]

        mock_download.assert_not_called()


async def test_document_url_pdf_force_download() -> None:
    """Test that force_download=True calls download_item for DocumentUrl (PDF)."""
    from unittest.mock import AsyncMock, patch

    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key='test-key'))

    with patch('pydantic_ai.models.anthropic.download_item', new_callable=AsyncMock) as mock_download:
        mock_download.return_value = {
            'data': b'%PDF-1.4 fake pdf data',
            'content_type': 'application/pdf',
        }

        messages = [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content=[
                            'Test PDF',
                            DocumentUrl(
                                url='https://example.com/doc.pdf',
                                media_type='application/pdf',
                                force_download=True,
                            ),
                        ]
                    )
                ]
            )
        ]

        await m._map_message(messages, ModelRequestParameters(), {})  # pyright: ignore[reportPrivateUsage,reportArgumentType]

        mock_download.assert_called_once()
        assert mock_download.call_args[0][0].url == 'https://example.com/doc.pdf'


async def test_document_url_text_force_download() -> None:
    """Test that force_download=True calls download_item for DocumentUrl (text/plain)."""
    from unittest.mock import AsyncMock, patch

    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key='test-key'))

    with patch('pydantic_ai.models.anthropic.download_item', new_callable=AsyncMock) as mock_download:
        mock_download.return_value = {
            'data': 'Sample text content',
            'content_type': 'text/plain',
        }

        messages = [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content=[
                            'Test text file',
                            DocumentUrl(
                                url='https://example.com/doc.txt',
                                media_type='text/plain',
                                force_download=True,
                            ),
                        ]
                    )
                ]
            )
        ]

        await m._map_message(messages, ModelRequestParameters(), {})  # pyright: ignore[reportPrivateUsage,reportArgumentType]

        mock_download.assert_called_once()
        assert mock_download.call_args[0][0].url == 'https://example.com/doc.txt'


def test_model_status_error(allow_model_requests: None) -> None:
    mock_client = MockAnthropic.create_mock(
        APIStatusError(
            'test error',
            response=httpx2.Response(status_code=500, request=httpx2.Request('POST', 'https://example.com/v1')),
            body={'error': 'test error'},
        )
    )
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)
    with pytest.raises(ModelHTTPError) as exc_info:
        agent.run_sync('hello')
    assert str(exc_info.value) == snapshot(
        "status_code: 500, model_name: claude-sonnet-4-5, body: {'error': 'test error'}"
    )


def test_model_connection_error(allow_model_requests: None) -> None:
    mock_client = MockAnthropic.create_mock(
        APIConnectionError(
            message='Connection to https://api.anthropic.com timed out',
            request=httpx2.Request('POST', 'https://api.anthropic.com/v1/messages'),
        )
    )
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)
    with pytest.raises(ModelAPIError) as exc_info:
        agent.run_sync('hello')
    assert exc_info.value.model_name == 'claude-sonnet-4-5'
    assert 'Connection to https://api.anthropic.com timed out' in str(exc_info.value.message)


async def test_count_tokens_connection_error(allow_model_requests: None) -> None:
    mock_client = MockAnthropic.create_mock(
        APIConnectionError(
            message='Connection to https://api.anthropic.com timed out',
            request=httpx2.Request('POST', 'https://api.anthropic.com/v1/messages'),
        )
    )
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)
    with pytest.raises(ModelAPIError) as exc_info:
        await agent.run('hello', usage_limits=UsageLimits(input_tokens_limit=20, count_tokens_before_request=True))
    assert exc_info.value.model_name == 'claude-sonnet-4-5'
    assert 'Connection to https://api.anthropic.com timed out' in str(exc_info.value.message)


async def test_document_binary_content_input(
    allow_model_requests: None, anthropic_api_key: str, document_content: BinaryContent
):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    result = await agent.run(['What is the main content on this document?', document_content])
    assert result.output == snapshot(
        'The document simply contains the text "Dummy PDF file" at the top of what appears to be an otherwise blank page.'
    )


async def test_document_url_input(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    document_url = DocumentUrl(url='https://pdfobject.com/pdf/sample.pdf')

    result = await agent.run(['What is the main content on this document?', document_url])
    assert result.output == snapshot(
        'This document appears to be a sample PDF file that mainly contains Lorem ipsum text, which is placeholder text commonly used in design and publishing. The document starts with "Sample PDF" as its title, followed by the line "This is a simple PDF file. Fun fun fun." The rest of the content consists of several paragraphs of Lorem ipsum text, which is Latin-looking but essentially meaningless text used to demonstrate the visual form of a document without the distraction of meaningful content.'
    )


async def test_text_document_url_input(
    allow_model_requests: None, anthropic_api_key: str, disable_ssrf_protection_for_vcr: None
):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    text_document_url = DocumentUrl(url='https://example-files.online-convert.com/document/txt/example.txt')

    result = await agent.run(['What is the main content on this document?', text_document_url])
    assert result.output == snapshot("""\
This document is a TXT test file that contains example content about the use of placeholder names like "John Doe," "Jane Doe," and their variants in legal and cultural contexts. The main content is divided into three main paragraphs explaining:

1. The use of "Doe" names as placeholders for unknown parties in legal actions
2. The use of "John Doe" as a reference to a typical male in various contexts
3. The use of variations like "Baby Doe" and numbered "John Doe"s in specific cases

The document also includes metadata about the file itself, including its purpose, type, and version, as well as attribution information indicating that the example content is from Wikipedia and is licensed under Attribution-ShareAlike 4.0.\
""")


async def test_text_document_as_binary_content_input(
    allow_model_requests: None, anthropic_api_key: str, text_document_content: BinaryContent
):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m)

    result = await agent.run(['What does this text file say?', text_document_content])
    assert result.output == snapshot('The text file says "Dummy TXT file".')


async def test_uploaded_file_with_text(allow_model_requests: None) -> None:
    """Test that UploadedFile is correctly mapped to a document block with file source."""
    c = completion_message(
        [BetaTextBlock(text='The file contains important data.', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=8),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run(['Analyze this file', UploadedFile(file_id='file-abc123', provider_name='anthropic')])

    assert result.output == 'The file contains important data.'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']
    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {'text': 'Analyze this file', 'type': 'text'},
                    {'source': {'file_id': 'file-abc123', 'type': 'file'}, 'type': 'document'},
                ],
            }
        ]
    )


async def test_uploaded_file_only(allow_model_requests: None) -> None:
    """Test UploadedFile as the only content in a message."""
    c = completion_message(
        [BetaTextBlock(text='This is a PDF document.', type='text')],
        usage=BetaUsage(input_tokens=5, output_tokens=6),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run([UploadedFile(file_id='file-xyz789', provider_name='anthropic')])

    assert result.output == 'This is a PDF document.'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    content = completion_kwargs['messages'][0]['content']
    assert content == snapshot([{'source': {'file_id': 'file-xyz789', 'type': 'file'}, 'type': 'document'}])


async def test_multiple_uploaded_files(allow_model_requests: None) -> None:
    """Test multiple UploadedFiles in a single message."""
    c = completion_message(
        [BetaTextBlock(text='Both files contain similar data.', type='text')],
        usage=BetaUsage(input_tokens=15, output_tokens=7),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run(
        [
            'Compare these files',
            UploadedFile(file_id='file-001', provider_name='anthropic'),
            UploadedFile(file_id='file-002', provider_name='anthropic'),
        ]
    )

    assert result.output == 'Both files contain similar data.'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    content = completion_kwargs['messages'][0]['content']
    assert content == snapshot(
        [
            {'text': 'Compare these files', 'type': 'text'},
            {'source': {'file_id': 'file-001', 'type': 'file'}, 'type': 'document'},
            {'source': {'file_id': 'file-002', 'type': 'file'}, 'type': 'document'},
        ]
    )


async def test_uploaded_file_image(allow_model_requests: None) -> None:
    """Test that UploadedFile with image media type is mapped to an image block."""
    c = completion_message(
        [BetaTextBlock(text='The image shows a cat.', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=6),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run(
        ['Describe this image', UploadedFile(file_id='file-img123', provider_name='anthropic', media_type='image/png')]
    )

    assert result.output == 'The image shows a cat.'

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    messages = completion_kwargs['messages']
    assert messages == snapshot(
        [
            {
                'role': 'user',
                'content': [
                    {'text': 'Describe this image', 'type': 'text'},
                    {'source': {'file_id': 'file-img123', 'type': 'file'}, 'type': 'image'},
                ],
            }
        ]
    )


async def test_uploaded_file_wrong_provider(allow_model_requests: None) -> None:
    """Test that UploadedFile with wrong provider raises an error."""
    c = completion_message(
        [BetaTextBlock(text='Should not reach here.', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=8),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    with pytest.raises(UserError, match=r"provider_name='openai'.*cannot be used with AnthropicModel"):
        await agent.run(['Analyze this file', UploadedFile(file_id='file-abc123', provider_name='openai')])


async def test_uploaded_file_unsupported_media_type(allow_model_requests: None) -> None:
    """Test that UploadedFile with unsupported media type (e.g. audio) raises an error."""
    c = completion_message(
        [BetaTextBlock(text='Should not reach here.', type='text')],
        usage=BetaUsage(input_tokens=10, output_tokens=8),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    with pytest.raises(UserError, match=r'Unsupported media type.*audio/mpeg'):
        await agent.run(
            [
                'Analyze this file',
                UploadedFile(file_id='file-abc123', provider_name='anthropic', media_type='audio/mpeg'),
            ]
        )


@pytest.mark.parametrize(
    'content,expect_beta',
    [
        pytest.param(
            ['Analyze this file', UploadedFile(file_id='file-abc123', provider_name='anthropic')],
            True,
            id='document',
        ),
        pytest.param(
            [
                'Describe this image',
                UploadedFile(file_id='file-img123', provider_name='anthropic', media_type='image/png'),
            ],
            True,
            id='image',
        ),
        pytest.param('hello', False, id='no-file'),
    ],
)
async def test_files_api_beta_added_only_for_anthropic_uploaded_file(
    content: str | list[Any], expect_beta: bool, allow_model_requests: None
) -> None:
    """Anthropic attaches `files-api-2025-04-14` iff the request carries an Anthropic `UploadedFile`.

    Unit test (not VCR): cassette matchers don't pin the `betas` kwarg, so a regression that added or
    dropped the auto-beta would still replay green. We assert the kwarg on the mock client directly.
    The `no-file` case guards the proxy/compatible-provider path where the Anthropic-only header must
    not leak.
    """
    c = completion_message([BetaTextBlock(text='ok', type='text')], usage=BetaUsage(input_tokens=3, output_tokens=1))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    await agent.run(content)

    # `betas` may be absent entirely (NOT_GIVEN/OMIT) when no betas are required.
    betas: list[str] = get_mock_chat_completion_kwargs(mock_client)[0].get('betas') or []
    assert ('files-api-2025-04-14' in betas) is expect_beta


async def test_uploaded_file_for_other_provider_does_not_add_anthropic_files_api_beta(
    allow_model_requests: None,
) -> None:
    """`UploadedFile` carrying a non-Anthropic `provider_name` should not auto-attach the beta.

    The request mappers will raise their existing `UserError` for the cross-provider case,
    but the gate that adds the beta runs before mapping — it must not return True for
    foreign `provider_name`s, otherwise a user-supplied OpenAI `UploadedFile` accidentally
    forwarded to `AnthropicModel` would still leak the Anthropic beta header before erroring.
    Unit test for the same cassette-matcher reason as the positive cases.
    """
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        usage=BetaUsage(input_tokens=5, output_tokens=2),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    # Reach into the helper directly so we can assert the gate's return value without going
    # through `agent.run` (which would hit the request mapper's existing UserError first).
    foreign = ModelRequest(
        parts=[
            UserPromptPart(
                content=['Analyze this file', UploadedFile(file_id='file-abc123', provider_name='openai')],
            )
        ]
    )
    assert m._messages_use_anthropic_uploaded_file([foreign]) is False  # pyright: ignore[reportPrivateUsage]


async def test_uploaded_file_user_provided_betas_are_preserved(allow_model_requests: None) -> None:
    """User-supplied `anthropic_betas` and the auto Files API beta should be merged, not clobbered.

    Unit test (not VCR): asserts the resulting `betas` set is a superset of both sources.
    """
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        usage=BetaUsage(input_tokens=5, output_tokens=2),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel(
        'claude-haiku-4-5',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(anthropic_betas=['custom-feature-1']),
    )
    agent = Agent(m)

    await agent.run(['Analyze this file', UploadedFile(file_id='file-abc123', provider_name='anthropic')])

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert set(completion_kwargs['betas']) >= {'files-api-2025-04-14', 'custom-feature-1'}


async def test_uploaded_file_adds_files_api_beta_to_count_tokens(allow_model_requests: None) -> None:
    """Token counting must mirror actual request parameters — the Files API beta belongs there too.

    Unit test (not VCR): the project's `models/AGENTS.md` guideline that "token counting must
    mirror actual request parameters" is exactly the kind of internal-shape rule a VCR cassette
    matcher cannot pin. We assert the `betas` kwarg on `messages.count_tokens` directly.
    """
    mock_client = cast(AsyncAnthropic, MockAnthropic())
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    await m.count_tokens(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content=['Estimate this file', UploadedFile(file_id='file-ct-1', provider_name='anthropic')],
                    )
                ]
            )
        ],
        None,
        ModelRequestParameters(),
    )

    count_tokens_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert 'files-api-2025-04-14' in count_tokens_kwargs['betas']


async def test_uploaded_file_in_tool_return_adds_files_api_beta(allow_model_requests: None) -> None:
    """An `UploadedFile` returned by a tool auto-attaches the Files API beta on the follow-up request.

    Unit test (not VCR): tool-returned files are mapped to the same `source.type='file'` wire shape
    as user-prompt files and require the same beta, but cassette matchers don't pin the `betas` kwarg,
    so a regression dropping the auto-beta on the tool-return path would still replay green. We assert
    the kwarg directly on the second (post-tool) request. The first request carries no file, so it must
    not include the beta.
    """
    responses = [
        completion_message(
            [BetaToolUseBlock(id='1', input={}, name='get_file', type='tool_use')],
            usage=BetaUsage(input_tokens=2, output_tokens=1),
        ),
        completion_message(
            [BetaTextBlock(text='ok', type='text')],
            usage=BetaUsage(input_tokens=3, output_tokens=2),
        ),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    @agent.tool_plain
    def get_file() -> UploadedFile:
        return UploadedFile(file_id='file-tr-1', provider_name='anthropic')

    await agent.run('Fetch a file and describe it')

    request_kwargs = get_mock_chat_completion_kwargs(mock_client)
    assert 'files-api-2025-04-14' not in (request_kwargs[0].get('betas') or [])
    assert 'files-api-2025-04-14' in (request_kwargs[1].get('betas') or [])


def test_init_with_provider():
    provider = AnthropicProvider(api_key='api-key')
    model = AnthropicModel('claude-3-opus-latest', provider=provider)
    assert model.model_name == 'claude-3-opus-latest'
    assert model.client == provider.client


def test_init_with_provider_string(env: TestEnv):
    env.set('ANTHROPIC_API_KEY', 'env-api-key')
    model = AnthropicModel('claude-3-opus-latest', provider='anthropic')
    assert model.model_name == 'claude-3-opus-latest'
    assert model.client is not None


async def test_anthropic_model_instructions(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-3-opus-latest', capture=True)
    agent = Agent(m)

    @agent.instructions
    def simple_instructions():
        return 'You are a helpful assistant.'

    result = await agent.run('What is the capital of France?')
    assert request_capture.body()['system'] == snapshot([{'type': 'text', 'text': 'You are a helpful assistant.'}])
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='What is the capital of France?', timestamp=IsDatetime())],
                timestamp=IsNow(tz=timezone.utc),
                instructions='You are a helpful assistant.',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='The capital of France is Paris.')],
                usage=RequestUsage(
                    input_tokens=20,
                    output_tokens=10,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 20,
                        'output_tokens': 10,
                    },
                    cost=Decimal('0.00105'),
                ),
                model_name='claude-3-opus-20240229',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01Fg1JVgvCYUHWsxrj9GkpEv',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_model_thinking_part(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 1024})
    agent = Agent(m, model_settings=settings)

    result = await agent.run('How do I cross the street?')
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='How do I cross the street?', timestamp=IsDatetime())],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='This is a straightforward question about pedestrian safety. I should provide clear, practical advice about crossing the street safely.',
                        signature='Eq8CCkYICxgCKkDdadQOXMzNBqjrNVAKWsgUfg49NpPg026zBGxIIGwEHVCq0JTW/P9fKHjZdjgO8Dyx03YDw6hN0w1HucifXFggEgzoVS5Gogi9nvJSOA8aDDYuCAX4nGGkeHQLayIw+MWbf/TYU4AqT1X89p4S7fe7LOO+B8o24yCHQ8cFK9QK9p5WMj2Y4oBFBfC9uL8ZKpYBDjoKceyqFJA56ewVH73lNY5szTvm52+CVXMZJCb8x0B1bf9LIOsFUoJD6F4gZBdKfMqJgFCcKFR6iZh09pwa0E8lHvEnUeF1A0AJ6z0j8gQd5NxgipxWrF9908qJbMSkVDdg1dT/3Rr0nbGguAYTYdoV4MrVxyk29dSkkjyAAZBMI3p+HOwiaT6GmYq4qVE3kWnSoiEJGAE=',
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=43,
                    output_tokens=321,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 43,
                        'output_tokens': 321,
                    },
                    cost=Decimal('0.004944'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01TGA8SWcHTTn5674cmicbnJ',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    result = await agent.run(
        'Considering the way to cross the street, analogously, how do I cross the river?',
        message_history=result.all_messages(),
    )
    assert result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Considering the way to cross the street, analogously, how do I cross the river?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content="""\
This is an interesting analogy question. The person is asking me to apply the safety principles and general approach from crossing a street to crossing a river. Let me think about the parallel elements:

Street crossing principles:
- Find safe crossing point
- Assess conditions
- Look for hazards
- Use designated crossings when available
- Wait for safe conditions
- Cross carefully while staying alert

River crossing would involve similar safety thinking:
- Find safe crossing point (bridge, ford, ferry, shallow area)
- Assess conditions (water depth, current, weather)
- Look for hazards (rocks, debris, cold water, strong current)
- Use established crossings when available
- Wait for safe conditions (water levels, weather)
- Cross carefully while staying alert

I should provide practical advice for different methods of crossing a river.\
""",
                        signature='EvgHCkYICxgCKkBWep44ZkS8HkPkKt2q7OJir9S1aK8TFXpFjWz4yEEVk+2r0FCXIRwuIJBfrLI+kTWKzAFtjxpM+G+S8Btnle6sEgwSq3W1+WbBYHYolVYaDCbom89zf38EbOe8jCIwKz0NLPNu1XU3I3nREDwVSSBCe/u2C+Ryon6gXHWSWlM7r6M2jMVUNynufqiO9m+jKt8GDH5qCKJRfydyyKcS1muFqazBmHs8L3sUsHzj7s2XkvP+2yA789klS3DrrYj4H1kYbRWpmGlTxkpPAuXUr8u1U02sNS0zqh5HiIEu2LZesOj5l1jw68VXcVBPsYEdkSvarScNKzmDBOiw0vTV9EkoxZ/p/ZvoP4PUYSzFc1oJRPaLDCn7KW/aAsZBbsS55YDwHBXvjrDFFtcd2V04JuavcKi0EwomwCy95e0NAaOrA9aAFizZoG30V9KSiz0XUQ3+8ByxKILXk1qvtaV2HJgYahAuRcOpEoty4+Dqx96KsA4ifPaU0+MRwoVUwGUm+mK75ViBIAQdRFblkHbPHYHpK+P9SjdIb00h6PUH59pPyNFQOMJyav7c6dy2efTmiTdzejLHXjUzVvG2LaDnq7cFM2MpqvxlIxDULVG+N13xOTStjLJ9Siwq/zMPKTZYhbYYYC6INlMxwmvM0xz3ofsZbUVOAHv2Ti9jixmB38wyKaFiS7GkQvaK9r9AYl7b632bnsjexiHMe+HMAwfOiA9d2bfhGYCwnt59uNCPgXRihLqaeemq84tiHjSpXrYAieAHtiwEhh0Zz5/ztFgn9pDko5ZmfUvXW9kcZ/8nthmDJSD0z933gw5gITW5u+4S4ozqkGtQ4lGgHNzXLpAEs1A6lsqh2jC2iAskj4Mc/oihJbmAFT0UQ0uopcExyImY6maqKub7xYUseRiNjd1Y7hq7eLDlrMiOR8DDoUoTEIz1imI+KetpLXJoSorecGkYivZajx9ZY+L/R4VcA6olgJsjSpztEvlNextE8sAcAnwBK5l8+yBxWBflFf96wOcvbxE3xtEfR5+ISy6+A6kcxPkpj/31B0VM9y3EqMcDqKmMCF6r7MpwRzXxkHofWCG49N4SQKDJrRJSMldy/qGvd5TIVDghEK+8AoVhWZXqXl6y9z5NG72fOlXLdh3me1jtqMSBX3q0gxmljqzqii/r4F6Qmmmwl2szfryxwgUWAAPS6yDEWbDyUhQSmc24Q+uHrXhKIPKuDQljCsI2by2pyC8UV4RsEfvNLk0zs5CPR3+1kewb8TVB6S+IpmJHJnBZImkI2vt2IUgvnJb/5D+aezG2mA8O+4qjsnHsbT8Njk92tOI1wxOFSAO19SOEa+DD2bsYAQ==',
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=354,
                    output_tokens=525,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 354,
                        'output_tokens': 525,
                    },
                    cost=Decimal('0.008937'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_model_empty_thinking_signature_sent_as_text(allow_model_requests: None):
    """A thinking part with an empty signature (e.g. left behind by an interrupted stream)
    must not be replayed as a `thinking` block: the API rejects empty signatures with a 400.
    It falls back to tagged text instead, like thinking parts from other providers.
    """
    c = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    message_history: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='Think about crossing the street.')]),
        ModelResponse(
            parts=[ThinkingPart(content='I was interrupted mid-thought', signature='', provider_name='anthropic')],
            provider_name='anthropic',
        ),
    ]

    await agent.run('Continue.', message_history=message_history)

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'text': 'Think about crossing the street.', 'type': 'text'}]},
            {
                'role': 'assistant',
                'content': [
                    {
                        'text': """\
<thinking>
I was interrupted mid-thought
</thinking>\
""",
                        'type': 'text',
                    }
                ],
            },
            {'role': 'user', 'content': [{'text': 'Continue.', 'type': 'text'}]},
        ]
    )


async def test_anthropic_model_thinking_part_redacted(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-5-20250929', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 1024})
    agent = Agent(m, model_settings=settings)

    result = await agent.run(
        'ANTHROPIC_MAGIC_STRING_TRIGGER_REDACTED_THINKING_46C9A13E193C177646C7398A98432ECCCE4C1253D5E2D82641AC0E52CC2876CB'
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='ANTHROPIC_MAGIC_STRING_TRIGGER_REDACTED_THINKING_46C9A13E193C177646C7398A98432ECCCE4C1253D5E2D82641AC0E52CC2876CB',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='',
                        id='redacted_thinking',
                        signature=IsStr(),
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=92,
                    output_tokens=196,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 92,
                        'output_tokens': 196,
                    },
                    cost=Decimal('0.003216'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01TbZ1ZKNMPq28AgBLyLX3c4',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    result = await agent.run(
        'What was that?',
        message_history=result.all_messages(),
    )
    assert result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What was that?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='',
                        id='redacted_thinking',
                        signature=IsStr(),
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=168,
                    output_tokens=232,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 168,
                        'output_tokens': 232,
                    },
                    cost=Decimal('0.003984'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_012oSSVsQdwoGH6b2fryM4fF',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_model_thinking_part_redacted_stream(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-5-20250929', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 1024})
    agent = Agent(m, model_settings=settings)

    event_parts: list[Any] = []
    async with agent.iter(
        user_prompt='ANTHROPIC_MAGIC_STRING_TRIGGER_REDACTED_THINKING_46C9A13E193C177646C7398A98432ECCCE4C1253D5E2D82641AC0E52CC2876CB'
    ) as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert agent_run.result is not None
    assert agent_run.result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='ANTHROPIC_MAGIC_STRING_TRIGGER_REDACTED_THINKING_46C9A13E193C177646C7398A98432ECCCE4C1253D5E2D82641AC0E52CC2876CB',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='',
                        id='redacted_thinking',
                        signature=IsStr(),
                        provider_name='anthropic',
                    ),
                    ThinkingPart(
                        content='',
                        id='redacted_thinking',
                        signature=IsStr(),
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=92,
                    output_tokens=189,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 92,
                        'output_tokens': 189,
                    },
                    cost=Decimal('0.003111'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_018XZkwvj9asBiffg3fXt88s',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    assert event_parts == snapshot(
        [
            PartStartEvent(
                index=0,
                part=ThinkingPart(
                    content='',
                    id='redacted_thinking',
                    signature=IsStr(),
                    provider_name='anthropic',
                ),
            ),
            PartEndEvent(
                index=0,
                part=ThinkingPart(
                    content='',
                    id='redacted_thinking',
                    signature='EqkECkYIBxgCKkA8AZ4noDfV5VcOJe/p3JTRB6Xz5297mrWhl3MbHSXDKTMfuB/Z52U2teiWWTN0gg4eQ4bGS9TPilFX/xWTIq9HEgyOmstSPriNwyn1G7AaDC51r0hQ062qEd55IiIwYQj3Z3MSBBv0bSVdXi60LEHDvC7tzzmpQfw5Hb6R9rtyOz/6vC/xPw9/E1mUqfBqKpADO2HS2QlE/CnuzR901nZOn0TOw7kEXwH7kg30c85b9W7iKALgEejY9sELMBdPyIZNlTgKqNOKtY3R/aV5rGIRPTHh2Wh9Ijmqsf/TT7i//Z+InaYTo6f/fxF8R0vFXMRPOBME4XIscb05HcNhh4c9FDkpqQGYKaq31IR1NNwPWA0BsvdDz7SIo1nfx4H+X0qKKqqegKnQ3ynaXiD5ydT1C4U7fku4ftgF0LGwIk4PwXBE+4BP0DcKr1HV3cn7YSyNakBSDTvRJMKcXW6hl7X3w2a4//sxjC1Cjq0uzkIHkhzRWirN0OSXt+g3m6b1ex0wGmSyuO17Ak6kgVBpxwPugtrqsflG0oujFem44hecXJ9LQNssPf4RSlcydiG8EXp/XLGTe0YfHbe3kJagkowSH/Dm6ErXBiVs7249brncyY8WA+7MOoqIM82YIU095B9frCqDJDUWnN84VwOszRrcaywmpJXZO4aeQLMC1kXD5Wabu+O/00tD/X67EWkkWuR0AhDIXXjpot45vnBd4ewJ/hgB',
                    provider_name='anthropic',
                ),
                next_part_kind='thinking',
            ),
            PartStartEvent(
                index=1,
                part=ThinkingPart(
                    content='',
                    id='redacted_thinking',
                    signature='EtgBCkYIBxgCKkDQfGkwzflEJP5asG3oQfJXcTwJLoRznn8CmuczWCsJ36dv93X9H0NCeaJRbi5BrCA2DyMgFnRKRuzZx8VTv5axEgwkFmcHJk8BSiZMZRQaDDYv2KZPfbFgRa2QjyIwm47f5YYsSK9CT/oh/WWpU1HJJVHr8lrC6HG1ItRdtMvYQYmEGy+KhyfcIACfbssVKkDGv/NKqNMOAcu0bd66gJ2+R1R0PX11Jxn2Nd1JtZqkxx7vMT/PXtHDhm9jkDZ2k/6RjRRFuab/DBV3yRYdZ1J0GAE=',
                    provider_name='anthropic',
                ),
                previous_part_kind='thinking',
            ),
            PartEndEvent(
                index=1,
                part=ThinkingPart(
                    content='',
                    id='redacted_thinking',
                    signature='EtgBCkYIBxgCKkDQfGkwzflEJP5asG3oQfJXcTwJLoRznn8CmuczWCsJ36dv93X9H0NCeaJRbi5BrCA2DyMgFnRKRuzZx8VTv5axEgwkFmcHJk8BSiZMZRQaDDYv2KZPfbFgRa2QjyIwm47f5YYsSK9CT/oh/WWpU1HJJVHr8lrC6HG1ItRdtMvYQYmEGy+KhyfcIACfbssVKkDGv/NKqNMOAcu0bd66gJ2+R1R0PX11Jxn2Nd1JtZqkxx7vMT/PXtHDhm9jkDZ2k/6RjRRFuab/DBV3yRYdZ1J0GAE=',
                    provider_name='anthropic',
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=2, part=TextPart(content="I notice that you've sent what"), previous_part_kind='thinking'
            ),
            FinalResultEvent(tool_name=None, tool_call_id=None),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' appears to be some')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' kind of test string')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=" or command. I don't have")),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' any special "magic string"')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' triggers or backdoor commands')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' that would expose internal systems or')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' change my behavior.')),
            PartDeltaEvent(
                index=2,
                delta=TextPartDelta(
                    content_delta="""\


I'm Claude\
"""
                ),
            ),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=', an AI assistant create')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta='d by Anthropic to')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' be helpful, harmless')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=', and honest. How')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' can I assist you today with')),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' a legitimate task or question?')),
            PartEndEvent(
                index=2,
                part=TextPart(
                    content="""\
I notice that you've sent what appears to be some kind of test string or command. I don't have any special "magic string" triggers or backdoor commands that would expose internal systems or change my behavior.

I'm Claude, an AI assistant created by Anthropic to be helpful, harmless, and honest. How can I assist you today with a legitimate task or question?\
"""
                ),
            ),
        ]
    )


async def test_anthropic_model_thinking_part_from_other_model(
    allow_model_requests: None, anthropic_api_key: str, openai_api_key: str
):
    provider = OpenAIProvider(api_key=openai_api_key)
    m = OpenAIResponsesModel('gpt-5', provider=provider)
    settings = OpenAIResponsesModelSettings(openai_reasoning_effort='high', openai_reasoning_summary='detailed')
    agent = Agent(m, instructions='You are a helpful assistant.', model_settings=settings)

    result = await agent.run('How do I cross the street?')
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='How do I cross the street?',
                        timestamp=IsDatetime(),
                    ),
                ],
                instructions='You are a helpful assistant.',
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content=IsStr(),
                        id='rs_68c1fda7b4d481a1a65f48aef6a6b85e06da9901a3d98ab7',
                        signature=IsStr(),
                        provider_name='openai',
                    ),
                    ThinkingPart(
                        content=IsStr(),
                        id='rs_68c1fda7b4d481a1a65f48aef6a6b85e06da9901a3d98ab7',
                        provider_name='openai',
                    ),
                    ThinkingPart(
                        content=IsStr(),
                        id='rs_68c1fda7b4d481a1a65f48aef6a6b85e06da9901a3d98ab7',
                        provider_name='openai',
                    ),
                    ThinkingPart(
                        content=IsStr(),
                        id='rs_68c1fda7b4d481a1a65f48aef6a6b85e06da9901a3d98ab7',
                        provider_name='openai',
                    ),
                    ThinkingPart(
                        content=IsStr(),
                        id='rs_68c1fda7b4d481a1a65f48aef6a6b85e06da9901a3d98ab7',
                        provider_name='openai',
                    ),
                    ThinkingPart(
                        content=IsStr(),
                        id='rs_68c1fda7b4d481a1a65f48aef6a6b85e06da9901a3d98ab7',
                        provider_name='openai',
                    ),
                    TextPart(
                        content=IsStr(),
                        id='msg_68c1fdbecbf081a18085a084257a9aef06da9901a3d98ab7',
                        provider_name='openai',
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=23,
                    output_tokens=2211,
                    output_reasoning_tokens=1920,
                    details={'reasoning_tokens': 1920},
                    cost=Decimal('0.02213875'),
                ),
                model_name='gpt-5-2025-08-07',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_details={
                    'finish_reason': 'completed',
                    'timestamp': datetime(2025, 9, 10, 22, 37, 27, tzinfo=timezone.utc),
                },
                provider_response_id='resp_68c1fda6f11081a1b9fa80ae9122743506da9901a3d98ab7',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    result = await agent.run(
        'Considering the way to cross the street, analogously, how do I cross the river?',
        model=AnthropicModel(
            'claude-sonnet-4-0',
            provider=AnthropicProvider(api_key=anthropic_api_key),
            settings=AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 1024}),
        ),
        message_history=result.all_messages(),
    )
    assert result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Considering the way to cross the street, analogously, how do I cross the river?',
                        timestamp=IsDatetime(),
                    )
                ],
                instructions='You are a helpful assistant.',
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content=IsStr(),
                        signature=IsStr(),
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=1343,
                    output_tokens=538,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 1343,
                        'output_tokens': 538,
                    },
                    cost=Decimal('0.012099'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_016e2w8nkCuArd5HFSfEwke7',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_model_thinking_part_stream(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-0', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 1024})
    agent = Agent(m, model_settings=settings)

    event_parts: list[Any] = []
    async with agent.iter(user_prompt='How do I cross the street?') as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert agent_run.result is not None
    assert agent_run.result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='How do I cross the street?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content=IsStr(),
                        signature=IsStr(),
                        provider_name='anthropic',
                    ),
                    TextPart(content=IsStr()),
                ],
                usage=RequestUsage(
                    input_tokens=43,
                    output_tokens=282,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 43,
                        'output_tokens': 282,
                    },
                    cost=Decimal('0.004359'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01ALwQ87pTS7hH1PjSdC9wJD',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    assert event_parts == snapshot(
        [
            PartStartEvent(index=0, part=ThinkingPart(content='', signature='', provider_name='anthropic')),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=IsInstance(ThinkingPartDelta)),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' This is basic')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' safety information that could')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' help prevent')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' accidents.')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta='')),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(
                    signature_delta='EvMCCkYICxgCKkCHP2cSuEdcJK/0rFwqES/ecn+VurRpNTwI4XNyM0vnNfGsc9OmE8YYHauwBZ/uaRpmlEn2I4/kszHlcpptO82JEgyRMSbPkJYaegxYF3AaDHZbSm9EzZ6CM+YtliIw3iNVP/ilYrfoneo8S2+ad/5xSC62nKbk6joLtKmqXgXwYFJRpjIUjM2V7EGReOPRKtoBKfNHVmdNf7SeMhHalX/ObSeJ1G/NjDyGQAsDjyHGd7uY1r5gAIn3Cpdv5r+gHYJmWT+w2uiKZsBDRoSf4O3Km0l752EhPD4InEhqpCKyqhbUZ3dt5+JVKQHk2iyTBhQMB/XBYgZTstIpRqQRXU5ypcrydgnqj3mD1G9C7YC0ZTCNvFluAx0OL8q+cQwufgfqKquLEf2+XMYzhx9jYkVFEpnf/s1nx6gNBATKfF3Dmrs2r4tWu2QJB+FjlRuDp/8dxUxgJbmyhGxb7XsYeb1vgb7wwzDvP/UhjfQYAQ=='
                ),
            ),
            PartEndEvent(
                index=0,
                part=ThinkingPart(
                    content='This is a straightforward question about pedestrian safety. I should provide clear, helpful advice about how to safely cross a street. This is basic safety information that could help prevent accidents.',
                    signature='EvMCCkYICxgCKkCHP2cSuEdcJK/0rFwqES/ecn+VurRpNTwI4XNyM0vnNfGsc9OmE8YYHauwBZ/uaRpmlEn2I4/kszHlcpptO82JEgyRMSbPkJYaegxYF3AaDHZbSm9EzZ6CM+YtliIw3iNVP/ilYrfoneo8S2+ad/5xSC62nKbk6joLtKmqXgXwYFJRpjIUjM2V7EGReOPRKtoBKfNHVmdNf7SeMhHalX/ObSeJ1G/NjDyGQAsDjyHGd7uY1r5gAIn3Cpdv5r+gHYJmWT+w2uiKZsBDRoSf4O3Km0l752EhPD4InEhqpCKyqhbUZ3dt5+JVKQHk2iyTBhQMB/XBYgZTstIpRqQRXU5ypcrydgnqj3mD1G9C7YC0ZTCNvFluAx0OL8q+cQwufgfqKquLEf2+XMYzhx9jYkVFEpnf/s1nx6gNBATKfF3Dmrs2r4tWu2QJB+FjlRuDp/8dxUxgJbmyhGxb7XsYeb1vgb7wwzDvP/UhjfQYAQ==',
                    provider_name='anthropic',
                ),
                next_part_kind='text',
            ),
            PartStartEvent(index=1, part=TextPart(content='Here are'), previous_part_kind='thinking'),
            FinalResultEvent(tool_name=None, tool_call_id=None),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(index=1, delta=IsInstance(TextPartDelta)),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\

- Stop\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' at')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' the curb and')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' look')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' left, right')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
, then left again
-\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' Wait for a')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' clear')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' gap')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
 in traffic
- Walk\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' br')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta='iskly but')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=" don't run")),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\

- Keep\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' looking')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' for traffic as')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' you cross')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\


**General\
"""
                ),
            ),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
 safety tips:**
- Put\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' away')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' phones and remove')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' head')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
phones
-\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' Wear bright')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' or')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' reflective clothing in')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' low light')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\

- Never\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' assume')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' drivers')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' see you')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\

-\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' Avoid crossing between')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
 parked cars
- Walk\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' facing')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' traffic')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' when there')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta="'s no")),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' sidew')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
alk

**In\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' busy')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' urban')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
 areas:**
- Follow\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' pedest')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta='rian signals strictly')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\

- Be\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' extra cautious of')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' cyclists')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' in')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' bike')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
 lanes
- Watch\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' for buses')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' and large')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' vehicles with')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' blind')),
            PartDeltaEvent(
                index=1,
                delta=TextPartDelta(
                    content_delta="""\
 spots

The\
"""
                ),
            ),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' key is to')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' be visible')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=', alert, and predict')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta='able in')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' your movements. Always')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' prioritize safety over speed')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' when')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' crossing')),
            PartDeltaEvent(index=1, delta=TextPartDelta(content_delta=' streets.')),
            PartEndEvent(
                index=1,
                part=TextPart(
                    content="""\
Here are the basic steps for safely crossing the street:

**At intersections with traffic lights:**
- Wait for the pedestrian "Walk" signal
- Look both ways before stepping into the street
- Make eye contact with drivers when possible
- Stay alert for turning vehicles

**At intersections without signals:**
- Use crosswalks when available
- Stop at the curb and look left, right, then left again
- Wait for a clear gap in traffic
- Walk briskly but don't run
- Keep looking for traffic as you cross

**General safety tips:**
- Put away phones and remove headphones
- Wear bright or reflective clothing in low light
- Never assume drivers see you
- Avoid crossing between parked cars
- Walk facing traffic when there's no sidewalk

**In busy urban areas:**
- Follow pedestrian signals strictly
- Be extra cautious of cyclists in bike lanes
- Watch for buses and large vehicles with blind spots

The key is to be visible, alert, and predictable in your movements. Always prioritize safety over speed when crossing streets.\
"""
                ),
            ),
        ]
    )


@pytest.mark.parametrize(
    'case_id',
    ['basic', 'effort', 'adaptive-thinking'],
)
async def test_anthropic_opus_46_features(
    allow_model_requests: None,
    anthropic_api_key: str,
    case_id: str,
):
    settings_map: dict[str, AnthropicModelSettings] = {
        'basic': AnthropicModelSettings(),
        'effort': AnthropicModelSettings(anthropic_effort='low'),
        'adaptive-thinking': AnthropicModelSettings(anthropic_thinking={'type': 'adaptive'}),
    }
    has_thinking = case_id == 'adaptive-thinking'
    m = AnthropicModel('claude-opus-4-6', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, model_settings=settings_map[case_id])

    result = await agent.run('What is 2+2?')
    response = message(result.all_messages(), ModelResponse, index=-1)
    assert response.model_name == 'claude-opus-4-6'

    if has_thinking:
        assert any(isinstance(p, ThinkingPart) for p in response.parts)
    assert any(isinstance(p, TextPart) for p in response.parts)


async def test_anthropic_opus_47_features(allow_model_requests: None, anthropic_api_key: str, vcr: Cassette):
    settings = AnthropicModelSettings(
        anthropic_thinking={'type': 'adaptive', 'display': 'summarized'},
        anthropic_effort='xhigh',
    )
    m = AnthropicModel('claude-opus-4-7', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, model_settings=settings)

    result = await agent.run('What is 2+2?')
    response = message(result.all_messages(), ModelResponse, index=-1)
    assert response.model_name == 'claude-opus-4-7'
    request_body = single_request_body(vcr)
    assert {k: request_body[k] for k in ('model', 'thinking', 'output_config')} == snapshot(
        {
            'model': 'claude-opus-4-7',
            'thinking': {'type': 'adaptive', 'display': 'summarized'},
            'output_config': {'effort': 'xhigh'},
        }
    )
    assert any(isinstance(p, TextPart) for p in response.parts)


async def test_anthropic_opus_48_features(allow_model_requests: None, anthropic_api_key: str, vcr: Cassette):
    settings = AnthropicModelSettings(
        anthropic_thinking={'type': 'adaptive', 'display': 'summarized'},
        anthropic_effort='xhigh',
    )
    m = AnthropicModel('claude-opus-4-8', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, model_settings=settings)

    result = await agent.run('What is 2+2?')
    response = message(result.all_messages(), ModelResponse, index=-1)
    assert response.model_name == 'claude-opus-4-8'
    request_body = single_request_body(vcr)
    assert {k: request_body[k] for k in ('model', 'thinking', 'output_config')} == snapshot(
        {
            'model': 'claude-opus-4-8',
            'thinking': {'type': 'adaptive', 'display': 'summarized'},
            'output_config': {'effort': 'xhigh'},
        }
    )
    assert any(isinstance(p, TextPart) for p in response.parts)
    # Thinking was enabled but the recording reports `thinking_tokens: 0`, which is omitted
    # rather than written as a zero.
    assert 'thinking_tokens' not in result.usage.details


async def test_anthropic_opus_5_features(allow_model_requests: None, anthropic_api_key: str, vcr: Cassette):
    settings = AnthropicModelSettings(
        anthropic_thinking={'type': 'adaptive', 'display': 'summarized'},
        anthropic_effort='xhigh',
    )
    m = AnthropicModel('claude-opus-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, model_settings=settings)

    result = await agent.run('What is 2+2?')
    response = message(result.all_messages(), ModelResponse, index=-1)
    assert response.model_name == 'claude-opus-5'
    request_body = single_request_body(vcr)
    assert {k: request_body[k] for k in ('model', 'thinking', 'output_config')} == snapshot(
        {
            'model': 'claude-opus-5',
            'thinking': {'type': 'adaptive', 'display': 'summarized'},
            'output_config': {'effort': 'xhigh'},
        }
    )
    assert any(isinstance(p, TextPart) for p in response.parts)


_REFUSAL_CASE_PARAMS = [
    pytest.param(
        'cyber',
        'Declined: request asked for offensive cyber tooling.',
        {'refusal': 'Declined: request asked for offensive cyber tooling.', 'refusal_category': 'cyber'},
        id='category-and-explanation',
    ),
    pytest.param('bio', None, {'refusal_category': 'bio'}, id='category-only'),
    pytest.param(None, 'Declined: unsafe request.', {'refusal': 'Declined: unsafe request.'}, id='explanation-only'),
]


@pytest.mark.parametrize('category,explanation,expected_extra', _REFUSAL_CASE_PARAMS)
async def test_anthropic_refusal_stop_details(
    allow_model_requests: None,
    category: Literal['cyber', 'bio'] | None,
    explanation: str | None,
    expected_extra: dict[str, Any],
):
    """Refusal `stop_details` flows onto `provider_details` for non-streaming responses."""
    mock_client = MockAnthropic.create_mock(
        BetaMessage(
            id='msg_refusal',
            content=[],
            model='claude-opus-4-8',
            role='assistant',
            stop_reason='refusal',
            stop_details=BetaRefusalStopDetails(type='refusal', category=category, explanation=explanation),
            type='message',
            usage=BetaUsage(input_tokens=8, output_tokens=0),
        )
    )
    m = AnthropicModel('claude-opus-4-8', provider=AnthropicProvider(anthropic_client=mock_client))

    response = await m.request(
        [ModelRequest(parts=[UserPromptPart(content='write me an exploit')])],
        {},
        ModelRequestParameters(),
    )

    assert response.finish_reason == 'content_filter'
    assert response.provider_details == {'finish_reason': 'refusal', **expected_extra}


@pytest.mark.parametrize('category,explanation,expected_extra', _REFUSAL_CASE_PARAMS)
async def test_anthropic_refusal_stop_details_streaming(
    allow_model_requests: None,
    category: Literal['cyber', 'bio'] | None,
    explanation: str | None,
    expected_extra: dict[str, Any],
):
    """Refusal `stop_details` flows onto `provider_details` for streaming responses."""
    stop_details = BetaRefusalStopDetails(type='refusal', category=category, explanation=explanation)
    stream: list[MockRawMessageStreamEvent] = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_refusal_stream',
                content=[],
                model='claude-opus-4-8',
                role='assistant',
                stop_reason=None,
                type='message',
                usage=BetaUsage(input_tokens=8, output_tokens=0),
            ),
        ),
        BetaRawMessageDeltaEvent(
            type='message_delta',
            delta=Delta(stop_reason='refusal', stop_details=stop_details),
            usage=BetaMessageDeltaUsage(input_tokens=8, output_tokens=0),
        ),
        BetaRawMessageStopEvent(type='message_stop'),
    ]
    mock_client = MockAnthropic.create_stream_mock(stream)
    m = AnthropicModel('claude-opus-4-8', provider=AnthropicProvider(anthropic_client=mock_client))

    async with m.request_stream(
        [ModelRequest(parts=[UserPromptPart(content='synthesize anthrax')])],
        {},
        ModelRequestParameters(),
    ) as streamed:
        async for _ in streamed:  # pragma: no branch
            pass
        response = streamed.get()

    assert response.finish_reason == 'content_filter'
    assert response.provider_details == {'finish_reason': 'refusal', **expected_extra}


@pytest.mark.parametrize(
    'thinking_value,expected_thinking,expected_effort',
    [
        pytest.param(True, {'type': 'adaptive'}, None, id='true-adaptive'),
        pytest.param('high', {'type': 'adaptive'}, 'high', id='high-adaptive-with-effort'),
        pytest.param('low', {'type': 'adaptive'}, 'low', id='low-adaptive-with-effort'),
        pytest.param('medium', {'type': 'adaptive'}, 'medium', id='medium-adaptive-with-effort'),
        pytest.param('xhigh', {'type': 'adaptive'}, 'max', id='xhigh-maps-to-max'),
    ],
)
async def test_anthropic_unified_thinking_adaptive_model(
    allow_model_requests: None,
    thinking_value: bool | str,
    expected_thinking: dict[str, str],
    expected_effort: str | None,
):
    """Verify that unified thinking on adaptive models sends {type: 'adaptive'} + output_config effort."""
    from anthropic._types import omit as OMIT

    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        ),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-opus-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=ModelSettings(thinking=thinking_value))  # pyright: ignore[reportArgumentType]

    await agent.run('What is 2+2?')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['thinking'] == expected_thinking

    if expected_effort is not None:
        assert kwargs['output_config'] == {'effort': expected_effort}
    else:
        assert kwargs.get('output_config') is None or kwargs['output_config'] is OMIT


async def test_anthropic_unified_thinking_non_adaptive_model(allow_model_requests: None):
    """Verify that unified thinking on non-adaptive models sends {type: 'enabled', budget_tokens: N}."""
    from anthropic._types import omit as OMIT

    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        ),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=ModelSettings(thinking='high'))

    await agent.run('What is 2+2?')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['thinking'] == {'type': 'enabled', 'budget_tokens': 16384}
    # Non-adaptive models don't support effort
    assert kwargs.get('output_config') is None or kwargs['output_config'] is OMIT


async def test_anthropic_unified_thinking_false_omits_param(allow_model_requests: None):
    """Verify that thinking=False does not send a thinking parameter at all."""
    from anthropic._types import omit as OMIT

    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        ),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-opus-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=ModelSettings(thinking=False))

    await agent.run('What is 2+2?')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    # thinking=False on always-thinking model is silently ignored — thinking param is OMIT
    assert kwargs.get('thinking') is OMIT


@pytest.mark.parametrize('model_name', ['claude-opus-4-7', 'claude-opus-4-8'])
async def test_anthropic_opus_47_rejects_budget_thinking(allow_model_requests: None, model_name: str):
    mock_client = MockAnthropic.create_mock(
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        )
    )
    m = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        model_settings=AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 1024}),
    )

    with pytest.raises(UserError, match=f"'{model_name}' does not support"):
        await agent.run('What is 2+2?')


@pytest.mark.parametrize('model_name', ['claude-opus-4-7', 'claude-opus-4-8'])
async def test_anthropic_unified_thinking_opus_47_xhigh(allow_model_requests: None, model_name: str):
    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        ),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=ModelSettings(thinking='xhigh'))

    await agent.run('What is 2+2?')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['thinking'] == {'type': 'adaptive'}
    assert kwargs['output_config'] == {'effort': 'xhigh'}


async def test_anthropic_task_budget_coexists_with_effort(
    allow_model_requests: None, anthropic_api_key: str, vcr: Cassette
):
    m = AnthropicModel('claude-opus-4-7', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(
        m,
        model_settings=AnthropicModelSettings(
            anthropic_effort='high',
            anthropic_task_budget={'type': 'tokens', 'total': 20_000},
        ),
    )

    result = await agent.run('What is 2+2?')
    assert result.output

    assert single_request_body(vcr)['output_config'] == snapshot(
        {'effort': 'high', 'task_budget': {'type': 'tokens', 'total': 20_000}}
    )


@pytest.mark.vcr()
async def test_anthropic_explicit_effort_xhigh_unsupported_model_errors(
    allow_model_requests: None, anthropic_api_key: str, vcr: Cassette
):
    """Explicit `anthropic_effort='xhigh'` is passed through so unsupported models fail at the API."""
    m = AnthropicModel('claude-opus-4-6', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, model_settings=AnthropicModelSettings(anthropic_effort='xhigh'))

    with pytest.raises(ModelHTTPError) as exc_info:
        await agent.run('What is 2+2?')

    assert (
        exc_info.value.status_code,
        exc_info.value.model_name,
        exc_info.value.body,
    ) == snapshot(
        (
            400,
            'claude-opus-4-6',
            {
                'error': {
                    'message': "This model does not support effort level 'xhigh'. Supported levels: high, low, max, medium.",
                    'type': 'invalid_request_error',
                },
                'request_id': IsStr(),
                'type': 'error',
            },
        )
    )


@pytest.mark.parametrize('model_name', ['claude-opus-4-7', 'claude-opus-4-8'])
@pytest.mark.parametrize('settings_source', ['agent', 'model'])
async def test_anthropic_opus_47_drops_sampling_settings(
    allow_model_requests: None, settings_source: Literal['agent', 'model'], model_name: str
):
    settings = AnthropicModelSettings(
        temperature=0.2,
        top_p=0.3,
        extra_body={'top_k': 5, 'metadata': {'keep': True}},
    )
    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        )
    ]
    mock_client = MockAnthropic.create_mock(responses)
    if settings_source == 'model':
        m = AnthropicModel(
            model_name,
            provider=AnthropicProvider(anthropic_client=mock_client),
            settings=settings,
        )
        agent = Agent(m)
    else:
        m = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
        agent = Agent(m, model_settings=settings)

    with pytest.warns(UserWarning, match='Sampling parameters'):
        await agent.run('What is 2+2?')

    # Original settings dict is preserved — filtering happens on a copy inside `prepare_request`.
    assert settings == snapshot(
        {'temperature': 0.2, 'top_p': 0.3, 'extra_body': {'top_k': 5, 'metadata': {'keep': True}}}
    )
    # The sampling settings ride in `extra_body`, so dropping them means they never appear there.
    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['extra_body'] == {'metadata': {'keep': True}}


@pytest.mark.parametrize('model_name', ['claude-opus-4-7', 'claude-opus-4-8'])
async def test_anthropic_opus_47_dedups_sampling_warning_across_settings_and_extra_body(
    allow_model_requests: None, model_name: str
):
    settings = AnthropicModelSettings(
        temperature=0.2,
        extra_body={'temperature': 0.5, 'top_k': 5},
    )
    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        )
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=settings)

    with pytest.warns(UserWarning) as recorded:
        await agent.run('What is 2+2?')

    sampling_warnings = [str(w.message) for w in recorded if 'Sampling parameters' in str(w.message)]
    assert sampling_warnings == [
        f"Sampling parameters ['temperature', 'top_k'] are not supported by '{model_name}'. These settings will be ignored."
    ]


@pytest.mark.parametrize('model_name', ['claude-opus-4-7', 'claude-opus-4-8'])
async def test_anthropic_opus_47_keeps_non_sampling_extra_body(allow_model_requests: None, model_name: str):
    settings = AnthropicModelSettings(temperature=0.2, extra_body={'metadata': {'keep': True}})
    responses = [
        completion_message(
            [BetaTextBlock(text='4', type='text')],
            usage=BetaUsage(input_tokens=10, output_tokens=1),
        )
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=settings)

    with pytest.warns(UserWarning, match='Sampling parameters'):
        await agent.run('What is 2+2?')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['extra_body'] == {'metadata': {'keep': True}}


async def test_anthropic_explicit_extra_body_overrides_the_sampling_setting(allow_model_requests: None):
    """A user's own `extra_body` entry wins over the `ModelSettings` field of the same name.

    Both now land in the same dict, where before the SDK merged `extra_body` over the named argument.
    Kept as a unit test because the precedence is only visible when the two disagree, which the API
    itself has no opinion about.
    """
    responses = [
        completion_message([BetaTextBlock(text='4', type='text')], usage=BetaUsage(input_tokens=10, output_tokens=1))
    ]
    mock_client = MockAnthropic.create_mock(responses)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    settings = AnthropicModelSettings(
        temperature=0.2, top_k=40, extra_body={'temperature': 0.9, 'metadata': {'keep': True}}
    )
    agent = Agent(m, model_settings=settings)

    await agent.run('What is 2+2?')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['extra_body'] == snapshot({'temperature': 0.9, 'top_k': 40, 'metadata': {'keep': True}})


@pytest.mark.vcr()
@pytest.mark.parametrize(
    'provider_specific_thinking',
    [pytest.param(True, id='provider_specific'), pytest.param(False, id='unified')],
)
async def test_anthropic_opus_46_adaptive_thinking_accepts_tool_output(
    allow_model_requests: None,
    anthropic_model: AnthropicModelFactory,
    request_capture: RequestCapture,
    provider_specific_thinking: bool,
):
    """Adaptive thinking is compatible with Tool Output, so the request keeps `output_mode='tool'`.

    Tool Output without a text fallback resolves to `tool_choice={'type': 'any'}`, i.e. forced tool
    use, so this exchange proves both halves of the compatibility claim at once. Only extended
    thinking conflicts: the same request with `{'type': 'enabled'}` is rejected by the API with
    `Thinking may not be enabled when tool_choice forces tool use.`, which is why that mode still
    switches away from Tool Output.

    Both ways of asking for thinking are exercised, because they reach the compatibility guards
    differently: the provider-specific setting carries the type itself, while a unified `thinking`
    only resolves to `adaptive` via the profile's `anthropic_supports_adaptive_thinking` flag.

    The outbound `thinking`/`tool_choice` pair is asserted via an httpx event hook so it runs against
    what the client actually sent, not what the cassette happens to hold.

    Regression test for https://github.com/pydantic/pydantic-ai/issues/7195.
    """
    model_settings: ModelSettings = (
        AnthropicModelSettings(anthropic_thinking={'type': 'adaptive'})
        if provider_specific_thinking
        else ModelSettings(thinking='high')
    )
    m = anthropic_model('claude-opus-4-6', capture=True)

    class CityLocation(BaseModel):
        city: str
        country: str

    agent = Agent(m, output_type=ToolOutput(CityLocation), model_settings=model_settings)
    result = await agent.run('What is the capital of France?')

    assert result.output == snapshot(CityLocation(city='Paris', country='France'))
    assert [(body['thinking'], body['tool_choice']) for body in request_capture.bodies()] == snapshot(
        [({'type': 'adaptive'}, {'type': 'any'})]
    )


async def test_multiple_system_prompt_formatting(allow_model_requests: None):
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic().create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, system_prompt='this is the system prompt')

    @agent.system_prompt
    def system_prompt() -> str:
        return 'and this is another'

    await agent.run('hello')
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert 'system' in completion_kwargs
    assert completion_kwargs['system'] == 'this is the system prompt\n\nand this is another'


async def test_non_leading_system_prompt_wraps_as_user_message(allow_model_requests: None):
    c = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic().create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    message_history: list[ModelRequest | ModelResponse] = [
        ModelRequest(
            parts=[SystemPromptPart(content='You are helpful.'), UserPromptPart(content='hi')],
        ),
        ModelResponse(parts=[TextPart(content='hello')]),
        ModelRequest(
            parts=[SystemPromptPart(content='Now be terse.'), UserPromptPart(content='what next?')],
        ),
    ]
    agent = Agent(m)
    await agent.run('continue', message_history=message_history)

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['system'] == 'You are helpful.'
    wrapped_contents = [
        block['text']
        for msg in kwargs['messages']
        if msg['role'] == 'user'
        for block in (msg['content'] if isinstance(msg['content'], list) else [{'text': msg['content']}])
        if '<system>' in block.get('text', '')
    ]
    assert wrapped_contents == ['<system>Now be terse.</system>']


def anth_msg(usage: BetaUsage) -> BetaMessage:
    return BetaMessage(
        id='x',
        content=[],
        model='claude-sonnet-4-5',
        role='assistant',
        type='message',
        usage=usage,
    )


@pytest.mark.parametrize(
    'message_callback,usage',
    [
        pytest.param(
            lambda: anth_msg(BetaUsage(input_tokens=1, output_tokens=1)),
            snapshot(RequestUsage(input_tokens=1, output_tokens=1, details={'input_tokens': 1, 'output_tokens': 1})),
            id='AnthropicMessage',
        ),
        pytest.param(
            lambda: anth_msg(
                BetaUsage(input_tokens=1, output_tokens=1, cache_creation_input_tokens=2, cache_read_input_tokens=3)
            ),
            snapshot(
                RequestUsage(
                    input_tokens=6,
                    cache_write_tokens=2,
                    cache_read_tokens=3,
                    output_tokens=1,
                    details={
                        'cache_creation_input_tokens': 2,
                        'cache_read_input_tokens': 3,
                        'input_tokens': 1,
                        'output_tokens': 1,
                    },
                )
            ),
            id='AnthropicMessage-cached',
        ),
        pytest.param(
            lambda: anth_msg(
                BetaUsage(
                    input_tokens=23,
                    output_tokens=1,
                    iterations=[
                        BetaCompactionIterationUsage(
                            type='compaction',
                            input_tokens=180,
                            output_tokens=3,
                            cache_creation_input_tokens=4,
                            cache_read_input_tokens=5,
                        ),
                        BetaMessageIterationUsage(
                            type='message',
                            model='claude-sonnet-4-5',
                            input_tokens=23,
                            output_tokens=1,
                            cache_creation_input_tokens=0,
                            cache_read_input_tokens=0,
                        ),
                    ],
                )
            ),
            snapshot(
                RequestUsage(
                    input_tokens=212,
                    output_tokens=4,
                    cache_write_tokens=4,
                    cache_read_tokens=5,
                    details={
                        'input_tokens': 23,
                        'output_tokens': 1,
                        'compaction_iterations': 1,
                        'message_iterations': 1,
                        'compaction_input_tokens': 180,
                        'compaction_output_tokens': 3,
                        'compaction_cache_creation_input_tokens': 4,
                        'compaction_cache_read_input_tokens': 5,
                    },
                )
            ),
            id='AnthropicMessage-compaction-iterations',
        ),
        pytest.param(
            lambda: BetaRawMessageStartEvent(
                message=anth_msg(BetaUsage(input_tokens=1, output_tokens=1)), type='message_start'
            ),
            snapshot(RequestUsage(input_tokens=1, output_tokens=1, details={'input_tokens': 1, 'output_tokens': 1})),
            id='RawMessageStartEvent',
        ),
    ],
)
def test_usage(
    message_callback: Callable[[], BetaMessage | BetaRawMessageStartEvent | BetaRawMessageDeltaEvent], usage: RunUsage
):
    assert _map_usage(message_callback(), 'anthropic', '', 'unknown') == usage


def test_usage_otel_attributes_omit_first_class_token_details_with_compaction():
    """With compaction, `details['input_tokens']` (raw, pre-compaction) diverges from the first-class
    `input_tokens` (raw + compaction totals), yet both name the same conceptual quantity. The colliding
    `input_tokens`/`output_tokens` detail keys must not be emitted under `gen_ai.usage.details.*`, or a
    Langfuse-style consumer summing them double-counts. `compaction_*` keys don't collide and are kept.
    """
    message = anth_msg(
        BetaUsage(
            input_tokens=23,
            output_tokens=1,
            iterations=[
                BetaCompactionIterationUsage(
                    type='compaction',
                    input_tokens=180,
                    output_tokens=3,
                    cache_creation_input_tokens=4,
                    cache_read_input_tokens=5,
                ),
                BetaMessageIterationUsage(
                    type='message',
                    model='claude-sonnet-4-5',
                    input_tokens=23,
                    output_tokens=1,
                    cache_creation_input_tokens=0,
                    cache_read_input_tokens=0,
                ),
            ],
        )
    )
    mapped = _map_usage(message, 'anthropic', '', 'unknown')
    assert mapped.input_tokens == 212
    assert mapped.details['input_tokens'] == 23  # still accessible on `details`
    attributes = mapped.opentelemetry_attributes()
    assert 'gen_ai.usage.details.input_tokens' not in attributes
    assert 'gen_ai.usage.details.output_tokens' not in attributes
    assert attributes == snapshot(
        {
            'gen_ai.usage.input_tokens': 212,
            'gen_ai.usage.output_tokens': 4,
            'gen_ai.usage.cache_creation.input_tokens': 4,
            'gen_ai.usage.cache_read.input_tokens': 5,
            'gen_ai.usage.details.compaction_iterations': 1,
            'gen_ai.usage.details.message_iterations': 1,
            'gen_ai.usage.details.compaction_input_tokens': 180,
            'gen_ai.usage.details.compaction_output_tokens': 3,
            'gen_ai.usage.details.compaction_cache_creation_input_tokens': 4,
            'gen_ai.usage.details.compaction_cache_read_input_tokens': 5,
            'gen_ai.usage.details.cache_write_tokens': 4,
            'gen_ai.usage.details.cache_read_tokens': 5,
        }
    )


def test_streaming_usage():
    start = BetaRawMessageStartEvent(message=anth_msg(BetaUsage(input_tokens=1, output_tokens=1)), type='message_start')
    initial_usage = _map_usage(start, 'anthropic', '', 'unknown')
    delta = BetaRawMessageDeltaEvent(delta=Delta(), usage=BetaMessageDeltaUsage(output_tokens=5), type='message_delta')
    final_usage = _map_usage(delta, 'anthropic', '', 'unknown', existing_usage=initial_usage)
    assert final_usage == snapshot(
        RequestUsage(input_tokens=1, output_tokens=5, details={'input_tokens': 1, 'output_tokens': 5})
    )


def test_streaming_usage_thinking_tokens():
    """`thinking_tokens` carried by a `message_delta` lands in the merged streaming usage.

    A unit test rather than a VCR one: it pins how a delta merges into the running usage, which a
    cassette cannot protect because the matcher replays whatever delta was recorded regardless.
    """
    start = BetaRawMessageStartEvent(message=anth_msg(BetaUsage(input_tokens=1, output_tokens=1)), type='message_start')
    initial_usage = _map_usage(start, 'anthropic', '', 'unknown')
    delta = BetaRawMessageDeltaEvent(
        delta=Delta(),
        usage=BetaMessageDeltaUsage(output_tokens=5, output_tokens_details=BetaOutputTokensDetails(thinking_tokens=3)),
        type='message_delta',
    )
    final_usage = _map_usage(delta, 'anthropic', '', 'unknown', existing_usage=initial_usage)
    assert final_usage == snapshot(
        RequestUsage(
            input_tokens=1,
            output_tokens=5,
            details={'input_tokens': 1, 'output_tokens': 5, 'thinking_tokens': 3},
        )
    )


def test_map_usage_bedrock_start_event_without_message():
    """On Bedrock the SDK drops SSE event types, so Bedrock-only chunks are non-validating
    `construct_type`d into `BetaRawMessageStartEvent(message=None)`, violating the annotation.
    `_map_usage` must not dereference `message.message.usage` on such events (https://github.com/pydantic/pydantic-ai/issues/5774).

    A unit test rather than VCR: the `message=None` event is an SDK construct artifact, not a
    server response shape, so it can't be elicited from a recorded request.
    """
    # `model_construct` skips validation, mirroring the SDK's `construct_type` on Bedrock.
    start = BetaRawMessageStartEvent.model_construct(type='message_start', message=None)
    assert _map_usage(start, 'anthropic', '', 'unknown') == snapshot(RequestUsage())

    existing = RequestUsage(input_tokens=7, output_tokens=3)
    assert _map_usage(start, 'anthropic', '', 'unknown', existing_usage=existing) == existing


async def test_streaming_bedrock_start_event_without_message_is_skipped(allow_model_requests: None):
    """A Bedrock `message=None` start event must be skipped across the whole streaming path (https://github.com/pydantic/pydantic-ai/issues/5774).

    On Bedrock the SDK drops SSE event types, so Bedrock-only chunks (e.g. `amazon-bedrock-invocationMetrics`)
    are non-validating `construct_type`d into `BetaRawMessageStartEvent(message=None)`. Driving `run_stream`
    exercises `_process_streamed_response` and `AnthropicStreamedResponse._get_event_iterator`, which
    previously crashed on `event.message.id`. The malformed chunk is placed first — a constructed worst case
    (real Bedrock trails the metrics chunk) that also reaches the `_process_streamed_response` model-name
    fallback: the streamed response then reports the configured model id, while usage and response id come
    from the real `message_start` that follows.
    """
    stream: list[MockRawMessageStreamEvent] = [
        # Contract-violating Bedrock chunk: the SDK hands out `message=None`.
        BetaRawMessageStartEvent.model_construct(type='message_start', message=None),
        BetaRawMessageStartEvent(message=anth_msg(BetaUsage(input_tokens=4, output_tokens=0)), type='message_start'),
        BetaRawContentBlockStartEvent(
            content_block=BetaTextBlock(text='hello', type='text'), index=0, type='content_block_start'
        ),
        BetaRawContentBlockStopEvent(index=0, type='content_block_stop'),
        BetaRawMessageDeltaEvent(
            delta=Delta(stop_reason='end_turn'),
            usage=BetaMessageDeltaUsage(output_tokens=2),
            type='message_delta',
        ),
        BetaRawMessageStopEvent(type='message_stop'),
    ]
    mock_client = MockAnthropic.create_stream_mock(stream)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    async with agent.run_stream('hello') as result:
        output = await result.get_output()
    assert output == snapshot('hello')

    # The skipped `message=None` chunk contributes no usage and no response id: usage comes from the
    # real `message_start` (input) + `message_delta` (output), and the id from the real event. The model
    # name falls back to the configured id because the peeked-first chunk carried no `message.model`.
    response = message(result.all_messages(), ModelResponse, index=-1)
    assert response.usage == snapshot(
        RequestUsage(
            input_tokens=4, output_tokens=2, details={'input_tokens': 4, 'output_tokens': 2}, cost=Decimal('0.000014')
        )
    )
    assert response.provider_response_id == 'x'
    assert response.model_name == 'claude-haiku-4-5'


def test_streaming_usage_with_compaction():
    """Delta events don't carry the `iterations` array, so the fixed compaction totals set
    by the start event must survive the merge and still be summed into the final totals."""
    start = BetaRawMessageStartEvent(
        message=anth_msg(
            BetaUsage(
                input_tokens=23,
                output_tokens=1,
                iterations=[
                    BetaCompactionIterationUsage(
                        type='compaction',
                        input_tokens=180,
                        output_tokens=3,
                        cache_creation_input_tokens=4,
                        cache_read_input_tokens=5,
                    ),
                    BetaMessageIterationUsage(
                        type='message',
                        model='claude-sonnet-4-5',
                        input_tokens=23,
                        output_tokens=1,
                        cache_creation_input_tokens=0,
                        cache_read_input_tokens=0,
                    ),
                ],
            )
        ),
        type='message_start',
    )
    initial_usage = _map_usage(start, 'anthropic', '', 'unknown')
    delta = BetaRawMessageDeltaEvent(
        delta=Delta(), usage=BetaMessageDeltaUsage(input_tokens=23, output_tokens=500), type='message_delta'
    )
    final_usage = _map_usage(delta, 'anthropic', '', 'unknown', existing_usage=initial_usage)
    assert final_usage == snapshot(
        RequestUsage(
            input_tokens=212,
            output_tokens=503,
            cache_write_tokens=4,
            cache_read_tokens=5,
            details={
                'input_tokens': 23,
                'output_tokens': 500,
                'compaction_iterations': 1,
                'message_iterations': 1,
                'compaction_input_tokens': 180,
                'compaction_output_tokens': 3,
                'compaction_cache_creation_input_tokens': 4,
                'compaction_cache_read_input_tokens': 5,
            },
        )
    )


async def test_anthropic_model_empty_message_on_history(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """The Anthropic API will error if you send an empty message on the history.

    Check <https://github.com/pydantic/pydantic-ai/pull/1027> for more details.
    """
    m = anthropic_model('claude-sonnet-4-5', capture=True)
    agent = Agent(m, instructions='You are a helpful assistant.')

    result = await agent.run(
        'I need a potato!',
        message_history=[
            ModelRequest(parts=[], instructions='You are a helpful assistant.', kind='request', timestamp=IsDatetime()),
            ModelResponse(parts=[TextPart(content='Hello, how can I help you?')], kind='response'),
        ],
    )
    assert request_capture.body()['system'] == snapshot([{'type': 'text', 'text': 'You are a helpful assistant.'}])
    assert result.output == snapshot("""\
I can't physically give you a potato since I'm a digital assistant. However, I can:

1. Help you find recipes that use potatoes
2. Give you tips on how to select, store, or prepare potatoes
3. Share information about different types of potatoes
4. Suggest where you might buy potatoes locally

What specific information about potatoes would be most helpful to you?\
""")


async def test_anthropic_web_search_tool(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-0', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(m, capabilities=[NativeTool(WebSearchTool())], model_settings=settings)

    result = await agent.run('What is the weather in San Francisco today?')
    # The native tool declaration and `tool_choice` as actually sent. `tool_choice` is `None` here
    # while the cassette still records `{'type': 'auto'}`: requests carrying no function tools stopped
    # sending it when #3611 added the `tool_choice` setting. Pre-existing drift that the lax cassette
    # matchers hid — this PR adds the detection, it did not change the behaviour.
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_search',
                    'type': 'web_search_20250305',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'user_location': None,
                }
            ],
            None,
        )
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='What is the weather in San Francisco today?', timestamp=IsDatetime())],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content="""\
The user is asking about the weather in San Francisco today. This is asking for current, real-time information that would require a web search since weather conditions change frequently and I need up-to-date information. According to the guidelines, I should search for current conditions or recent events, and this clearly falls under that category.

I should search for San Francisco weather today to get the most current information.\
""",
                        signature='Et0ECkYIBxgCKkCXTXBKWJ3QYffHphenTDDE5jxo/vbyyvFuY7Gi5PGLYFdjxF0KQ4BGT7bGzB53hSRPgJtjUD975U7TZ4f9IheWEgy4pMKmvEJ0D9XDrxsaDDpjMZqhX/EnpJmjGyIwreKtd2Xj+RpguF1YI50dldiwk6qQNW2rK+xLwmWY5qF75b7WZrmOZ3endXYEQjBMKsQDmsnYnUODvD5Uh/yRIUgOp+6P5JrYjLabtsC3wfuIISLVe5QhC/3Ep7K/x55u97qy/DIhCAOz38x4YId37Pqq8XARrRq5CPwzxBzsMfPwpeV5eRHLQmasZxpOhivd1lMLC7B6D9EdpWefKWE+Ux1cMxpfaQj45cpMn93qLyCLGtNqnZJ2nPT7eoOtavZ9VvN5LsJOIWYEkxK+iq/6XYSJE5JlqBtDt9Y5P1QT/QnhFwfxjD/Cs3+RrGzKp2loEjmeYzNBwEfbY+pyKHJUS3bsxWyyi0d9Gc6Zfj4Xiuf/G0ninvXpSQheXi5gcvqIir6ZhcC40vHwvdVtJipSLkqMoPQcppCTOa2ATFyLKZIlug2OjoWIHrC5xnkCuKLXVMtHTF0mdrW0R/SgecnequYprzPeCc+Niqf4CVk62qtp+H06oWKQvHbP+s7kuAbdnhJjkcETiN8fP7+eLzKjRFAVnT0tixaNFjB6lWbg2ePyQDhqeVn6i/ULCzKyoY/hSIfZXUFwTCSDW42WvITFfPfWBBW+p6R/8peJ/KS2q0wHT2G3N4N7xFaNLOTXE0iPPtWsdqZw4cNQi9IUGKayqZ+/02tJYaEYAQ==',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='web_search',
                        args={'query': 'San Francisco weather today'},
                        tool_call_id='srvtoolu_01EoSNE7k4dUJyGatASCV5qs',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_search',
                        content=[
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '6 days ago',
                                'title': 'San Francisco, CA Weather Forecast | AccuWeather',
                                'type': 'web_search_result',
                                'url': 'https://www.accuweather.com/en/us/san-francisco/94103/weather-forecast/347629',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '6 days ago',
                                'title': '10-Day Weather Forecast for San Francisco, CA - The Weather Channel | weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/tenday/l/San+Francisco+CA+USCA0987:1:US',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Weather Forecast and Conditions for San Francisco, CA - The Weather Channel | Weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/today/l/USCA0987:1:US',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA 10-Day Weather Forecast | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/forecast/us/ca/san-francisco',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 week ago',
                                'title': 'National Weather Service',
                                'type': 'web_search_result',
                                'url': 'https://forecast.weather.gov/MapClick.php?lat=37.7771&lon=-122.4196',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 week ago',
                                'title': 'San Francisco Bay Area weather forecast – NBC Bay Area',
                                'type': 'web_search_result',
                                'url': 'https://www.nbcbayarea.com/weather/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA Current Weather - The Weather Network',
                                'type': 'web_search_result',
                                'url': 'https://www.theweathernetwork.com/en/city/us/california/san-francisco/current?_guid_iss_=1',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '6 days ago',
                                'title': 'San Francisco, CA Weather Conditions | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/weather/us/ca/san-francisco',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA Hourly Weather Forecast | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/hourly/us/ca/san-francisco',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 week ago',
                                'title': 'Live Doppler 7 | Bay Area Weather News - ABC7 San Francisco',
                                'type': 'web_search_result',
                                'url': 'https://abc7news.com/weather/',
                            },
                        ],
                        tool_call_id='srvtoolu_01EoSNE7k4dUJyGatASCV5qs',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
Based on the search results, here's the weather information for San Francisco today (September 16, 2025):

**Current Conditions:**
- \
"""
                    ),
                    TextPart(content='Temperature: 66°F with clear skies'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Wind: W at 3 mph with gusts up to 5 mph'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Air quality is poor and unhealthy for sensitive groups'),
                    TextPart(
                        content="""\


**Today's Forecast:**
- \
"""
                    ),
                    TextPart(content='High: 78°F with partly cloudy skies'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Winds W at 10 to 20 mph'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='8% chance of precipitation'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(
                        content='Some clouds in the morning will give way to mainly sunny skies for the afternoon'
                    ),
                    TextPart(
                        content="""\


**Tonight:**
- \
"""
                    ),
                    TextPart(content='Low: 57°F with clear to partly cloudy conditions'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Winds W at 10 to 20 mph'),
                    TextPart(
                        content="""\


Overall, it's a pleasant day in San Francisco with mild temperatures and mostly sunny conditions, though the air quality is poor, so sensitive individuals should limit outdoor activities.\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=8984,
                    output_tokens=520,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 8984,
                        'output_tokens': 520,
                    },
                    cost=Decimal('0.034752'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_0119wM5YxCLg3hwUWrxEQ9Y8',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    messages = result.all_messages()
    result = await agent.run(user_prompt='how about Mexico City?', message_history=messages)
    assert result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='how about Mexico City?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user is now asking about the weather in Mexico City today. I should search for current weather information for Mexico City.',
                        signature='EqgCCkYIBxgCKkAhyrWtc4MfwZtLCpH/f41h3xS0UBTKetW5LA6ADj/q/8G5GiD+31L8MWU5+8QbLKrdzKIr5RZTEmval6pjPCxwEgygcM1WHSKHKa3PiscaDDtaNmY6L04w/DaCFSIw4mjvUNimq2ShpHNyVrezsnnXaRyyt2Ei4Iik2sCgzARFHGyDNzerHS/aCxzMR8MFKo8BVo7IxMBObxJIn43oG4aHroTyH4tX0IB3HPE1L1O/RZ9HfrmCc/KJwvIc79klaolMdyFvc343GJbssZxF1YJ+8YgGJtrzsKaawjsNelJBqkNWdF/TFwY0G+zGS90yWmHp4hFylIib5OTYz1Dm8O066biiZps8EDkINIoiIfkslPdnP3FWiCl9g6+gSiJd+WwYAQ==',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='web_search',
                        args={'query': 'Mexico City weather today'},
                        tool_call_id='srvtoolu_01SnV7n4h3ZQtz14JriSp4xa',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_search',
                        content=[
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 month ago',
                                'title': 'Weather Forecast and Conditions for Mexico City, Mexico - The Weather Channel | Weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/today/l/6121681b2c5df01145b9723d497c595c53ae08104787aa1c26bafdf2fb875c07',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Mexico City, México City, Mexico Weather Forecast | AccuWeather',
                                'type': 'web_search_result',
                                'url': 'https://www.accuweather.com/en/mx/mexico-city/242560/weather-forecast/242560',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': 'August 12, 2025',
                                'title': 'Weather Forecast and Conditions for Cuauhtémoc, Mexico - The Weather Channel | Weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/today/l/Cuauht%C3%A9moc+Mexico?canonicalCityId=7164197a006f4e553a538a0b73c06757',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Mexico City, CMX, MX Current Weather - The Weather Network',
                                'type': 'web_search_result',
                                'url': 'https://www.theweathernetwork.com/en/city/mx/ciudad-de-mexico/mexico-city/current?_guid_iss_=1',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Mexico City, Mexico 10-Day Weather Forecast | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/forecast/mx/mexico-city',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': 'August 12, 2025',
                                'title': 'Mexico City, Mexico Weather Conditions | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/weather/mx/mexico-city',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': 'June 19, 2025',
                                'title': 'Weather for Mexico City, Ciudad de México, Mexico',
                                'type': 'web_search_result',
                                'url': 'https://www.timeanddate.com/weather/mexico/mexico-city',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': '10-Day Weather Forecast for Mexico City, Mexico - The Weather Channel | weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/tenday/l/6121681b2c5df01145b9723d497c595c53ae08104787aa1c26bafdf2fb875c07',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Yr - Mexico City - Hourly weather forecast',
                                'type': 'web_search_result',
                                'url': 'https://www.yr.no/en/forecast/hourly-table/2-3530597/Mexico/Mexico%20City/Mexico%20City?i=0',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': '10-Day Weather Forecast for Cuauhtémoc, Mexico - The Weather Channel | weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/tenday/l/Cuauht%C3%A9moc+Mexico?canonicalCityId=7164197a006f4e553a538a0b73c06757',
                            },
                        ],
                        tool_call_id='srvtoolu_01SnV7n4h3ZQtz14JriSp4xa',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
Based on the search results, here's the weather information for Mexico City today (September 16, 2025):

**Current Conditions:**
- \
"""
                    ),
                    TextPart(content='Temperature: 59°F (15°C) with clouds and sun'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Wind: NNE at 6 mph with gusts up to 6 mph'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Air quality is poor and unhealthy for sensitive groups'),
                    TextPart(
                        content="""\


**Today's Forecast:**
- \
"""
                    ),
                    TextPart(content='High: 72°F (22°C) - mostly cloudy with a touch of rain this afternoon'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(
                        content='High 73F with partly cloudy conditions early followed by scattered thunderstorms. Winds NNE at 10 to 15 mph, 70% chance of rain'
                    ),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(
                        content='Scattered thunderstorms developing during the afternoon. High near 75F with winds NNE at 10 to 15 mph and 70% chance of rain'
                    ),
                    TextPart(
                        content="""\


**Tonight:**
- \
"""
                    ),
                    TextPart(content='Low: 58°F with cloudy conditions and a couple of showers'),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(content='Cloudy overnight with low 57F and winds NNW at 10 to 15 mph'),
                    TextPart(
                        content="""\


Mexico City is experiencing typical rainy season weather with moderate temperatures, high humidity, and afternoon thunderstorms expected. Like San Francisco, the air quality is poor, so those with respiratory sensitivities should take precautions.\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=19859,
                    output_tokens=544,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 19859,
                        'output_tokens': 544,
                    },
                    cost=Decimal('0.067737'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01Vatv9GeGaeqVHfSGhkU7mo',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_model_web_search_tool_stream(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-0', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(m, capabilities=[NativeTool(WebSearchTool())], model_settings=settings)

    event_parts: list[Any] = []
    async with agent.iter(user_prompt='What is the weather in San Francisco today?') as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert agent_run.result is not None
    messages = agent_run.result.all_messages()
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_search',
                    'type': 'web_search_20250305',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'user_location': None,
                }
            ],
            None,
        )
    )
    assert messages == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the weather in San Francisco today?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content="""\
The user is asking about the weather in San Francisco today. This is clearly a request for current, real-time information that changes daily, so I should use web search to get up-to-date weather information. According to the guidelines, today's date is September 16, 2025.

I should search for current weather in San Francisco. I'll include "today" in the search query to get the most current information.\
""",
                        signature='Er8ECkYIBxgCKkDp29haxwUos3j9hg3HNQI8e4jcFtinIsLxpzaQR/MhPnIpHkUpSNPatD/C2EVyiEGg2LIO1lhkU/P8XLgiyejFEgzinYyrRtGe03DeFEIaDL63CVUOAo1v/57lpSIw+msm1NHv1h+xLzkbu2YqlXPwjza0tVjwAj7RLUFwB1HpPbdv6hlityaMFb/SwKZZKqYDwbYu36cdPpUcpirpZaKZ/DITzfWJkX93BXmRl5au50mxAiFe9B8XxreADaofra5cmevEaaLH0b5Ze/IC0ja/cJdo9NoVlyHlqdXmex22CAkg0Y/HnsZr8MbnE6GyG9bOqAEhwb6YgKHMaMLDVmElbNSsD7luWtsbw5BDvRaqSSROzTxH4s0dqjUqJsoOBeUXuUqWHSl2KwQi8akELKUnvlDz15ZwFI1yVTHA5nSMFIhjB0jECs1g8PjFkAYTHkHddYR5/SLruy1ENpKU0xjc/hd/O41xnI3PxHBGDKv/hdeSVBKjJ0SDYIwXW96QS5vzlKxYGCqtibj2VxPzUlDITvhn1oO+cjCXClo1lE+ul//+nk7jk7fRkvl1/+pscYCpBoGKprA7CU1kpiggO9pAVUrpZM9vC2jF5/VVVYEoY3CyC+hrNpDWXTUdGdCTofhp2wdWVZzCmO7/+L8SUnlu64YYe9PWsRDuHRe8Lvl0M9EyBrhWnGWQkkk9b+O5uNU5xgE0sjbuGzgYswhwSd7Powb8XbtbW6h7lTbo1M2IQ3Ok0kdt0RAYAQ==',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='web_search',
                        args='{"query": "San Francisco weather today"}',
                        tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_search',
                        content=[
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '6 days ago',
                                'title': 'San Francisco, CA Weather Forecast | AccuWeather',
                                'type': 'web_search_result',
                                'url': 'https://www.accuweather.com/en/us/san-francisco/94103/weather-forecast/347629',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '6 days ago',
                                'title': '10-Day Weather Forecast for San Francisco, CA - The Weather Channel | weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/tenday/l/San+Francisco+CA+USCA0987:1:US',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Weather Forecast and Conditions for San Francisco, CA - The Weather Channel | Weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/today/l/USCA0987:1:US',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA 10-Day Weather Forecast | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/forecast/us/ca/san-francisco',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 week ago',
                                'title': 'National Weather Service',
                                'type': 'web_search_result',
                                'url': 'https://forecast.weather.gov/MapClick.php?lat=37.7771&lon=-122.4196',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 week ago',
                                'title': 'San Francisco Bay Area weather forecast – NBC Bay Area',
                                'type': 'web_search_result',
                                'url': 'https://www.nbcbayarea.com/weather/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA Current Weather - The Weather Network',
                                'type': 'web_search_result',
                                'url': 'https://www.theweathernetwork.com/en/city/us/california/san-francisco/current?_guid_iss_=1',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '6 days ago',
                                'title': 'San Francisco, CA Weather Conditions | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/weather/us/ca/san-francisco',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA Hourly Weather Forecast | Weather Underground',
                                'type': 'web_search_result',
                                'url': 'https://www.wunderground.com/hourly/us/ca/san-francisco',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '1 week ago',
                                'title': 'Live Doppler 7 | Bay Area Weather News - ABC7 San Francisco',
                                'type': 'web_search_result',
                                'url': 'https://abc7news.com/weather/',
                            },
                        ],
                        tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content='Based on the search results, I can see that the information is a bit dated (most results are from about 6 days to a week ago), but I can provide you with the available weather information for San Francisco. Let me search for more current information.'
                    ),
                    NativeToolCallPart(
                        tool_name='web_search',
                        args='{"query": "San Francisco weather September 16 2025"}',
                        tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_search',
                        content=[
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco weather in September 2025 | Weather25.com',
                                'type': 'web_search_result',
                                'url': 'https://www.weather25.com/north-america/usa/california/san-francisco?page=month&month=September',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Weather in San Francisco in September 2025 (California) - detailed Weather Forecast for a month',
                                'type': 'web_search_result',
                                'url': 'https://world-weather.info/forecast/usa/san_francisco/september-2025/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, CA Monthly Weather | AccuWeather',
                                'type': 'web_search_result',
                                'url': 'https://www.accuweather.com/en/us/san-francisco/94103/september-weather/347629',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Weather San Francisco in September 2025: Temperature & Climate',
                                'type': 'web_search_result',
                                'url': 'https://en.climate-data.org/north-america/united-states-of-america/california/san-francisco-385/t/september-9/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco weather in September 2025 | California',
                                'type': 'web_search_result',
                                'url': 'https://www.weather2travel.com/california/san-francisco/september/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco, Weather for September, USA',
                                'type': 'web_search_result',
                                'url': 'https://www.holiday-weather.com/san_francisco/averages/september/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'Monthly Weather Forecast for San Francisco, CA - weather.com',
                                'type': 'web_search_result',
                                'url': 'https://weather.com/weather/monthly/l/69bedc6a5b6e977993fb3e5344e3c06d8bc36a1fb6754c3ddfb5310a3c6d6c87',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '3 weeks ago',
                                'title': 'September 2025 Weather - San Francisco',
                                'type': 'web_search_result',
                                'url': 'https://www.easeweather.com/north-america/united-states/california/city-and-county-of-san-francisco/san-francisco/september',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': None,
                                'title': 'San Francisco Weather in September | Thomas Cook',
                                'type': 'web_search_result',
                                'url': 'https://www.thomascook.com/holidays/weather/usa/california/san-francisco/september/',
                            },
                            {
                                'encrypted_content': IsStr(),
                                'page_age': '4 days ago',
                                'title': IsStr(),
                                'type': 'web_search_result',
                                'url': 'https://www.sfchronicle.com/weather-forecast/article/weather-forecast-san-francisco-21043269.php',
                            },
                        ],
                        tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
Based on the search results, I can provide you with information about San Francisco's weather today (September 16, 2025):

According to AccuWeather's forecast, \
"""
                    ),
                    TextPart(content='today (September 16) shows a high of 76°F and low of 59°F'),
                    TextPart(
                        content="""\
 for San Francisco.

From the recent San Francisco Chronicle weather report, \
"""
                    ),
                    TextPart(content='average mid-September highs in San Francisco are around 70 degrees'),
                    TextPart(
                        content="""\
, so today's forecast of 76°F is slightly above the typical temperature for this time of year.

The general weather pattern for San Francisco in September includes:
- \
"""
                    ),
                    TextPart(
                        content='Daytime temperatures usually reach 22°C (72°F) in San Francisco in September, falling to 13°C (55°F) at night'
                    ),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(
                        content='There are normally 9 hours of bright sunshine each day in San Francisco in September'
                    ),
                    TextPart(
                        content="""\

- \
"""
                    ),
                    TextPart(
                        content='San Francisco experiences minimal rainfall in September, with an average precipitation of just 3mm. Typically, there are no rainy days during this month'
                    ),
                    TextPart(
                        content="""\


So for today, you can expect partly sunny to sunny skies with a high around 76°F (24°C) and a low around 59°F (15°C), with very little chance of rain. It's shaping up to be a pleasant day in San Francisco!\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=22397,
                    output_tokens=637,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 22397,
                        'output_tokens': 637,
                    },
                    cost=Decimal('0.076746'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01QmxBSdEbD9ZeBWDVgFDoQ5',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    assert event_parts == snapshot(
        [
            PartStartEvent(index=0, part=ThinkingPart(content='', signature='', provider_name='anthropic')),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta='The user is asking about the weather'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' in San Francisco today. This is clearly a request'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' for current, real-time information'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' that changes daily, so I should use'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' web search to get up-to-date weather'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' information. According to the guidelines, today'),
            ),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta="'s date is September 16, ")),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(
                    content_delta="""\
2025.

I should search for current\
"""
                ),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' weather in San Francisco. I\'ll include "'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta='today" in the search query to get the most current'),
            ),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' information.')),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(
                    signature_delta='Er8ECkYIBxgCKkDp29haxwUos3j9hg3HNQI8e4jcFtinIsLxpzaQR/MhPnIpHkUpSNPatD/C2EVyiEGg2LIO1lhkU/P8XLgiyejFEgzinYyrRtGe03DeFEIaDL63CVUOAo1v/57lpSIw+msm1NHv1h+xLzkbu2YqlXPwjza0tVjwAj7RLUFwB1HpPbdv6hlityaMFb/SwKZZKqYDwbYu36cdPpUcpirpZaKZ/DITzfWJkX93BXmRl5au50mxAiFe9B8XxreADaofra5cmevEaaLH0b5Ze/IC0ja/cJdo9NoVlyHlqdXmex22CAkg0Y/HnsZr8MbnE6GyG9bOqAEhwb6YgKHMaMLDVmElbNSsD7luWtsbw5BDvRaqSSROzTxH4s0dqjUqJsoOBeUXuUqWHSl2KwQi8akELKUnvlDz15ZwFI1yVTHA5nSMFIhjB0jECs1g8PjFkAYTHkHddYR5/SLruy1ENpKU0xjc/hd/O41xnI3PxHBGDKv/hdeSVBKjJ0SDYIwXW96QS5vzlKxYGCqtibj2VxPzUlDITvhn1oO+cjCXClo1lE+ul//+nk7jk7fRkvl1/+pscYCpBoGKprA7CU1kpiggO9pAVUrpZM9vC2jF5/VVVYEoY3CyC+hrNpDWXTUdGdCTofhp2wdWVZzCmO7/+L8SUnlu64YYe9PWsRDuHRe8Lvl0M9EyBrhWnGWQkkk9b+O5uNU5xgE0sjbuGzgYswhwSd7Powb8XbtbW6h7lTbo1M2IQ3Ok0kdt0RAYAQ=='
                ),
            ),
            PartEndEvent(
                index=0,
                part=ThinkingPart(
                    content="""\
The user is asking about the weather in San Francisco today. This is clearly a request for current, real-time information that changes daily, so I should use web search to get up-to-date weather information. According to the guidelines, today's date is September 16, 2025.

I should search for current weather in San Francisco. I'll include "today" in the search query to get the most current information.\
""",
                    signature='Er8ECkYIBxgCKkDp29haxwUos3j9hg3HNQI8e4jcFtinIsLxpzaQR/MhPnIpHkUpSNPatD/C2EVyiEGg2LIO1lhkU/P8XLgiyejFEgzinYyrRtGe03DeFEIaDL63CVUOAo1v/57lpSIw+msm1NHv1h+xLzkbu2YqlXPwjza0tVjwAj7RLUFwB1HpPbdv6hlityaMFb/SwKZZKqYDwbYu36cdPpUcpirpZaKZ/DITzfWJkX93BXmRl5au50mxAiFe9B8XxreADaofra5cmevEaaLH0b5Ze/IC0ja/cJdo9NoVlyHlqdXmex22CAkg0Y/HnsZr8MbnE6GyG9bOqAEhwb6YgKHMaMLDVmElbNSsD7luWtsbw5BDvRaqSSROzTxH4s0dqjUqJsoOBeUXuUqWHSl2KwQi8akELKUnvlDz15ZwFI1yVTHA5nSMFIhjB0jECs1g8PjFkAYTHkHddYR5/SLruy1ENpKU0xjc/hd/O41xnI3PxHBGDKv/hdeSVBKjJ0SDYIwXW96QS5vzlKxYGCqtibj2VxPzUlDITvhn1oO+cjCXClo1lE+ul//+nk7jk7fRkvl1/+pscYCpBoGKprA7CU1kpiggO9pAVUrpZM9vC2jF5/VVVYEoY3CyC+hrNpDWXTUdGdCTofhp2wdWVZzCmO7/+L8SUnlu64YYe9PWsRDuHRe8Lvl0M9EyBrhWnGWQkkk9b+O5uNU5xgE0sjbuGzgYswhwSd7Powb8XbtbW6h7lTbo1M2IQ3Ok0kdt0RAYAQ==',
                    provider_name='anthropic',
                ),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=1,
                part=NativeToolCallPart(
                    tool_name='web_search', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h', provider_name='anthropic'
                ),
                previous_part_kind='thinking',
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='{"query": ', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='"Sa', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='n Fr', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='anc', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='isc', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='o weather', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta=' tod', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='ay"}', tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h')
            ),
            PartEndEvent(
                index=1,
                part=NativeToolCallPart(
                    tool_name='web_search',
                    args='{"query": "San Francisco weather today"}',
                    tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h',
                    provider_name='anthropic',
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=2,
                part=NativeToolReturnPart(
                    tool_name='web_search',
                    content=[
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '6 days ago',
                            'title': 'San Francisco, CA Weather Forecast | AccuWeather',
                            'type': 'web_search_result',
                            'url': 'https://www.accuweather.com/en/us/san-francisco/94103/weather-forecast/347629',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '6 days ago',
                            'title': '10-Day Weather Forecast for San Francisco, CA - The Weather Channel | weather.com',
                            'type': 'web_search_result',
                            'url': 'https://weather.com/weather/tenday/l/San+Francisco+CA+USCA0987:1:US',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Weather Forecast and Conditions for San Francisco, CA - The Weather Channel | Weather.com',
                            'type': 'web_search_result',
                            'url': 'https://weather.com/weather/today/l/USCA0987:1:US',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco, CA 10-Day Weather Forecast | Weather Underground',
                            'type': 'web_search_result',
                            'url': 'https://www.wunderground.com/forecast/us/ca/san-francisco',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 week ago',
                            'title': 'National Weather Service',
                            'type': 'web_search_result',
                            'url': 'https://forecast.weather.gov/MapClick.php?lat=37.7771&lon=-122.4196',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 week ago',
                            'title': 'San Francisco Bay Area weather forecast – NBC Bay Area',
                            'type': 'web_search_result',
                            'url': 'https://www.nbcbayarea.com/weather/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco, CA Current Weather - The Weather Network',
                            'type': 'web_search_result',
                            'url': 'https://www.theweathernetwork.com/en/city/us/california/san-francisco/current?_guid_iss_=1',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '6 days ago',
                            'title': 'San Francisco, CA Weather Conditions | Weather Underground',
                            'type': 'web_search_result',
                            'url': 'https://www.wunderground.com/weather/us/ca/san-francisco',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco, CA Hourly Weather Forecast | Weather Underground',
                            'type': 'web_search_result',
                            'url': 'https://www.wunderground.com/hourly/us/ca/san-francisco',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 week ago',
                            'title': 'Live Doppler 7 | Bay Area Weather News - ABC7 San Francisco',
                            'type': 'web_search_result',
                            'url': 'https://abc7news.com/weather/',
                        },
                    ],
                    tool_call_id='srvtoolu_01FYcUbzEaqqQh1WBRj1QX3h',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(index=3, part=TextPart(content='Base'), previous_part_kind='builtin-tool-return'),
            FinalResultEvent(tool_name=None, tool_call_id=None),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='d on the search results, I can see')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' that the information is a bit date')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='d (most results are from about 6')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' days to a week ago), but I can provide')),
            PartDeltaEvent(
                index=3,
                delta=TextPartDelta(content_delta=' you with the available weather information for San Francisco.'),
            ),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' Let me search for more current')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' information.')),
            PartEndEvent(
                index=3,
                part=TextPart(
                    content='Based on the search results, I can see that the information is a bit dated (most results are from about 6 days to a week ago), but I can provide you with the available weather information for San Francisco. Let me search for more current information.'
                ),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=4,
                part=NativeToolCallPart(
                    tool_name='web_search', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx', provider_name='anthropic'
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='{"', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='quer', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='y": ', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='"San', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta=' Fra', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='nci', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='sco w', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4,
                delta=ToolCallPartDelta(args_delta='eather S', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx'),
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='ep', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartDeltaEvent(
                index=4,
                delta=ToolCallPartDelta(args_delta='tember 16 2', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx'),
            ),
            PartDeltaEvent(
                index=4, delta=ToolCallPartDelta(args_delta='025"}', tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx')
            ),
            PartEndEvent(
                index=4,
                part=NativeToolCallPart(
                    tool_name='web_search',
                    args='{"query": "San Francisco weather September 16 2025"}',
                    tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx',
                    provider_name='anthropic',
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=5,
                part=NativeToolReturnPart(
                    tool_name='web_search',
                    content=[
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco weather in September 2025 | Weather25.com',
                            'type': 'web_search_result',
                            'url': 'https://www.weather25.com/north-america/usa/california/san-francisco?page=month&month=September',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Weather in San Francisco in September 2025 (California) - detailed Weather Forecast for a month',
                            'type': 'web_search_result',
                            'url': 'https://world-weather.info/forecast/usa/san_francisco/september-2025/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco, CA Monthly Weather | AccuWeather',
                            'type': 'web_search_result',
                            'url': 'https://www.accuweather.com/en/us/san-francisco/94103/september-weather/347629',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Weather San Francisco in September 2025: Temperature & Climate',
                            'type': 'web_search_result',
                            'url': 'https://en.climate-data.org/north-america/united-states-of-america/california/san-francisco-385/t/september-9/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco weather in September 2025 | California',
                            'type': 'web_search_result',
                            'url': 'https://www.weather2travel.com/california/san-francisco/september/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco, Weather for September, USA',
                            'type': 'web_search_result',
                            'url': 'https://www.holiday-weather.com/san_francisco/averages/september/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Monthly Weather Forecast for San Francisco, CA - weather.com',
                            'type': 'web_search_result',
                            'url': 'https://weather.com/weather/monthly/l/69bedc6a5b6e977993fb3e5344e3c06d8bc36a1fb6754c3ddfb5310a3c6d6c87',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '3 weeks ago',
                            'title': 'September 2025 Weather - San Francisco',
                            'type': 'web_search_result',
                            'url': 'https://www.easeweather.com/north-america/united-states/california/city-and-county-of-san-francisco/san-francisco/september',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'San Francisco Weather in September | Thomas Cook',
                            'type': 'web_search_result',
                            'url': 'https://www.thomascook.com/holidays/weather/usa/california/san-francisco/september/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '4 days ago',
                            'title': IsStr(),
                            'type': 'web_search_result',
                            'url': 'https://www.sfchronicle.com/weather-forecast/article/weather-forecast-san-francisco-21043269.php',
                        },
                    ],
                    tool_call_id='srvtoolu_01FDqc7ruGpVRoNuD5G6jkUx',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(index=6, part=TextPart(content='Base'), previous_part_kind='builtin-tool-return'),
            PartDeltaEvent(
                index=6,
                delta=TextPartDelta(
                    content_delta="d on the search results, I can provide you with information about San Francisco's weather"
                ),
            ),
            PartDeltaEvent(
                index=6,
                delta=TextPartDelta(
                    content_delta="""\
 today (September 16, 2025):

According\
"""
                ),
            ),
            PartDeltaEvent(index=6, delta=TextPartDelta(content_delta=" to AccuWeather's forecast, ")),
            PartEndEvent(
                index=6,
                part=TextPart(
                    content="""\
Based on the search results, I can provide you with information about San Francisco's weather today (September 16, 2025):

According to AccuWeather's forecast, \
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=7,
                part=TextPart(content='today (September 16) shows a high of 76°F and low of 59°F'),
                previous_part_kind='text',
            ),
            PartEndEvent(
                index=7,
                part=TextPart(content='today (September 16) shows a high of 76°F and low of 59°F'),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=8,
                part=TextPart(
                    content="""\
 for San Francisco.

From the recent San\
"""
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=8, delta=TextPartDelta(content_delta=' Francisco Chronicle weather report, ')),
            PartEndEvent(
                index=8,
                part=TextPart(
                    content="""\
 for San Francisco.

From the recent San Francisco Chronicle weather report, \
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=9,
                part=TextPart(content='average mid-September highs in San Francisco are around 70 degrees'),
                previous_part_kind='text',
            ),
            PartEndEvent(
                index=9,
                part=TextPart(content='average mid-September highs in San Francisco are around 70 degrees'),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=10, part=TextPart(content=", so today's forecast of 76°F is"), previous_part_kind='text'
            ),
            PartDeltaEvent(
                index=10,
                delta=TextPartDelta(
                    content_delta="""\
 slightly above the typical temperature for this time of year.

The\
"""
                ),
            ),
            PartDeltaEvent(
                index=10,
                delta=TextPartDelta(
                    content_delta="""\
 general weather pattern for San Francisco in September includes:
- \
"""
                ),
            ),
            PartEndEvent(
                index=10,
                part=TextPart(
                    content="""\
, so today's forecast of 76°F is slightly above the typical temperature for this time of year.

The general weather pattern for San Francisco in September includes:
- \
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=11,
                part=TextPart(
                    content='Daytime temperatures usually reach 22°C (72°F) in San Francisco in September, falling to 13°C'
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=11, delta=TextPartDelta(content_delta=' (55°F) at night')),
            PartEndEvent(
                index=11,
                part=TextPart(
                    content='Daytime temperatures usually reach 22°C (72°F) in San Francisco in September, falling to 13°C (55°F) at night'
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=12,
                part=TextPart(
                    content="""\

- \
"""
                ),
                previous_part_kind='text',
            ),
            PartEndEvent(
                index=12,
                part=TextPart(
                    content="""\

- \
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=13,
                part=TextPart(content='There are normally 9 hours of bright sunshine each day in San Francisco in'),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=13, delta=TextPartDelta(content_delta=' September')),
            PartEndEvent(
                index=13,
                part=TextPart(
                    content='There are normally 9 hours of bright sunshine each day in San Francisco in September'
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=14,
                part=TextPart(
                    content="""\

- \
"""
                ),
                previous_part_kind='text',
            ),
            PartEndEvent(
                index=14,
                part=TextPart(
                    content="""\

- \
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=15,
                part=TextPart(
                    content='San Francisco experiences minimal rainfall in September, with an average precipitation of just 3mm.'
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=15, delta=TextPartDelta(content_delta=' Typically, there are no rainy days')),
            PartDeltaEvent(index=15, delta=TextPartDelta(content_delta=' during this month')),
            PartEndEvent(
                index=15,
                part=TextPart(
                    content='San Francisco experiences minimal rainfall in September, with an average precipitation of just 3mm. Typically, there are no rainy days during this month'
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=16,
                part=TextPart(
                    content="""\


So for today, you can expect partly sunny to sunny skies with a\
"""
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=16, delta=TextPartDelta(content_delta=' high around 76°F (24°C)')),
            PartDeltaEvent(index=16, delta=TextPartDelta(content_delta=' and a low around 59°F (15°C),')),
            PartDeltaEvent(index=16, delta=TextPartDelta(content_delta=" with very little chance of rain. It's sh")),
            PartDeltaEvent(
                index=16, delta=TextPartDelta(content_delta='aping up to be a pleasant day in San Francisco!')
            ),
            PartEndEvent(
                index=16,
                part=TextPart(
                    content="""\


So for today, you can expect partly sunny to sunny skies with a high around 76°F (24°C) and a low around 59°F (15°C), with very little chance of rain. It's shaping up to be a pleasant day in San Francisco!\
"""
                ),
            ),
        ]
    )


@pytest.mark.vcr()
async def test_anthropic_web_fetch_tool(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-0', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(m, capabilities=[NativeTool(WebFetchTool())], model_settings=settings)

    result = await agent.run(
        'What is the first sentence on the page https://ai.pydantic.dev? Reply with only the sentence.'
    )

    assert result.output == snapshot(
        'Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.'
    )

    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_fetch',
                    'type': 'web_fetch_20250910',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'citations': None,
                    'max_content_tokens': None,
                }
            ],
            None,
        )
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the first sentence on the page https://ai.pydantic.dev? Reply with only the sentence.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content="""\
The user is asking me to fetch the content from https://ai.pydantic.dev and return only the first sentence on that page. I need to use the web_fetch tool to get the content from this URL, then identify the first sentence and return only that sentence.

Let me fetch the page first.\
""",
                        signature='EsIDCkYICRgCKkAKi/j4a8lGN12CjyS27ZXcPkXHGyTbn1vJENJz+AjinyTnsrynMEhidWT5IMNAs0TDgwSwPLNmgq4MsPkVekB8EgxetaK+Nhg8wUdhTEAaDMukODgr3JaYHZwVEiIwgKBckFLJ/C7wCD9oGCIECbqpaeEuWQ8BH3Hev6wpuc+66Wu7AJM1jGH60BpsUovnKqkCrHNq6b1SDT41cm2w7cyxZggrX6crzYh0fAkZ+VC6FBjy6mJikZtX6reKD+064KZ4F1oe4Qd40EBp/wHvD7oPV/fhGut1fzwl48ZgB8uzJb3tHr9MBjs4PVTsvKstpHKpOo6NLvCknQJ/0730OTENp/JOR6h6RUl6kMl5OrHTvsDEYpselUBPtLikm9p4t+d8CxqGm/B1kg1wN3FGJK31PD3veYIOO4hBirFPXWd+AiB1rZP++2QjToZ9lD2xqP/Q3vWEU+/Ryp6uzaRFWPVQkIr+mzpIaJsYuKDiyduxF4LD/hdMTV7IVDtconeQIPQJRhuO6nICBEuqb0uIotPDnCU6iI2l9OyEeKJM0RS6/NTNG8DZnvyVJ8gGKbtZKSHK6KKsdH0f7d+DGAE=',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='web_fetch',
                        args={'url': 'https://ai.pydantic.dev'},
                        tool_call_id=IsStr(),
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_fetch',
                        content={
                            'content': {
                                'citations': None,
                                'source': {
                                    'data': IsStr(),
                                    'media_type': 'text/plain',
                                    'type': 'text',
                                },
                                'title': 'Pydantic AI',
                                'type': 'document',
                            },
                            'retrieved_at': IsStr(),
                            'type': 'web_fetch_result',
                            'url': 'https://ai.pydantic.dev',
                        },
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content='Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.'
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=7262,
                    output_tokens=171,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 7262,
                        'output_tokens': 171,
                    },
                    cost=Decimal('0.024351'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    # Second run to test message replay (multi-turn conversation)
    result2 = await agent.run(
        'Based on the page you just fetched, what framework does it mention?',
        message_history=result.all_messages(),
    )

    assert 'Pydantic AI' in result2.output or 'pydantic' in result2.output.lower()
    assert result2.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the first sentence on the page https://ai.pydantic.dev? Reply with only the sentence.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content="""\
The user is asking me to fetch the content from https://ai.pydantic.dev and return only the first sentence on that page. I need to use the web_fetch tool to get the content from this URL, then identify the first sentence and return only that sentence.

Let me fetch the page first.\
""",
                        signature='EsIDCkYICRgCKkAKi/j4a8lGN12CjyS27ZXcPkXHGyTbn1vJENJz+AjinyTnsrynMEhidWT5IMNAs0TDgwSwPLNmgq4MsPkVekB8EgxetaK+Nhg8wUdhTEAaDMukODgr3JaYHZwVEiIwgKBckFLJ/C7wCD9oGCIECbqpaeEuWQ8BH3Hev6wpuc+66Wu7AJM1jGH60BpsUovnKqkCrHNq6b1SDT41cm2w7cyxZggrX6crzYh0fAkZ+VC6FBjy6mJikZtX6reKD+064KZ4F1oe4Qd40EBp/wHvD7oPV/fhGut1fzwl48ZgB8uzJb3tHr9MBjs4PVTsvKstpHKpOo6NLvCknQJ/0730OTENp/JOR6h6RUl6kMl5OrHTvsDEYpselUBPtLikm9p4t+d8CxqGm/B1kg1wN3FGJK31PD3veYIOO4hBirFPXWd+AiB1rZP++2QjToZ9lD2xqP/Q3vWEU+/Ryp6uzaRFWPVQkIr+mzpIaJsYuKDiyduxF4LD/hdMTV7IVDtconeQIPQJRhuO6nICBEuqb0uIotPDnCU6iI2l9OyEeKJM0RS6/NTNG8DZnvyVJ8gGKbtZKSHK6KKsdH0f7d+DGAE=',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='web_fetch',
                        args={'url': 'https://ai.pydantic.dev'},
                        tool_call_id=IsStr(),
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_fetch',
                        content={
                            'content': {
                                'citations': None,
                                'source': {
                                    'data': IsStr(),
                                    'media_type': 'text/plain',
                                    'type': 'text',
                                },
                                'title': 'Pydantic AI',
                                'type': 'document',
                            },
                            'retrieved_at': IsStr(),
                            'type': 'web_fetch_result',
                            'url': 'https://ai.pydantic.dev',
                        },
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content='Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.'
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=7262,
                    output_tokens=171,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 7262,
                        'output_tokens': 171,
                    },
                    cost=Decimal('0.024351'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Based on the page you just fetched, what framework does it mention?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content="""\
The user is asking about what framework is mentioned on the Pydantic AI page that I just fetched. Looking at the content, I can see several frameworks mentioned:

1. Pydantic AI itself - described as "a Python agent framework"
2. FastAPI - mentioned as having "revolutionized web development by offering an innovative and ergonomic design"
3. Various other frameworks/libraries mentioned like LangChain, LlamaIndex, AutoGPT, Transformers, CrewAI, Instructor
4. Pydantic Validation is mentioned as being used by many frameworks
5. OpenTelemetry is mentioned in relation to observability

But the most prominently featured framework that seems to be the main comparison point is FastAPI, as the page talks about bringing "that FastAPI feeling to GenAI app and agent development."\
""",
                        signature='ErIHCkYICRgCKkDZrwipmaxoEat4WffzPSjVzIuSQWM2sHE6FLC2wt5S2qiJN2MQh//EImuLE9I2ssZjTMxGXZV+esnf5ipnzbvnEgxfcXs2ax8vnLdroxMaDCpqvdPKpCP3Qi0txCIw55NdOjY30P3/yRL9RF8sPGioyitlzkhSpf+PuC3YXwz4N0hoy8zVY1MHecwc60vcKpkGxtZsfqmAuJwjeGRr/Ugxcxd69+0X/Y9pojMiklNHq9otW+ehDX0rR0EzfdN/2jNOs3bOrzfy9jmvYE5FU2c5e0JpMP3LH0LrFvZYkSh7RkbhYuHvrOqohlE3BhpflrszowmiozUk+aG4wSqx5Dtxo9W7jfeU4wduy6OyEFdIqdYdTMR8VVf9Qnd5bLX4rY09xcGQc4JcX2mFjdSR2WgEJM7p5lytlN5unH3selWBVPbCj7ogU8DbT9zhY3zkDW1dMt2vNbWNaY4gVrLwi42qBJvjC5eJTADckvXAt+MCT9AAe1kmH9NlsgBnRy13O4lhXv9SPNDfk2tU5Tdco4h/I/fXh+WuPe6/MKk+tJuoBQTGVQ5ryFmomsNiwhwtLbQ44fLVHhyqEKSEdo/107xvbzhjmY/MAzn1Pmc9rd+OhFsjUCvgqI8cWNc/E694eJqg3J2S+I6YRzG3d2tR7laUivf+J38c2XmwSyXfdRoJpyZ9TixubpPk04WSchdFlEkxPBGEWLDkWOVL1PG5ztY48di7EzM1tvAwiT1BOxl4WRZ78Ewc+C5BVHwT658rIrcKJXXI/zBMsoReQT9xsRhpozbb576wNXggJdZsd2ysQY0O6Pihz54emwigm+zPbO5n8HvlrGKf6dSsrwusUJ1BIY4wI6qjz7gweRryReDEvEzMT8Ul4mIrigRy4yL2w+03qAclz8oGwxinMvcu8vJzXg+uRm/WbOgyco4gTPQiN4NcXbzwhVtJlNWZYXCiiMb/i6IXuOzZmSjI7LqxLubD9RgOy/2890RLvVJQBBVnOowW8q+iE93CoVBr1l5D54opLS9fHYcM7ezV0Ul34qMu6K0uoBG0+aLVlZHKEecN2/VE4fh0zYEDaeqRZfNH2gnAGmokdmPtEHlp33pvJ0IFDAbxKq2CVFFdB+lCGlaLQuZ5v6Mhq4b6H8DjaGZqo/vcB/MK4pr/F1SRjLzSHyh7Ey4ogBYSOXWfaeXQiZZFoEfxIUG9PzofIA1CCFk+eZSG7bGY4wXe2Whhh5bs+cJ3duYI9SL+49WBABgB',
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
Based on the page I fetched, the main framework it mentions and compares itself to is **FastAPI**. The page states that "FastAPI revolutionized web development by offering an innovative and ergonomic design" and that Pydantic AI was built with the aim "to bring that FastAPI feeling to GenAI app and agent development."

The page also mentions several other frameworks and libraries including:
- LangChain
- LlamaIndex  \n\
- AutoGPT
- Transformers
- CrewAI
- Instructor

It notes that "virtually every Python agent framework and LLM library" uses Pydantic Validation, which is the foundation that Pydantic AI builds upon.\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=6346,
                    output_tokens=354,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 6346,
                        'output_tokens': 354,
                    },
                    cost=Decimal('0.024348'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


@pytest.mark.vcr()
async def test_anthropic_web_fetch_tool_stream(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):  # pragma: lax no cover
    from pydantic_ai.messages import PartDeltaEvent, PartStartEvent

    m = anthropic_model('claude-sonnet-4-0', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(m, capabilities=[NativeTool(WebFetchTool())], model_settings=settings)

    # Iterate through the stream to ensure streaming code paths are covered
    event_parts: list[Any] = []
    async with agent.iter(  # pragma: lax no cover
        user_prompt='What is the first sentence on the page https://ai.pydantic.dev? Reply with only the sentence.'
    ) as agent_run:
        async for node in agent_run:  # pragma: lax no cover
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):  # pragma: lax no cover
                async with node.stream(agent_run.ctx) as request_stream:  # pragma: lax no cover
                    async for event in request_stream:  # pragma: lax no cover
                        if (  # pragma: lax no cover
                            isinstance(event, PartStartEvent)
                            and isinstance(event.part, NativeToolCallPart | NativeToolReturnPart)
                        ) or isinstance(event, PartDeltaEvent):
                            event_parts.append(event)

    assert agent_run.result is not None
    assert agent_run.result.output == snapshot(
        'Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.'
    )

    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_fetch',
                    'type': 'web_fetch_20250910',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'citations': None,
                    'max_content_tokens': None,
                }
            ],
            None,
        )
    )
    assert agent_run.result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the first sentence on the page https://ai.pydantic.dev? Reply with only the sentence.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user wants me to fetch the content from the URL https://ai.pydantic.dev and provide only the first sentence from that page. I need to use the web_fetch tool to get the content from this URL.',
                        signature='EusCCkYICRgCKkAG/7zhRcmUoiMtml5iZUXVv3nqupp8kgk0nrq9zOoklaXzVCnrb9kwLNWGETIcCaAnLd0cd0ESwjslkVKdV9n8EgxKKdu8LlEvh9VGIWIaDAJ2Ja2NEacp1Am6jSIwyNO36tV+Sj+q6dWf79U+3KOIa1khXbIYarpkIViCuYQaZwpJ4Vtedrd7dLWTY2d5KtIB9Pug5UPuvepSOjyhxLaohtGxmdvZN8crGwBdTJYF9GHSli/rzvkR6CpH+ixd8iSopwFcsJgQ3j68fr/yD7cHmZ06jU3LaESVEBwTHnlK0ABiYnGvD3SvX6PgImMSQxQ1ThARFTA7DePoWw+z5DI0L2vgSun2qTYHkmGxzaEskhNIBlK9r7wS3tVcO0Di4lD/rhYV61tklL2NBWJqvm7ZCtJTN09CzPFJy7HDkg7bSINVL4kuu9gTWEtb/o40tw1b+sO62UcfxQTVFQ4Cj8D8XFZbGAE=',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='web_fetch',
                        args='{"url": "https://ai.pydantic.dev"}',
                        tool_call_id=IsStr(),
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_fetch',
                        content={
                            'content': {
                                'citations': None,
                                'source': {
                                    'data': IsStr(),
                                    'media_type': 'text/plain',
                                    'type': 'text',
                                },
                                'title': 'Pydantic AI',
                                'type': 'document',
                            },
                            'retrieved_at': IsStr(),
                            'type': 'web_fetch_result',
                            'url': 'https://ai.pydantic.dev',
                        },
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content='Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.'
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=7244,
                    output_tokens=153,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 7244,
                        'output_tokens': 153,
                    },
                    cost=Decimal('0.024027'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )
    assert event_parts == snapshot(
        [
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta='The user wants')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' me to fetch')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' the content')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' from the URL https')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta='://ai.pydantic.dev')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' and provide')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' only')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' the first sentence from')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' that page.')),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' I need to use the web_fetch'),
            ),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' tool to')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' get the content from')),
            PartDeltaEvent(index=0, delta=ThinkingPartDelta(content_delta=' this URL.')),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(
                    signature_delta='EusCCkYICRgCKkAG/7zhRcmUoiMtml5iZUXVv3nqupp8kgk0nrq9zOoklaXzVCnrb9kwLNWGETIcCaAnLd0cd0ESwjslkVKdV9n8EgxKKdu8LlEvh9VGIWIaDAJ2Ja2NEacp1Am6jSIwyNO36tV+Sj+q6dWf79U+3KOIa1khXbIYarpkIViCuYQaZwpJ4Vtedrd7dLWTY2d5KtIB9Pug5UPuvepSOjyhxLaohtGxmdvZN8crGwBdTJYF9GHSli/rzvkR6CpH+ixd8iSopwFcsJgQ3j68fr/yD7cHmZ06jU3LaESVEBwTHnlK0ABiYnGvD3SvX6PgImMSQxQ1ThARFTA7DePoWw+z5DI0L2vgSun2qTYHkmGxzaEskhNIBlK9r7wS3tVcO0Di4lD/rhYV61tklL2NBWJqvm7ZCtJTN09CzPFJy7HDkg7bSINVL4kuu9gTWEtb/o40tw1b+sO62UcfxQTVFQ4Cj8D8XFZbGAE='
                ),
            ),
            PartStartEvent(
                index=1,
                part=NativeToolCallPart(tool_name='web_fetch', tool_call_id=IsStr(), provider_name='anthropic'),
                previous_part_kind='thinking',
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_018ADaxdJjyZ8HXtF3sTBPNk')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='{"url": "', tool_call_id='srvtoolu_018ADaxdJjyZ8HXtF3sTBPNk'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='https://ai', tool_call_id='srvtoolu_018ADaxdJjyZ8HXtF3sTBPNk'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='.p', tool_call_id='srvtoolu_018ADaxdJjyZ8HXtF3sTBPNk')
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='yd', tool_call_id='srvtoolu_018ADaxdJjyZ8HXtF3sTBPNk')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='antic.dev"}', tool_call_id='srvtoolu_018ADaxdJjyZ8HXtF3sTBPNk'),
            ),
            PartStartEvent(
                index=2,
                part=NativeToolReturnPart(
                    tool_name='web_fetch',
                    content={
                        'content': {
                            'citations': None,
                            'source': {
                                'data': '''\
Pydantic AI
GenAI Agent Framework, the Pydantic way
Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.
FastAPI revolutionized web development by offering an innovative and ergonomic design, built on the foundation of [Pydantic Validation](https://docs.pydantic.dev) and modern Python features like type hints.
Yet despite virtually every Python agent framework and LLM library using Pydantic Validation, when we began to use LLMs in [Pydantic Logfire](https://pydantic.dev/logfire), we couldn't find anything that gave us the same feeling.
We built Pydantic AI with one simple aim: to bring that FastAPI feeling to GenAI app and agent development.
Why use Pydantic AI
-
Built by the Pydantic Team:
[Pydantic Validation](https://docs.pydantic.dev/latest/)is the validation layer of the OpenAI SDK, the Google ADK, the Anthropic SDK, LangChain, LlamaIndex, AutoGPT, Transformers, CrewAI, Instructor and many more. Why use the derivative when you can go straight to the source? -
Model-agnostic: Supports virtually every
[model](models/overview/)and provider: OpenAI, Anthropic, Gemini, DeepSeek, Grok, Cohere, Mistral, and Perplexity; Azure AI Foundry, Amazon Bedrock, Google Vertex AI, Ollama, LiteLLM, Groq, OpenRouter, Together AI, Fireworks AI, Cerebras, Hugging Face, GitHub, Heroku, Vercel, Nebius, OVHcloud, and Outlines. If your favorite model or provider is not listed, you can easily implement a[custom model](models/overview/#custom-models). -
Seamless Observability: Tightly
[integrates](logfire/)with[Pydantic Logfire](https://pydantic.dev/logfire), our general-purpose OpenTelemetry observability platform, for real-time debugging, evals-based performance monitoring, and behavior, tracing, and cost tracking. If you already have an observability platform that supports OTel, you can[use that too](logfire/#alternative-observability-backends). -
Fully Type-safe: Designed to give your IDE or AI coding agent as much context as possible for auto-completion and
[type checking](agents/#static-type-checking), moving entire classes of errors from runtime to write-time for a bit of that Rust "if it compiles, it works" feel. -
Powerful Evals: Enables you to systematically test and
[evaluate](evals/)the performance and accuracy of the agentic systems you build, and monitor the performance over time in Pydantic Logfire. -
MCP, A2A, and UI: Integrates the
[Model Context Protocol](mcp/overview/),[Agent2Agent](a2a/), and various[UI event stream](ui/overview/)standards to give your agent access to external tools and data, let it interoperate with other agents, and build interactive applications with streaming event-based communication. -
Human-in-the-Loop Tool Approval: Easily lets you flag that certain tool calls
[require approval](deferred-tools/#human-in-the-loop-tool-approval)before they can proceed, possibly depending on tool call arguments, conversation history, or user preferences. -
Durable Execution: Enables you to build
[durable agents](durable_execution/overview/)that can preserve their progress across transient API failures and application errors or restarts, and handle long-running, asynchronous, and human-in-the-loop workflows with production-grade reliability. -
Streamed Outputs: Provides the ability to
[stream](output/#streamed-results)structured output continuously, with immediate validation, ensuring real time access to generated data. -
Graph Support: Provides a powerful way to define
[graphs](graph/)using type hints, for use in complex applications where standard control flow can degrade to spaghetti code.
Realistically though, no list is going to be as convincing as [giving it a try](#next-steps) and seeing how it makes you feel!
Sign up for our newsletter, The Pydantic Stack, with updates & tutorials on Pydantic AI, Logfire, and Pydantic:
Hello World Example
Here's a minimal example of Pydantic AI:
[Learn about Gateway](gateway)hello_world.py
from pydantic_ai import Agent
agent = Agent( # (1)!
'gateway/anthropic:claude-sonnet-4-0',
instructions='Be concise, reply with one sentence.', # (2)!
)
result = agent.run_sync('Where does "hello world" come from?') # (3)!
print(result.output)
"""
The first known use of "hello, world" was in a 1974 textbook about the C programming language.
"""
- We configure the agent to use
[Anthropic's Claude Sonnet 4.0](api/models/anthropic/)model, but you can also set the model when running the agent. - Register static
[instructions](agents/#instructions)using a keyword argument to the agent. [Run the agent](agents/#running-agents)synchronously, starting a conversation with the LLM.
from pydantic_ai import Agent
agent = Agent( # (1)!
'anthropic:claude-sonnet-4-0',
instructions='Be concise, reply with one sentence.', # (2)!
)
result = agent.run_sync('Where does "hello world" come from?') # (3)!
print(result.output)
"""
The first known use of "hello, world" was in a 1974 textbook about the C programming language.
"""
- We configure the agent to use
[Anthropic's Claude Sonnet 4.0](api/models/anthropic/)model, but you can also set the model when running the agent. - Register static
[instructions](agents/#instructions)using a keyword argument to the agent. [Run the agent](agents/#running-agents)synchronously, starting a conversation with the LLM.
(This example is complete, it can be run "as is", assuming you've [installed the pydantic_ai package](install/))
The exchange will be very short: Pydantic AI will send the instructions and the user prompt to the LLM, and the model will return a text response.
Not very interesting yet, but we can easily add [tools](tools/), [dynamic instructions](agents/#instructions), and [structured outputs](output/) to build more powerful agents.
Tools & Dependency Injection Example
Here is a concise example using Pydantic AI to build a support agent for a bank:
[Learn about Gateway](gateway)bank_support.py
from dataclasses import dataclass
from pydantic import BaseModel, Field
from pydantic_ai import Agent, RunContext
from bank_database import DatabaseConn
@dataclass
class SupportDependencies: # (3)!
customer_id: int
db: DatabaseConn # (12)!
class SupportOutput(BaseModel): # (13)!
support_advice: str = Field(description='Advice returned to the customer')
block_card: bool = Field(description="Whether to block the customer's card")
risk: int = Field(description='Risk level of query', ge=0, le=10)
support_agent = Agent( # (1)!
'gateway/openai:gpt-5', # (2)!
deps_type=SupportDependencies,
output_type=SupportOutput, # (9)!
instructions=( # (4)!
'You are a support agent in our bank, give the '
'customer support and judge the risk level of their query.'
),
)
@support_agent.instructions # (5)!
async def add_customer_name(ctx: RunContext[SupportDependencies]) -> str:
customer_name = await ctx.deps.db.customer_name(id=ctx.deps.customer_id)
return f"The customer's name is {customer_name!r}"
@support_agent.tool # (6)!
async def customer_balance(
ctx: RunContext[SupportDependencies], include_pending: bool
) -> float:
"""Returns the customer's current account balance.""" # (7)!
return await ctx.deps.db.customer_balance(
id=ctx.deps.customer_id,
include_pending=include_pending,
)
... # (11)!
async def main():
deps = SupportDependencies(customer_id=123, db=DatabaseConn())
result = await support_agent.run('What is my balance?', deps=deps) # (8)!
print(result.output) # (10)!
"""
support_advice='Hello John, your current account balance, including pending transactions, is $123.45.' block_card=False risk=1
"""
result = await support_agent.run('I just lost my card!', deps=deps)
print(result.output)
"""
support_advice="I'm sorry to hear that, John. We are temporarily blocking your card to prevent unauthorized transactions." block_card=True risk=8
"""
- This
[agent](agents/)will act as first-tier support in a bank. Agents are generic in the type of dependencies they accept and the type of output they return. In this case, the support agent has typeAgent[SupportDependencies, SupportOutput]
. - Here we configure the agent to use
[OpenAI's GPT-5 model](api/models/openai/), you can also set the model when running the agent. - The
SupportDependencies
dataclass is used to pass data, connections, and logic into the model that will be needed when running[instructions](agents/#instructions)and[tool](tools/)functions. Pydantic AI's system of dependency injection provides a[type-safe](agents/#static-type-checking)way to customise the behavior of your agents, and can be especially useful when running[unit tests](testing/)and evals. - Static
[instructions](agents/#instructions)can be registered with theto the agent.instructions
keyword argument - Dynamic
[instructions](agents/#instructions)can be registered with thedecorator, and can make use of dependency injection. Dependencies are carried via the@agent.instructions
argument, which is parameterized with theRunContext
deps_type
from above. If the type annotation here is wrong, static type checkers will catch it. - The
decorator let you register functions which the LLM may call while responding to a user. Again, dependencies are carried via@agent.tool
, any other arguments become the tool schema passed to the LLM. Pydantic is used to validate these arguments, and errors are passed back to the LLM so it can retry.RunContext
- The docstring of a tool is also passed to the LLM as the description of the tool. Parameter descriptions are
[extracted](tools/#function-tools-and-schema)from the docstring and added to the parameter schema sent to the LLM. [Run the agent](agents/#running-agents)asynchronously, conducting a conversation with the LLM until a final response is reached. Even in this fairly simple case, the agent will exchange multiple messages with the LLM as tools are called to retrieve an output.- The response from the agent will be guaranteed to be a
SupportOutput
. If validation fails[reflection](agents/#reflection-and-self-correction), the agent is prompted to try again. - The output will be validated with Pydantic to guarantee it is a
SupportOutput
, since the agent is generic, it'll also be typed as aSupportOutput
to aid with static type checking. - In a real use case, you'd add more tools and longer instructions to the agent to extend the context it's equipped with and support it can provide.
- This is a simple sketch of a database connection, used to keep the example short and readable. In reality, you'd be connecting to an external database (e.g. PostgreSQL) to get information about customers.
- This
[Pydantic](https://docs.pydantic.dev)model is used to constrain the structured data returned by the agent. From this simple definition, Pydantic builds the JSON Schema that tells the LLM how to return the data, and performs validation to guarantee the data is correct at the end of the run.
from dataclasses import dataclass
from pydantic import BaseModel, Field
from pydantic_ai import Agent, RunContext
from bank_database import DatabaseConn
@dataclass
class SupportDependencies: # (3)!
customer_id: int
db: DatabaseConn # (12)!
class SupportOutput(BaseModel): # (13)!
support_advice: str = Field(description='Advice returned to the customer')
block_card: bool = Field(description="Whether to block the customer's card")
risk: int = Field(description='Risk level of query', ge=0, le=10)
support_agent = Agent( # (1)!
'openai:gpt-5', # (2)!
deps_type=SupportDependencies,
output_type=SupportOutput, # (9)!
instructions=( # (4)!
'You are a support agent in our bank, give the '
'customer support and judge the risk level of their query.'
),
)
@support_agent.instructions # (5)!
async def add_customer_name(ctx: RunContext[SupportDependencies]) -> str:
customer_name = await ctx.deps.db.customer_name(id=ctx.deps.customer_id)
return f"The customer's name is {customer_name!r}"
@support_agent.tool # (6)!
async def customer_balance(
ctx: RunContext[SupportDependencies], include_pending: bool
) -> float:
"""Returns the customer's current account balance.""" # (7)!
return await ctx.deps.db.customer_balance(
id=ctx.deps.customer_id,
include_pending=include_pending,
)
... # (11)!
async def main():
deps = SupportDependencies(customer_id=123, db=DatabaseConn())
result = await support_agent.run('What is my balance?', deps=deps) # (8)!
print(result.output) # (10)!
"""
support_advice='Hello John, your current account balance, including pending transactions, is $123.45.' block_card=False risk=1
"""
result = await support_agent.run('I just lost my card!', deps=deps)
print(result.output)
"""
support_advice="I'm sorry to hear that, John. We are temporarily blocking your card to prevent unauthorized transactions." block_card=True risk=8
"""
- This
[agent](agents/)will act as first-tier support in a bank. Agents are generic in the type of dependencies they accept and the type of output they return. In this case, the support agent has typeAgent[SupportDependencies, SupportOutput]
. - Here we configure the agent to use
[OpenAI's GPT-5 model](api/models/openai/), you can also set the model when running the agent. - The
SupportDependencies
dataclass is used to pass data, connections, and logic into the model that will be needed when running[instructions](agents/#instructions)and[tool](tools/)functions. Pydantic AI's system of dependency injection provides a[type-safe](agents/#static-type-checking)way to customise the behavior of your agents, and can be especially useful when running[unit tests](testing/)and evals. - Static
[instructions](agents/#instructions)can be registered with theto the agent.instructions
keyword argument - Dynamic
[instructions](agents/#instructions)can be registered with thedecorator, and can make use of dependency injection. Dependencies are carried via the@agent.instructions
argument, which is parameterized with theRunContext
deps_type
from above. If the type annotation here is wrong, static type checkers will catch it. - The
decorator let you register functions which the LLM may call while responding to a user. Again, dependencies are carried via@agent.tool
, any other arguments become the tool schema passed to the LLM. Pydantic is used to validate these arguments, and errors are passed back to the LLM so it can retry.RunContext
- The docstring of a tool is also passed to the LLM as the description of the tool. Parameter descriptions are
[extracted](tools/#function-tools-and-schema)from the docstring and added to the parameter schema sent to the LLM. [Run the agent](agents/#running-agents)asynchronously, conducting a conversation with the LLM until a final response is reached. Even in this fairly simple case, the agent will exchange multiple messages with the LLM as tools are called to retrieve an output.- The response from the agent will be guaranteed to be a
SupportOutput
. If validation fails[reflection](agents/#reflection-and-self-correction), the agent is prompted to try again. - The output will be validated with Pydantic to guarantee it is a
SupportOutput
, since the agent is generic, it'll also be typed as aSupportOutput
to aid with static type checking. - In a real use case, you'd add more tools and longer instructions to the agent to extend the context it's equipped with and support it can provide.
- This is a simple sketch of a database connection, used to keep the example short and readable. In reality, you'd be connecting to an external database (e.g. PostgreSQL) to get information about customers.
- This
[Pydantic](https://docs.pydantic.dev)model is used to constrain the structured data returned by the agent. From this simple definition, Pydantic builds the JSON Schema that tells the LLM how to return the data, and performs validation to guarantee the data is correct at the end of the run.
Complete bank_support.py
example
The code included here is incomplete for the sake of brevity (the definition of DatabaseConn
is missing); you can find the complete bank_support.py
example [here](examples/bank-support/).
Instrumentation with Pydantic Logfire
Even a simple agent with just a handful of tools can result in a lot of back-and-forth with the LLM, making it nearly impossible to be confident of what's going on just from reading the code. To understand the flow of the above runs, we can watch the agent in action using Pydantic Logfire.
To do this, we need to [set up Logfire](logfire/#using-logfire), and add the following to our code:
[Learn about Gateway](gateway)bank_support_with_logfire.py
...
from pydantic_ai import Agent, RunContext
from bank_database import DatabaseConn
import logfire
logfire.configure() # (1)!
logfire.instrument_pydantic_ai() # (2)!
logfire.instrument_asyncpg() # (3)!
...
support_agent = Agent(
'gateway/openai:gpt-5',
deps_type=SupportDependencies,
output_type=SupportOutput,
system_prompt=(
'You are a support agent in our bank, give the '
'customer support and judge the risk level of their query.'
),
)
- Configure the Logfire SDK, this will fail if project is not set up.
- This will instrument all Pydantic AI agents used from here on out. If you want to instrument only a specific agent, you can pass the
to the agent.instrument=True
keyword argument - In our demo,
DatabaseConn
usesto connect to a PostgreSQL database, soasyncpg
is used to log the database queries.logfire.instrument_asyncpg()
...
from pydantic_ai import Agent, RunContext
from bank_database import DatabaseConn
import logfire
logfire.configure() # (1)!
logfire.instrument_pydantic_ai() # (2)!
logfire.instrument_asyncpg() # (3)!
...
support_agent = Agent(
'openai:gpt-5',
deps_type=SupportDependencies,
output_type=SupportOutput,
system_prompt=(
'You are a support agent in our bank, give the '
'customer support and judge the risk level of their query.'
),
)
- Configure the Logfire SDK, this will fail if project is not set up.
- This will instrument all Pydantic AI agents used from here on out. If you want to instrument only a specific agent, you can pass the
to the agent.instrument=True
keyword argument - In our demo,
DatabaseConn
usesto connect to a PostgreSQL database, soasyncpg
is used to log the database queries.logfire.instrument_asyncpg()
That's enough to get the following view of your agent in action:
See [Monitoring and Performance](logfire/) to learn more.
llms.txt
The Pydantic AI documentation is available in the [llms.txt](https://llmstxt.org/) format.
This format is defined in Markdown and suited for LLMs and AI coding assistants and agents.
Two formats are available:
: a file containing a brief description of the project, along with links to the different sections of the documentation. The structure of this file is described in detailsllms.txt
[here](https://llmstxt.org/#format).: Similar to thellms-full.txt
llms.txt
file, but every link content is included. Note that this file may be too large for some LLMs.
As of today, these files are not automatically leveraged by IDEs or coding agents, but they will use it if you provide a link or the full text.
Next Steps
To try Pydantic AI for yourself, [install it](install/) and follow the instructions [in the examples](examples/setup/).
Read the [docs](agents/) to learn more about building applications with Pydantic AI.
Read the [API Reference](api/agent/) to understand Pydantic AI's interface.
Join [ Slack](https://logfire.pydantic.dev/docs/join-slack/) or file an issue on [ GitHub](https://github.com/pydantic/pydantic-ai/issues) if you have any questions.\
''',
                                'media_type': 'text/plain',
                                'type': 'text',
                            },
                            'title': 'Pydantic AI',
                            'type': 'document',
                        },
                        'retrieved_at': IsStr(),
                        'type': 'web_fetch_result',
                        'url': 'https://ai.pydantic.dev',
                    },
                    tool_call_id=IsStr(),
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='ydantic AI is a')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' Python')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' agent')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' framework')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' designe')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='d to help')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' you quickly')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=',')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' confi')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='dently,')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' and pain')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='lessly build production')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' grade')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' applications')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' an')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='d workflows')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' with')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta=' Gener')),
            PartDeltaEvent(index=3, delta=TextPartDelta(content_delta='ative AI.')),
        ]
    )


async def test_anthropic_web_fetch_tool_message_replay():
    """Test that NativeToolCallPart and NativeToolReturnPart for WebFetchTool are correctly serialized."""
    from typing import cast

    from pydantic_ai.models.anthropic import AnthropicModel
    from pydantic_ai.providers.anthropic import AnthropicProvider

    # Create a model instance
    m = AnthropicModel('claude-sonnet-4-0', provider=AnthropicProvider(api_key='test-key'))

    # Create message history with NativeToolCallPart and NativeToolReturnPart
    messages = [
        ModelRequest(parts=[UserPromptPart(content='Test')], timestamp=IsDatetime()),
        ModelResponse(
            parts=[
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name=WebFetchTool.kind,
                    args={'url': 'https://example.com'},
                    tool_call_id='test_id_1',
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name=WebFetchTool.kind,
                    content={
                        'content': {'type': 'document'},
                        'type': 'web_fetch_result',
                        'url': 'https://example.com',
                        'retrieved_at': '2025-01-01T00:00:00Z',
                    },
                    tool_call_id='test_id_1',
                ),
            ],
            model_name='claude-sonnet-4-0',
        ),
    ]

    # Call _map_message to trigger serialization
    model_settings = {}
    model_request_parameters = ModelRequestParameters(
        function_tools=[],
        native_tools=[WebFetchTool()],
        output_tools=[],
    )

    system_prompt, anthropic_messages = await m._map_message(messages, model_request_parameters, model_settings)  # pyright: ignore[reportPrivateUsage,reportArgumentType]

    # Verify the messages were serialized correctly
    assert system_prompt is None or isinstance(system_prompt, (list | str))
    assert len(anthropic_messages) == 2
    assert anthropic_messages[1]['role'] == 'assistant'

    # Check that server_tool_use block is present
    content = anthropic_messages[1]['content']
    assert any(
        isinstance(item, dict) and item.get('type') == 'server_tool_use' and item.get('name') == 'web_fetch'
        for item in content
    )

    # Check that web_fetch_tool_result block is present and contains URL and retrieved_at
    web_fetch_result = next(
        item for item in content if isinstance(item, dict) and item.get('type') == 'web_fetch_tool_result'
    )
    assert 'content' in web_fetch_result
    result_content = web_fetch_result['content']
    assert isinstance(result_content, dict)  # Type narrowing for mypy
    assert result_content['type'] == 'web_fetch_result'  # type: ignore[typeddict-item]
    assert result_content['url'] == 'https://example.com'  # type: ignore[typeddict-item]
    # retrieved_at is optional - cast to avoid complex union type issues
    assert cast(dict, result_content).get('retrieved_at') == '2025-01-01T00:00:00Z'  # pyright: ignore[reportUnknownMemberType,reportMissingTypeArgument]
    assert 'content' in result_content  # The actual document content


async def test_anthropic_web_fetch_tool_with_parameters():
    """Test that WebFetchTool parameters are correctly passed to Anthropic API."""
    from pydantic_ai.models.anthropic import AnthropicModel
    from pydantic_ai.providers.anthropic import AnthropicProvider

    # Create a model instance
    m = AnthropicModel('claude-sonnet-4-0', provider=AnthropicProvider(api_key='test-key'))

    # Create WebFetchTool with all parameters
    web_fetch_tool = WebFetchTool(
        max_uses=5,
        allowed_domains=['example.com', 'ai.pydantic.dev'],
        enable_citations=True,
        max_content_tokens=50000,
    )

    model_request_parameters = ModelRequestParameters(
        function_tools=[],
        native_tools=[web_fetch_tool],
        output_tools=[],
    )

    # Get tools from model
    tools, _, beta_features = m._add_native_tools(  # pyright: ignore[reportPrivateUsage]
        [], model_request_parameters, AnthropicModelSettings()
    )

    # Find the web_fetch tool
    web_fetch_tool_param = next((t for t in tools if t.get('name') == 'web_fetch'), None)
    assert web_fetch_tool_param is not None

    # Verify all parameters are passed correctly
    assert web_fetch_tool_param.get('type') == 'web_fetch_20250910'
    assert 'web-fetch-2025-09-10' in beta_features
    assert web_fetch_tool_param.get('max_uses') == 5
    assert web_fetch_tool_param.get('allowed_domains') == ['example.com', 'ai.pydantic.dev']
    assert web_fetch_tool_param.get('blocked_domains') is None
    assert web_fetch_tool_param.get('citations') == {'enabled': True}
    assert web_fetch_tool_param.get('max_content_tokens') == 50000


async def test_anthropic_web_fetch_tool_domain_filtering():
    """Test that blocked_domains work and are mutually exclusive with allowed_domains."""
    from pydantic_ai.models.anthropic import AnthropicModel
    from pydantic_ai.providers.anthropic import AnthropicProvider

    # Create a model instance
    m = AnthropicModel('claude-sonnet-4-0', provider=AnthropicProvider(api_key='test-key'))

    # Test with blocked_domains
    web_fetch_tool = WebFetchTool(blocked_domains=['private.example.com', 'internal.example.com'])

    model_request_parameters = ModelRequestParameters(
        function_tools=[],
        native_tools=[web_fetch_tool],
        output_tools=[],
    )

    # Get tools from model
    tools, _, _ = m._add_native_tools(  # pyright: ignore[reportPrivateUsage]
        [], model_request_parameters, AnthropicModelSettings()
    )

    # Find the web_fetch tool
    web_fetch_tool_param = next((t for t in tools if t.get('name') == 'web_fetch'), None)
    assert web_fetch_tool_param is not None

    # Verify blocked_domains is passed correctly
    assert web_fetch_tool_param.get('blocked_domains') == ['private.example.com', 'internal.example.com']
    assert web_fetch_tool_param.get('allowed_domains') is None


def test_advisor_tool_max_tokens_validation():
    """`AdvisorTool.max_tokens` below Anthropic's 1024 floor is a `ValueError`; at/above is fine."""
    with pytest.raises(ValueError, match='max_tokens must be at least 1024'):
        AdvisorTool(model='claude-opus-4-8', max_tokens=512)
    assert AdvisorTool(model='claude-opus-4-8', max_tokens=1024).max_tokens == 1024
    assert AdvisorTool(model='claude-opus-4-8').max_tokens is None


def test_anthropic_advisor_tool_request_shape():
    """`_add_native_tools` emits the advisor tool definition and beta header, translating `caching`.

    This intentionally calls the private mapper because the VCR matcher does not compare request
    bodies and therefore cannot pin the exact tool definition.
    """
    m = AnthropicModel('claude-opus-4-8', provider=AnthropicProvider(api_key='test-key'))

    full = ModelRequestParameters(
        native_tools=[AdvisorTool(model='claude-opus-4-8', max_uses=2, max_tokens=2048, caching='1h')],
    )
    tools, _, beta_features = m._add_native_tools([], full, AnthropicModelSettings())  # pyright: ignore[reportPrivateUsage]
    advisor_param = next(t for t in tools if t.get('name') == 'advisor')
    assert advisor_param == snapshot(
        {
            'type': 'advisor_20260301',
            'name': 'advisor',
            'model': 'claude-opus-4-8',
            'max_uses': 2,
            'max_tokens': 2048,
            'caching': {'type': 'ephemeral', 'ttl': '1h'},
        }
    )
    assert 'advisor-tool-2026-03-01' in beta_features

    # Optional fields are omitted from the wire payload when unset.
    minimal = ModelRequestParameters(native_tools=[AdvisorTool(model='claude-fable-5')])
    tools, _, _ = m._add_native_tools([], minimal, AnthropicModelSettings())  # pyright: ignore[reportPrivateUsage]
    assert next(t for t in tools if t.get('name') == 'advisor') == snapshot(
        {'type': 'advisor_20260301', 'name': 'advisor', 'model': 'claude-fable-5'}
    )


def test_anthropic_advisor_tool_profile_gating():
    """The advisor tool is gated by both executor model and client/platform."""
    # Executor gating: valid executors expose the tool, older/other models don't.
    assert AdvisorTool in (anthropic_model_profile('claude-sonnet-5') or {}).get(
        'supported_native_tools', frozenset[Any]()
    )
    assert AdvisorTool in (anthropic_model_profile('claude-opus-4-8') or {}).get(
        'supported_native_tools', frozenset[Any]()
    )
    assert AdvisorTool not in (anthropic_model_profile('claude-sonnet-4-5') or {}).get(
        'supported_native_tools', frozenset[Any]()
    )
    assert AdvisorTool not in (anthropic_model_profile('claude-opus-4-1') or {}).get(
        'supported_native_tools', frozenset[Any]()
    )

    # Client gating: available on the direct API and Mantle, not on Bedrock/Vertex/Foundry.
    pytest.importorskip('botocore')
    from anthropic import (
        AsyncAnthropicBedrock,
        AsyncAnthropicBedrockMantle,
        AsyncAnthropicFoundry,
        AsyncAnthropicVertex,
    )

    supported: dict[str, bool] = {}
    for name, client in (
        ('direct', None),
        ('bedrock', AsyncAnthropicBedrock(aws_access_key='x', aws_secret_key='y', aws_region='us-east-1')),
        ('vertex', AsyncAnthropicVertex(project_id='p', region='us-central1', access_token='x')),
        ('foundry', AsyncAnthropicFoundry(api_key='x', base_url='https://example.com')),
        ('mantle', AsyncAnthropicBedrockMantle(aws_region='us-east-1', aws_access_key='x', aws_secret_key='y')),
    ):
        provider = AnthropicProvider(api_key='x') if client is None else AnthropicProvider(anthropic_client=client)
        model = AnthropicModel('claude-opus-4-8', provider=provider)
        supported[name] = AdvisorTool in model.profile.get('supported_native_tools', frozenset[Any]())
    assert supported == snapshot({'direct': True, 'bedrock': False, 'vertex': False, 'foundry': False, 'mantle': True})


def _advisor_response(
    result_content: BetaAdvisorResultBlock | BetaAdvisorRedactedResultBlock | BetaAdvisorToolResultError,
    *,
    final_text: str = '2 + 2 = 4.',
) -> BetaMessage:
    return completion_message(
        [
            BetaTextBlock(text='Let me consult my advisor.', type='text'),
            BetaServerToolUseBlock(
                id='adv_1', name='advisor', input={}, type='server_tool_use', caller=BetaDirectCaller(type='direct')
            ),
            BetaAdvisorToolResultBlock(tool_use_id='adv_1', type='advisor_tool_result', content=result_content),
            BetaTextBlock(text=final_text, type='text'),
        ],
        BetaUsage(input_tokens=10, output_tokens=20),
    )


@pytest.mark.parametrize(
    'variant,expected_content',
    [
        pytest.param(
            'plaintext',
            {'stop_reason': 'max_tokens', 'text': 'The answer is 4.', 'type': 'advisor_result'},
            id='plaintext',
        ),
        pytest.param(
            'redacted',
            {'encrypted_content': 'ENCRYPTED_BLOB', 'stop_reason': 'end_turn', 'type': 'advisor_redacted_result'},
            id='redacted',
        ),
        pytest.param(
            'error',
            {'error_code': 'max_uses_exceeded', 'type': 'advisor_tool_result_error'},
            id='error',
        ),
    ],
)
async def test_anthropic_advisor_result_variants(
    allow_model_requests: None,
    variant: Literal['plaintext', 'redacted', 'error'],
    expected_content: dict[str, Any],
):
    """Plaintext, redacted, and error advisor results all map through one path, stored verbatim."""
    if variant == 'plaintext':
        result_content = BetaAdvisorResultBlock(
            text='The answer is 4.', type='advisor_result', stop_reason='max_tokens'
        )
    elif variant == 'redacted':
        result_content = BetaAdvisorRedactedResultBlock(
            encrypted_content='ENCRYPTED_BLOB', type='advisor_redacted_result', stop_reason='end_turn'
        )
    else:
        result_content = BetaAdvisorToolResultError(error_code='max_uses_exceeded', type='advisor_tool_result_error')

    mock_client = MockAnthropic.create_mock(_advisor_response(result_content))
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(AdvisorTool(model='claude-opus-4-8', max_tokens=1024))])

    result = await agent.run('What is 2 + 2?')
    assert result.output == '2 + 2 = 4.'

    calls = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolCallPart))
    returns = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolReturnPart))
    assert [c.tool_name for c in calls] == ['advisor']
    # The advisor `server_tool_use` input is always empty, so `args` stays None.
    assert calls[0].args is None
    assert [r.tool_name for r in returns] == ['advisor']
    assert returns[0].content == expected_content


async def test_anthropic_advisor_usage_iterations():
    """Advisor iteration tokens are recorded under `advisor_*` keys and excluded from request totals.

    This intentionally calls the private usage mapper because a VCR test cannot isolate whether
    advisor iteration tokens were folded into the normalized request totals.
    """
    usage_with_advisor = BetaUsage(
        input_tokens=100,
        output_tokens=50,
        cache_creation_input_tokens=0,
        cache_read_input_tokens=0,
        iterations=[
            BetaMessageIterationUsage(
                type='message',
                model='claude-sonnet-5',
                input_tokens=100,
                output_tokens=50,
                cache_creation_input_tokens=0,
                cache_read_input_tokens=0,
            ),
            BetaAdvisorMessageIterationUsage(
                type='advisor_message',
                model='claude-opus-4-8',
                input_tokens=500,
                output_tokens=200,
                cache_creation_input_tokens=10,
                cache_read_input_tokens=0,
            ),
        ],
    )
    mapped = _map_usage(
        completion_message([BetaTextBlock(text='ok', type='text')], usage_with_advisor),
        'anthropic',
        'https://api.anthropic.com',
        'claude-sonnet-5',
    )
    assert mapped.details == snapshot(
        {
            'input_tokens': 100,
            'output_tokens': 50,
            'cache_creation_input_tokens': 0,
            'cache_read_input_tokens': 0,
            'message_iterations': 1,
            'advisor_iterations': 1,
            'advisor_input_tokens': 500,
            'advisor_output_tokens': 200,
            'advisor_cache_creation_input_tokens': 10,
        }
    )
    # Advisor tokens must NOT inflate the request totals (they bill at the advisor model's rates).
    assert mapped.input_tokens == 100
    assert mapped.output_tokens == 50


def _advisor_history(m: AnthropicModel) -> list[ModelMessage]:
    return [
        ModelRequest(parts=[UserPromptPart(content='What is 2 + 2?')]),
        ModelResponse(
            parts=[
                NativeToolCallPart(provider_name=m.system, tool_name=AdvisorTool.kind, tool_call_id='adv_1'),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name=AdvisorTool.kind,
                    content={'stop_reason': 'end_turn', 'text': 'It is 4.', 'type': 'advisor_result'},
                    tool_call_id='adv_1',
                ),
                TextPart(content='2 + 2 = 4.'),
            ],
            model_name='claude-sonnet-5',
        ),
        ModelRequest(parts=[UserPromptPart(content='Are you sure?')]),
    ]


async def test_anthropic_advisor_history_replayed_when_active():
    """With the advisor tool in the request, advisor call/result blocks round-trip verbatim.

    This intentionally calls the private message mapper because the VCR matcher does not compare
    request bodies and therefore cannot pin the exact replayed blocks.
    """
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key='test-key'))
    mrp = ModelRequestParameters(native_tools=[AdvisorTool(model='claude-opus-4-8')])
    _, anthropic_messages = await m._map_message(_advisor_history(m), mrp, {})  # pyright: ignore[reportPrivateUsage]

    assistant_content = next(msg['content'] for msg in anthropic_messages if msg['role'] == 'assistant')
    blocks = [item for item in assistant_content if isinstance(item, dict)]
    assert [b for b in blocks if b.get('type') in ('server_tool_use', 'advisor_tool_result')] == snapshot(
        [
            {'id': 'adv_1', 'type': 'server_tool_use', 'name': 'advisor', 'input': {}},
            {
                'tool_use_id': 'adv_1',
                'type': 'advisor_tool_result',
                'content': {'stop_reason': 'end_turn', 'text': 'It is 4.', 'type': 'advisor_result'},
            },
        ]
    )


async def test_anthropic_advisor_history_dropped_when_absent():
    """Without the advisor tool in the request, advisor call/result blocks are stripped from history.

    This intentionally calls the private message mapper because the VCR matcher does not compare
    request bodies and therefore cannot prove the advisor blocks were omitted.
    """
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key='test-key'))
    mrp = ModelRequestParameters(native_tools=[])
    _, anthropic_messages = await m._map_message(_advisor_history(m), mrp, {})  # pyright: ignore[reportPrivateUsage]

    assistant_content = next(msg['content'] for msg in anthropic_messages if msg['role'] == 'assistant')
    blocks = [item for item in assistant_content if isinstance(item, dict)]
    # Only the assistant text survives; the advisor call and result blocks are gone.
    assert [b.get('type') for b in blocks] == snapshot(['text'])


async def test_anthropic_advisor_history_dropped_for_count_tokens(allow_model_requests: None):
    """`count_tokens` strips the advisor tool from the wire, so advisor history must be stripped too.

    The advisor tool is a server tool that `count_tokens` rejects, so `_messages_count_tokens`
    drops it from the outgoing `tools`. Replaying advisor call/result history blocks without the
    tool definition would 400, so mapping must run with advisor inactive even though the request
    params still carry the `AdvisorTool` (which stays active on the real `/v1/messages` request).
    """
    mock_client = cast(AsyncAnthropic, MockAnthropic())
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(anthropic_client=mock_client))
    mrp = ModelRequestParameters(native_tools=[AdvisorTool(model='claude-opus-4-8')])

    await m.count_tokens(_advisor_history(m), None, mrp)

    count_tokens_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    # The advisor beta header is only added when the advisor tool reaches the wire; its absence
    # (`betas` stays unset/`Omit`) confirms the tool was stripped from the count-tokens request...
    assert count_tokens_kwargs.get('betas', OMIT) is OMIT
    # ...so the advisor history blocks it would otherwise require must be stripped too.
    assistant_content = cast(
        list[dict[str, Any]],
        next(msg['content'] for msg in count_tokens_kwargs['messages'] if msg['role'] == 'assistant'),
    )
    assert [block.get('type') for block in assistant_content] == snapshot(['text'])


async def test_anthropic_advisor_dangling_call_replayed_when_active():
    """A dangling advisor call (pause-turn resume) with no paired result replays verbatim when active.

    This intentionally calls the private message mapper because the VCR matcher does not compare
    request bodies and therefore cannot pin the dangling replay shape.
    """
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key='test-key'))
    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='What is 2 + 2?')]),
        ModelResponse(
            parts=[
                TextPart(content='Consulting the advisor.'),
                NativeToolCallPart(provider_name=m.system, tool_name=AdvisorTool.kind, tool_call_id='adv_dangling'),
            ],
            model_name='claude-sonnet-5',
        ),
    ]
    mrp = ModelRequestParameters(native_tools=[AdvisorTool(model='claude-opus-4-8')])
    _, anthropic_messages = await m._map_message(messages, mrp, {})  # pyright: ignore[reportPrivateUsage]

    assistant_content = next(msg['content'] for msg in anthropic_messages if msg['role'] == 'assistant')
    server_tool_uses = [
        item for item in assistant_content if isinstance(item, dict) and item.get('type') == 'server_tool_use'
    ]
    assert server_tool_uses == snapshot(
        [{'id': 'adv_dangling', 'type': 'server_tool_use', 'name': 'advisor', 'input': {}}]
    )


@pytest.mark.vcr()
async def test_anthropic_advisor_tool(allow_model_requests: None, anthropic_api_key: str):
    """Live: a Sonnet 5 executor consults an Opus 4.8 advisor, which returns plaintext advice."""
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, capabilities=[NativeTool(AdvisorTool(model='claude-opus-4-8', max_tokens=1024))])

    result = await agent.run("What's 2+2? Consult your advisor first.")
    assert '4' in result.output

    calls = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolCallPart))
    returns = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolReturnPart))
    assert [c.tool_name for c in calls] == ['advisor']
    # The advisor `server_tool_use` input is always empty, so `args` stays None.
    assert calls[0].args is None
    assert [r.tool_name for r in returns] == ['advisor']
    content = returns[0].content
    assert isinstance(content, dict)
    assert content['type'] == 'advisor_result'
    assert isinstance(content['text'], str) and content['text']
    # `stop_reason` is present because `max_tokens` was set on the advisor tool.
    assert content['stop_reason'] is not None

    details = result.usage.details
    assert details['advisor_iterations'] == 1
    assert details['advisor_input_tokens'] > 0
    assert details['advisor_output_tokens'] > 0
    # Advisor tokens bill at the advisor model's rates and are excluded from the request totals.
    assert result.usage.input_tokens == details['input_tokens']
    # Recorded top-level `output_tokens_details.thinking_tokens`, billed within `output_tokens`.
    assert details['thinking_tokens'] == 28
    assert details['thinking_tokens'] < details['output_tokens']


@pytest.mark.vcr()
async def test_anthropic_advisor_tool_stream(
    allow_model_requests: None, anthropic_api_key: str
):  # pragma: lax no cover
    """Live: the advisor result block streams in fully formed via a single `content_block_start`."""
    from pydantic_ai.messages import PartStartEvent

    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, capabilities=[NativeTool(AdvisorTool(model='claude-opus-4-8', max_tokens=1024))])

    advisor_return_started = False
    async with agent.iter(user_prompt="What's 2+2? Consult your advisor first.") as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        if (
                            isinstance(event, PartStartEvent)
                            and isinstance(event.part, NativeToolReturnPart)
                            and event.part.tool_name == 'advisor'
                        ):
                            advisor_return_started = True

    assert agent_run.result is not None
    assert '4' in agent_run.result.output
    assert advisor_return_started
    returns = list(iter_message_parts(agent_run.result.all_messages(), ModelResponse, NativeToolReturnPart))
    content = returns[0].content
    assert isinstance(content, dict)
    assert content['type'] == 'advisor_result'
    # Recorded on a streaming `message_delta`, which is the only place the field appears mid-stream.
    assert agent_run.result.usage.details['thinking_tokens'] == 47


@pytest.mark.vcr()
async def test_anthropic_advisor_tool_redacted(allow_model_requests: None, anthropic_api_key: str):
    """Live: a Fable 5 advisor returns encrypted content the client cannot read."""
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, capabilities=[NativeTool(AdvisorTool(model='claude-fable-5', max_tokens=1024))])

    result = await agent.run("What's 2+2? Consult your advisor first.")
    assert '4' in result.output

    returns = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolReturnPart))
    assert [r.tool_name for r in returns] == ['advisor']
    content = returns[0].content
    assert isinstance(content, dict)
    assert content['type'] == 'advisor_redacted_result'
    assert isinstance(content['encrypted_content'], str) and content['encrypted_content']
    assert result.usage.details['advisor_iterations'] == 1


@pytest.mark.vcr()
async def test_anthropic_advisor_tool_message_replay(allow_model_requests: None, anthropic_api_key: str):
    """Live: advisor blocks round-trip verbatim across turns; a second run with the tool must not 400."""
    m = AnthropicModel('claude-sonnet-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(m, capabilities=[NativeTool(AdvisorTool(model='claude-opus-4-8', max_tokens=1024))])

    result = await agent.run("What's 2+2? Consult your advisor first.")
    assert '4' in result.output
    first_returns = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolReturnPart))
    assert [r.tool_name for r in first_returns] == ['advisor']

    result2 = await agent.run('And what is that plus one?', message_history=result.all_messages())
    assert '5' in result2.output
    # The original advisor result survives unchanged in the replayed history.
    replayed_returns = list(iter_message_parts(result2.all_messages(), ModelResponse, NativeToolReturnPart))
    assert replayed_returns[0].content == first_returns[0].content


async def test_anthropic_mcp_call_replays_empty_tool_args(allow_model_requests: None):
    c = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=1, output_tokens=1))
    mock_client = MockAnthropic.create_mock(c)
    model = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    messages: list[ModelRequest | ModelResponse] = [
        ModelRequest(parts=[UserPromptPart(content='Call current_time')]),
        ModelResponse(
            parts=[
                NativeToolCallPart(
                    tool_name='mcp_server:clock',
                    tool_call_id='mcptoolu_123',
                    args={'action': 'call_tool', 'tool_name': 'current_time', 'tool_args': {}},
                    provider_name='anthropic',
                ),
                NativeToolReturnPart(
                    tool_name='mcp_server:clock',
                    tool_call_id='mcptoolu_123',
                    content={'content': [{'type': 'text', 'text': '2026-05-06T00:00:00Z'}], 'is_error': False},
                    provider_name='anthropic',
                ),
            ],
            provider_name='anthropic',
        ),
        ModelRequest(parts=[UserPromptPart(content='What did you call?')]),
    ]

    await model.request(
        messages,
        {},
        ModelRequestParameters(
            native_tools=[MCPServerTool(id='clock', url='https://example.com/mcp', allowed_tools=['current_time'])]
        ),
    )

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['messages'][1]['content'][0] == snapshot(
        {'id': 'mcptoolu_123', 'type': 'mcp_tool_use', 'server_name': 'clock', 'name': 'current_time', 'input': {}}
    )


@pytest.mark.vcr()
async def test_anthropic_mcp_servers(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-0', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(
        m,
        capabilities=[
            NativeTool(
                MCPServerTool(
                    id='deepwiki',
                    url='https://mcp.deepwiki.com/mcp',
                )
            )
        ],
        model_settings=settings,
    )

    result = await agent.run('Can you tell me more about the pydantic/pydantic-ai repo? Keep your answer short')
    messages = result.all_messages()
    assert messages == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Can you tell me more about the pydantic/pydantic-ai repo? Keep your answer short',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user is asking about the pydantic/pydantic-ai repository and wants me to keep the answer short. I should use the deepwiki tools to get information about this repository. Let me start by asking a general question about what this repository is about.',
                        signature='EqUDCkYICBgCKkCTiLjx5Rzw9zXo4pFDhFAc9Ci1R+d2fpkiqw7IPt1PgxBankr7bhRfh2iQOFEUy7sYVtsBxvnHW8zfBRxH1j6lEgySvdOyObrcFdJX3qkaDMAMCdLHIevZ/mSx/SIwi917U34N5jLQH1yMoCx/k72klLG5v42vcwUTG4ngKDI69Ddaf0eeDpgg3tL5FHfvKowCnslWg3Pd3ITe+TLlzu+OVZhRKU9SEwDJbjV7ZF954Ls6XExAfjdXhrhvXDB+hz6fZFPGFEfXV7jwElFT5HcGPWy84xvlwzbklZ2zH3XViik0B5dMErMAKs6IVwqXo3s+0p9xtX5gCBuvLkalET2upNsmdKGJv7WQWoaLch5N07uvSgWkO8AkGuVtBgqZH+uRGlPfYlnAgifNHu00GSAVK3beeyZfpnSQ6LQKcH+wVmrOi/3UvzA5f1LvsXG32gQKUCxztATnlBaI+7GMs1IAloaRHBndyRoe8Lwv79zZe9u9gnF9WCgK3yQsAR5hGZXlBKiIWfnRrXQ7QmA2hVO+mhEOCnz7OQkMIEUlfxgB',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='mcp_server:deepwiki',
                        args={
                            'action': 'call_tool',
                            'tool_name': 'ask_question',
                            'tool_args': {
                                'repoName': 'pydantic/pydantic-ai',
                                'question': 'What is pydantic-ai and what does this repository do?',
                            },
                        },
                        tool_call_id='mcptoolu_01SAss3KEwASziHZoMR6HcZU',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='mcp_server:deepwiki',
                        content={
                            'content': [
                                {
                                    'citations': None,
                                    'text': IsStr(),
                                    'type': 'text',
                                }
                            ],
                            'is_error': False,
                        },
                        tool_call_id='mcptoolu_01SAss3KEwASziHZoMR6HcZU',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
**Pydantic AI** is a Python agent framework for building production-grade applications with Generative AI. It provides:

- **Type-safe agents** with compile-time validation using `Agent[Deps, Output]`
- **Model-agnostic design** supporting 15+ LLM providers (OpenAI, Anthropic, Google, etc.)
- **Structured outputs** with automatic Pydantic validation and self-correction
- **Built-in observability** via OpenTelemetry and Logfire integration
- **Production tooling** including evaluation framework, durable execution, and tool system

The repo is organized as a monorepo with core packages like `pydantic-ai-slim` (core framework), `pydantic-graph` (execution engine), and `pydantic-evals` (evaluation tools). It emphasizes developer ergonomics and type safety, similar to Pydantic and FastAPI.\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=2674,
                    output_tokens=373,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 2674,
                        'output_tokens': 373,
                    },
                    cost=Decimal('0.013617'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01MYDjkvBDRaKsY6PDwQz3n6',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    result = await agent.run(
        'How about the pydantic repo in the same org?', message_history=messages
    )  # pragma: lax no cover
    messages = result.new_messages()  # pragma: lax no cover
    assert messages == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='How about the pydantic repo in the same org?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user is asking about the pydantic repo in the same org, so that would be pydantic/pydantic. I should ask about what this repository does and provide a short answer.',
                        signature='EtECCkYICBgCKkAkKy+K3Z/q4dGwZGr1MdsH8HLaULElUSaa/Y8A1L/Jp7y1AfJd1zrTL7Zfa2KoPr0HqO/AI/cJJreheuwcn/dWEgw0bPLie900a4h9wS0aDACnsdbr+adzpUyExiIwyuNjV82BVkK/kU+sMyrfbhgb6ob/DUgudJPaK5zR6cINAAGQnIy3iOXTwu3OUfPAKrgBzF9HD5HjiPSJdsxlkI0RA5Yjiol05/hR3fUB6WWrs0aouxIzlriJ6NzmzvqctkFJdRgAL9Mh06iK1A61PLyBWRdo1f5TBziFP1c6z7iQQzH9DdcaHvG8yLoaadbyTxMvTn2PtfEcSPjuZcLgv7QcF+HZXbDVjsHJW78OK2ta0M6/xuU1p4yG3qgoss3b0G6fAyvUVgVbb1wknkE/9W9gd2k/ZSh4P7F6AcvLTXQScTyMfWRtAWQqABgB',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='mcp_server:deepwiki',
                        args={
                            'action': 'call_tool',
                            'tool_name': 'ask_question',
                            'tool_args': {
                                'repoName': 'pydantic/pydantic',
                                'question': 'What is Pydantic and what does this repository do?',
                            },
                        },
                        tool_call_id='mcptoolu_01A9RvAqDeoUnaMgQc6Nn75y',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='mcp_server:deepwiki',
                        content={
                            'content': [
                                {
                                    'citations': None,
                                    'text': """\
Pydantic is a Python library for data validation, parsing, and serialization using type hints  . This repository, `pydantic/pydantic`, contains the source code for the Pydantic library itself, including its core validation logic, documentation, and continuous integration/continuous deployment (CI/CD) pipelines  .

## What is Pydantic

Pydantic is designed to ensure that data conforms to specified types and constraints at runtime . It leverages Python type hints to define data schemas and provides mechanisms for data conversion and validation . The library's core validation logic is implemented in Rust within a separate package called `pydantic-core`, which contributes to its performance .

Pydantic offers several user-facing APIs for validation:
*   `BaseModel`: Used for defining class-based models with fields, suitable for domain models, API schemas, and configuration .
*   `TypeAdapter`: Provides a flexible way to validate and serialize arbitrary Python types, including primitive types and dataclasses .
*   `@dataclass`: Enhances Python's built-in dataclasses with Pydantic's validation capabilities .
*   `@validate_call`: Used for validating function arguments and return values .

## What this Repository Does

The `pydantic/pydantic` repository serves as the development hub for the Pydantic library. Its primary functions include:

### Core Library Development
The repository contains the Python source code for the Pydantic library, including modules for `BaseModel` , `Field` definitions , configuration management , and type adapters . It also includes internal modules responsible for model construction and schema generation .

### Documentation
The repository hosts the documentation for Pydantic, which is built using MkDocs . The documentation covers installation instructions , core concepts like models , fields, and JSON Schema generation . It also includes information on contributing to the project .

### Continuous Integration and Deployment (CI/CD)
The repository utilizes GitHub Actions for its CI/CD pipeline . This pipeline includes:
*   **Linting**: Checks code quality and style .
*   **Testing**: Runs a comprehensive test suite across multiple operating systems and Python versions . This includes memory profiling tests, Mypy plugin tests, and type-checking integration tests   .
*   **Coverage**: Aggregates test coverage data and posts comments to pull requests .
*   **Release Process**: Automates publishing new versions to PyPI and sending release announcements .
*   **Third-Party Integration Testing**: Tests Pydantic's compatibility with other popular libraries like FastAPI, SQLModel, and Beanie .
*   **Dependency Management**: Uses `uv` for managing dependencies and includes workflows to check compatibility with various dependency versions  .
*   **Performance Benchmarking**: Utilizes CodSpeed to track and analyze performance .

## Versioning and Compatibility
Pydantic maintains strict version compatibility between the pure Python package (`pydantic`) and its Rust-based validation core (`pydantic-core`)  . A `SystemError` is raised if there's a mismatch in `pydantic-core` versions, ensuring a stable environment . The `version_info()` function provides detailed version information for Pydantic and its dependencies .

Notes:
The `CITATION.cff` file also provides a concise description of Pydantic as "the most widely used data validation library for Python" . The `README.md` and `docs/index.md` files reiterate this, emphasizing its speed and extensibility  .

Wiki pages you might want to explore:
- [Overview (pydantic/pydantic)](/wiki/pydantic/pydantic#1)
- [Development and Deployment (pydantic/pydantic)](/wiki/pydantic/pydantic#7)

View this search on DeepWiki: https://deepwiki.com/search/what-is-pydantic-and-what-does_dab96efa-752a-4688-a630-3f4658084a88
""",
                                    'type': 'text',
                                }
                            ],
                            'is_error': False,
                        },
                        tool_call_id='mcptoolu_01A9RvAqDeoUnaMgQc6Nn75y',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
**Pydantic** is Python's most widely used data validation library for parsing, validation, and serialization using type hints. The repository contains:

**Core Features:**
- **Data validation** with automatic type conversion and constraint checking
- **Multiple APIs**: `BaseModel` for class-based models, `TypeAdapter` for arbitrary types, `@dataclass` decorator, and `@validate_call` for functions
- **High performance** via Rust-based validation core (`pydantic-core`)
- **JSON Schema generation** and comprehensive serialization support

**Repository Contents:**
- Python source code for the main Pydantic library
- Comprehensive documentation built with MkDocs
- Extensive CI/CD pipeline with testing across multiple Python versions and OS
- Integration testing with popular libraries (FastAPI, SQLModel, etc.)
- Performance benchmarking and dependency compatibility checks

Pydantic ensures runtime data integrity through type hints and is foundational to many Python frameworks, especially in web APIs and data processing applications.\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=5262,
                    output_tokens=369,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 5262,
                        'output_tokens': 369,
                    },
                    cost=Decimal('0.021321'),
                ),
                model_name='claude-sonnet-4-20250514',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01DSGib8F7nNoYprfYSGp1sd',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_mcp_servers_stream(allow_model_requests: None, anthropic_api_key: str):
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(
        m,
        capabilities=[
            NativeTool(
                MCPServerTool(
                    id='deepwiki',
                    url='https://mcp.deepwiki.com/mcp',
                    allowed_tools=['ask_question'],
                )
            )
        ],
        model_settings=settings,
    )

    event_parts: list[Any] = []
    async with agent.iter(
        user_prompt='Can you tell me more about the pydantic/pydantic-ai repo? Keep your answer short'
    ) as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        if (
                            isinstance(event, PartStartEvent)
                            and isinstance(event.part, NativeToolCallPart | NativeToolReturnPart)
                        ) or (isinstance(event, PartDeltaEvent) and isinstance(event.delta, ToolCallPartDelta)):
                            event_parts.append(event)

    assert agent_run.result is not None
    messages = agent_run.result.all_messages()
    assert messages == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Can you tell me more about the pydantic/pydantic-ai repo? Keep your answer short',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user is asking about the pydantic/pydantic-ai repository. They want a short answer about the repo. I should use the deepwiki_ask_question function to get information about this repository.',
                        signature='EuoCCkYICBgCKkDPqznnPHupi9rVXvaQQqrMprXof9wtQsCqw7Yw687UIk/FvF65omU22QO+CmIcYqTwhBfifPEp9A3/lM9C8cIcEgzGsjorcyNe2H0ZFf8aDCA4iLG6qgUL6fLhzCIwVWcg65CrvSFusXtMH18p+XiF+BUxT+rvnCFsnLbFsxtjGyKh1j4UW6V0Tk0O7+3sKtEBEzvxztXkMkeXkXRsQFJ00jTNhkUHu74sqnh6QxgV8wK2vlJRnBnes/oh7QdED0h/pZaUbxplYJiPFisWx/zTJQvOv29I46sM2CdY5ggGO1KWrEF/pognyod+jdCdb481XUET9T7nl/VMz/Og2QkyGf+5MvSecKQhujlS0VFhCgaYv68sl0Fv3hj2AkeE4vcYu3YdDaNDLXerbIaLCMkkn08NID/wKZTwtLSL+N6+kOi+4peGqXDNps8oa3mqIn7NAWFlwEUrFZd5kjtDkQ5dw/IYAQ==',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='mcp_server:deepwiki',
                        args='{"action":"call_tool","tool_name":"ask_question","tool_args":{"repoName": "pydantic/pydantic-ai", "question": "What is this repository about? What are its main features and purpose?"}}',
                        tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1',
                        provider_name='anthropic',
                    ),
                    NativeToolReturnPart(
                        tool_name='mcp_server:deepwiki',
                        content={
                            'content': [
                                {
                                    'citations': None,
                                    'text': IsStr(),
                                    'type': 'text',
                                }
                            ],
                            'is_error': False,
                        },
                        tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                    ),
                    TextPart(
                        content="""\
**Pydantic-AI** is a framework for building Generative AI applications with type safety. It provides:

- **Unified LLM interface** - Works with OpenAI, Anthropic, Google, Groq, Cohere, Mistral, AWS Bedrock, and more
- **Type-safe agents** - Uses Pydantic for validation and type checking throughout
- **Tool integration** - Easily add custom functions/tools agents can call
- **Graph-based execution** - Manages agent workflows as finite state machines
- **Multiple output formats** - Text, structured data, and multimodal content
- **Durable execution** - Integration with systems like DBOS and Temporal for fault tolerance
- **Streaming support** - Stream responses in real-time

It's designed to simplify building robust, production-ready AI agents while abstracting away provider-specific complexities.\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=3042,
                    output_tokens=354,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 3042,
                        'output_tokens': 354,
                    },
                    cost=Decimal('0.014436'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01Xf6SmUVY1mDrSwFc5RsY3n',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    assert event_parts == snapshot(
        [
            PartStartEvent(
                index=1,
                part=NativeToolCallPart(
                    tool_name='mcp_server:deepwiki',
                    tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1',
                    provider_name='anthropic',
                ),
                previous_part_kind='thinking',
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(
                    args_delta='{"action":"call_tool","tool_name":"ask_question","tool_args":',
                    tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1',
                ),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='{"repoName"', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta=': "', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='pydantic', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='/pydantic-ai', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='"', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta=', "question', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='": "What', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta=' is ', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='this repo', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='sitory about', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='? Wha', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='t are i', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='ts main feat', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='ure', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='s and purpo', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='se?"}', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='}', tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1'),
            ),
            PartStartEvent(
                index=2,
                part=NativeToolReturnPart(
                    tool_name='mcp_server:deepwiki',
                    content={
                        'content': [
                            {
                                'citations': None,
                                'text': """\
This repository, `pydantic/pydantic-ai`, is a GenAI Agent Framework that leverages Pydantic for building Generative AI applications. Its main purpose is to provide a unified and type-safe way to interact with various large language models (LLMs) from different providers, manage agent execution flows, and integrate with external tools and services. \n\

## Main Features and Purpose

The `pydantic-ai` repository offers several core features:

### 1. Agent System
The `Agent` class serves as the main orchestrator for managing interactions with LLMs and executing tasks.  Agents can be configured with generic types for dependency injection (`Agent[AgentDepsT, OutputDataT]`) and output validation, ensuring type safety throughout the application. \n\

Agents support various execution methods:
*   `agent.run()`: An asynchronous function that returns a completed `RunResult`. \n\
*   `agent.run_sync()`: A synchronous function that internally calls `run()` to return a completed `RunResult`. \n\
*   `agent.run_stream()`: An asynchronous context manager for streaming text and structured output. \n\
*   `agent.run_stream_events()`: Returns an asynchronous iterable of `AgentStreamEvent`s and a final `AgentRunResultEvent`. \n\
*   `agent.iter()`: A context manager that provides an asynchronous iterable over the nodes of the agent's underlying `Graph`, allowing for deeper control and insight into the execution flow. \n\

### 2. Model Integration
The framework provides a unified interface for integrating with various LLM providers, including OpenAI, Anthropic, Google, Groq, Cohere, Mistral, Bedrock, and HuggingFace.  Each model integration follows a consistent settings pattern with provider-specific prefixes (e.g., `google_*`, `anthropic_*`). \n\

Examples of supported models and their capabilities include:
*   `GoogleModel`: Integrates with Google's Gemini API, supporting both Gemini API (`google-gla`) and Vertex AI (`google-vertex`) providers.  It supports token counting, streaming, built-in tools like `WebSearchTool`, `WebFetchTool`, `CodeExecutionTool`, and native JSON schema output. \n\
*   `AnthropicModel`: Uses Anthropic's beta API for advanced features like "Thinking Blocks" and built-in tools. \n\
*   `GroqModel`: Offers high-speed inference and specialized reasoning support with configurable reasoning formats. \n\
*   `MistralModel`: Supports customizable JSON schema prompting and thinking support. \n\
*   `BedrockConverseModel`: Utilizes AWS Bedrock's Converse API for unified access to various foundation models like Claude, Titan, Llama, and Mistral. \n\
*   `CohereModel`: Integrates with Cohere's v2 API for chat completions, including thinking support and tool calling. \n\

The framework also supports multimodal inputs such as `AudioUrl`, `DocumentUrl`, `ImageUrl`, and `VideoUrl`, allowing agents to process and respond to diverse content types. \n\

### 3. Graph-based Execution
Pydantic AI uses `pydantic-graph` to manage the execution flow of agents, representing it as a finite state machine.  The execution typically flows through `UserPromptNode` → `ModelRequestNode` → `CallToolsNode`.  This allows for detailed tracking of message history and usage. \n\

### 4. Tool System
Function tools enable models to perform actions and retrieve additional information.  Tools can be registered using decorators like `@agent.tool` (for tools needing `RunContext` access) or `@agent.tool_plain` (for tools without `RunContext` access).  The framework also supports toolsets for managing collections of tools. \n\

Tools can return various types of output, including anything Pydantic can serialize to JSON, as well as multimodal content like `AudioUrl`, `VideoUrl`, `ImageUrl`, or `DocumentUrl`.  The `ToolReturn` object allows for separating the `return_value` (for the model), `content` (for additional context), and `metadata` (for application-specific use). \n\

Built-in tools like `WebFetchTool` allow agents to pull web content into their context. \n\

### 5. Output Handling
The framework supports various output types:
*   `TextOutput`: Plain text responses. \n\
*   `ToolOutput`: Structured data via tool calls. \n\
*   `NativeOutput`: Provider-specific structured output. \n\
*   `PromptedOutput`: Prompt-based structured extraction. \n\

### 6. Durable Execution
Pydantic AI integrates with durable execution systems like DBOS and Temporal.  This allows agents to maintain state and resume execution after failures or restarts, making them suitable for long-running or fault-tolerant applications. \n\

### 7. Multi-Agent Patterns and Integrations
The repository supports multi-agent applications and various integrations, including:
*   Pydantic Evals: For evaluating agent performance. \n\
*   Pydantic Graph: The underlying graph execution engine. \n\
*   Logfire: For debugging and monitoring. \n\
*   Agent-User Interaction (AG-UI) and Agent2Agent (A2A): For facilitating interactions between agents and users, and between agents themselves. \n\
*   Clai: A CLI tool. \n\

## Purpose

The overarching purpose of `pydantic-ai` is to simplify the development of robust and reliable Generative AI applications by providing a structured, type-safe, and extensible framework. It aims to abstract away the complexities of interacting with different LLM providers and managing agent workflows, allowing developers to focus on application logic. \n\

Notes:
The `CLAUDE.md` file provides guidance for Claude Code when working with the repository, outlining development commands and project architecture.  The `mkdocs.yml` file defines the structure and content of the project's documentation, further detailing the features and organization of the repository. \n\

Wiki pages you might want to explore:
- [Google, Anthropic and Other Providers (pydantic/pydantic-ai)](/wiki/pydantic/pydantic-ai#3.3)

View this search on DeepWiki: https://deepwiki.com/search/what-is-this-repository-about_5104a64d-2f5e-4461-80d8-eb0892242441
""",
                                'type': 'text',
                            }
                        ],
                        'is_error': False,
                    },
                    tool_call_id='mcptoolu_01FZmJ5UspaX5BB9uU339UT1',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                ),
                previous_part_kind='builtin-tool-call',
            ),
        ]
    )


async def test_anthropic_code_execution_tool(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, vcr: Any, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-6', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(
        m,
        capabilities=[NativeTool(CodeExecutionTool())],
        model_settings=settings,
        instructions='Always use the code execution tool for math.',
    )

    first_result = await agent.run('How much is 3 * 12390?')
    messages = first_result.all_messages()
    second_result = await agent.run('How about 4 * 12390?')

    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        ([{'name': 'code_execution', 'type': 'code_execution_20260120'}], None)
    )
    assert messages == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='How much is 3 * 12390?', timestamp=IsDatetime())],
                timestamp=IsNow(tz=timezone.utc),
                instructions='Always use the code execution tool for math.',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user wants to calculate 3 * 12390.',
                        signature='EuMBClsIDRgCKkCBepwkio14AThnNMEKAu3rSfMVfRaW6geACt55taz42duIJbFXxOJf0tI8EjTRA9RAKhwp+xXRURux2EQFBfXyMhFjbGF1ZGUtc29ubmV0LTQtNjgAEgzHGYHisxljYWpLnrgaDKZKZae+36/i1yGDySIw0y5IUqbGZAIbYwNMB08PQHqnGTATDg6fz5BZamuXOePOJjzuZAIgrLwihf5klQ2GKjY4OpKH9AeabXOH8IMNB0hXb2kKErLgHKRqM1XpUgcb1+CT+WQ44PaSGqORUYphCKXv3rL84J0YAQ==',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'echo $((3 * 12390))'},
                        tool_call_id='srvtoolu_01Y5A969cu9rsnDkHF6brfKF',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': '37170\n',
                            'type': 'bash_code_execution_result',
                        },
                        timestamp=IsDatetime(),
                        tool_call_id='srvtoolu_01Y5A969cu9rsnDkHF6brfKF',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    TextPart(content='The result of **3 × 12,390 = 37,170**.'),
                ],
                usage=RequestUsage(
                    input_tokens=4692,
                    output_tokens=106,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 4692,
                        'output_tokens': 106,
                    },
                    cost=Decimal('0.015666'),
                ),
                model_name='claude-sonnet-4-6',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn', 'container_id': 'container_011CaNRhtVsGiXZx1CgSETLH'},
                provider_response_id='msg_01FzttSG1H2WSfUwv2J5qbMB',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    assert second_result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='How about 4 * 12390?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                instructions='Always use the code execution tool for math.',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='The user wants to calculate 4 * 12390.',
                        signature='EuMBClsIDRgCKkCL2iffHrB6tHBOjw6/tZsNE9mjnkPnnIfacGJ5k7bsyvJA+ns/Ip2UFePesjpTjejc4cuMUUyE5JubAP+vUYc4MhFjbGF1ZGUtc29ubmV0LTQtNjgAEgw1F/YrMZLYbqWCvIAaDLAuwVJtNlAhRAfAPyIwBNQfxK3FouQBAtlU2oGolIVbYhYiGvWjGrCqU/+HSoYBBUBx1nWMExSOyyUJnNy1KjYI1DEPApNrjV0XjCy3dGoIIeNeBL/viz2uAotZTe1qQaDwmo71S5jILbV1iLihcE1cL9LWFJMYAQ==',
                        provider_name='anthropic',
                    ),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'echo $((4 * 12390))'},
                        tool_call_id='srvtoolu_01VjgZr13GE2HYtGnPkHeuHh',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': '49560\n',
                            'type': 'bash_code_execution_result',
                        },
                        tool_call_id='srvtoolu_01VjgZr13GE2HYtGnPkHeuHh',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    TextPart(content='**4 × 12,390 = 49,560**'),
                ],
                usage=RequestUsage(
                    input_tokens=4690,
                    output_tokens=103,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 4690,
                        'output_tokens': 103,
                    },
                    cost=Decimal('0.015615'),
                ),
                model_name='claude-sonnet-4-6',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn', 'container_id': 'container_011CaNRiLGQoB5CoDJP5jaVY'},
                provider_response_id='msg_01GpqA67eRBKk6HEb9w5Rs28',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    request_bodies = [json.loads(request.body) for request in vcr.requests]
    assert [body['tools'] for body in request_bodies] == [
        [{'name': 'code_execution', 'type': 'code_execution_20260120'}],
        [{'name': 'code_execution', 'type': 'code_execution_20260120'}],
    ]


async def test_anthropic_code_execution_tool_stream(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-6', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())], model_settings=settings)

    event_parts: list[Any] = []
    async with agent.iter(user_prompt='what is 65465-6544 * 65464-6+1.02255') as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert agent_run.result is not None
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        ([{'name': 'code_execution', 'type': 'code_execution_20260120'}], None)
    )
    assert agent_run.result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='what is 65465-6544 * 65464-6+1.02255',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='Let me calculate this mathematical expression.',
                        signature='EusBClsIDRgCKkBpzetW9oKOZtFP6IeFJJr3gnQBXqdZrYcRnwTLcVuC/mkNQXFCRtvXzgnEVf7l5fFR7h3ot66yltYQokOJgU0XMhFjbGF1ZGUtc29ubmV0LTQtNjgAEgx4VA49Y9x4euFn/C8aDLaPUE1i8unro8wUZyIwTVsbnme/ZlJjB/k0sJpLe/6Hhr1hiJBEwIautRYb9wRO69nCOmte8rf2JIlb3WN2Kj5V5cgiQPXU7/dckGIBOjC3LbVg4fl1yJKZ6A9eiNDAfvI1a3el8ptl54928QUlCPHT6QRNK5dDomrp4RcinBgB',
                        provider_name='anthropic',
                    ),
                    TextPart(content="I'll calculate that expression for you right away!"),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args='{"command": "echo \\"65465-6544 * 65464-6+1.02255\\" | bc -l"}',
                        tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': '-428330955.97745\n',
                            'type': 'bash_code_execution_result',
                        },
                        tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    TextPart(
                        content="""\
Following the standard **order of operations (PEMDAS/BODMAS)** — multiplication is performed before addition and subtraction — here's the breakdown:

| Step | Operation | Result |
|------|-----------|--------|
| 1️⃣ | `6544 × 65464` | `428,394,416` |
| 2️⃣ | `65465 - 428,394,416` | `-428,328,951` |
| 3️⃣ | `-428,328,951 - 6` | `-428,328,957` |
| 4️⃣ | `-428,328,957 + 1.02255` | **`-428,328,955.97745`** |

### ✅ Final Answer: **-428,330,955.97745**\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=4714,
                    output_tokens=304,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 4714,
                        'output_tokens': 304,
                    },
                    cost=Decimal('0.018702'),
                ),
                model_name='claude-sonnet-4-6',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={
                    'finish_reason': 'end_turn',
                    'container_id': 'container_011CaNRFAbjdPf4rmBarZzqQ',
                },
                provider_response_id='msg_01Js8aWE7YbmiaUPneGiCskE',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    assert event_parts == snapshot(
        [
            PartStartEvent(index=0, part=ThinkingPart(content='', signature='', provider_name='anthropic')),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta='Let'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(content_delta=' me calculate this mathematical expression.'),
            ),
            PartDeltaEvent(
                index=0,
                delta=ThinkingPartDelta(
                    signature_delta='EusBClsIDRgCKkBpzetW9oKOZtFP6IeFJJr3gnQBXqdZrYcRnwTLcVuC/mkNQXFCRtvXzgnEVf7l5fFR7h3ot66yltYQokOJgU0XMhFjbGF1ZGUtc29ubmV0LTQtNjgAEgx4VA49Y9x4euFn/C8aDLaPUE1i8unro8wUZyIwTVsbnme/ZlJjB/k0sJpLe/6Hhr1hiJBEwIautRYb9wRO69nCOmte8rf2JIlb3WN2Kj5V5cgiQPXU7/dckGIBOjC3LbVg4fl1yJKZ6A9eiNDAfvI1a3el8ptl54928QUlCPHT6QRNK5dDomrp4RcinBgB'
                ),
            ),
            PartEndEvent(
                index=0,
                part=ThinkingPart(
                    content='Let me calculate this mathematical expression.',
                    signature='EusBClsIDRgCKkBpzetW9oKOZtFP6IeFJJr3gnQBXqdZrYcRnwTLcVuC/mkNQXFCRtvXzgnEVf7l5fFR7h3ot66yltYQokOJgU0XMhFjbGF1ZGUtc29ubmV0LTQtNjgAEgx4VA49Y9x4euFn/C8aDLaPUE1i8unro8wUZyIwTVsbnme/ZlJjB/k0sJpLe/6Hhr1hiJBEwIautRYb9wRO69nCOmte8rf2JIlb3WN2Kj5V5cgiQPXU7/dckGIBOjC3LbVg4fl1yJKZ6A9eiNDAfvI1a3el8ptl54928QUlCPHT6QRNK5dDomrp4RcinBgB',
                    provider_name='anthropic',
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=1,
                part=TextPart(content="I'll calculate that expression for you right away!"),
                previous_part_kind='thinking',
            ),
            FinalResultEvent(tool_name=None, tool_call_id=None),
            PartEndEvent(
                index=1,
                part=TextPart(content="I'll calculate that expression for you right away!"),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=2,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=2, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q')
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='{"com', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='mand": "ec', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='ho \\"65465-', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='6544 * 6', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='54', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='64-6+1.02', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='255\\" | ', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='bc -l"}', tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q'),
            ),
            PartEndEvent(
                index=2,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    args='{"command": "echo \\"65465-6544 * 65464-6+1.02255\\" | bc -l"}',
                    tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=3,
                part=NativeToolReturnPart(
                    tool_name='code_execution',
                    content={
                        'content': [],
                        'return_code': 0,
                        'stderr': '',
                        'stdout': '-428330955.97745\n',
                        'type': 'bash_code_execution_result',
                    },
                    tool_call_id='srvtoolu_01MwXaweAHve88x6s3Fc8x6Q',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(index=4, part=TextPart(content='Following'), previous_part_kind='builtin-tool-return'),
            PartDeltaEvent(
                index=4,
                delta=TextPartDelta(
                    content_delta=' the standard **order of operations (PEMDAS/BODMAS)** — multiplication is'
                ),
            ),
            PartDeltaEvent(
                index=4,
                delta=TextPartDelta(
                    content_delta="""\
 performed before addition and subtraction — here's the breakdown:

| Step | Operation | Result |
|------|-----------|--------|
| 1️\
"""
                ),
            ),
            PartDeltaEvent(
                index=4,
                delta=TextPartDelta(content_delta='⃣ | `6544 × 65464` | `428,394,416'),
            ),
            PartDeltaEvent(
                index=4,
                delta=TextPartDelta(
                    content_delta="""\
` |
| 2️⃣ | `65465 - 428,394,416` | `-428,328,951\
"""
                ),
            ),
            PartDeltaEvent(
                index=4,
                delta=TextPartDelta(
                    content_delta="""\
` |
| 3️⃣ | `-428,328,951 - 6` | `-428,328,957` |
| 4️\
"""
                ),
            ),
            PartDeltaEvent(
                index=4,
                delta=TextPartDelta(
                    content_delta="""\
⃣ | `-428,328,957 + 1.02255` | **`-428,328,955.97745`** |

### \
"""
                ),
            ),
            PartDeltaEvent(index=4, delta=TextPartDelta(content_delta='✅ Final Answer: **-428,330,955.97745**')),
            PartEndEvent(
                index=4,
                part=TextPart(
                    content="""\
Following the standard **order of operations (PEMDAS/BODMAS)** — multiplication is performed before addition and subtraction — here's the breakdown:

| Step | Operation | Result |
|------|-----------|--------|
| 1️⃣ | `6544 × 65464` | `428,394,416` |
| 2️⃣ | `65465 - 428,394,416` | `-428,328,951` |
| 3️⃣ | `-428,328,951 - 6` | `-428,328,957` |
| 4️⃣ | `-428,328,957 + 1.02255` | **`-428,328,955.97745`** |

### ✅ Final Answer: **-428,330,955.97745**\
"""
                ),
            ),
        ]
    )


async def test_anthropic_code_execution_tool_version_unsupported(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel(
        'claude-haiku-4-5-20251001',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(anthropic_code_execution_tool_version='20260120'),
    )
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    with pytest.raises(
        UserError,
        match=(
            "`anthropic_code_execution_tool_version='20260120'` is not supported by model 'claude-haiku-4-5-20251001'"
        ),
    ):
        await agent.run('hello')

    assert get_mock_chat_completion_kwargs(mock_client) == []


@pytest.mark.parametrize(
    ('model_name', 'expected_tool_type'),
    [
        ('claude-sonnet-4-0', 'code_execution_20250825'),
        ('claude-opus-4-1', 'code_execution_20250825'),
        ('claude-haiku-4-5-20251001', 'code_execution_20250825'),
        ('claude-sonnet-4-5', 'code_execution_20260120'),
        ('claude-sonnet-4-6', 'code_execution_20260120'),
        ('claude-opus-4-5', 'code_execution_20260120'),
    ],
)
async def test_anthropic_code_execution_tool_version_auto(
    allow_model_requests: None,
    model_name: str,
    expected_tool_type: str,
):
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    await agent.run('hello')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['tools'] == [{'name': 'code_execution', 'type': expected_tool_type}]


@pytest.mark.parametrize(
    ('tool_version', 'expected_tool_type'),
    [
        ('20250825', 'code_execution_20250825'),
        ('20260120', 'code_execution_20260120'),
    ],
)
async def test_anthropic_code_execution_tool_version_setting(
    allow_model_requests: None,
    tool_version: AnthropicCodeExecutionToolVersion,
    expected_tool_type: str,
):
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel(
        'claude-sonnet-4-5',
        provider=AnthropicProvider(anthropic_client=mock_client),
        settings=AnthropicModelSettings(anthropic_code_execution_tool_version=tool_version),
    )
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    await agent.run('hello')

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['tools'] == [{'name': 'code_execution', 'type': expected_tool_type}]
    assert completion_kwargs['betas'] is OMIT


async def test_anthropic_server_tool_pass_history_to_another_provider(
    allow_model_requests: None,
    anthropic_model: AnthropicModelFactory,
    openai_api_key: str,
    request_capture: RequestCapture,
):
    from pydantic_ai.models.openai import OpenAIResponsesModel
    from pydantic_ai.providers.openai import OpenAIProvider

    openai_model = OpenAIResponsesModel('gpt-4.1', provider=OpenAIProvider(api_key=openai_api_key))
    model = anthropic_model('claude-sonnet-4-5', capture=True)
    agent = Agent(model, capabilities=[NativeTool(WebSearchTool())])

    result = await agent.run('What day is today?')
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_search',
                    'type': 'web_search_20250305',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'user_location': None,
                }
            ],
            None,
        )
    )
    assert result.output == snapshot('Today is November 19, 2025.')
    result = await agent.run('What day is tomorrow?', model=openai_model, message_history=result.all_messages())
    assert result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='What day is tomorrow?', timestamp=IsDatetime())],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    TextPart(
                        content='Tomorrow is November 20, 2025.',
                        id='msg_0dcd74f01910b54500691e5596124081a087e8fa7b2ca19d5a',
                        provider_name='openai',
                    )
                ],
                usage=RequestUsage(
                    input_tokens=329,
                    output_tokens=12,
                    output_reasoning_tokens=0,
                    details={'reasoning_tokens': 0},
                    cost=Decimal('0.000754'),
                ),
                model_name='gpt-4.1-2025-04-14',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_details={
                    'finish_reason': 'completed',
                    'timestamp': datetime(2025, 11, 19, 23, 41, 8, tzinfo=timezone.utc),
                },
                provider_response_id='resp_0dcd74f01910b54500691e5594957481a0ac36dde76eca939f',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_server_tool_receive_history_from_another_provider(
    allow_model_requests: None,
    anthropic_model: AnthropicModelFactory,
    gemini_api_key: str,
    request_capture: RequestCapture,
):
    from pydantic_ai.models.google import GoogleModel
    from pydantic_ai.providers.google import GoogleProvider

    google_model = GoogleModel('gemini-2.0-flash', provider=GoogleProvider(api_key=gemini_api_key))
    model = anthropic_model('claude-sonnet-4-6', capture=True)
    agent = Agent(capabilities=[NativeTool(CodeExecutionTool())])

    result = await agent.run('How much is 3 * 12390?', model=google_model)
    assert part_types_from_messages(result.all_messages()) == snapshot(
        [
            [UserPromptPart],
            [
                NativeToolCallPart,
                NativeToolReturnPart,
                TextPart,
                NativeToolCallPart,
                NativeToolReturnPart,
                TextPart,
                NativeToolCallPart,
                NativeToolReturnPart,
                TextPart,
            ],
        ]
    )

    result = await agent.run('Multiplied by 12390', model=model, message_history=result.all_messages())
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        ([{'name': 'code_execution', 'type': 'code_execution_20260120'}], None)
    )
    assert part_types_from_messages(result.all_messages()) == snapshot(
        [
            [UserPromptPart],
            [
                NativeToolCallPart,
                NativeToolReturnPart,
                TextPart,
                NativeToolCallPart,
                NativeToolReturnPart,
                TextPart,
                NativeToolCallPart,
                NativeToolReturnPart,
                TextPart,
            ],
            [UserPromptPart],
            [TextPart, NativeToolCallPart, NativeToolReturnPart, TextPart],
        ]
    )


async def test_anthropic_empty_content_filtering(env: TestEnv):
    """Test the empty content filtering logic directly."""

    # Initialize model for all tests
    env.set('ANTHROPIC_API_KEY', 'test-key')
    model = AnthropicModel('claude-sonnet-4-5', provider='anthropic')

    # Test _map_message with empty string in user prompt
    messages_empty_string: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='')], kind='request', timestamp=IsDatetime()),
    ]
    _, anthropic_messages = await model._map_message(messages_empty_string, ModelRequestParameters(), {})  # type: ignore[attr-defined]
    assert anthropic_messages == snapshot([])  # Empty content should be filtered out

    # Test _map_message with list containing empty strings in user prompt
    messages_mixed_content: list[ModelMessage] = [
        ModelRequest(
            parts=[UserPromptPart(content=['', 'Hello', '', 'World'])], kind='request', timestamp=IsDatetime()
        ),
    ]
    _, anthropic_messages = await model._map_message(messages_mixed_content, ModelRequestParameters(), {})  # type: ignore[attr-defined]
    assert anthropic_messages == snapshot(
        [{'role': 'user', 'content': [{'text': 'Hello', 'type': 'text'}, {'text': 'World', 'type': 'text'}]}]
    )

    # Test _map_message with empty assistant response
    messages: list[ModelMessage] = [
        ModelRequest(parts=[SystemPromptPart(content='You are helpful')], kind='request', timestamp=IsDatetime()),
        ModelResponse(parts=[TextPart(content='')], kind='response'),  # Empty response
        ModelRequest(parts=[UserPromptPart(content='Hello')], kind='request', timestamp=IsDatetime()),
    ]
    _, anthropic_messages = await model._map_message(messages, ModelRequestParameters(), {})  # type: ignore[attr-defined]
    # The empty assistant message should be filtered out
    assert anthropic_messages == snapshot([{'role': 'user', 'content': [{'text': 'Hello', 'type': 'text'}]}])

    # Test with only empty assistant parts
    messages_resp: list[ModelMessage] = [
        ModelResponse(parts=[TextPart(content=''), TextPart(content='')], kind='response'),
    ]
    _, anthropic_messages = await model._map_message(messages_resp, ModelRequestParameters(), {})  # type: ignore[attr-defined]
    assert len(anthropic_messages) == 0  # No messages should be added


async def test_anthropic_tool_output(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-5', capture=True)

    class CityLocation(BaseModel):
        city: str
        country: str

    agent = Agent(m, output_type=ToolOutput(CityLocation))

    @agent.tool_plain
    async def get_user_country() -> str:
        return 'Mexico'

    result = await agent.run('What is the largest city in the user country?')
    assert content_blocks(request_capture.body(), 'tool_result') == snapshot([])
    assert result.output == snapshot(CityLocation(city='Mexico City', country='Mexico'))

    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the largest city in the user country?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(tool_name='get_user_country', args={}, tool_call_id='toolu_01X9wcHKKAZD9tBC711xipPa')
                ],
                usage=RequestUsage(
                    input_tokens=445,
                    output_tokens=23,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 445,
                        'output_tokens': 23,
                    },
                    cost=Decimal('0.001680'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'tool_use'},
                provider_response_id='msg_012TXW181edhmR5JCsQRsBKx',
                finish_reason='tool_call',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_user_country',
                        content='Mexico',
                        tool_call_id='toolu_01X9wcHKKAZD9tBC711xipPa',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name='final_result',
                        args={'city': 'Mexico City', 'country': 'Mexico'},
                        tool_call_id='toolu_01LZABsgreMefH2Go8D5PQbW',
                    )
                ],
                usage=RequestUsage(
                    input_tokens=497,
                    output_tokens=56,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 497,
                        'output_tokens': 56,
                    },
                    cost=Decimal('0.002331'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'tool_use'},
                provider_response_id='msg_01K4Fzcf1bhiyLzHpwLdrefj',
                finish_reason='tool_call',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='final_result',
                        content='Final result processed.',
                        tool_call_id='toolu_01LZABsgreMefH2Go8D5PQbW',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_text_output_function(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-5', capture=True)

    def upcase(text: str) -> str:
        return text.upper()

    agent = Agent(m, output_type=TextOutput(upcase))

    @agent.tool_plain
    async def get_user_country() -> str:
        return 'Mexico'

    result = await agent.run(
        'What is the largest city in the user country? Use the get_user_country tool and then your own world knowledge.'
    )
    assert content_blocks(request_capture.body(), 'tool_result') == snapshot([])
    assert result.output == snapshot(
        'BASED ON THE RESULT, YOU ARE LOCATED IN MEXICO. THE LARGEST CITY IN MEXICO IS MEXICO CITY (CIUDAD DE MÉXICO), WHICH IS BOTH THE CAPITAL AND THE MOST POPULOUS CITY IN THE COUNTRY. WITH A POPULATION OF APPROXIMATELY 9.2 MILLION PEOPLE IN THE CITY PROPER AND OVER 21 MILLION PEOPLE IN ITS METROPOLITAN AREA, MEXICO CITY IS NOT ONLY THE LARGEST CITY IN MEXICO BUT ALSO ONE OF THE LARGEST CITIES IN THE WORLD.'
    )

    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the largest city in the user country? Use the get_user_country tool and then your own world knowledge.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    TextPart(
                        content="I'll help find the largest city in your country. Let me first check your country using the get_user_country tool."
                    ),
                    ToolCallPart(tool_name='get_user_country', args={}, tool_call_id='toolu_01JJ8TequDsrEU2pv1QFRWAK'),
                ],
                usage=RequestUsage(
                    input_tokens=383,
                    output_tokens=65,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 383,
                        'output_tokens': 65,
                    },
                    cost=Decimal('0.002124'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'tool_use'},
                provider_response_id='msg_01MsqUB7ZyhjGkvepS1tCXp3',
                finish_reason='tool_call',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_user_country',
                        content='Mexico',
                        tool_call_id='toolu_01JJ8TequDsrEU2pv1QFRWAK',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    TextPart(
                        content='Based on the result, you are located in Mexico. The largest city in Mexico is Mexico City (Ciudad de México), which is both the capital and the most populous city in the country. With a population of approximately 9.2 million people in the city proper and over 21 million people in its metropolitan area, Mexico City is not only the largest city in Mexico but also one of the largest cities in the world.'
                    )
                ],
                usage=RequestUsage(
                    input_tokens=460,
                    output_tokens=91,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 460,
                        'output_tokens': 91,
                    },
                    cost=Decimal('0.002745'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_0142umg4diSckrDtV9vAmmPL',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


@pytest.mark.vcr()
async def test_anthropic_prompted_output(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-5', capture=True)

    class CityLocation(BaseModel):
        city: str
        country: str

    agent = Agent(m, output_type=PromptedOutput(CityLocation))

    @agent.tool_plain
    async def get_user_country() -> str:
        return 'Mexico'

    result = await agent.run(
        'What is the largest city in the user country? Use the get_user_country tool and then your own world knowledge.'
    )
    assert result.output == snapshot(CityLocation(city='Mexico City', country='Mexico'))

    assert request_capture.body()['system'] == snapshot(
        [
            {
                'type': 'text',
                'text': """\

Always respond with a JSON object that's compatible with this schema:

{"properties": {"city": {"type": "string"}, "country": {"type": "string"}}, "required": ["city", "country"], "type": "object", "title": "CityLocation"}

Don't include any text or Markdown fencing before or after.
""",
            }
        ]
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the largest city in the user country? Use the get_user_country tool and then your own world knowledge.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(tool_name='get_user_country', args={}, tool_call_id='toolu_01ArHq5f2wxRpRF2PVQcKExM')
                ],
                usage=RequestUsage(
                    input_tokens=459,
                    output_tokens=38,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 459,
                        'output_tokens': 38,
                    },
                    cost=Decimal('0.001947'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'tool_use'},
                provider_response_id='msg_018YiNXULHGpoKoHkTt6GivG',
                finish_reason='tool_call',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_user_country',
                        content='Mexico',
                        tool_call_id='toolu_01ArHq5f2wxRpRF2PVQcKExM',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='{"city": "Mexico City", "country": "Mexico"}')],
                usage=RequestUsage(
                    input_tokens=510,
                    output_tokens=17,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 510,
                        'output_tokens': 17,
                    },
                    cost=Decimal('0.001785'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01WiRVmLhCrJbJZRqmAWKv3X',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_prompted_output_multiple(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-5', capture=True)

    class CityLocation(BaseModel):
        city: str
        country: str

    class CountryLanguage(BaseModel):
        country: str
        language: str

    agent = Agent(m, output_type=PromptedOutput([CityLocation, CountryLanguage]))

    result = await agent.run('What is the largest city in Mexico?')
    assert result.output == snapshot(CityLocation(city='Mexico City', country='Mexico'))

    assert request_capture.body()['system'] == snapshot(
        [
            {
                'type': 'text',
                'text': """\

Always respond with a JSON object that's compatible with this schema:

{"type": "object", "properties": {"result": {"anyOf": [{"type": "object", "properties": {"kind": {"type": "string", "const": "CityLocation"}, "data": {"properties": {"city": {"type": "string"}, "country": {"type": "string"}}, "required": ["city", "country"], "type": "object"}}, "required": ["kind", "data"], "additionalProperties": false}, {"type": "object", "properties": {"kind": {"type": "string", "const": "CountryLanguage"}, "data": {"properties": {"country": {"type": "string"}, "language": {"type": "string"}}, "required": ["country", "language"], "type": "object"}}, "required": ["kind", "data"], "additionalProperties": false}]}}, "required": ["result"], "additionalProperties": false}

Don't include any text or Markdown fencing before or after.
""",
            }
        ]
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What is the largest city in Mexico?',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    TextPart(
                        content='{"result": {"kind": "CityLocation", "data": {"city": "Mexico City", "country": "Mexico"}}}'
                    )
                ],
                usage=RequestUsage(
                    input_tokens=265,
                    output_tokens=31,
                    details={
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                        'input_tokens': 265,
                        'output_tokens': 31,
                    },
                    cost=Decimal('0.001260'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_01N2PwwVQo2aBtt6UFhMDtEX',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_output_tool_with_thinking(
    allow_model_requests: None, anthropic_api_key: str, request_capture: RequestCapture
):
    m = AnthropicModel(
        'claude-sonnet-4-0',
        provider=AnthropicProvider(api_key=anthropic_api_key, http_client=request_capture.client),
        settings=AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000}),
    )

    agent = Agent(m, output_type=ToolOutput(int))

    with pytest.raises(
        UserError,
        match=re.escape(
            'Anthropic does not support extended thinking and output tools at the same time. Use `output_type=PromptedOutput(...)` instead.'
        ),
    ):
        await agent.run('What is 3 + 3?')

    # Will default to prompted output
    agent = Agent(m, output_type=int)

    result = await agent.run('What is 3 + 3?')
    assert request_capture.body()['system'] == snapshot(
        [
            {
                'type': 'text',
                'text': """\

Always respond with a JSON object that's compatible with this schema:

{"properties": {"response": {"type": "integer"}}, "required": ["response"], "type": "object", "title": "int"}

Don't include any text or Markdown fencing before or after.
""",
            }
        ]
    )
    assert result.output == snapshot(6)


async def test_anthropic_tool_with_thinking(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """When using thinking with tool calls in Anthropic, we need to send the thinking part back to the provider.

    This tests the issue raised in https://github.com/pydantic/pydantic-ai/issues/2040.
    """
    m = anthropic_model('claude-sonnet-4-0', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 3000})
    agent = Agent(m, model_settings=settings)

    @agent.tool_plain
    async def get_user_country() -> str:
        return 'Mexico'

    result = await agent.run('What is the largest city in the user country?')
    assert content_blocks(request_capture.body(), 'tool_result') == snapshot([])
    assert result.output == snapshot("""\
Based on the information that you're from Mexico, the largest city in your country is **Mexico City** (Ciudad de México). \n\

Mexico City is not only the largest city in Mexico but also one of the largest metropolitan areas in the world. The city proper has a population of approximately 9.2 million people, while the greater Mexico City metropolitan area (which includes surrounding municipalities) has over 21 million inhabitants, making it one of the most populous urban agglomerations globally.

Mexico City serves as the country's capital and is the political, economic, and cultural center of Mexico.\
""")


async def test_anthropic_web_search_tool_pass_history_back(env: TestEnv, allow_model_requests: None):
    """Test passing web search tool history back to Anthropic."""
    # Create the first mock response with server tool blocks
    content: list[BetaContentBlock] = []
    content.append(BetaTextBlock(text='Let me search for the current date.', type='text'))
    content.append(
        BetaServerToolUseBlock(
            id='server_tool_123',
            name='web_search',
            input={'query': 'current date today'},
            type='server_tool_use',
            caller=BetaDirectCaller(type='direct'),
        )
    )
    content.append(
        BetaWebSearchToolResultBlock(
            tool_use_id='server_tool_123',
            type='web_search_tool_result',
            content=[
                BetaWebSearchResultBlock(
                    title='Current Date and Time',
                    url='https://example.com/date',
                    type='web_search_result',
                    encrypted_content='dummy_encrypted_content',
                )
            ],
        ),
    )
    content.append(BetaTextBlock(text='Today is January 2, 2025.', type='text'))
    first_response = completion_message(
        content,
        BetaUsage(input_tokens=10, output_tokens=20),
    )

    # Create the second mock response that references the history
    second_response = completion_message(
        [BetaTextBlock(text='The web search result showed that today is January 2, 2025.', type='text')],
        BetaUsage(input_tokens=50, output_tokens=30),
    )

    mock_client = MockAnthropic.create_mock([first_response, second_response])
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(WebSearchTool())])

    # First run to get server tool history
    result = await agent.run('What day is today?')

    # Verify we have server tool parts in the history
    server_tool_calls = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolCallPart))
    server_tool_returns = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolReturnPart))
    assert len(server_tool_calls) == 1
    assert len(server_tool_returns) == 1
    assert server_tool_calls[0].tool_name == 'web_search'
    assert server_tool_returns[0].tool_name == 'web_search'

    # Pass the history back to another Anthropic agent run
    agent2 = Agent(m)
    result2 = await agent2.run('What was the web search result?', message_history=result.all_messages())
    assert result2.output == 'The web search result showed that today is January 2, 2025.'


async def test_anthropic_code_execution_tool_pass_history_back(env: TestEnv, allow_model_requests: None):
    """Test passing code execution tool history back to Anthropic."""
    # Create the first mock response with server tool blocks
    content: list[BetaContentBlock] = []
    content.append(BetaTextBlock(text='Let me calculate 2 + 2.', type='text'))
    content.append(
        BetaServerToolUseBlock(
            id='server_tool_456',
            name='code_execution',
            input={'code': 'print(2 + 2)'},
            type='server_tool_use',
            caller=BetaDirectCaller(type='direct'),
        )
    )
    content.append(
        BetaCodeExecutionToolResultBlock(
            tool_use_id='server_tool_456',
            type='code_execution_tool_result',
            content=BetaCodeExecutionResultBlock(
                content=[],
                return_code=0,
                stderr='',
                stdout='4\n',
                type='code_execution_result',
            ),
        ),
    )
    content.append(BetaTextBlock(text='The result is 4.', type='text'))
    first_response = completion_message(
        content,
        BetaUsage(input_tokens=10, output_tokens=20),
    )

    # Create the second mock response that references the history
    second_response = completion_message(
        [BetaTextBlock(text='The code execution returned the result: 4', type='text')],
        BetaUsage(input_tokens=50, output_tokens=30),
    )

    mock_client = MockAnthropic.create_mock([first_response, second_response])
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    # First run to get server tool history
    result = await agent.run('What is 2 + 2?')

    # Verify we have server tool parts in the history
    server_tool_calls = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolCallPart))
    server_tool_returns = list(iter_message_parts(result.all_messages(), ModelResponse, NativeToolReturnPart))
    assert len(server_tool_calls) == 1
    assert len(server_tool_returns) == 1
    assert server_tool_calls[0].tool_name == 'code_execution'
    assert server_tool_returns[0].tool_name == 'code_execution'

    # Pass the history back to another Anthropic agent run
    agent2 = Agent(m)
    result2 = await agent2.run('What was the code execution result?', message_history=result.all_messages())
    assert result2.output == 'The code execution returned the result: 4'


async def test_anthropic_text_editor_code_execution_tool(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-6', capture=True)
    agent = Agent(
        m,
        capabilities=[NativeTool(CodeExecutionTool())],
        instructions=(
            'Use only the text editor `create` and `view` commands from the code execution sandbox. '
            'Do not run any shell commands.'
        ),
    )

    result = await agent.run(
        'Use the text editor to create /tmp/hello.txt with the text: Hello, world! '
        'Then use the text editor to view the file and tell me what it contains.'
    )
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        ([{'name': 'code_execution', 'type': 'code_execution_20260120'}], None)
    )
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Use the text editor to create /tmp/hello.txt with the text: Hello, world! Then use the text editor to view the file and tell me what it contains.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsDatetime(),
                instructions='Use only the text editor `create` and `view` commands from the code execution sandbox. Do not run any shell commands.',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    TextPart(
                        content="Sure! I'll do both steps simultaneously -- creating the file and viewing it at the same time!"
                    ),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'create', 'file_text': 'Hello, world!', 'path': '/tmp/hello.txt'},
                        tool_call_id='srvtoolu_016pLxxM63EiNXuNu4xif3v6',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'view', 'path': '/tmp/hello.txt'},
                        tool_call_id='srvtoolu_01PZq4iFAcL7tePiLnstxaXh',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'error_code': 'unavailable',
                            'error_message': 'Tool response parsing error for create: Failed to parse tool response as JSON: Input is a zero-length, empty document: line 1 column 1 (char 0)',
                            'type': 'text_editor_code_execution_tool_result_error',
                        },
                        tool_call_id='srvtoolu_016pLxxM63EiNXuNu4xif3v6',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'error_code': 'unavailable',
                            'error_message': 'Tool response parsing error for view: Failed to parse tool response as JSON: unexpected character: line 1 column 1 (char 0)',
                            'type': 'text_editor_code_execution_tool_result_error',
                        },
                        tool_call_id='srvtoolu_01PZq4iFAcL7tePiLnstxaXh',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    TextPart(content='Let me try again, this time sequentially -- first creating, then viewing.'),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'create', 'file_text': 'Hello, world!', 'path': '/tmp/hello.txt'},
                        tool_call_id='srvtoolu_01R4E6F3kJy4AHsq9D956u2Q',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'is_file_update': False,
                            'type': 'text_editor_code_execution_create_result',
                        },
                        timestamp=IsDatetime(),
                        tool_call_id='srvtoolu_01R4E6F3kJy4AHsq9D956u2Q',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    TextPart(content="File created! Now let's view it."),
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'view', 'path': '/tmp/hello.txt'},
                        tool_call_id='srvtoolu_01NCMtdMpuTRPDtCeaPC1WWw',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'content': 'Hello, world!',
                            'file_type': 'text',
                            'num_lines': 1,
                            'start_line': 1,
                            'total_lines': 1,
                            'type': 'text_editor_code_execution_view_result',
                        },
                        tool_call_id='srvtoolu_01NCMtdMpuTRPDtCeaPC1WWw',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                    ),
                    TextPart(
                        content="""\
Here's a summary of what happened:

1. **Created** `/tmp/hello.txt` with the text `Hello, world!` -- the tool confirmed the file was created successfully.
2. **Viewed** `/tmp/hello.txt` -- the file contains exactly:

> `Hello, world!`

Everything looks perfect! 🎉\
"""
                    ),
                ],
                usage=RequestUsage(
                    input_tokens=10490,
                    output_tokens=469,
                    details={
                        'input_tokens': 10490,
                        'output_tokens': 469,
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                    },
                    cost=Decimal('0.038505'),
                ),
                model_name='claude-sonnet-4-6',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn', 'container_id': 'container_011CaNRHVR8X8ny5XjueVygS'},
                provider_response_id='msg_015ZT9schxByyYqpexx5ir4o',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_text_editor_code_execution_tool_stream(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-6', capture=True)
    agent = Agent(
        m,
        capabilities=[NativeTool(CodeExecutionTool())],
        instructions=(
            'Use only the text editor `create` and `view` commands from the code execution sandbox. '
            'Do not run any shell commands.'
        ),
    )

    event_parts: list[Any] = []
    async with agent.iter(
        user_prompt=(
            'Use the text editor to create /tmp/hello.txt with the text: Hello, world! '
            'Then use the text editor to view the file and tell me what it contains.'
        )
    ) as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        ([{'name': 'code_execution', 'type': 'code_execution_20260120'}], None)
    )
    assert event_parts == snapshot(
        [
            PartStartEvent(index=0, part=TextPart(content='Sure')),
            FinalResultEvent(tool_name=None, tool_call_id=None),
            PartDeltaEvent(
                index=0,
                delta=TextPartDelta(
                    content_delta="! I'll do both steps simultaneously — creating the file and viewing it at the same time!"
                ),
            ),
            PartEndEvent(
                index=0,
                part=TextPart(
                    content="Sure! I'll do both steps simultaneously — creating the file and viewing it at the same time!"
                ),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=1,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='{"command":', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta=' "creat', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='e"', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta=', "p', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='ath": "/', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1, delta=ToolCallPartDelta(args_delta='tmp/he', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi')
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='llo.t', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='xt"', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta=', "file_t', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='ext', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta='": "Hello', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartDeltaEvent(
                index=1,
                delta=ToolCallPartDelta(args_delta=', world!"}', tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi'),
            ),
            PartEndEvent(
                index=1,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    args='{"command": "create", "path": "/tmp/hello.txt", "file_text": "Hello, world!"}',
                    tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=2,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartDeltaEvent(
                index=2, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs')
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='{"comman', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='d": "view', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs'),
            ),
            PartDeltaEvent(
                index=2, delta=ToolCallPartDelta(args_delta='"', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs')
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta=', "pa', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='th": "/', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs'),
            ),
            PartDeltaEvent(
                index=2,
                delta=ToolCallPartDelta(args_delta='tmp/hello.', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs'),
            ),
            PartDeltaEvent(
                index=2, delta=ToolCallPartDelta(args_delta='txt"}', tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs')
            ),
            PartEndEvent(
                index=2,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    args='{"command": "view", "path": "/tmp/hello.txt"}',
                    tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=3,
                part=NativeToolReturnPart(
                    tool_name='code_execution',
                    content={'is_file_update': False, 'type': 'text_editor_code_execution_create_result'},
                    timestamp=IsDatetime(),
                    tool_call_id='srvtoolu_01Xd8YZU6yAcvd5JbLCTRfFi',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=4,
                part=NativeToolReturnPart(
                    tool_name='code_execution',
                    content={
                        'error_code': 'unavailable',
                        'error_message': 'Tool response parsing error for view: Failed to parse tool response as JSON: unexpected character: line 1 column 1 (char 0)',
                        'type': 'text_editor_code_execution_tool_result_error',
                    },
                    tool_call_id='srvtoolu_01F3VxYFjEyogm8Ynuc75zfs',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                previous_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=5,
                part=TextPart(content='No'),
                previous_part_kind='builtin-tool-return',
            ),
            PartDeltaEvent(
                index=5, delta=TextPartDelta(content_delta=" worries — the `view` couldn't run in parallel with")
            ),
            PartDeltaEvent(
                index=5,
                delta=TextPartDelta(
                    content_delta=" the `create` since the file didn't exist yet at the time both calls"
                ),
            ),
            PartDeltaEvent(
                index=5,
                delta=TextPartDelta(
                    content_delta=' were dispatched. Now that the file has been created, let me view it!'
                ),
            ),
            PartEndEvent(
                index=5,
                part=TextPart(
                    content="No worries — the `view` couldn't run in parallel with the `create` since the file didn't exist yet at the time both calls were dispatched. Now that the file has been created, let me view it!"
                ),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=6,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6,
                delta=ToolCallPartDelta(args_delta='{"command":', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU'),
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta=' "view"', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta=', ', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta='"p', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta='ath": ', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta='"/', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6, delta=ToolCallPartDelta(args_delta='tmp/he', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU')
            ),
            PartDeltaEvent(
                index=6,
                delta=ToolCallPartDelta(args_delta='llo.txt"}', tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU'),
            ),
            PartEndEvent(
                index=6,
                part=NativeToolCallPart(
                    tool_name='code_execution',
                    args='{"command": "view", "path": "/tmp/hello.txt"}',
                    tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU',
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=7,
                part=NativeToolReturnPart(
                    tool_name='code_execution',
                    content={
                        'content': 'Hello, world!',
                        'file_type': 'text',
                        'num_lines': 1,
                        'start_line': 1,
                        'total_lines': 1,
                        'type': 'text_editor_code_execution_view_result',
                    },
                    tool_call_id='srvtoolu_01UZ1EtACaBJ87pPA9guaxHU',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(index=8, part=TextPart(content="Here's a"), previous_part_kind='builtin-tool-return'),
            PartDeltaEvent(
                index=8,
                delta=TextPartDelta(
                    content_delta="""\
 summary of what happened:

1. **Created** `/tmp/hello.txt` — the file was successfully written to\
"""
                ),
            ),
            PartDeltaEvent(
                index=8,
                delta=TextPartDelta(
                    content_delta="""\
 disk.
2. **Viewed** `/tmp/hello.txt` — the file contains exactly:\
"""
                ),
            ),
            PartDeltaEvent(
                index=8,
                delta=TextPartDelta(
                    content_delta="""\


> `Hello, world!`

Everything looks perfect! The file contains the text you specified.\
"""
                ),
            ),
            PartEndEvent(
                index=8,
                part=TextPart(
                    content="""\
Here's a summary of what happened:

1. **Created** `/tmp/hello.txt` — the file was successfully written to disk.
2. **Viewed** `/tmp/hello.txt` — the file contains exactly:

> `Hello, world!`

Everything looks perfect! The file contains the text you specified.\
"""
                ),
            ),
        ]
    )


async def test_anthropic_text_editor_code_execution_tool_message_replay(allow_model_requests: None):
    """Serialize Anthropic text editor code execution metadata back to Anthropic block params."""
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='View the file.')], timestamp=IsDatetime()),
        ModelResponse(
            parts=[
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    args={'command': 'view', 'path': '/tmp/hello.txt'},
                    tool_call_id='srvtoolu_text_editor_1',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content={
                        'content': 'Hello, world!',
                        'file_type': 'text',
                        'num_lines': 1,
                        'start_line': 1,
                        'total_lines': 1,
                        'type': 'text_editor_code_execution_view_result',
                    },
                    tool_call_id='srvtoolu_text_editor_1',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
            ],
            model_name='claude-sonnet-4-6',
        ),
    ]

    await agent.run('Continue.', message_history=messages)

    assert get_mock_chat_completion_kwargs(mock_client)[0]['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'text', 'text': 'View the file.'}]},
            {
                'role': 'assistant',
                'content': [
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_text_editor_1',
                        'name': 'text_editor_code_execution',
                        'input': {'command': 'view', 'path': '/tmp/hello.txt'},
                    },
                    {
                        'type': 'text_editor_code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_text_editor_1',
                        'content': {
                            'content': 'Hello, world!',
                            'file_type': 'text',
                            'num_lines': 1,
                            'start_line': 1,
                            'total_lines': 1,
                            'type': 'text_editor_code_execution_view_result',
                        },
                    },
                ],
            },
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Continue.'}]},
        ]
    )


async def test_anthropic_bash_code_execution_tool_message_replay(allow_model_requests: None):
    """Serialize Anthropic bash code execution metadata back to Anthropic block params."""
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='Run a shell command.')], timestamp=IsDatetime()),
        ModelResponse(
            parts=[
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    args={'command': 'echo hello'},
                    tool_call_id='srvtoolu_bash_1',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content={
                        'content': [],
                        'return_code': 0,
                        'stderr': '',
                        'stdout': 'hello\n',
                        'type': 'bash_code_execution_result',
                    },
                    tool_call_id='srvtoolu_bash_1',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
            ],
            model_name='claude-sonnet-4-6',
        ),
    ]

    await agent.run('Continue.', message_history=messages)

    assert get_mock_chat_completion_kwargs(mock_client)[0]['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Run a shell command.'}]},
            {
                'role': 'assistant',
                'content': [
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_bash_1',
                        'name': 'bash_code_execution',
                        'input': {'command': 'echo hello'},
                    },
                    {
                        'type': 'bash_code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_bash_1',
                        'content': {
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': 'hello\n',
                            'type': 'bash_code_execution_result',
                        },
                    },
                ],
            },
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Continue.'}]},
        ]
    )


async def test_anthropic_code_execution_tool_message_replay_with_list_results(allow_model_requests: None):
    """Serialize Anthropic code execution result lists instead of dropping them."""
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    bash_result = [
        {
            'return_code': 0,
            'stderr': '',
            'stdout': 'hello\n',
            'type': 'bash_code_execution_result',
        }
    ]
    text_editor_result = [
        {
            'content': 'Hello, world!',
            'file_type': 'text',
            'num_lines': 1,
            'start_line': 1,
            'total_lines': 1,
            'type': 'text_editor_code_execution_view_result',
        }
    ]
    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='Replay code execution history.')], timestamp=IsDatetime()),
        ModelResponse(
            parts=[
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    args={'command': 'echo hello'},
                    tool_call_id='srvtoolu_bash_list',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content=bash_result,
                    tool_call_id='srvtoolu_bash_list',
                    provider_details={'anthropic_tool_name': 'bash_code_execution'},
                ),
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    args={'command': 'view', 'path': '/tmp/hello.txt'},
                    tool_call_id='srvtoolu_text_editor_list',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content=text_editor_result,
                    tool_call_id='srvtoolu_text_editor_list',
                    provider_details={'anthropic_tool_name': 'text_editor_code_execution'},
                ),
            ],
            model_name='claude-sonnet-4-6',
        ),
    ]

    await agent.run('Continue.', message_history=messages)

    assert get_mock_chat_completion_kwargs(mock_client)[0]['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Replay code execution history.'}]},
            {
                'role': 'assistant',
                'content': [
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_bash_list',
                        'name': 'bash_code_execution',
                        'input': {'command': 'echo hello'},
                    },
                    {
                        'type': 'bash_code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_bash_list',
                        'content': [
                            {
                                'return_code': 0,
                                'stderr': '',
                                'stdout': 'hello\n',
                                'type': 'bash_code_execution_result',
                            }
                        ],
                    },
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_text_editor_list',
                        'name': 'text_editor_code_execution',
                        'input': {'command': 'view', 'path': '/tmp/hello.txt'},
                    },
                    {
                        'type': 'text_editor_code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_text_editor_list',
                        'content': [
                            {
                                'content': 'Hello, world!',
                                'file_type': 'text',
                                'num_lines': 1,
                                'start_line': 1,
                                'total_lines': 1,
                                'type': 'text_editor_code_execution_view_result',
                            }
                        ],
                    },
                ],
            },
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Continue.'}]},
        ]
    )


async def test_anthropic_code_execution_tool_message_replay_infers_anthropic_tool_name(
    allow_model_requests: None,
):
    """Infer Anthropic code execution tool variants from legacy names and result content."""
    c = completion_message(
        [BetaTextBlock(text='ok', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(CodeExecutionTool())])

    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='Replay code execution history.')], timestamp=IsDatetime()),
        ModelResponse(
            parts=[
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='text_editor_code_execution',
                    args={'command': 'view', 'path': '/tmp/hello.txt'},
                    tool_call_id='srvtoolu_legacy_text_editor_call',
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content={
                        'content': 'Hello, world!',
                        'file_type': 'text',
                        'num_lines': 1,
                        'start_line': 1,
                        'total_lines': 1,
                        'type': 'text_editor_code_execution_view_result',
                    },
                    tool_call_id='srvtoolu_legacy_text_editor_call',
                ),
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='bash_code_execution',
                    args={'command': 'echo hello'},
                    tool_call_id='srvtoolu_legacy_bash_call',
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content={
                        'content': [],
                        'return_code': 0,
                        'stderr': '',
                        'stdout': 'hello\n',
                        'type': 'bash_code_execution_result',
                    },
                    tool_call_id='srvtoolu_legacy_bash_call',
                    provider_details={'anthropic_tool_name': 'not_a_code_execution_tool'},
                ),
                NativeToolCallPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    args={'code': 'print(2 + 2)'},
                    tool_call_id='srvtoolu_default_code_call',
                    provider_details={'anthropic_tool_name': 123},
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content={
                        'content': [],
                        'return_code': 0,
                        'stderr': '',
                        'stdout': '4\n',
                        'type': 'code_execution_result',
                    },
                    tool_call_id='srvtoolu_default_code_call',
                ),
                NativeToolReturnPart(
                    provider_name=m.system,
                    tool_name='code_execution',
                    content={'content': [], 'return_code': 0, 'stderr': '', 'stdout': '', 'type': 123},
                    tool_call_id='srvtoolu_default_code_call',
                ),
            ],
            model_name='claude-sonnet-4-6',
        ),
    ]

    await agent.run('Continue.', message_history=messages)

    assert get_mock_chat_completion_kwargs(mock_client)[0]['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Replay code execution history.'}]},
            {
                'role': 'assistant',
                'content': [
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_legacy_text_editor_call',
                        'name': 'text_editor_code_execution',
                        'input': {'command': 'view', 'path': '/tmp/hello.txt'},
                    },
                    {
                        'type': 'text_editor_code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_legacy_text_editor_call',
                        'content': {
                            'content': 'Hello, world!',
                            'file_type': 'text',
                            'num_lines': 1,
                            'start_line': 1,
                            'total_lines': 1,
                            'type': 'text_editor_code_execution_view_result',
                        },
                    },
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_legacy_bash_call',
                        'name': 'bash_code_execution',
                        'input': {'command': 'echo hello'},
                    },
                    {
                        'type': 'bash_code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_legacy_bash_call',
                        'content': {
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': 'hello\n',
                            'type': 'bash_code_execution_result',
                        },
                    },
                    {
                        'type': 'server_tool_use',
                        'id': 'srvtoolu_default_code_call',
                        'name': 'code_execution',
                        'input': {'code': 'print(2 + 2)'},
                    },
                    {
                        'type': 'code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_default_code_call',
                        'content': {
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': '4\n',
                            'type': 'code_execution_result',
                        },
                    },
                    {
                        'type': 'code_execution_tool_result',
                        'tool_use_id': 'srvtoolu_default_code_call',
                        'content': {'content': [], 'return_code': 0, 'stderr': '', 'stdout': '', 'type': 123},
                    },
                ],
            },
            {'role': 'user', 'content': [{'type': 'text', 'text': 'Continue.'}]},
        ]
    )


async def test_anthropic_web_search_tool_stream(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    m = anthropic_model('claude-sonnet-4-0', capture=True)
    agent = Agent(m, instructions='You are a helpful assistant.', capabilities=[NativeTool(WebSearchTool())])

    event_parts: list[Any] = []
    async with agent.iter(user_prompt='Give me the top 3 news in the world today.') as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_search',
                    'type': 'web_search_20250305',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'user_location': None,
                }
            ],
            None,
        )
    )
    assert event_parts == snapshot(
        [
            PartStartEvent(
                index=0,
                part=NativeToolCallPart(
                    tool_name='web_search', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY', provider_name='anthropic'
                ),
            ),
            PartDeltaEvent(
                index=0, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY')
            ),
            PartDeltaEvent(
                index=0, delta=ToolCallPartDelta(args_delta='{"q', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY')
            ),
            PartDeltaEvent(
                index=0,
                delta=ToolCallPartDelta(args_delta='uery": "top', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY'),
            ),
            PartDeltaEvent(
                index=0, delta=ToolCallPartDelta(args_delta=' w', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY')
            ),
            PartDeltaEvent(
                index=0, delta=ToolCallPartDelta(args_delta='orld n', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY')
            ),
            PartDeltaEvent(
                index=0, delta=ToolCallPartDelta(args_delta='ew', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY')
            ),
            PartDeltaEvent(
                index=0,
                delta=ToolCallPartDelta(args_delta='s today"}', tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY'),
            ),
            PartEndEvent(
                index=0,
                part=NativeToolCallPart(
                    tool_name='web_search',
                    args='{"query": "top world news today"}',
                    tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY',
                    provider_name='anthropic',
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=1,
                part=NativeToolReturnPart(
                    tool_name='web_search',
                    content=[
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '4 hours ago',
                            'title': 'World news - breaking news, video, headlines and opinion | CNN',
                            'type': 'web_search_result',
                            'url': 'https://www.cnn.com/world',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 hour ago',
                            'title': 'Breaking News, World News and Video from Al Jazeera',
                            'type': 'web_search_result',
                            'url': 'https://www.aljazeera.com/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 hour ago',
                            'title': 'News: U.S. and World News Headlines : NPR',
                            'type': 'web_search_result',
                            'url': 'https://www.npr.org/sections/news/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '7 hours ago',
                            'title': 'NBC News - Breaking News & Top Stories - Latest World, US & Local News | NBC News',
                            'type': 'web_search_result',
                            'url': 'https://www.nbcnews.com/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '3 hours ago',
                            'title': 'Breaking News, Latest News and Videos | CNN',
                            'type': 'web_search_result',
                            'url': 'https://www.cnn.com/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '14 hours ago',
                            'title': "World news: Latest news, breaking news, today's news stories from around the world, updated daily from CBS News",
                            'type': 'web_search_result',
                            'url': 'https://www.cbsnews.com/world/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '4 hours ago',
                            'title': 'International News | Latest World News, Videos & Photos -ABC News - ABC News',
                            'type': 'web_search_result',
                            'url': 'https://abcnews.go.com/International',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 hour ago',
                            'title': 'Google News',
                            'type': 'web_search_result',
                            'url': 'https://news.google.com/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '2 days ago',
                            'title': 'World News Headlines - US News and World Report',
                            'type': 'web_search_result',
                            'url': 'https://www.usnews.com/news/world',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '2 hours ago',
                            'title': 'Fox News - Breaking News Updates | Latest News Headlines | Photos & News Videos',
                            'type': 'web_search_result',
                            'url': 'https://www.foxnews.com/',
                        },
                    ],
                    tool_call_id='srvtoolu_01NcU4XNwyxWK6a9tcJZ8wGY',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=2,
                part=TextPart(content='Let me search for more specific breaking'),
                previous_part_kind='builtin-tool-return',
            ),
            FinalResultEvent(tool_name=None, tool_call_id=None),
            PartDeltaEvent(index=2, delta=TextPartDelta(content_delta=' news stories to get clearer headlines.')),
            PartEndEvent(
                index=2,
                part=TextPart(
                    content='Let me search for more specific breaking news stories to get clearer headlines.'
                ),
                next_part_kind='builtin-tool-call',
            ),
            PartStartEvent(
                index=3,
                part=NativeToolCallPart(
                    tool_name='web_search', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T', provider_name='anthropic'
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=3, delta=ToolCallPartDelta(args_delta='', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T')
            ),
            PartDeltaEvent(
                index=3, delta=ToolCallPartDelta(args_delta='{"query', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T')
            ),
            PartDeltaEvent(
                index=3,
                delta=ToolCallPartDelta(args_delta='": "breaki', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T'),
            ),
            PartDeltaEvent(
                index=3,
                delta=ToolCallPartDelta(args_delta='ng news ', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T'),
            ),
            PartDeltaEvent(
                index=3, delta=ToolCallPartDelta(args_delta='headl', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T')
            ),
            PartDeltaEvent(
                index=3,
                delta=ToolCallPartDelta(args_delta='ines August ', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T'),
            ),
            PartDeltaEvent(
                index=3, delta=ToolCallPartDelta(args_delta='14 2025', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T')
            ),
            PartDeltaEvent(
                index=3, delta=ToolCallPartDelta(args_delta='"}', tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T')
            ),
            PartEndEvent(
                index=3,
                part=NativeToolCallPart(
                    tool_name='web_search',
                    args='{"query": "breaking news headlines August 14 2025"}',
                    tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T',
                    provider_name='anthropic',
                ),
                next_part_kind='builtin-tool-return',
            ),
            PartStartEvent(
                index=4,
                part=NativeToolReturnPart(
                    tool_name='web_search',
                    content=[
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Breaking News, Latest News and Videos | CNN',
                            'type': 'web_search_result',
                            'url': 'https://edition.cnn.com/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'News: U.S. and World News Headlines : NPR',
                            'type': 'web_search_result',
                            'url': 'https://www.npr.org/sections/news/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'ABC News – Breaking News, Latest News and Videos',
                            'type': 'web_search_result',
                            'url': 'https://abcnews.go.com/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '4 hours ago',
                            'title': 'Newspaper headlines: Thursday, August 14, 2025 - Adomonline.com',
                            'type': 'web_search_result',
                            'url': 'https://www.adomonline.com/newspaper-headlines-thursday-august-14-2025/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Global News - Breaking International News And Headlines | Inquirer.net',
                            'type': 'web_search_result',
                            'url': 'https://globalnation.inquirer.net',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'News – The White House',
                            'type': 'web_search_result',
                            'url': 'https://www.whitehouse.gov/news/',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '1 hour ago',
                            'title': 'Latest News: Top News, Breaking News, LIVE News Headlines from India & World | Business Standard',
                            'type': 'web_search_result',
                            'url': 'https://www.business-standard.com/latest-news',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': '10 hours ago',
                            'title': 'Ukraine News Today: Breaking Updates & Live Coverage - August 14, 2025 from Kyiv Post',
                            'type': 'web_search_result',
                            'url': 'https://www.kyivpost.com/thread/58085',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': 'July 14, 2025',
                            'title': '5 things to know for July 14: Immigration, Gaza, Epstein files, Kentucky shooting, Texas flooding | CNN',
                            'type': 'web_search_result',
                            'url': 'https://www.cnn.com/2025/07/14/us/5-things-to-know-for-july-14-immigration-gaza-epstein-files-kentucky-shooting-texas-flooding',
                        },
                        {
                            'encrypted_content': IsStr(),
                            'page_age': None,
                            'title': 'Daily Show for July 14, 2025 | Democracy Now!',
                            'type': 'web_search_result',
                            'url': 'https://www.democracynow.org/shows/2025/7/14',
                        },
                    ],
                    tool_call_id='srvtoolu_01WiP3ZfXZXSykVQEL78XJ4T',
                    timestamp=IsDatetime(),
                    provider_name='anthropic',
                ),
                previous_part_kind='builtin-tool-call',
            ),
            PartStartEvent(index=5, part=TextPart(content='Base'), previous_part_kind='builtin-tool-return'),
            PartDeltaEvent(
                index=5, delta=TextPartDelta(content_delta='d on the search results, I can identify the top')
            ),
            PartDeltaEvent(index=5, delta=TextPartDelta(content_delta=' 3 major news stories from aroun')),
            PartDeltaEvent(
                index=5,
                delta=TextPartDelta(
                    content_delta="""\
d the world today (August 14, 2025):

## Top\
"""
                ),
            ),
            PartDeltaEvent(
                index=5,
                delta=TextPartDelta(
                    content_delta="""\
 3 World News Stories Today

**\
"""
                ),
            ),
            PartDeltaEvent(index=5, delta=TextPartDelta(content_delta='1. Trump-Putin Summit and Ukraine Crisis')),
            PartDeltaEvent(index=5, delta=TextPartDelta(content_delta='**\n')),
            PartEndEvent(
                index=5,
                part=TextPart(
                    content="""\
Based on the search results, I can identify the top 3 major news stories from around the world today (August 14, 2025):

## Top 3 World News Stories Today

**1. Trump-Putin Summit and Ukraine Crisis**
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=6,
                part=TextPart(
                    content='European leaders held a high-stakes meeting Wednesday with President Trump, Vice President Vance, Ukraine'
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=6, delta=TextPartDelta(content_delta="'s Volodymyr Zel")),
            PartDeltaEvent(index=6, delta=TextPartDelta(content_delta="enskyy and NATO's chief ahea")),
            PartDeltaEvent(index=6, delta=TextPartDelta(content_delta="d of Friday's U.S.-")),
            PartDeltaEvent(index=6, delta=TextPartDelta(content_delta='Russia summit')),
            PartEndEvent(
                index=6,
                part=TextPart(
                    content="European leaders held a high-stakes meeting Wednesday with President Trump, Vice President Vance, Ukraine's Volodymyr Zelenskyy and NATO's chief ahead of Friday's U.S.-Russia summit"
                ),
                next_part_kind='text',
            ),
            PartStartEvent(index=7, part=TextPart(content='. '), previous_part_kind='text'),
            PartEndEvent(index=7, part=TextPart(content='. '), next_part_kind='text'),
            PartStartEvent(
                index=8,
                part=TextPart(content='The White House lowered its expectations surrounding'),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=8, delta=TextPartDelta(content_delta=' the Trump-Putin summit on Friday')),
            PartEndEvent(
                index=8,
                part=TextPart(
                    content='The White House lowered its expectations surrounding the Trump-Putin summit on Friday'
                ),
                next_part_kind='text',
            ),
            PartStartEvent(index=9, part=TextPart(content='. '), previous_part_kind='text'),
            PartEndEvent(index=9, part=TextPart(content='. '), next_part_kind='text'),
            PartStartEvent(
                index=10,
                part=TextPart(content='In a surprise move just days before the Trump-Putin summit'),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=10, delta=TextPartDelta(content_delta=', the White House swapped out pro')),
            PartDeltaEvent(index=10, delta=TextPartDelta(content_delta="-EU PM Tusk for Poland's new president –")),
            PartDeltaEvent(index=10, delta=TextPartDelta(content_delta=" a political ally who once opposed Ukraine's")),
            PartDeltaEvent(index=10, delta=TextPartDelta(content_delta=' NATO and EU bids')),
            PartEndEvent(
                index=10,
                part=TextPart(
                    content="In a surprise move just days before the Trump-Putin summit, the White House swapped out pro-EU PM Tusk for Poland's new president – a political ally who once opposed Ukraine's NATO and EU bids"
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=11,
                part=TextPart(
                    content="""\
.

**2. Trump's Federal Takeover of Washington D\
"""
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=11, delta=TextPartDelta(content_delta='.C.**')),
            PartDeltaEvent(index=11, delta=TextPartDelta(content_delta='\n')),
            PartEndEvent(
                index=11,
                part=TextPart(
                    content="""\
.

**2. Trump's Federal Takeover of Washington D.C.**
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=12,
                part=TextPart(
                    content="Federal law enforcement's presence in Washington, DC, continued to be felt Wednesday as President Donald Trump's tak"
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=12, delta=TextPartDelta(content_delta="eover of the city's police entered its thir")),
            PartDeltaEvent(index=12, delta=TextPartDelta(content_delta='d night')),
            PartEndEvent(
                index=12,
                part=TextPart(
                    content="Federal law enforcement's presence in Washington, DC, continued to be felt Wednesday as President Donald Trump's takeover of the city's police entered its third night"
                ),
                next_part_kind='text',
            ),
            PartStartEvent(index=13, part=TextPart(content='. '), previous_part_kind='text'),
            PartEndEvent(index=13, part=TextPart(content='. '), next_part_kind='text'),
            PartStartEvent(
                index=14,
                part=TextPart(
                    content="National Guard troops arrived in Washington, D.C., following President Trump's deployment an"
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=14, delta=TextPartDelta(content_delta='d federalization of local police to crack down on crime')
            ),
            PartDeltaEvent(index=14, delta=TextPartDelta(content_delta=" in the nation's capital")),
            PartEndEvent(
                index=14,
                part=TextPart(
                    content="National Guard troops arrived in Washington, D.C., following President Trump's deployment and federalization of local police to crack down on crime in the nation's capital"
                ),
                next_part_kind='text',
            ),
            PartStartEvent(index=15, part=TextPart(content='. '), previous_part_kind='text'),
            PartEndEvent(index=15, part=TextPart(content='. '), next_part_kind='text'),
            PartStartEvent(
                index=16,
                part=TextPart(content='Over 100 arrests made as National Guard rolls into DC under'),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=16, delta=TextPartDelta(content_delta=" Trump's federal takeover")),
            PartEndEvent(
                index=16,
                part=TextPart(
                    content="Over 100 arrests made as National Guard rolls into DC under Trump's federal takeover"
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=17,
                part=TextPart(
                    content="""\
.

**3. Air\
"""
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=17, delta=TextPartDelta(content_delta=' Canada Flight Disruption')),
            PartDeltaEvent(index=17, delta=TextPartDelta(content_delta='**\n')),
            PartEndEvent(
                index=17,
                part=TextPart(
                    content="""\
.

**3. Air Canada Flight Disruption**
"""
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=18,
                part=TextPart(
                    content='Air Canada plans to lock out its flight attendants and cancel all flights starting this weekend'
                ),
                previous_part_kind='text',
            ),
            PartEndEvent(
                index=18,
                part=TextPart(
                    content='Air Canada plans to lock out its flight attendants and cancel all flights starting this weekend'
                ),
                next_part_kind='text',
            ),
            PartStartEvent(index=19, part=TextPart(content='. '), previous_part_kind='text'),
            PartEndEvent(index=19, part=TextPart(content='. '), next_part_kind='text'),
            PartStartEvent(
                index=20,
                part=TextPart(
                    content='Air Canada says it will begin cancelling flights starting Thursday to allow an orderly shutdown of operations'
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(
                index=20,
                delta=TextPartDelta(
                    content_delta=" with a complete cessation of flights for the country's largest airline by"
                ),
            ),
            PartDeltaEvent(
                index=20, delta=TextPartDelta(content_delta=' Saturday as it faces a potential work stoppage by')
            ),
            PartDeltaEvent(index=20, delta=TextPartDelta(content_delta=' its flight attendants')),
            PartEndEvent(
                index=20,
                part=TextPart(
                    content="Air Canada says it will begin cancelling flights starting Thursday to allow an orderly shutdown of operations with a complete cessation of flights for the country's largest airline by Saturday as it faces a potential work stoppage by its flight attendants"
                ),
                next_part_kind='text',
            ),
            PartStartEvent(
                index=21,
                part=TextPart(
                    content="""\
.

These stories represent major international diplomatic developments, significant domestic policy\
"""
                ),
                previous_part_kind='text',
            ),
            PartDeltaEvent(index=21, delta=TextPartDelta(content_delta=' changes in the US, and major transportation')),
            PartDeltaEvent(index=21, delta=TextPartDelta(content_delta=' disruptions affecting North America.')),
            PartEndEvent(
                index=21,
                part=TextPart(
                    content="""\
.

These stories represent major international diplomatic developments, significant domestic policy changes in the US, and major transportation disruptions affecting North America.\
"""
                ),
            ),
        ]
    )


async def test_anthropic_text_parts_ahead_of_built_in_tool_call(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    # Verify that text parts ahead of the built-in tool call are not included in the output

    model = anthropic_model('claude-sonnet-4-5', capture=True)
    agent = Agent(model, capabilities=[NativeTool(WebSearchTool())], instructions='Be very concise.')

    result = await agent.run('Briefly mention 1 event that happened today in history?')
    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_search',
                    'type': 'web_search_20250305',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'user_location': None,
                }
            ],
            None,
        )
    )
    assert result.output == snapshot("""\
Here's one significant historical event that occurred on September 17:

In 1939, Finnish runner Taisto Mäki made history by becoming the first person to run 10,000 meters in less than 30 minutes, completing the distance in 29 minutes and 52 seconds.\
""")

    async with agent.run_stream('Briefly mention 1 event that happened tomorrow in history?') as result:
        chunks = [c async for c in result.stream_output(debounce_by=None)]
        assert chunks == snapshot(
            [
                'Let',
                'Let me search for a significant',
                'Let me search for a significant historical event that occurred on',
                'Let me search for a significant historical event that occurred on September 18th.',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                'Here',
                "Here's one notable historical event that occurred on September",
                "Here's one notable historical event that occurred on September 18th: ",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marke",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building in Washington DC, and he",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building in Washington DC, and he would return periodically to oversee its",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building in Washington DC, and he would return periodically to oversee its construction personally",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building in Washington DC, and he would return periodically to oversee its construction personally.",
                "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building in Washington DC, and he would return periodically to oversee its construction personally.",
            ]
        )

    assert await result.get_output() == snapshot(
        "Here's one notable historical event that occurred on September 18th: On September 18, 1793, President George Washington marked the location for the Capitol Building in Washington DC, and he would return periodically to oversee its construction personally."
    )

    async with agent.run_stream('Briefly mention 1 event that happened yesterday in history?') as result:
        chunks = [c async for c in result.stream_text(debounce_by=None)]
        assert chunks == snapshot(
            [
                'Let',
                'Let me search for a historical',
                'Let me search for a historical event that occurred on September',
                "Let me search for a historical event that occurred on September 16th (yesterday's date since",
                "Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17,",
                "Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025",
                "Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Base\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), \
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, \
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts of New Zealand, an\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts of New Zealand, and a notable court case involving\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts of New Zealand, and a notable court case involving a British aristoc\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts of New Zealand, and a notable court case involving a British aristocrat\
""",
                """\
Let me search for a historical event that occurred on September 16th (yesterday's date since today is September 17, 2025).

Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts of New Zealand, and a notable court case involving a British aristocrat.\
""",
            ]
        )

    assert await result.get_output() == snapshot(
        "Based on yesterday's date (September 16, 2025), Asian markets rose higher as Federal Reserve rate cut hopes lifted global market sentiment. Additionally, there were severe rain and gales impacting parts of New Zealand, and a notable court case involving a British aristocrat."
    )

    async with agent.run_stream(
        'Briefly mention 1 event that happened the day after tomorrow in history?'
    ) as result:  # pragma: lax no cover
        chunks = [c async for c in result.stream_text(debounce_by=None, delta=True)]  # pragma: lax no cover
        assert chunks == snapshot(
            [
                'Let',
                ' me search for historical',
                ' events that occurred on',
                ' September 19th.',
                """\


""",
                'Here',
                "'s one significant historical event that occurred on September",
                ' 19th: ',
                'New Zealand made history by becoming the first self-governing nation to grant women the right',
                ' to vote in national elections. It',
                ' would take 27 more',
                ' years before American women gained the',
                ' same right.',
            ]
        )

    assert await result.get_output() == snapshot(
        "Here's one significant historical event that occurred on September 19th: New Zealand made history by becoming the first self-governing nation to grant women the right to vote in national elections. It would take 27 more years before American women gained the same right."
    )


async def test_anthropic_memory_tool(
    allow_model_requests: None, anthropic_api_key: str, request_capture: RequestCapture
):
    anthropic_model = AnthropicModel(
        'claude-sonnet-4-5',
        provider=AnthropicProvider(api_key=anthropic_api_key, http_client=request_capture.client),
        settings=AnthropicModelSettings(extra_headers={'anthropic-beta': 'context-1m-2025-08-07'}),
    )
    agent = Agent(anthropic_model, capabilities=[NativeTool(MemoryTool())])

    with pytest.raises(UserError, match=re.escape("Native `MemoryTool` requires a 'memory' tool to be defined.")):
        await agent.run('Where do I live?')

    class FakeMemoryTool(BetaAbstractMemoryTool):
        def view(self, command: BetaMemoryTool20250818ViewCommand) -> str:
            return 'The user lives in Mexico City.'

        def create(self, command: BetaMemoryTool20250818CreateCommand) -> str:
            return f'File created successfully at {command.path}'  # pragma: no cover

        def str_replace(self, command: BetaMemoryTool20250818StrReplaceCommand) -> str:
            return f'File {command.path} has been edited'  # pragma: no cover

        def insert(self, command: BetaMemoryTool20250818InsertCommand) -> str:
            return f'Text inserted at line {command.insert_line} in {command.path}'  # pragma: no cover

        def delete(self, command: BetaMemoryTool20250818DeleteCommand) -> str:
            return f'File deleted: {command.path}'  # pragma: no cover

        def rename(self, command: BetaMemoryTool20250818RenameCommand) -> str:
            return f'Renamed {command.old_path} to {command.new_path}'  # pragma: no cover

        def clear_all_memory(self) -> str:
            return 'All memory cleared'  # pragma: no cover

    fake_memory = FakeMemoryTool()

    @agent.tool_plain
    def memory(**command: Any) -> Any:
        return fake_memory.call(command)

    result = await agent.run('Where do I live?')
    assert content_blocks(request_capture.body(), 'tool_result') == snapshot([])
    assert result.output == snapshot("""\


According to my memory, you live in **Mexico City**.\
""")


def test_hidden_memory_function_tool_is_not_restored_as_native() -> None:
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(api_key='not-used'))
    params = ModelRequestParameters(
        function_tools=[ToolDefinition(name='memory', defer_loading=True)],
        native_tools=[MemoryTool()],
        tool_visibility={'memory': 'withheld'},
    )
    with pytest.raises(UserError, match="requires a 'memory' tool to be defined"):
        model._add_native_tools([], params, AnthropicModelSettings())  # pyright: ignore[reportPrivateUsage]


async def test_anthropic_model_usage_limit_exceeded(
    allow_model_requests: None,
    anthropic_api_key: str,
):
    model = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(model=model)

    with pytest.raises(
        UsageLimitExceeded,
        match='The next request would exceed the input_tokens_limit of 18 \\(input_tokens=19\\)',
    ):
        await agent.run(
            'The quick brown fox jumps over the lazydog.',
            usage_limits=UsageLimits(input_tokens_limit=18, count_tokens_before_request=True),
        )


async def test_anthropic_model_usage_limit_not_exceeded(
    allow_model_requests: None,
    anthropic_api_key: str,
):
    model = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(model=model)

    result = await agent.run(
        'The quick brown fox jumps over the lazydog.',
        usage_limits=UsageLimits(input_tokens_limit=25, count_tokens_before_request=True),
    )
    assert result.output == snapshot(
        """\
I noticed a small typo in that famous pangram! It should be:

"The quick brown fox jumps over the **lazy dog**."

(There should be a space between "lazy" and "dog")

This sentence is often used for testing typewriters, fonts, and keyboards because it contains every letter of the English alphabet at least once.\
"""
    )


async def test_anthropic_count_tokens_with_mock(allow_model_requests: None):
    """Test that count_tokens is called on the mock client."""
    c = completion_message(
        [BetaTextBlock(text='hello world', type='text')], BetaUsage(input_tokens=5, output_tokens=10)
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('hello', usage_limits=UsageLimits(input_tokens_limit=20, count_tokens_before_request=True))
    assert result.output == 'hello world'
    assert len(mock_client.chat_completion_kwargs) == 2  # pyright: ignore[reportAttributeAccessIssue, reportUnknownArgumentType, reportUnknownMemberType]
    count_tokens_kwargs = mock_client.chat_completion_kwargs[0]  # pyright: ignore[reportAttributeAccessIssue, reportUnknownMemberType, reportUnknownVariableType]
    assert 'model' in count_tokens_kwargs
    assert 'messages' in count_tokens_kwargs


async def test_anthropic_count_tokens_blocks_requests_when_disabled():
    mock_client = cast(AsyncAnthropic, MockAnthropic())
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    with pytest.raises(RuntimeError, match='Model requests are not allowed'):
        await m.count_tokens([ModelRequest.user_text_prompt('hello')], None, ModelRequestParameters())


async def test_anthropic_count_tokens_enforces_cost_limit(allow_model_requests: None):
    """`cost_limit` is enforced before the request using the cost of the counted input tokens.

    Uses the count_tokens mock so the pre-request cost accumulation in the agent graph runs against a model
    genai-prices can actually price (unlike TestModel), without needing a recorded request.
    """
    c = completion_message(
        [BetaTextBlock(text='hello world', type='text')], BetaUsage(input_tokens=5, output_tokens=10)
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # count_tokens reports 10 input tokens, which price above this tiny limit, so the request is blocked up front.
    with pytest.raises(UsageLimitExceeded, match=r'The next request would exceed the `cost_limit` of 0\.000001'):
        await agent.run(
            'hello',
            usage_limits=UsageLimits(cost_limit=Decimal('0.000001'), count_tokens_before_request=True),
        )


async def test_anthropic_count_tokens_with_no_messages(allow_model_requests: None):
    """Test count_tokens when messages_ is None (no exception configured)."""
    mock_client = cast(AsyncAnthropic, MockAnthropic())
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    result = await m.count_tokens(
        [ModelRequest.user_text_prompt('hello')],
        None,
        ModelRequestParameters(),
    )

    assert result.input_tokens == 10


async def test_anthropic_count_tokens_omits_native_tools(allow_model_requests: None):
    c = completion_message(
        [BetaTextBlock(text='hello world', type='text')], BetaUsage(input_tokens=5, output_tokens=10)
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m,
        capabilities=[NativeTool(CodeExecutionTool()), NativeTool(WebFetchTool()), NativeTool(MemoryTool())],
    )

    @agent.tool_plain
    def lookup() -> str:  # pragma: no cover
        return 'lookup result'

    @agent.tool_plain
    def memory(**command: Any) -> Any:  # pragma: no cover
        return 'memory response'

    result = await agent.run('hello', usage_limits=UsageLimits(input_tokens_limit=20, count_tokens_before_request=True))

    assert result.output == 'hello world'
    count_tokens_kwargs, create_kwargs = get_mock_chat_completion_kwargs(mock_client)
    # Server-side tools (`code_execution`, `web_fetch`) are dropped from the `count_tokens` payload, but the
    # client-side `MemoryTool` is kept so the count includes its definition (and beta).
    assert count_tokens_kwargs['tools'] == [
        {
            'name': 'lookup',
            'description': '',
            'input_schema': {'additionalProperties': False, 'properties': {}, 'type': 'object'},
        },
        {'name': 'memory', 'type': 'memory_20250818'},
    ]
    assert count_tokens_kwargs['mcp_servers'] is OMIT
    assert count_tokens_kwargs['betas'] == ['context-management-2025-06-27']
    assert {tool['name'] for tool in create_kwargs['tools']} == {'lookup', 'code_execution', 'web_fetch', 'memory'}
    assert {tool['name']: tool['type'] for tool in create_kwargs['tools'] if 'type' in tool} == {
        'code_execution': 'code_execution_20260120',
        'web_fetch': 'web_fetch_20260209',
        'memory': 'memory_20250818',
    }
    assert create_kwargs['betas'] == ['context-management-2025-06-27']


async def test_anthropic_count_tokens_preserves_tool_search_replay(allow_model_requests: None):
    """`count_tokens` renders a tool-search replay turn with the same `tool_reference` wire shape
    as the real `/v1/messages` request, while still omitting the server-side `tool_search_tool_*`
    entry that the endpoint rejects.

    The count path strips server tools from the params it maps messages with, and both paths read
    the deferred function tools to decide whether a `tool_reference` reveal is legal. Dropping a
    deferred tool from either would silently re-serialize the history turn as plain text and diverge
    from the real request. A VCR test wouldn't catch this — the cassette matcher isn't sensitive to
    the `messages` body.

    Regression test for https://github.com/pydantic/pydantic-ai/issues/5780
    """
    c = completion_message([BetaTextBlock(text='done', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    params = ModelRequestParameters(
        function_tools=[
            ToolDefinition(
                name='get_exchange_rate',
                description='',
                parameters_json_schema={'type': 'object'},
                defer_loading=True,
                with_native=ToolSearchTool.kind,
            )
        ],
        native_tools=[ToolSearchTool()],
    )
    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='What is the USD to EUR rate?')]),
        ModelResponse(parts=[ToolSearchCallPart(args={'queries': ['exchange rate']}, tool_call_id='search-1')]),
        ModelRequest(
            parts=[
                ToolSearchReturnPart(
                    content={
                        'discovered_tools': [{'name': 'get_exchange_rate'}],
                        'message': 'Found 1 tool',
                    },
                    tool_call_id='search-1',
                )
            ]
        ),
    ]

    await m.count_tokens(messages, None, params)
    await m.request(messages, None, params)

    count_tokens_kwargs, create_kwargs = get_mock_chat_completion_kwargs(mock_client)

    # The tool-search replay turn renders identically on both paths: a `tool_result` whose content
    # is a `tool_reference` array pointing at the discovered function tool.
    assert count_tokens_kwargs['messages'] == create_kwargs['messages']
    assert count_tokens_kwargs['messages'][-1]['content'][0] == snapshot(
        {
            'tool_use_id': 'search-1',
            'type': 'tool_result',
            'content': [{'tool_name': 'get_exchange_rate', 'type': 'tool_reference'}],
            'is_error': False,
        }
    )

    # The server-side `tool_search_tool_*` entry is rejected by `count_tokens`, so it's omitted there
    # but present on the real request.
    assert not any(str(tool.get('type', '')).startswith('tool_search_tool_') for tool in count_tokens_kwargs['tools'])
    assert any(str(tool.get('type', '')).startswith('tool_search_tool_') for tool in create_kwargs['tools'])


async def test_anthropic_count_tokens_keeps_defer_loading(allow_model_requests: None):
    """`count_tokens` marks a deferred tool `defer_loading` exactly as the real request does.

    The count path strips server tools from the params it builds the wire `tools` list from, and
    `defer_loading` is gated on `ToolSearchTool` being present — so counting used to describe a
    request we never send, with every deferred tool's full schema exposed. That isn't cosmetic: the
    endpoint honors the flag rather than ignoring it, and a deferred tool whose schema stays hidden
    counts as its name and description alone. Measured live on `claude-opus-4-8` with one 30-field
    tool: 440 tokens with the flag, 1761 without.

    The server-side `tool_search_tool_*` entry, the one thing `count_tokens` really does reject,
    still has to be absent — so this pins both halves against each other.
    """
    c = completion_message([BetaTextBlock(text='done', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))

    params = ModelRequestParameters(
        function_tools=[
            ToolDefinition(
                name='get_exchange_rate',
                description='Look up an exchange rate.',
                parameters_json_schema={'type': 'object'},
                defer_loading=True,
                with_native=ToolSearchTool.kind,
            )
        ],
        native_tools=[ToolSearchTool()],
    )
    messages: list[ModelMessage] = [ModelRequest(parts=[UserPromptPart(content='What is the USD to EUR rate?')])]

    await m.count_tokens(messages, None, params)
    await m.request(messages, None, params)

    count_tokens_kwargs, create_kwargs = get_mock_chat_completion_kwargs(mock_client)

    def deferred_tool(kwargs: dict[str, Any]) -> dict[str, Any]:
        [tool] = [tool for tool in kwargs['tools'] if tool.get('name') == 'get_exchange_rate']
        return tool

    assert deferred_tool(count_tokens_kwargs) == deferred_tool(create_kwargs)
    assert deferred_tool(count_tokens_kwargs)['defer_loading'] is True

    assert not any(str(tool.get('type', '')).startswith('tool_search_tool_') for tool in count_tokens_kwargs['tools'])
    assert any(str(tool.get('type', '')).startswith('tool_search_tool_') for tool in create_kwargs['tools'])


@pytest.mark.parametrize('capabilities', [None, [ToolSearch()]])
async def test_anthropic_bare_tool_search_is_stripped_for_capability_only_corpus(
    allow_model_requests: None, capabilities: list[ToolSearch[None]] | None
):
    """A bare explicit `ToolSearch()` is semantically identical to the auto-injected capability."""
    response = completion_message(
        [BetaTextBlock(text='Done.', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        capabilities=[refunds, *(capabilities or [])],
    )
    await agent.run('Hello')

    [request] = get_mock_chat_completion_kwargs(mock_client)
    assert not any(tool.get('name') == 'search_tools' for tool in request['tools'])


async def test_anthropic_keyword_tool_search_is_stripped_for_capability_only_corpus(allow_model_requests: None):
    """An explicit keyword strategy has no useful search surface for a capability-only corpus."""
    response = completion_message(
        [BetaTextBlock(text='Done.', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        capabilities=[refunds, ToolSearch(strategy='keywords')],
    )
    await agent.run('Hello')

    [request] = get_mock_chat_completion_kwargs(mock_client)
    assert not any(tool.get('name') == 'search_tools' for tool in request['tools'])


async def test_anthropic_named_native_tool_search_withholds_capability_tool(allow_model_requests: None):
    """A named native strategy stays native while a hidden capability tool stays off the wire."""
    response = completion_message(
        [BetaTextBlock(text='Done.', type='text')],
        BetaUsage(input_tokens=5, output_tokens=10),
    )
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    def searchable_tool(query: str) -> str:  # pragma: no cover
        return query

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        tools=[Tool(searchable_tool, defer_loading=True)],
        capabilities=[refunds, ToolSearch(strategy='regex')],
    )
    await agent.run('Hello')

    [request] = get_mock_chat_completion_kwargs(mock_client)
    assert any(tool.get('type') == 'tool_search_tool_regex_20251119' for tool in request['tools'])
    assert any(tool.get('name') == 'searchable_tool' for tool in request['tools'])
    assert not any(tool.get('name') == 'lookup_refund_policy' for tool in request['tools'])


async def test_anthropic_callable_tool_search_is_stripped_for_capability_only_corpus(
    allow_model_requests: None,
):
    """Nothing is searchable, so no search surface is offered — local or native.

    A capability-gated tool becomes available by loading its capability, never by querying for it,
    so an explicitly configured callable strategy has nothing to index. Neither the local
    `search_tools` function nor the native `tool_search` tool goes on the wire, and the callable is
    never invoked: a search that could only ever answer "no matches" would cost a tool slot and
    cache-prefix bytes on every turn. The tool still arrives — `defer_loading` and the
    `tool_reference` reveal do that on their own, without a search surface.
    """
    responses = [
        completion_message(
            [BetaToolUseBlock(id='load-1', input={'id': 'refunds'}, name='load_capability', type='tool_use')],
            BetaUsage(input_tokens=5, output_tokens=10),
        ),
        completion_message(
            [BetaTextBlock(text='Done.', type='text')],
            BetaUsage(input_tokens=5, output_tokens=10),
        ),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    calls: list[tuple[Sequence[str], Sequence[str]]] = []

    def search(ctx: RunContext[None], queries: Sequence[str], tools: Sequence[ToolDefinition]) -> list[str]:
        calls.append((queries, [tool.name for tool in tools]))  # pragma: no cover
        return ['lookup_refund_policy']  # pragma: no cover

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        capabilities=[refunds, ToolSearch(strategy=search)],
    )
    result = await agent.run('Find the refund tool.')

    assert result.output == 'Done.'
    assert calls == []
    requests = get_mock_chat_completion_kwargs(mock_client)
    for request in requests:
        assert [tool.get('name') or tool.get('type') for tool in request['tools']] == snapshot(
            ['load_capability', 'lookup_refund_policy']
        )
    # The gated tool is declared from the first turn with its schema withheld, so `tools` is
    # byte-identical across the reveal and the cached prefix survives it.
    assert all(
        tool.get('defer_loading') is True
        for request in requests
        for tool in request['tools']
        if tool.get('name') == 'lookup_refund_policy'
    )


async def test_anthropic_lazy_advertisement_appends_with_tool_addition(allow_model_requests: None):
    """A delta-tier mixed run appends the revealed deferred entry and references it in the same request."""
    responses = [
        completion_message(
            [BetaToolUseBlock(id='load-1', input={'id': 'refunds'}, name='load_capability', type='tool_use')],
            BetaUsage(input_tokens=5, output_tokens=10),
        ),
        completion_message(
            [
                BetaToolUseBlock(
                    id='refund-1',
                    input={'order_id': 'A-4417'},
                    name='lookup_refund_policy',
                    type='tool_use',
                )
            ],
            BetaUsage(input_tokens=5, output_tokens=10),
        ),
        completion_message([BetaTextBlock(text='Done.', type='text')], BetaUsage(input_tokens=5, output_tokens=10)),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    model = AnthropicModel('claude-opus-4-8', provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:
        return f'{order_id}: refund allowed'

    def searchable_tool(query: str) -> str:  # pragma: no cover
        return query

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        tools=[Tool(searchable_tool, defer_loading=True)],
        capabilities=[refunds, ToolSearch()],
    )
    result = await agent.run('Load refunds and look up order A-4417.')

    before, after, final = get_mock_chat_completion_kwargs(mock_client)
    before_names = [tool.get('name') for tool in before['tools']]
    after_names = [tool.get('name') for tool in after['tools']]
    assert {key: value for key, value in before.items() if key not in ('tools', 'messages', 'betas')} == {
        key: value for key, value in after.items() if key not in ('tools', 'messages', 'betas')
    }
    assert before['betas'] is OMIT
    assert 'mid-conversation-tool-changes-2026-07-01' in after['betas']
    assert 'lookup_refund_policy' not in before_names
    assert after_names == [*before_names, 'lookup_refund_policy']
    [revealed] = [tool for tool in after['tools'] if tool.get('name') == 'lookup_refund_policy']
    assert revealed['defer_loading'] is True
    addition_names = [
        block['tool']['name']
        for message in after['messages']
        for block in message['content']
        if block.get('type') == 'tool_addition'
    ]
    # List equality: a same-request duplicate `tool_addition` must fail here, not only in the
    # dedupe unit test.
    assert addition_names == ['lookup_refund_policy']
    assert set(addition_names) <= set(after_names)
    assert [tool.get('name') for tool in final['tools']] == after_names
    assert any(
        part.tool_name == 'lookup_refund_policy'
        for part in iter_message_parts(result.all_messages(), ModelRequest, ToolReturnPart)
    )
    # Full-byte prefix property, not just names: every pre-existing declaration must serialize
    # identically across the reveal, the reveal may only append, and the request after the reveal
    # must repeat the grown list byte-for-byte. A mutated or reordered entry would pass the name
    # checks above, and — sitting in the deferred tail — would also escape the cassette
    # cache-prefix model, so the bytes are asserted here in full.
    assert json.dumps(after['tools'][: len(before['tools'])]) == json.dumps(before['tools'])
    assert json.dumps(final['tools']) == json.dumps(after['tools'])
    assert json.dumps(after['system']) == json.dumps(before['system'])
    assert json.dumps(after['messages'][: len(before['messages'])]) == json.dumps(before['messages'])
    assert json.dumps(final['messages'][: len(after['messages'])]) == json.dumps(after['messages'])


@pytest.mark.vcr()
async def test_anthropic_lazy_advertisement_live(
    allow_model_requests: None,
    anthropic_model: AnthropicModelFactory,
    request_capture: RequestCapture,
    vcr: Any,
):
    """A real mixed run appends and calls a capability tool on the first reveal request.

    The cassette serializer strips `anthropic-*` headers, so the request hook pins beta gating
    against the actual generated wire while the recorded bodies pin tools and `tool_addition`.
    """
    model = anthropic_model('claude-opus-4-8', capture=True)
    refunds = Capability[None](
        id='refunds',
        description='Refund policy tools. Load this capability before looking up refund policy.',
        defer_loading=True,
    )

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:
        return f'{order_id}: refund allowed'

    def searchable_tool(query: str) -> str:  # pragma: no cover
        return query

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        tools=[Tool(searchable_tool, defer_loading=True)],
        capabilities=[refunds, ToolSearch()],
    )
    result = await agent.run(
        'First load the refunds capability. Then call lookup_refund_policy for order A-4417. '
        'Return only the tool result.'
    )

    # Read off the wire, not `vcr.requests`: the cassette is frozen and matched without reference to
    # the body, so tool/`tool_addition` claims asserted against it survive the code drifting away.
    request_bodies = request_capture.bodies()
    assert len(request_bodies) >= 3
    before, reveal, *later = request_bodies
    before_tools = before['tools']
    reveal_tools = reveal['tools']
    before_names = [tool.get('name') for tool in before_tools]
    reveal_names = [tool.get('name') for tool in reveal_tools]
    assert 'lookup_refund_policy' not in before_names
    assert reveal_tools[:-1] == before_tools
    assert reveal_names == [*before_names, 'lookup_refund_policy']
    assert reveal_tools[-1]['defer_loading'] is True
    addition_names = [
        block['tool']['name']
        for message in reveal['messages']
        for block in message['content']
        if block.get('type') == 'tool_addition'
    ]
    # List equality: a same-request duplicate `tool_addition` must fail here, not only in the
    # dedupe unit test.
    assert addition_names == ['lookup_refund_policy']
    assert set(addition_names) <= set(reveal_names)
    assert all(request_body['tools'] == reveal_tools for request_body in later)

    beta_headers = [h.get('anthropic-beta', '') for h in request_capture.headers]
    beta = 'mid-conversation-tool-changes-2026-07-01'
    assert beta not in beta_headers[0]
    assert all(beta in header for header in beta_headers[1:])
    assert any(
        part.tool_name == 'lookup_refund_policy'
        for part in iter_message_parts(result.all_messages(), ModelRequest, ToolReturnPart)
    )


@pytest.mark.vcr()
async def test_anthropic_fable_5_lazy_advertisement_live(
    allow_model_requests: None,
    anthropic_model: AnthropicModelFactory,
    request_capture: RequestCapture,
    vcr: Any,
):
    """Fable 5 accepts a same-request deferred definition and `tool_addition` reveal."""
    model = anthropic_model('claude-fable-5', capture=True)
    refunds = Capability[None](
        id='refunds',
        description='Refund policy tools. Load this capability before looking up refund policy.',
        defer_loading=True,
    )

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:
        return f'{order_id}: refund allowed'

    def searchable_tool(query: str) -> str:  # pragma: no cover
        return query

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        tools=[Tool(searchable_tool, defer_loading=True)],
        capabilities=[refunds, ToolSearch()],
    )
    result = await agent.run(
        'First load the refunds capability. Then call lookup_refund_policy for order A-4417. '
        'Return only the tool result.'
    )

    # Read off the wire, not `vcr.requests`: the cassette is frozen and matched without reference to
    # the body, so tool/`tool_addition` claims asserted against it survive the code drifting away.
    request_bodies = request_capture.bodies()
    assert len(request_bodies) >= 3
    before, reveal, *later = request_bodies
    before_tools = before['tools']
    reveal_tools = reveal['tools']
    before_names = [tool.get('name') for tool in before_tools]
    reveal_names = [tool.get('name') for tool in reveal_tools]
    assert 'lookup_refund_policy' not in before_names
    assert reveal_tools[:-1] == before_tools
    assert reveal_names == [*before_names, 'lookup_refund_policy']
    assert reveal_tools[-1]['defer_loading'] is True
    addition_names = [
        block['tool']['name']
        for message in reveal['messages']
        for block in message['content']
        if block.get('type') == 'tool_addition'
    ]
    # List equality: a same-request duplicate `tool_addition` must fail here, not only in the
    # dedupe unit test.
    assert addition_names == ['lookup_refund_policy']
    assert set(addition_names) <= set(reveal_names)
    assert all(request_body['tools'] == reveal_tools for request_body in later)

    beta_headers = [h.get('anthropic-beta', '') for h in request_capture.headers]
    beta = 'mid-conversation-tool-changes-2026-07-01'
    assert beta not in beta_headers[0]
    assert all(beta in header for header in beta_headers[1:])
    assert any(
        part.tool_name == 'lookup_refund_policy'
        for part in iter_message_parts(result.all_messages(), ModelRequest, ToolReturnPart)
    )


async def test_anthropic_standalone_lazy_advertisement_synthesizes_reveal(allow_model_requests: None):
    """A sub-delta Anthropic tier appends one deferred entry with the synthesized search exchange."""
    responses = [
        completion_message(
            [BetaToolUseBlock(id='load-1', input={'id': 'refunds'}, name='load_capability', type='tool_use')],
            BetaUsage(input_tokens=5, output_tokens=10),
        ),
        completion_message([BetaTextBlock(text='Done.', type='text')], BetaUsage(input_tokens=5, output_tokens=10)),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    def searchable_tool(query: str) -> str:  # pragma: no cover
        return query

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        tools=[Tool(searchable_tool, defer_loading=True)],
        capabilities=[refunds, ToolSearch()],
    )
    await agent.run('Load refunds.')

    before, after = get_mock_chat_completion_kwargs(mock_client)
    before_names = [tool.get('name') for tool in before['tools']]
    after_names = [tool.get('name') for tool in after['tools']]
    assert {key: value for key, value in before.items() if key not in ('tools', 'messages')} == {
        key: value for key, value in after.items() if key not in ('tools', 'messages')
    }
    assert 'lookup_refund_policy' not in before_names
    assert after_names == [*before_names, 'lookup_refund_policy']
    [revealed] = [tool for tool in after['tools'] if tool.get('name') == 'lookup_refund_policy']
    assert revealed['defer_loading'] is True
    assert not any(
        block.get('type') == 'tool_addition' for message in after['messages'] for block in message['content']
    )
    assert any(
        block.get('type') == 'tool_result'
        and any(item.get('type') == 'tool_reference' for item in block.get('content', []))
        for message in after['messages']
        for block in message['content']
    )


async def test_anthropic_rejects_all_deferred_tools_before_request(allow_model_requests: None):
    """The adapter explains Anthropic's all-deferred `tools` constraint before making an API call."""
    mock_client = MockAnthropic.create_mock(
        completion_message([BetaTextBlock(text='unused', type='text')], BetaUsage(input_tokens=1, output_tokens=1))
    )
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    params = ModelRequestParameters(
        function_tools=[
            ToolDefinition(
                name='only_tool',
                parameters_json_schema={'type': 'object'},
                defer_loading=True,
            )
        ],
        tool_visibility={'only_tool': 'deferred'},
    )
    with pytest.raises(UserError, match=r'Make at least one tool visible.*tool-search surface or capability catalog'):
        await model.request([ModelRequest(parts=[UserPromptPart(content='Hi')])], None, params)
    assert get_mock_chat_completion_kwargs(mock_client) == []


async def test_anthropic_lazy_advertisement_uses_reveal_order(allow_model_requests: None):
    """Lazily appended definitions follow first-reveal order, not registration order."""
    mock_client = MockAnthropic.create_mock(
        completion_message([BetaTextBlock(text='Done.', type='text')], BetaUsage(input_tokens=1, output_tokens=1))
    )
    model = AnthropicModel('claude-opus-4-8', provider=AnthropicProvider(anthropic_client=mock_client))
    params = ModelRequestParameters(
        function_tools=[
            ToolDefinition(name='always_ready', parameters_json_schema={'type': 'object'}),
            ToolDefinition(name='alpha', parameters_json_schema={'type': 'object'}, defer_loading=True),
            ToolDefinition(name='beta', parameters_json_schema={'type': 'object'}, defer_loading=True),
        ],
        native_tools=[ToolSearchTool()],
        revealed_tool_names={'alpha', 'beta'},
    )
    await model.request(
        [
            ModelRequest(parts=[UserPromptPart(content='Hi')]),
            ModelRequest(parts=[ToolAvailabilityDeltaPart(tools_added=['beta', 'alpha'])]),
        ],
        None,
        params,
    )

    [request] = get_mock_chat_completion_kwargs(mock_client)
    assert [tool.get('name') for tool in request['tools']][-2:] == ['beta', 'alpha']


@pytest.mark.parametrize(
    ('model_name', 'expected_defer_loading'),
    [('claude-sonnet-5', True), ('claude-opus-4-1-20250805', None)],
)
async def test_anthropic_defer_loading_needs_a_reveal_mechanism(
    allow_model_requests: None, model_name: str, expected_defer_loading: bool | None
):
    """`defer_loading` only goes on the wire where a `tool_reference` reveal can take it off again.

    `defer_loading` records what the author asked for, so it stays set on a capability's tools after
    `load_capability` runs. Sonnet 5 renders the reveal as the `tool_reference` block in the recorded
    result, which unhides the schema. Opus 4.1 predates tool search, gets the same result as plain
    JSON text, and honors `defer_loading` regardless — verified live: with the flag it calls
    `load_capability`, without it, the tool itself — so sending the flag there would leave the
    loaded tool permanently unreachable.
    """
    responses = [
        completion_message(
            [BetaToolUseBlock(id='load-1', input={'id': 'refunds'}, name='load_capability', type='tool_use')],
            BetaUsage(input_tokens=5, output_tokens=10),
        ),
        completion_message([BetaTextBlock(text='Done.', type='text')], BetaUsage(input_tokens=5, output_tokens=10)),
    ]
    mock_client = MockAnthropic.create_mock(responses)
    model = AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=mock_client))
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    agent: Agent[None, str] = Agent(model, deps_type=type(None), capabilities=[refunds])
    await agent.run('Hello')

    _, request = get_mock_chat_completion_kwargs(mock_client)
    [tool] = [t for t in request['tools'] if t.get('name') == 'lookup_refund_policy']
    assert tool.get('defer_loading') is expected_defer_loading
    result_block_types: list[str] = []
    for wire_message in cast(list[dict[str, Any]], request['messages']):
        for content_block in cast(list[dict[str, Any]], wire_message['content']):
            if content_block['type'] == 'tool_result':
                result_block_types += [block['type'] for block in cast(list[dict[str, Any]], content_block['content'])]
    # The reveal and the flag travel together: whichever model gets one gets the other.
    assert ('tool_reference' in result_block_types) is (expected_defer_loading is True)


@pytest.mark.vcr()
async def test_anthropic_explicit_tool_search_keeps_search_surface(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, vcr: Any, request_capture: RequestCapture
):
    """A mixed corpus retains explicit keyword search and can discover a standalone deferred tool."""
    model = anthropic_model('claude-sonnet-4-6', capture=True)
    refunds = Capability[None](id='refunds', description='Refund policy tools.', defer_loading=True)

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: refund allowed'

    def search_only_tool(query: str) -> str:
        return query

    agent: Agent[None, str] = Agent(
        model,
        deps_type=type(None),
        tools=[Tool(search_only_tool, defer_loading=True)],
        capabilities=[refunds, ToolSearch(strategy='keywords')],
    )
    result = await agent.run(
        'Use tool search to find search_only_tool, call it with query "recorded", then return only its result.'
    )
    advertised = [
        (tool['name'], tool.get('defer_loading'), tool.get('description')) for tool in request_capture.body()['tools']
    ]
    assert advertised == snapshot(
        [
            (
                'load_capability',
                None,
                'Load a listed capability whenever it is plausibly relevant to the task. Loading makes the capability instructions and any tools it provides available.',
            ),
            ('search_only_tool', True, ''),
            (
                'search_tools',
                None,
                'Search first for a standalone deferred tool when current tools and catalog descriptions do not name the requested operation. A capability id used as an ordinary domain word does not request that capability. This cannot find capability-owned tools; load a listed capability by id instead. If no tools are found, do not retry.',
            ),
        ]
    )
    assert request_capture.body()['system'] == snapshot(
        [
            {
                'type': 'text',
                'text': """\
The following capabilities are deferred and can be loaded using the `load_capability` tool. A capability's tools stay hidden until it is loaded — load the capability first rather than searching for its tools:
- refunds: Refund policy tools.\
""",
            }
        ]
    )

    request_bodies = [json.loads(request.body) for request in vcr.requests]
    assert len(request_bodies) >= 2
    for request_body in request_bodies:
        assert any(tool.get('name') == 'search_tools' for tool in request_body['tools'])
    [standalone_tool] = [tool for tool in request_bodies[0]['tools'] if tool.get('name') == 'search_only_tool']
    assert standalone_tool['defer_loading'] is True
    assert any(
        part.tool_name == 'search_only_tool'
        for part in iter_message_parts(result.all_messages(), ModelRequest, ToolReturnPart)
    )


@pytest.mark.vcr()
async def test_anthropic_always_on_capability_toolset_is_visible(
    allow_model_requests: None, anthropic_api_key: str, vcr: Any
):
    """An always-on capability contributes plainly visible tools without a search surface."""

    def lookup_shipping(order_id: str) -> str:  # pragma: no cover
        return f'{order_id}: shipped'

    toolset = FunctionToolset([lookup_shipping])
    shipping = Capability[None](id='shipping', toolsets=[toolset])
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent: Agent[None, str] = Agent(model, deps_type=type(None), capabilities=[shipping])
    result = await agent.run('Reply with exactly: ready')

    assert result.output.strip().lower() == 'ready'
    request_body = single_request_body(vcr)
    [lookup_tool] = [tool for tool in request_body['tools'] if tool.get('name') == 'lookup_shipping']
    assert 'defer_loading' not in lookup_tool
    assert not any(
        tool.get('name') in {'search_tools', 'tool_search_tool_bm25', 'tool_search_tool_regex'}
        for tool in request_body['tools']
    )


@pytest.mark.vcr()
async def test_anthropic_deferred_capability_tool_callable_without_tool_search(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, vcr: Any, request_capture: RequestCapture
):
    """Anthropic accepts a capability-revealed tool that stays deferred without a tool-search surface."""
    model = anthropic_model('claude-sonnet-4-6', capture=True)
    refunds = Capability[None](
        id='refunds',
        description='Refund policy tools. Load this capability before looking up refund policy.',
        defer_loading=True,
    )

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:
        return f'{order_id}: refund allowed'

    agent: Agent[None, str] = Agent(model, deps_type=type(None), capabilities=[refunds])
    result = await agent.run(
        'First load the refunds capability. Then call lookup_refund_policy for order-123. Return only the tool result.'
    )
    advertised = [
        (tool['name'], tool.get('defer_loading'), tool.get('description')) for tool in request_capture.body()['tools']
    ]
    assert advertised == snapshot(
        [
            (
                'load_capability',
                None,
                'Load a listed capability whenever it is plausibly relevant to the task. Loading makes the capability instructions and any tools it provides available.',
            ),
            ('lookup_refund_policy', True, ''),
        ]
    )
    assert request_capture.body()['system'] == snapshot(
        [
            {
                'type': 'text',
                'text': """\
The following capabilities are deferred and can be loaded using the `load_capability` tool. A capability's tools stay hidden until it is loaded:
- refunds: Refund policy tools. Load this capability before looking up refund policy.\
""",
            }
        ]
    )

    # Read off the wire, not `vcr.requests`: the cassette is frozen and matched without reference to
    # the body, so tool/`tool_addition` claims asserted against it survive the code drifting away.
    request_bodies = request_capture.bodies()
    assert len(request_bodies) >= 3
    for request_body in request_bodies:
        assert not any(
            tool.get('name') in {'search_tools', 'tool_search_tool_bm25', 'tool_search_tool_regex'}
            for tool in request_body['tools']
        )
    [initial_lookup] = [tool for tool in request_bodies[0]['tools'] if tool.get('name') == 'lookup_refund_policy']
    assert initial_lookup['defer_loading'] is True
    assert all(
        [tool for tool in request_body['tools'] if tool.get('name') == 'lookup_refund_policy'] == [initial_lookup]
        for request_body in request_bodies[1:]
    )
    assert any(
        part.tool_name == 'lookup_refund_policy'
        for part in iter_message_parts(result.all_messages(), ModelRequest, ToolReturnPart)
    )


@pytest.mark.parametrize(
    'model_name',
    [
        'claude-haiku-4-5',
        'claude-fable-5',
        'claude-opus-5',
        'claude-sonnet-4-6',
        'claude-sonnet-5',
    ],
)
@pytest.mark.vcr()
async def test_anthropic_deferred_capability_without_tool_search_across_models(
    allow_model_requests: None,
    anthropic_model: AnthropicModelFactory,
    vcr: Any,
    model_name: str,
    request_capture: RequestCapture,
):
    """All Anthropic models honor standalone deferred capability reveals without a search surface."""
    model = anthropic_model(model_name, capture=True)
    refunds = Capability[None](
        id='refunds',
        description='Refund policy tools. Load this capability before looking up refund policy.',
        defer_loading=True,
    )

    @refunds.tool_plain
    def lookup_refund_policy(order_id: str) -> str:
        return f'{order_id}: refund allowed'

    agent: Agent[None, str] = Agent(model, deps_type=type(None), capabilities=[refunds])
    result = await agent.run(
        'First load the refunds capability. Then call lookup_refund_policy for order-123. Return only the tool result.'
    )
    advertised = [
        (tool['name'], tool.get('defer_loading'), tool.get('description')) for tool in request_capture.body()['tools']
    ]
    assert advertised == snapshot(
        [
            (
                'load_capability',
                None,
                'Load a listed capability whenever it is plausibly relevant to the task. Loading makes the capability instructions and any tools it provides available.',
            ),
            ('lookup_refund_policy', True, ''),
        ]
    )
    assert request_capture.body()['system'] == snapshot(
        [
            {
                'type': 'text',
                'text': """\
The following capabilities are deferred and can be loaded using the `load_capability` tool. A capability's tools stay hidden until it is loaded:
- refunds: Refund policy tools. Load this capability before looking up refund policy.\
""",
            }
        ]
    )

    request_bodies = [json.loads(request.body) for request in vcr.requests]
    assert len(request_bodies) >= 2
    for request_body in request_bodies:
        has_search_surface = any(
            tool.get('name') in {'search_tools', 'tool_search_tool_bm25', 'tool_search_tool_regex'}
            for tool in request_body['tools']
        )
        assert not has_search_surface
        [lookup_tool] = [tool for tool in request_body['tools'] if tool.get('name') == 'lookup_refund_policy']
        assert lookup_tool['defer_loading'] is True
    called_revealed_tool = any(
        part.tool_name == 'lookup_refund_policy'
        for part in iter_message_parts(result.all_messages(), ModelRequest, ToolReturnPart)
    )
    assert called_revealed_tool


@pytest.mark.vcr()
async def test_anthropic_count_tokens_with_native_tools(allow_model_requests: None, anthropic_api_key: str):
    """`count_tokens` succeeds against the live API when a native/server tool is configured.

    Anthropic rejects server tools (e.g. `code_execution`) on the `count_tokens` endpoint with a 400, so
    the model strips native tools from the `count_tokens` payload. A successful token count proves the
    native tools were omitted. The recorded request is itself the regression guard: it must NOT contain
    the `code_execution` entry, so a revert of the fix would send it and break playback.

    Regression test for https://github.com/pydantic/pydantic-ai/issues/5702
    """
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))

    usage = await m.count_tokens(
        [ModelRequest.user_text_prompt('What is 2 + 2?')],
        None,
        ModelRequestParameters(native_tools=[CodeExecutionTool()]),
    )

    assert usage.input_tokens > 0


@pytest.mark.vcr()
async def test_anthropic_count_tokens_with_tool_search_replay(
    allow_model_requests: None, anthropic_api_key: str, vcr: Any
):
    """`count_tokens` succeeds against the live API with a `ToolSearchTool` and a tool-search replay history.

    The endpoint rejects the server-side `tool_search_tool_*` entry, so it's omitted from the wire `tools`
    list, but the replay turn must still serialize as a `tool_reference` block (pointing at a `function_tools`
    entry, which is not stripped) — exactly as the real `/v1/messages` request does. A successful token count
    proves the endpoint accepts that payload; the recorded request is the regression guard.

    Regression test for https://github.com/pydantic/pydantic-ai/issues/5780
    """
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))

    params = ModelRequestParameters(
        function_tools=[
            ToolDefinition(name='get_exchange_rate', description='', parameters_json_schema={'type': 'object'})
        ],
        native_tools=[ToolSearchTool()],
    )
    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='What is the USD to EUR rate?')]),
        ModelResponse(parts=[ToolSearchCallPart(args={'queries': ['exchange rate']}, tool_call_id='search-1')]),
        ModelRequest(
            parts=[
                ToolSearchReturnPart(
                    content={
                        'discovered_tools': [{'name': 'get_exchange_rate'}],
                        'message': 'Found 1 tool',
                    },
                    tool_call_id='search-1',
                )
            ]
        ),
    ]

    usage = await m.count_tokens(messages, None, params)

    assert usage.input_tokens > 0
    request_body = json.loads(vcr.requests[0].body)
    assert not any(str(tool.get('type', '')).startswith('tool_search_tool_') for tool in request_body['tools'])
    tool_result = request_body['messages'][-1]['content'][0]
    assert tool_result['content'] == [{'tool_name': 'get_exchange_rate', 'type': 'tool_reference'}]


@pytest.mark.vcr()
async def test_anthropic_count_tokens_keeps_memory_tool(allow_model_requests: None, anthropic_api_key: str, vcr: Any):
    """`count_tokens` keeps the client-side `MemoryTool`, which the endpoint accepts and counts.

    Unlike server tools, `MemoryTool` is not rejected by `count_tokens` and its definition contributes
    real tokens, so stripping it would undercount the prompt. The recorded request is the regression
    guard: it must contain the `memory` tool, so a revert to clearing all native tools would omit it.

    Regression test for https://github.com/pydantic/pydantic-ai/issues/5702
    """
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))

    usage = await m.count_tokens(
        [ModelRequest.user_text_prompt('What is 2 + 2?')],
        None,
        ModelRequestParameters(
            native_tools=[MemoryTool()],
            function_tools=[ToolDefinition(name='memory', description='', parameters_json_schema={'type': 'object'})],
        ),
    )

    assert usage.input_tokens > 0
    request_body = json.loads(vcr.requests[0].body)
    assert {'name': 'memory', 'type': 'memory_20250818'} in request_body['tools']


@pytest.mark.vcr()
async def test_anthropic_count_tokens_with_adaptive_thinking_and_output_tools(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """`/v1/messages/count_tokens` accepts the forced `tool_choice` that adaptive thinking now keeps.

    `count_tokens` builds its payload from the same `prepare_request` result as the real request, so
    adaptive thinking + Tool Output reaches this endpoint with `tool_choice={'type': 'any'}` too. The
    endpoint rejects that pair under extended thinking, which would turn a token pre-check into a hard
    run failure; the recording pins that it does not reject it under adaptive thinking.

    The pair is read off an httpx event hook rather than the cassette, so a regression that stops
    sending it fails here instead of replaying a recording that still holds the old payload.
    """
    m = anthropic_model('claude-opus-4-6', capture=True)

    class CityLocation(BaseModel):
        city: str
        country: str

    agent = Agent(
        m,
        output_type=ToolOutput(CityLocation),
        model_settings=AnthropicModelSettings(anthropic_thinking={'type': 'adaptive'}),
    )
    result = await agent.run(
        'What is the capital of France?', usage_limits=UsageLimits(count_tokens_before_request=True)
    )

    assert result.output == snapshot(CityLocation(city='Paris', country='France'))
    count_tokens_body = request_capture.body('/v1/messages/count_tokens')
    assert (count_tokens_body['thinking'], count_tokens_body['tool_choice']) == snapshot(
        ({'type': 'adaptive'}, {'type': 'any'})
    )


@pytest.mark.vcr()
async def test_anthropic_count_tokens_error(allow_model_requests: None, anthropic_api_key: str):
    """Test that errors convert to ModelHTTPError."""
    model_id = 'claude-does-not-exist'
    model = AnthropicModel(model_id, provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(model)

    with pytest.raises(ModelHTTPError) as exc_info:
        await agent.run('hello', usage_limits=UsageLimits(input_tokens_limit=20, count_tokens_before_request=True))

    assert exc_info.value.status_code == 404
    assert exc_info.value.model_name == model_id


@pytest.mark.vcr()
async def test_anthropic_cache_real_api(allow_model_requests: None, anthropic_api_key: str):
    """Test that anthropic_cache passes top-level cache_control and produces cache usage.

    This test uses a cassette to verify the automatic caching behavior.
    When run with real API credentials, it demonstrates that:
    1. The first call with a long context creates a cache (cache_write_tokens > 0)
    2. Follow-up messages in the same conversation read from that cache (cache_read_tokens > 0)
    """
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(
        m,
        system_prompt='You are a helpful assistant.',
        model_settings=AnthropicModelSettings(
            anthropic_cache=True,
        ),
    )

    result1 = await agent.run('Please explain what Python is and its main use cases. ' * 100)
    assert result1.usage == snapshot(
        RunUsage(
            input_tokens=1114,
            cache_read_tokens=1111,
            output_tokens=406,
            details={
                'cache_creation_input_tokens': 0,
                'cache_read_input_tokens': 1111,
                'input_tokens': 3,
                'output_tokens': 406,
            },
            requests=1,
            cost=Decimal('0.0064323'),
        )
    )

    result2 = await agent.run('Can you summarize that in one sentence?', message_history=result1.all_messages())
    assert result2.usage == snapshot(
        RunUsage(
            input_tokens=1532,
            cache_read_tokens=1111,
            cache_write_tokens=418,
            output_tokens=33,
            details={
                'cache_creation_input_tokens': 418,
                'cache_read_input_tokens': 1111,
                'input_tokens': 3,
                'output_tokens': 33,
            },
            requests=1,
            cost=Decimal('0.0024048'),
        )
    )


@pytest.mark.vcr()
async def test_anthropic_cache_count_tokens(allow_model_requests: None, anthropic_api_key: str):
    """Test that count_tokens endpoint accepts the top-level cache_control parameter.

    The Anthropic count_tokens API supports cache_control:
    https://docs.anthropic.com/en/api/messages-count-tokens
    """
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(
        m,
        system_prompt='You are a helpful assistant.',
        model_settings=AnthropicModelSettings(
            anthropic_cache=True,
        ),
    )

    result = await agent.run(
        'Please explain what Python is and its main use cases. ' * 100,
        usage_limits=UsageLimits(input_tokens_limit=5000, count_tokens_before_request=True),
    )
    assert result.usage == snapshot(
        RunUsage(
            input_tokens=1114,
            cache_read_tokens=1111,
            output_tokens=414,
            details={
                'cache_creation_input_tokens': 0,
                'cache_read_input_tokens': 1111,
                'input_tokens': 3,
                'output_tokens': 414,
            },
            requests=1,
            cost=Decimal('0.0065523'),
        )
    )


@pytest.mark.vcr()
async def test_anthropic_cache_bedrock_real_api(allow_model_requests: None):
    """Test that anthropic_cache falls back to per-block caching on Bedrock with multi-turn conversations.

    On Bedrock, the top-level cache_control (automatic caching) is not supported.
    Instead, anthropic_cache triggers per-block cache_control on the last user message
    via _apply_per_block_caching_fallback, including the TTL parameter.

    Verifies multi-turn caching works: result2 passes message_history from result1,
    and the API accepts cache_control with TTL without error.
    """
    # `AsyncAnthropicBedrock`'s SigV4 signer imports `botocore` at request-prep time, which only
    # ships under the `bedrock` extra (not in the default `pydantic-ai` install on v2).
    pytest.importorskip('botocore')

    from anthropic import AsyncAnthropicBedrock

    bedrock_client = AsyncAnthropicBedrock(
        aws_access_key=os.environ.get('AWS_ACCESS_KEY_ID', 'test-access-key'),
        aws_secret_key=os.environ.get('AWS_SECRET_ACCESS_KEY', 'test-secret-key'),
        aws_session_token=os.environ.get('AWS_SESSION_TOKEN'),
        aws_region=os.environ.get('AWS_REGION', 'eu-central-1'),
    )
    m = AnthropicModel(
        'eu.anthropic.claude-haiku-4-5-20251001-v1:0',
        provider=AnthropicProvider(anthropic_client=bedrock_client),
    )
    agent = Agent(
        m,
        system_prompt='You are a helpful assistant.',
        model_settings=AnthropicModelSettings(
            anthropic_cache=True,
        ),
    )

    long_prompt = (
        'Describe the evolution of the Python programming language from version 2 to 3.13, '
        'including major PEPs, typing improvements, performance enhancements, and ecosystem growth. '
    ) * 250
    result1 = await agent.run(long_prompt)
    assert result1.usage == snapshot(
        RunUsage(
            input_tokens=9514,
            cache_read_tokens=9511,
            output_tokens=1944,
            details={
                'cache_creation_input_tokens': 0,
                'cache_read_input_tokens': 9511,
                'input_tokens': 3,
                'output_tokens': 1944,
            },
            requests=1,
            cost=Decimal('0.01174151'),
        )
    )

    result2 = await agent.run('Can you summarize that in one sentence?', message_history=result1.all_messages())
    assert result2.usage == snapshot(
        RunUsage(
            input_tokens=11470,
            cache_write_tokens=1956,
            cache_read_tokens=9511,
            output_tokens=44,
            details={
                'cache_creation_input_tokens': 1956,
                'cache_read_input_tokens': 9511,
                'input_tokens': 3,
                'output_tokens': 44,
            },
            requests=1,
            cost=Decimal('0.00398101'),
        )
    )


async def test_anthropic_container_setting_explicit_string(allow_model_requests: None):
    """A raw id string is passed through to the `container` request param."""
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    await agent.run('hello', model_settings=AnthropicModelSettings(anthropic_container='container_abc123'))

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['container'] == 'container_abc123'


async def test_anthropic_container_setting_id_only_dict_unwrapped_to_string(allow_model_requests: None):
    """`{'id': x}` (with no other keys) is unwrapped to the raw string `x`.

    The Anthropic live API rejects `container={'id': x}` with
    `container: Input should be a valid string` even though the SDK type permits it,
    so `_get_container()` unwraps this one specifically broken shape before sending.
    """
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    await agent.run('hello', model_settings=AnthropicModelSettings(anthropic_container={'id': 'container_abc123'}))

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['container'] == 'container_abc123'


async def test_anthropic_container_setting_dict_with_skills_passed_through(allow_model_requests: None):
    """Dicts carrying `skills` are passed through unchanged — the live API accepts them."""
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    container_with_skills: BetaContainerParams = {
        'id': 'container_abc123',
        'skills': [{'type': 'anthropic', 'skill_id': 'xlsx', 'version': 'latest'}],
    }
    await agent.run('hello', model_settings=AnthropicModelSettings(anthropic_container=container_with_skills))

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['container'] == container_with_skills


async def test_anthropic_container_from_message_history(allow_model_requests: None):
    """Test that container_id from message history is passed to subsequent requests."""
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock([c, c])
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # Create a message history with a container_id in provider_details
    history: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='hello')]),
        ModelResponse(
            parts=[TextPart(content='world')],
            provider_name='anthropic',
            provider_details={'container_id': 'container_from_history'},
        ),
    ]

    # Run with the message history
    await agent.run('follow up', message_history=history)

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['container'] == 'container_from_history'


async def test_anthropic_container_setting_false_ignores_history(allow_model_requests: None):
    """Test that anthropic_container=False ignores container_id from history."""
    c = completion_message([BetaTextBlock(text='world', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # Create a message history with a container_id
    history: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='hello')]),
        ModelResponse(
            parts=[TextPart(content='world')],
            provider_name='anthropic',
            provider_details={'container_id': 'container_should_be_ignored'},
        ),
    ]

    # Run with anthropic_container=False to force fresh container
    await agent.run(
        'follow up', message_history=history, model_settings=AnthropicModelSettings(anthropic_container=False)
    )

    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    # When anthropic_container=False, container should be OMIT (filtered out before sending to API)
    from anthropic import omit as OMIT

    assert completion_kwargs.get('container') is OMIT


async def test_anthropic_container_id_from_stream_response(allow_model_requests: None):
    """Test that container_id is extracted from streamed response and stored in provider_details."""
    from datetime import datetime

    stream_events: list[BetaRawMessageStreamEvent] = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_123',
                content=[],
                model='claude-3-5-haiku-123',
                role='assistant',
                stop_reason=None,
                type='message',
                usage=BetaUsage(input_tokens=5, output_tokens=0),
                container=BetaContainer(
                    id='container_from_stream',
                    expires_at=datetime(2025, 1, 1, 0, 0, 0),
                ),
            ),
        ),
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=0,
            content_block=BetaTextBlock(text='', type='text'),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaTextDelta(type='text_delta', text='hello'),
        ),
        BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
        BetaRawMessageDeltaEvent(
            type='message_delta',
            delta=Delta(stop_reason='end_turn', stop_sequence=None),
            usage=BetaMessageDeltaUsage(output_tokens=5),
        ),
        BetaRawMessageStopEvent(type='message_stop'),
    ]

    mock_client = MockAnthropic.create_stream_mock(stream_events)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    async with agent.run_stream('hello') as result:
        response = await result.get_output()
        assert response == 'hello'

    # Check that container_id was captured in the response
    messages = result.all_messages()
    model_response = message(messages, ModelResponse, index=-1)
    assert model_response.provider_details is not None
    assert model_response.provider_details.get('container_id') == 'container_from_stream'
    assert model_response.provider_details.get('finish_reason') == 'end_turn'


@pytest.mark.vcr()
async def test_anthropic_code_execution_tool_container_reuse(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """Reusing a `container_id` from message history must be sent as a raw string.

    The Anthropic SDK types `container` as `BetaContainerParams | str`, but the live
    API rejects the object form with `container: Input should be a valid string`.
    This test records a two-turn conversation using the code execution tool and
    asserts that the second request sends `container` on the wire as the raw id —
    reading it off `request_capture` so the assertion runs against what the client
    actually sent, not what the VCR cassette happens to hold.
    """
    agent = Agent(
        anthropic_model('claude-sonnet-4-5', capture=True),
        capabilities=[NativeTool(CodeExecutionTool())],
        instructions='Always use the code execution tool for math.',
    )

    first = await agent.run('How much is 3 * 12390?')
    first_response = message(first.all_messages(), ModelResponse, index=-1)
    assert first_response.provider_details is not None
    container_id = first_response.provider_details.get('container_id')
    assert isinstance(container_id, str) and container_id.startswith('container_')

    second = await agent.run('And what about 4 * 12390?', message_history=first.new_messages())

    sent_bodies = request_capture.bodies('/v1/messages')
    assert len(sent_bodies) == 2
    assert 'container' not in sent_bodies[0]
    assert sent_bodies[1]['container'] == container_id

    assert second.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='How much is 3 * 12390?', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                instructions='Always use the code execution tool for math.',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'echo $((3 * 12390))'},
                        tool_call_id='srvtoolu_01HdeXFEfm2TUaENsFep6QUJ',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': '37170\n',
                            'type': 'bash_code_execution_result',
                        },
                        tool_call_id='srvtoolu_01HdeXFEfm2TUaENsFep6QUJ',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    TextPart(content='3 * 12390 = **37,170**'),
                ],
                usage=RequestUsage(
                    input_tokens=4612,
                    output_tokens=80,
                    details={
                        'input_tokens': 4612,
                        'output_tokens': 80,
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                    },
                    cost=Decimal('0.015036'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn', 'container_id': 'container_011Caqgq9X3d68B2So2LZGmk'},
                provider_response_id='msg_01LZfXQfnKjDzM8MfBWwnVqV',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[UserPromptPart(content='And what about 4 * 12390?', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                instructions='Always use the code execution tool for math.',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'command': 'echo $((4 * 12390))'},
                        tool_call_id='srvtoolu_01XXQYLc95uCBCjeX52Pjopu',
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={
                            'content': [],
                            'return_code': 0,
                            'stderr': '',
                            'stdout': '49560\n',
                            'type': 'bash_code_execution_result',
                        },
                        tool_call_id='srvtoolu_01XXQYLc95uCBCjeX52Pjopu',
                        timestamp=IsDatetime(),
                        provider_name='anthropic',
                        provider_details={'anthropic_tool_name': 'bash_code_execution'},
                    ),
                    TextPart(content='4 * 12390 = **49,560**'),
                ],
                usage=RequestUsage(
                    input_tokens=4840,
                    output_tokens=80,
                    details={
                        'input_tokens': 4840,
                        'output_tokens': 80,
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                    },
                    cost=Decimal('0.01572'),
                ),
                model_name='claude-sonnet-4-5-20250929',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn', 'container_id': 'container_011Caqgq9X3d68B2So2LZGmk'},
                provider_response_id='msg_016CCM7vKzHb1YyMDsVofT35',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_anthropic_system_prompts_and_instructions_ordering():
    """Test that instructions are appended after all system prompts in the system prompt string."""
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key='test-key'))

    messages: list[ModelRequest | ModelResponse] = [
        ModelRequest(
            parts=[
                SystemPromptPart(content='System prompt 1'),
                SystemPromptPart(content='System prompt 2'),
                UserPromptPart(content='Hello'),
            ],
        ),
    ]
    model_request_parameters = ModelRequestParameters(
        instruction_parts=[InstructionPart(content='Instructions content')],
    )

    system_prompt, anthropic_messages = await m._map_message(messages, model_request_parameters, {})  # pyright: ignore[reportPrivateUsage]

    # Verify system prompts and instructions are joined in order: system1, system2, instructions
    assert system_prompt == snapshot(
        [
            {
                'type': 'text',
                'text': """\
System prompt 1

System prompt 2\
""",
            },
            {'type': 'text', 'text': 'Instructions content'},
        ]
    )
    # Verify user message is in anthropic_messages
    assert len(anthropic_messages) == 1
    assert anthropic_messages[0]['role'] == 'user'


async def test_anthropic_malformed_tool_args_no_crash(allow_model_requests: None):
    """Test that malformed JSON tool args don't crash the Anthropic retry path.

    Regression test for https://github.com/pydantic/pydantic-ai/issues/4430.

    When a tool call has malformed JSON arguments, a RetryPromptPart is correctly
    created. But when the message history is re-sent to Anthropic, the previous
    tool call's args are parsed via args_as_dict() which raises ValueError on
    invalid JSON, crashing the retry flow before the model can self-correct.
    """
    bad_args = '{"query": "bad query", "file_ids":[4556]</parameter>\n<parameter name="limit": 8}'

    # First response: the model "fixes" the tool call and returns text
    fixed_response = completion_message(
        [BetaTextBlock(text='Here is the corrected result.', type='text')],
        BetaUsage(input_tokens=10, output_tokens=5),
    )
    mock_client = MockAnthropic.create_mock(fixed_response)
    m = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    # Construct message_history with a malformed tool call + retry prompt
    # exactly as described in the issue
    message_history: list[ModelMessage] = [
        ModelResponse(
            parts=[
                ToolCallPart(
                    tool_name='search_knowledge',
                    tool_call_id='toolu_123',
                    args=bad_args,
                ),
            ],
            timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc),
        ),
        ModelRequest(
            parts=[
                RetryPromptPart(
                    tool_name='search_knowledge',
                    tool_call_id='toolu_123',
                    content='Invalid JSON: expected `,` or `}` at line 1 column 99',
                ),
            ],
        ),
    ]

    # This should NOT raise ValueError — args_as_dict() now gracefully handles
    # malformed JSON by returning {'INVALID_JSON': ...}, allowing the retry to proceed.
    result = await agent.run(
        'Please fix the tool call and try again.',
        message_history=message_history,
    )
    assert result.output == 'Here is the corrected result.'
    assert result.all_messages() == snapshot(
        [
            ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name='search_knowledge',
                        args="""\
{"query": "bad query", "file_ids":[4556]</parameter>
<parameter name="limit": 8}\
""",
                        tool_call_id='toolu_123',
                    )
                ],
                timestamp=IsDatetime(),
            ),
            ModelRequest(
                parts=[
                    RetryPromptPart(
                        content='Invalid JSON: expected `,` or `}` at line 1 column 99',
                        tool_name='search_knowledge',
                        tool_call_id='toolu_123',
                        timestamp=IsDatetime(),
                    )
                ]
            ),
            ModelRequest(
                parts=[UserPromptPart(content='Please fix the tool call and try again.', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='Here is the corrected result.')],
                usage=RequestUsage(
                    input_tokens=10,
                    output_tokens=5,
                    details={'input_tokens': 10, 'output_tokens': 5},
                    cost=Decimal('0.000028'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='123',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )

    # Verify the INVALID_JSON wrapper was actually sent to the Anthropic API
    completion_kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert completion_kwargs['messages'] == snapshot(
        [
            {
                'role': 'assistant',
                'content': [
                    {
                        'id': 'toolu_123',
                        'type': 'tool_use',
                        'name': 'search_knowledge',
                        'input': {
                            'INVALID_JSON': """\
{"query": "bad query", "file_ids":[4556]</parameter>
<parameter name="limit": 8}\
""",
                        },
                    }
                ],
            },
            {
                'role': 'user',
                'content': [
                    {
                        'tool_use_id': 'toolu_123',
                        'type': 'tool_result',
                        'content': """\
Invalid JSON: expected `,` or `}` at line 1 column 99

Fix the errors and try again.\
""",
                        'is_error': True,
                    },
                    {'text': 'Please fix the tool call and try again.', 'type': 'text'},
                ],
            },
        ]
    )


async def test_stream_cancel(allow_model_requests: None):
    stream = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_cancel',
                model='claude-haiku-4-5-123',
                role='assistant',
                type='message',
                content=[],
                stop_reason=None,
                usage=BetaUsage(input_tokens=5, output_tokens=0),
            ),
        ),
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=0,
            content_block=BetaTextBlock(type='text', text=''),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaTextDelta(type='text_delta', text='hello '),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaTextDelta(type='text_delta', text='world'),
        ),
        BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
        BetaRawMessageDeltaEvent(
            type='message_delta',
            delta=Delta(stop_reason='end_turn'),
            usage=BetaMessageDeltaUsage(input_tokens=5, output_tokens=2),
        ),
        BetaRawMessageStopEvent(type='message_stop'),
    ]
    mock_client = MockAnthropic.create_stream_mock(stream)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    async with agent.run_stream('') as result:
        async for _ in result.stream_text(delta=True, debounce_by=None):  # pragma: no branch
            break
        await result.cancel()
        await result.cancel()  # double cancel is a no-op
        assert result.cancelled

    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='hello ')],
                usage=RequestUsage(
                    input_tokens=5, details={'input_tokens': 5, 'output_tokens': 0}, cost=Decimal('0.000005')
                ),
                model_name='claude-haiku-4-5-123',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_response_id='msg_cancel',
                run_id=IsStr(),
                conversation_id=IsStr(),
                state='interrupted',
            ),
        ]
    )


async def test_anthropic_compaction_capability_settings(allow_model_requests: None, anthropic_api_key: str):
    """Test that AnthropicCompaction capability correctly configures model settings."""
    from unittest.mock import Mock

    cap = AnthropicCompaction(token_threshold=100_000, instructions='Keep it short.')

    settings_resolver = cap.get_model_settings()
    assert callable(settings_resolver)
    settings = settings_resolver(Mock(model_settings=None))
    assert settings is not None
    assert settings.get('anthropic_context_management') == {
        'edits': [
            {
                'type': 'compact_20260112',
                'trigger': {'type': 'input_tokens', 'value': 100_000},
                'instructions': 'Keep it short.',
            }
        ]
    }


async def test_anthropic_compaction_capability_settings_with_pause(allow_model_requests: None, anthropic_api_key: str):
    """Test that AnthropicCompaction correctly includes pause_after_compaction."""
    from unittest.mock import Mock

    cap = AnthropicCompaction(pause_after_compaction=True)
    settings_resolver = cap.get_model_settings()
    assert callable(settings_resolver)
    settings = settings_resolver(Mock(model_settings=None))
    assert settings is not None
    anthropic_settings = cast(AnthropicModelSettings, settings)
    edit = anthropic_settings['anthropic_context_management']['edits'][0]  # type: ignore[reportUnknownMemberType]
    assert edit['pause_after_compaction'] is True


async def test_anthropic_compaction_capability_preserves_existing_edits(
    allow_model_requests: None, anthropic_api_key: str
):
    """Test that AnthropicCompaction appends its edit to existing user-configured edits."""
    from unittest.mock import Mock

    cap = AnthropicCompaction(token_threshold=100_000)
    settings_resolver = cap.get_model_settings()
    assert callable(settings_resolver)

    existing_settings = {
        'anthropic_context_management': {
            'edits': [{'type': 'some_other_edit', 'custom': True}],
        }
    }
    settings = settings_resolver(Mock(model_settings=existing_settings))
    assert settings is not None
    cm = cast(dict[str, Any], settings.get('anthropic_context_management'))
    edits = cast(list[dict[str, Any]], cm['edits'])
    assert len(edits) == 2
    assert edits[0] == {'type': 'some_other_edit', 'custom': True}
    assert edits[1] == {'type': 'compact_20260112', 'trigger': {'type': 'input_tokens', 'value': 100_000}}


async def test_anthropic_compaction_round_trip(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """Test that CompactionPart is correctly round-tripped in Anthropic message mapping."""
    model = anthropic_model('claude-sonnet-4-6', capture=True)

    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='Hello!')]),
        ModelResponse(
            parts=[
                CompactionPart(content='Summary: user said hello.', provider_name='anthropic'),
                TextPart(content='Hello! How can I help?'),
            ],
            provider_name='anthropic',
        ),
        ModelRequest(parts=[UserPromptPart(content='What did I say earlier?')]),
    ]

    agent = Agent(model=model, instructions='Be brief.')
    result = await agent.run('What did I say earlier?', message_history=messages)

    # The compaction block and the turns kept around it, as rendered onto the wire — the actual
    # subject of this test, which `result.output` alone doesn't pin.
    assert message_shape(request_capture.body()) == snapshot(
        [('assistant', ['compaction', 'text']), ('user', ['text', 'text'])]
    )
    assert result.output


@pytest.mark.parametrize(
    ('provider_details', 'expected_encrypted_content'),
    [({'encrypted_content': 'opaque-blob'}, 'opaque-blob'), (None, None)],
)
async def test_anthropic_compaction_maps_encrypted_content(
    allow_model_requests: None,
    provider_details: dict[str, Any] | None,
    expected_encrypted_content: str | None,
):
    """The API does not emit encrypted compaction content yet, so pin the rendered SDK parameter."""
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelResponse(
            parts=[CompactionPart(content='Summary.', provider_name='anthropic', provider_details=provider_details)],
            provider_name='anthropic',
        ),
        ModelRequest.user_text_prompt('Continue'),
    ]

    await model.request(messages, None, ModelRequestParameters())

    compaction_block = get_mock_chat_completion_kwargs(mock_client)[0]['messages'][0]['content'][0]
    if expected_encrypted_content is None:
        assert 'encrypted_content' not in compaction_block
    else:
        assert compaction_block['encrypted_content'] == expected_encrypted_content


async def test_anthropic_trims_before_latest_compaction(allow_model_requests: None):
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelRequest(
            parts=[SystemPromptPart(content='Standing system prompt.'), UserPromptPart(content='drop first request')]
        ),
        ModelResponse(
            parts=[CompactionPart(content='old summary', provider_name='anthropic')], provider_name='anthropic'
        ),
        ModelRequest.user_text_prompt('drop between compactions'),
        ModelResponse(
            parts=[
                TextPart(content='drop before boundary'),
                CompactionPart(content='latest summary', provider_name='anthropic'),
                TextPart(content='keep after boundary'),
            ],
            provider_name='anthropic',
        ),
        ModelRequest.user_text_prompt('keep tail'),
    ]

    await model.request(messages, None, ModelRequestParameters())
    await model.count_tokens(messages, None, ModelRequestParameters())

    create_kwargs, count_kwargs = get_mock_chat_completion_kwargs(mock_client)
    # The messages start with the assistant compaction block — the API accepts that shape
    # (live-verified), and a kept user anchor could 400 on an orphaned `tool_result` — while the
    # standing system prompt survives via the separate `system` parameter, which the compaction
    # block does not replace.
    assert (
        create_kwargs['messages']
        == count_kwargs['messages']
        == snapshot(
            [
                {
                    'role': 'assistant',
                    'content': [
                        {'content': 'latest summary', 'type': 'compaction'},
                        {'text': 'keep after boundary', 'type': 'text'},
                    ],
                },
                {'role': 'user', 'content': [{'text': 'keep tail', 'type': 'text'}]},
            ]
        )
    )
    assert create_kwargs['system'] == count_kwargs['system'] == snapshot('Standing system prompt.')
    assert 'compact-2026-01-12' in create_kwargs['betas']
    assert 'compact-2026-01-12' in count_kwargs['betas']


async def test_anthropic_standing_prompt_survives_response_first_history(allow_model_requests: None):
    """A history that opens with a `ModelResponse` still keeps the first request's standing prompt."""
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelResponse(parts=[TextPart(content='resumed mid-conversation')], provider_name='anthropic'),
        ModelRequest(parts=[SystemPromptPart(content='Standing system prompt.'), UserPromptPart(content='dropped')]),
        ModelResponse(parts=[CompactionPart(content='Summary.', provider_name='anthropic')], provider_name='anthropic'),
        ModelRequest.user_text_prompt('keep tail'),
    ]

    await model.request(messages, None, ModelRequestParameters())

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['system'] == snapshot('Standing system prompt.')
    assert kwargs['messages'] == snapshot(
        [
            {'role': 'assistant', 'content': [{'content': 'Summary.', 'type': 'compaction'}]},
            {'role': 'user', 'content': [{'text': 'keep tail', 'type': 'text'}]},
        ]
    )


async def test_anthropic_standing_instructions_survive_compaction(allow_model_requests: None):
    """A direct `Model.request()` call whose only instructions live before the boundary keeps them:
    the standing-prompt request carries the latest prefix instructions, so the last-two-requests
    fallback still finds them when the trailing request is tool-return-only."""
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelRequest(parts=[UserPromptPart(content='dropped')], instructions='Standing instructions.'),
        ModelResponse(
            parts=[
                CompactionPart(content='Summary.', provider_name='anthropic'),
                ToolCallPart(tool_name='do_thing', args={}, tool_call_id='call-1'),
            ],
            provider_name='anthropic',
        ),
        ModelRequest(parts=[ToolReturnPart(tool_name='do_thing', content='done', tool_call_id='call-1')]),
    ]

    await model.request(messages, None, ModelRequestParameters())

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['system'] == snapshot([{'text': 'Standing instructions.', 'type': 'text'}])


async def test_anthropic_foreign_compaction_does_not_trim(allow_model_requests: None):
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelRequest.user_text_prompt('keep before foreign boundary'),
        ModelResponse(
            parts=[CompactionPart(content='foreign summary', provider_name='openai'), TextPart(content='keep text')],
            provider_name='openai',
        ),
        ModelRequest.user_text_prompt('keep tail'),
    ]

    await model.request(messages, None, ModelRequestParameters())

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'text': 'keep before foreign boundary', 'type': 'text'}]},
            {'role': 'assistant', 'content': [{'text': 'keep text', 'type': 'text'}]},
            {'role': 'user', 'content': [{'text': 'keep tail', 'type': 'text'}]},
        ]
    )


async def test_anthropic_contentless_compaction_does_not_trim(allow_model_requests: None):
    """A failed content-less compaction is a wire no-op and cannot hide preceding history."""
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelRequest.user_text_prompt('keep before failed boundary'),
        ModelResponse(
            parts=[CompactionPart(content=None, provider_name='anthropic'), TextPart(content='keep text')],
            provider_name='anthropic',
        ),
        ModelRequest.user_text_prompt('keep tail'),
    ]

    await model.request(messages, None, ModelRequestParameters())

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'text': 'keep before failed boundary', 'type': 'text'}]},
            {
                'role': 'assistant',
                'content': [{'content': None, 'type': 'compaction'}, {'text': 'keep text', 'type': 'text'}],
            },
            {'role': 'user', 'content': [{'text': 'keep tail', 'type': 'text'}]},
        ]
    )


async def test_anthropic_without_compaction_maps_unchanged(allow_model_requests: None):
    response = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=5, output_tokens=1))
    mock_client = MockAnthropic.create_mock(response)
    model = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    messages: list[ModelMessage] = [
        ModelRequest.user_text_prompt('first request'),
        ModelResponse(parts=[TextPart(content='first response')], provider_name='anthropic'),
        ModelRequest.user_text_prompt('second request'),
    ]

    await model.request(messages, None, ModelRequestParameters())

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    assert kwargs['messages'] == snapshot(
        [
            {'role': 'user', 'content': [{'text': 'first request', 'type': 'text'}]},
            {'role': 'assistant', 'content': [{'text': 'first response', 'type': 'text'}]},
            {'role': 'user', 'content': [{'text': 'second request', 'type': 'text'}]},
        ]
    )


async def test_anthropic_compaction_beta_header(allow_model_requests: None):
    """Test that compact-2026-01-12 beta is added when anthropic_context_management is set."""
    c = completion_message([BetaTextBlock(text='response', type='text')], BetaUsage(input_tokens=5, output_tokens=10))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(
        m, model_settings=AnthropicModelSettings(anthropic_context_management={'edits': [{'type': 'compact_20260112'}]})
    )

    result = await agent.run('hello')
    assert result.output == 'response'

    kwargs = cast(MockAnthropic, mock_client).chat_completion_kwargs[0]
    assert 'compact-2026-01-12' in kwargs['betas']


@pytest.mark.parametrize('encrypted_content', ['opaque-blob', None])
async def test_anthropic_compaction_in_response(allow_model_requests: None, encrypted_content: str | None):
    """Test that BetaCompactionBlock in API response is mapped to CompactionPart."""
    c = completion_message(
        [
            BetaCompactionBlock(
                content='Summary of prior conversation.', encrypted_content=encrypted_content, type='compaction'
            ),
            BetaTextBlock(text='Based on our conversation, here is my response.', type='text'),
        ],
        BetaUsage(input_tokens=100, output_tokens=20),
    )
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('Continue our conversation')
    assert result.output == 'Based on our conversation, here is my response.'

    response_msgs = [msg for msg in result.all_messages() if isinstance(msg, ModelResponse)]
    assert len(response_msgs) == 1
    compaction_parts = [p for p in response_msgs[0].parts if isinstance(p, CompactionPart)]
    assert len(compaction_parts) == 1
    assert compaction_parts[0].content == 'Summary of prior conversation.'
    assert compaction_parts[0].provider_name == 'anthropic'
    expected_provider_details = {'encrypted_content': encrypted_content} if encrypted_content is not None else None
    assert compaction_parts[0].provider_details == expected_provider_details


async def test_anthropic_compaction_streaming(allow_model_requests: None):
    """Test that BetaCompactionBlock in streaming response is handled correctly."""
    stream: list[BetaRawMessageStreamEvent] = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_123',
                model='claude-sonnet-4-6',
                role='assistant',
                type='message',
                content=[],
                stop_reason=None,
                usage=BetaUsage(input_tokens=100, output_tokens=0),
            ),
        ),
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=0,
            content_block=BetaCompactionBlock(
                content='Summary of conversation.', encrypted_content='initial-opaque-blob', type='compaction'
            ),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=0,
            delta=BetaCompactionContentBlockDelta(
                content='Updated summary of conversation.',
                encrypted_content='opaque-blob',
                type='compaction_delta',
            ),
        ),
        BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=1,
            content_block=BetaCompactionBlock(
                content='Second summary.', encrypted_content='start-only-opaque-blob', type='compaction'
            ),
        ),
        BetaRawContentBlockStopEvent(type='content_block_stop', index=1),
        BetaRawContentBlockStartEvent(
            type='content_block_start',
            index=2,
            content_block=BetaTextBlock(text='', type='text'),
        ),
        BetaRawContentBlockDeltaEvent(
            type='content_block_delta',
            index=2,
            delta=BetaTextDelta(type='text_delta', text='Here is my response.'),
        ),
        BetaRawContentBlockStopEvent(type='content_block_stop', index=2),
        BetaRawMessageDeltaEvent(
            type='message_delta',
            delta=Delta(stop_reason='end_turn'),
            usage=BetaMessageDeltaUsage(output_tokens=15),
        ),
        BetaRawMessageStopEvent(type='message_stop'),
    ]

    mock_client = MockAnthropic.create_stream_mock(stream)
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    async with agent.run_stream('Continue') as result:
        output = await result.get_output()
    assert output == 'Here is my response.'

    response_msgs = [msg for msg in result.all_messages() if isinstance(msg, ModelResponse)]
    assert len(response_msgs) == 1
    compaction_parts = [p for p in response_msgs[0].parts if isinstance(p, CompactionPart)]
    assert compaction_parts == snapshot(
        [
            CompactionPart(
                content='Updated summary of conversation.',
                provider_name='anthropic',
                provider_details={'encrypted_content': 'opaque-blob'},
            ),
            CompactionPart(
                content='Second summary.',
                provider_name='anthropic',
                provider_details={'encrypted_content': 'start-only-opaque-blob'},
            ),
        ]
    )


async def test_anthropic_compaction_only_response(allow_model_requests: None):
    """Test that a compaction-only response (pause_after_compaction=True) uses content as text output."""
    mock_client = MockAnthropic.create_mock(
        completion_message(
            [BetaCompactionBlock(content='Summary of prior conversation.', type='compaction')],
            BetaUsage(input_tokens=100, output_tokens=20),
        ),
    )
    m = AnthropicModel('claude-sonnet-4-6', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m)

    result = await agent.run('Continue our conversation')
    assert result.output == 'Summary of prior conversation.'

    all_msgs = result.all_messages()
    compaction_parts = [
        p for msg in all_msgs if isinstance(msg, ModelResponse) for p in msg.parts if isinstance(p, CompactionPart)
    ]
    assert len(compaction_parts) >= 1
    assert compaction_parts[0].content == 'Summary of prior conversation.'


async def test_anthropic_compaction_end_to_end(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """End-to-end test: Anthropic returns a compaction block when context exceeds threshold."""
    from pydantic_ai.messages import CompactionPart

    model = anthropic_model('claude-sonnet-4-6', capture=True)

    padding = 'The quick brown fox jumps over the lazy dog. ' * 5000  # ~230k chars ≈ ~55k tokens
    agent = Agent(
        model=model,
        instructions='You are a helpful assistant. Be very brief.',
        capabilities=[AnthropicCompaction(token_threshold=50_000)],
    )

    result = await agent.run(f'Remember this context: {padding}\n\nNow say hello.')

    # The history shape the second turn actually replays. The cassette records a different message
    # count, from before the compaction rendering changed; unrelated to this PR.
    assert message_shape(request_capture.body()) == snapshot([('user', ['text'])])

    all_msgs = result.all_messages()
    compaction_parts = [
        part
        for msg in all_msgs
        if isinstance(msg, ModelResponse)
        for part in msg.parts
        if isinstance(part, CompactionPart)
    ]
    assert len(compaction_parts) >= 1, (
        f'Expected compaction in response, got parts: {[type(p).__name__ for msg in all_msgs if isinstance(msg, ModelResponse) for p in msg.parts]}'
    )
    compaction = compaction_parts[0]
    assert compaction.provider_name == 'anthropic'
    assert compaction.content is not None

    result2 = await agent.run('What did I ask you to do?', message_history=result.all_messages())
    assert result2.output


async def test_anthropic_compaction_usage_with_cache(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """Verify usage aggregation when compaction + prompt caching interact in a real response.

    The Anthropic compaction docs only say top-level `input_tokens`/`output_tokens` exclude
    compaction iteration usage — they're silent on cache tokens. This cassette pins the real
    shape: top-level `cache_creation_input_tokens` is `0` even though the compaction iteration
    wrote ~55k tokens to cache, so `_map_usage` must sum the compaction cache back in to avoid
    understating the real cost.

    Where the cache breakpoints sit is asserted off the wire rather than the cassette, because a
    breakpoint that moves still replays against a recording that pins the old position.
    """
    model = anthropic_model('claude-sonnet-4-6', capture=True)
    padding = 'The quick brown fox jumps over the lazy dog. ' * 5000  # ~55k tokens
    agent = Agent(
        model=model,
        instructions='You are a helpful assistant. Be very brief.',
        capabilities=[AnthropicCompaction(token_threshold=50_000)],
        model_settings=AnthropicModelSettings(anthropic_cache=True),
    )

    result = await agent.run(f'Remember this context: {padding}\n\nNow say hello.')
    assert cache_breakpoints(request_capture.body()) == snapshot(({'type': 'ephemeral', 'ttl': '5m'}, []))
    assert result.usage == snapshot(
        RunUsage(
            input_tokens=55425,
            cache_write_tokens=55096,
            output_tokens=136,
            details={
                'input_tokens': 229,
                'output_tokens': 5,
                'cache_creation_input_tokens': 0,
                'cache_read_input_tokens': 0,
                'compaction_iterations': 1,
                'message_iterations': 1,
                'compaction_input_tokens': 100,
                'compaction_output_tokens': 131,
                'compaction_cache_creation_input_tokens': 55096,
            },
            requests=1,
            cost=Decimal('0.209637'),
        )
    )


async def test_anthropic_compaction_usage_with_cache_streaming(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    """Same as the non-streaming variant, but via `agent.run_stream`. The real API sends the
    `iterations` array on the `message_delta` event (not `message_start`), so this pins the
    merge-across-events path — specifically that the compaction cache (55k tokens) survives
    the delta overwriting the top-level cache fields back to 0.

    This one records a cache *read* where the non-streaming variant records a write: the padding
    is identical, so whichever test records second finds the prefix already cached. That makes the
    pair cover both compaction cache directions, `_read_` here and `_creation_` there.
    """
    model = anthropic_model('claude-sonnet-4-6', capture=True)
    padding = 'The quick brown fox jumps over the lazy dog. ' * 5000
    agent = Agent(
        model=model,
        instructions='You are a helpful assistant. Be very brief.',
        capabilities=[AnthropicCompaction(token_threshold=50_000)],
        model_settings=AnthropicModelSettings(anthropic_cache=True),
    )

    async with agent.run_stream(f'Remember this context: {padding}\n\nNow say hello.') as result:
        async for _ in result.stream_text():
            pass
        usage = result.usage
    assert cache_breakpoints(request_capture.body()) == snapshot(({'type': 'ephemeral', 'ttl': '5m'}, []))
    assert usage == snapshot(
        RunUsage(
            input_tokens=55377,
            cache_read_tokens=55096,
            output_tokens=91,
            details={
                'input_tokens': 181,
                'output_tokens': 8,
                'cache_creation_input_tokens': 0,
                'cache_read_input_tokens': 0,
                'compaction_iterations': 1,
                'message_iterations': 1,
                'compaction_input_tokens': 100,
                'compaction_output_tokens': 83,
                'compaction_cache_read_input_tokens': 55096,
            },
            requests=1,
            cost=Decimal('0.0187368'),
        )
    )


@pytest.mark.parametrize(
    'top_level,per_provider,expected',
    [
        pytest.param('auto', None, 'auto', id='top_level_auto'),
        pytest.param('default', None, 'standard_only', id='top_level_default_maps_to_standard_only'),
        pytest.param('flex', None, None, id='top_level_flex_omitted'),
        pytest.param('priority', None, None, id='top_level_priority_omitted'),
        pytest.param(None, 'standard_only', 'standard_only', id='per_provider_standard_only'),
        pytest.param('flex', 'auto', 'auto', id='per_provider_wins'),
    ],
)
async def test_anthropic_service_tier_mapping(
    allow_model_requests: None,
    top_level: Literal['auto', 'default', 'flex', 'priority'] | None,
    per_provider: Literal['auto', 'standard_only'] | None,
    expected: str | None,
):
    """Top-level `service_tier` maps to Anthropic's request value; `anthropic_service_tier` overrides."""
    settings = AnthropicModelSettings()
    if top_level is not None:
        settings['service_tier'] = top_level
    if per_provider is not None:
        settings['anthropic_service_tier'] = per_provider

    c = completion_message([BetaTextBlock(text='ok', type='text')], BetaUsage(input_tokens=1, output_tokens=1))
    mock_client = MockAnthropic.create_mock(c)
    m = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(m, model_settings=settings)

    await agent.run('hello')

    kwargs = get_mock_chat_completion_kwargs(mock_client)[0]
    if expected is None:
        assert 'service_tier' not in kwargs or kwargs['service_tier'] is OMIT
    else:
        assert kwargs['service_tier'] == expected


async def test_pause_turn_continues_run(allow_model_requests: None):
    c1 = completion_message([BetaTextBlock(text='paused', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
    c1.stop_reason = 'pause_turn'
    c2 = completion_message([BetaTextBlock(text='final', type='text')], BetaUsage(input_tokens=7, output_tokens=3))
    # A real `pause_turn` continuation appends new content under a fresh response id, so give the
    # segments distinct ids (they accumulate rather than replace) and distinct usage (so the merged
    # total exercises the sum, not a single segment's value).
    c2.id = '456'

    mock_client = MockAnthropic.create_mock([c1, c2])
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model)

    result = await agent.run('test prompt')

    # Both segments' text is retained (accumulate), and the merged usage sums the two.
    assert result.output == 'pausedfinal'
    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='test prompt', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='paused'), TextPart(content='final')],
                usage=RequestUsage(
                    input_tokens=17,
                    output_tokens=8,
                    details={'input_tokens': 17, 'output_tokens': 8},
                    cost=Decimal('0.0000456'),
                ),
                model_name='claude-3-5-haiku-123',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='456',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_pause_turn_exceeds_max_generation_continuations(allow_model_requests: None):
    """Test that exceeding the default generation-continuation limit raises `UnexpectedModelBehavior`."""
    responses: list[BetaMessage | Exception] = []
    for i in range(11):
        c = completion_message([BetaTextBlock(text='paused', type='text')], BetaUsage(input_tokens=10, output_tokens=5))
        c.stop_reason = 'pause_turn'
        # Distinct ids so each pause accumulates (real `pause_turn` behavior), hitting the accumulate cap
        # rather than the far larger same-id replace-poll backstop.
        c.id = str(i)
        responses.append(c)

    mock_client = MockAnthropic.create_mock(responses)
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model)

    with pytest.raises(UnexpectedModelBehavior, match='suspended more than the maximum of 10 times'):
        await agent.run('test prompt', usage_limits=UsageLimits(request_limit=None))


@pytest.mark.vcr()
async def test_pause_turn_web_search_vcr(
    allow_model_requests: None, anthropic_model: AnthropicModelFactory, request_capture: RequestCapture
):
    model = anthropic_model('claude-sonnet-4-5', capture=True)
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 4096}, max_tokens=15000)
    agent = Agent(model, capabilities=[NativeTool(WebSearchTool())], model_settings=settings)

    prompt = (
        'Run a series of web searches to gather up-to-date context. '
        'Do 6 separate searches, one at a time, and do not answer until all searches are complete. '
        'Queries: '
        '1) "San Francisco weather today", '
        '2) "San Francisco sunrise time today", '
        '3) "Golden Gate Bridge traffic today", '
        '4) "San Francisco air quality today", '
        '5) "San Francisco events this week", '
        '6) "San Francisco ferry schedule today". '
        '7) "prevailing information on quantum computing today", '
        '8) "latest news on the stock market today", '
        '9) "latest news on the weather in San Francisco today", '
        '10) "latest news on the traffic in San Francisco today", '
        '11) "latest news on the air quality in San Francisco today", '
        '12) "latest news on the events in San Francisco this week", '
        '13) "latest news on the ferry schedule in San Francisco today", '
        '14) "latest news on the quantum computing in San Francisco today", '
        '15) "latest news on the stock market in San Francisco today", '
        'After the searches, provide a concise summary.'
    )

    result = await agent.run(prompt)

    assert (request_capture.body()['tools'], request_capture.body().get('tool_choice')) == snapshot(
        (
            [
                {
                    'name': 'web_search',
                    'type': 'web_search_20250305',
                    'max_uses': None,
                    'allowed_domains': None,
                    'blocked_domains': None,
                    'user_location': None,
                }
            ],
            None,
        )
    )

    # `pause_turn` responses are stitched into the final merged response by the continuation loop,
    # so they no longer appear as separate messages in the history. Verify the agent completed
    # successfully, which exercises the (non-streaming) continuation path end-to-end.
    assert result.output


@pytest.mark.vcr()
async def test_pause_turn_web_search_streaming_vcr(allow_model_requests: None, anthropic_api_key: str):
    """Real streamed `pause_turn` continuation: server-side web search pauses the turn mid-stream.

    The streamed-continuation composite stitches every `messages.create(stream=True)` segment (the
    paused turn echoed back) into one `AgentStream`. Because Anthropic `pause_turn` continuations
    *accumulate* fresh parts, the stitched `PartStartEvent` indices must strictly increase across the
    pause (each new part offset past all prior ones, no index collision), and the final merged
    response must be a single coherent turn. This validates the accumulate reindex rule against real
    provider part-indexing.
    """
    model = AnthropicModel('claude-sonnet-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    settings = AnthropicModelSettings(anthropic_thinking={'type': 'enabled', 'budget_tokens': 4096}, max_tokens=15000)
    agent = Agent(model, capabilities=[NativeTool(WebSearchTool())], model_settings=settings)

    prompt = (
        'Run a series of web searches to gather up-to-date context. '
        'Do 6 separate searches, one at a time, and do not answer until all searches are complete. '
        'Queries: '
        '1) "San Francisco weather today", '
        '2) "San Francisco sunrise time today", '
        '3) "Golden Gate Bridge traffic today", '
        '4) "San Francisco air quality today", '
        '5) "San Francisco events this week", '
        '6) "San Francisco ferry schedule today". '
        '7) "prevailing information on quantum computing today", '
        '8) "latest news on the stock market today", '
        '9) "latest news on the weather in San Francisco today", '
        '10) "latest news on the traffic in San Francisco today", '
        '11) "latest news on the air quality in San Francisco today", '
        '12) "latest news on the events in San Francisco this week", '
        '13) "latest news on the ferry schedule in San Francisco today", '
        '14) "latest news on the quantum computing in San Francisco today", '
        '15) "latest news on the stock market in San Francisco today", '
        'After the searches, provide a concise summary.'
    )

    part_start_indices: list[int] = []
    request_stream_count = 0
    merged: ModelResponse | None = None
    async with agent.iter(prompt) as agent_run:
        node = agent_run.next_node
        while not isinstance(node, End):
            if isinstance(node, ModelRequestNode):
                async with node.stream(agent_run.ctx) as stream:
                    request_stream_count += 1
                    async for event in stream:
                        if isinstance(event, PartStartEvent):
                            part_start_indices.append(event.index)
                    merged = stream.response
            node = await agent_run.next(node)

    # The whole paused turn is stitched inside one `ModelRequestNode`, streamed once.
    assert request_stream_count == 1
    # Accumulate reindexing: each stitched part gets a strictly higher index than the previous one,
    # so segments from before and after the pause never collide.
    assert part_start_indices == sorted(set(part_start_indices))
    assert part_start_indices[0] == 0
    assert len(part_start_indices) > 1  # the turn spans multiple parts across the pause
    # The stitched result is a single coherent, completed turn.
    assert merged is not None
    assert merged.state == 'complete'
    assert agent_run.result
    assert agent_run.result.output


async def test_pause_turn_streaming_continuation(allow_model_requests: None):
    """`pause_turn` continuations are stitched into one streamed response with offset part indices.

    Every segment is streamed inside a single `ModelRequestNode`, so streaming that node once drives
    the whole `suspended → suspended → complete` chain. Because each `pause_turn` segment accumulates
    (fresh `provider_response_id`), the streamed `PartStartEvent` indices increase across segments and
    the final merged response carries all parts in order.
    """

    def _make_stream(text: str, stop_reason: str) -> list[BetaRawMessageStreamEvent]:
        return [
            BetaRawMessageStartEvent(
                type='message_start',
                message=BetaMessage(
                    id=f'msg_{text}',
                    model='claude-3-5-haiku-123',
                    role='assistant',
                    type='message',
                    content=[],
                    stop_reason=None,
                    usage=BetaUsage(input_tokens=10, output_tokens=0),
                ),
            ),
            BetaRawContentBlockStartEvent(
                type='content_block_start',
                index=0,
                content_block=BetaTextBlock(type='text', text=text),
            ),
            BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
            BetaRawMessageDeltaEvent(
                type='message_delta',
                delta=Delta(stop_reason=cast(Any, stop_reason)),
                usage=BetaMessageDeltaUsage(input_tokens=10, output_tokens=5),
            ),
            BetaRawMessageStopEvent(type='message_stop'),
        ]

    # All three segments are streamed: the composite opens one `request_stream` per segment as it
    # stitches `pause_turn → pause_turn → end_turn` into a single streamed response.
    mock_client = cast(
        AsyncAnthropic,
        MockAnthropic(
            stream=[
                _make_stream('first', 'pause_turn'),
                _make_stream('second', 'pause_turn'),
                _make_stream('done', 'end_turn'),
            ],
        ),
    )
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model)

    part_start_indices: list[int] = []
    async with agent.iter('test prompt') as agent_run:
        node = agent_run.next_node
        while not isinstance(node, End):
            if isinstance(node, ModelRequestNode):
                async with node.stream(agent_run.ctx) as stream:
                    async for event in stream:
                        if isinstance(event, PartStartEvent):
                            part_start_indices.append(event.index)
            node = await agent_run.next(node)

    # Each `pause_turn` segment appends a fresh text part, so the stitched indices increase.
    assert part_start_indices == snapshot([0, 1, 2])
    assert agent_run.result
    assert agent_run.result.output == snapshot('firstseconddone')


async def test_pause_turn_streaming_continuation_stream_error(allow_model_requests: None):
    """An error mid-stream during a `pause_turn` continuation propagates cleanly out of the node."""

    # First segment streams a `pause_turn`, the continuation segment raises mid-stream.
    def _make_stream(text: str, stop_reason: str) -> list[MockRawMessageStreamEvent]:
        return [
            BetaRawMessageStartEvent(
                type='message_start',
                message=BetaMessage(
                    id=f'msg_{text}',
                    model='claude-3-5-haiku-123',
                    role='assistant',
                    type='message',
                    content=[],
                    stop_reason=None,
                    usage=BetaUsage(input_tokens=10, output_tokens=0),
                ),
            ),
            BetaRawContentBlockStartEvent(
                type='content_block_start', index=0, content_block=BetaTextBlock(type='text', text=text)
            ),
            BetaRawContentBlockStopEvent(type='content_block_stop', index=0),
            BetaRawMessageDeltaEvent(
                type='message_delta',
                delta=Delta(stop_reason=cast(Any, stop_reason)),
                usage=BetaMessageDeltaUsage(input_tokens=10, output_tokens=5),
            ),
            BetaRawMessageStopEvent(type='message_stop'),
        ]

    error_stream: list[MockRawMessageStreamEvent] = [
        BetaRawMessageStartEvent(
            type='message_start',
            message=BetaMessage(
                id='msg_err',
                model='claude-3-5-haiku-123',
                role='assistant',
                type='message',
                content=[],
                stop_reason=None,
                usage=BetaUsage(input_tokens=10, output_tokens=0),
            ),
        ),
        RuntimeError('stream exploded'),
    ]

    mock_client = cast(
        AsyncAnthropic,
        MockAnthropic(stream=[_make_stream('first', 'pause_turn'), error_stream]),
    )
    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(anthropic_client=mock_client))
    agent = Agent(model)

    async with agent.iter('test prompt') as agent_run:
        node = agent_run.next_node
        while not isinstance(node, End):
            if isinstance(node, ModelRequestNode):
                with pytest.raises(RuntimeError, match='stream exploded'):
                    async with node.stream(agent_run.ctx) as stream:
                        async for _event in stream:
                            pass
                break
            node = await agent_run.next(node)


async def test_anthropic_model_retrying_after_empty_response(allow_model_requests: None, anthropic_api_key: str):
    """An empty `ModelResponse` in history is omitted from the payload; a retry prompt is sent
    instead so the model can produce a non-empty response. Anthropic accepts the resulting
    consecutive user turns.
    """
    message_history = [
        ModelRequest(parts=[UserPromptPart(content='Hi')]),
        ModelResponse(parts=[]),
    ]

    model = AnthropicModel('claude-haiku-4-5', provider=AnthropicProvider(api_key=anthropic_api_key))
    agent = Agent(model=model)

    result = await agent.run(message_history=message_history)
    assert result.output == snapshot("""\
# Hi there! 👋

How can I help you today?\
""")
    assert result.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    RetryPromptPart(
                        content='Please return text.',
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    TextPart(
                        content="""\
# Hi there! 👋

How can I help you today?\
"""
                    )
                ],
                usage=RequestUsage(
                    input_tokens=26,
                    output_tokens=18,
                    details={
                        'input_tokens': 26,
                        'output_tokens': 18,
                        'cache_creation_input_tokens': 0,
                        'cache_read_input_tokens': 0,
                    },
                    cost=Decimal('0.000116'),
                ),
                model_name='claude-haiku-4-5-20251001',
                timestamp=IsDatetime(),
                provider_name='anthropic',
                provider_url='https://api.anthropic.com',
                provider_details={'finish_reason': 'end_turn'},
                provider_response_id='msg_011Ccmc3JDrLNAjTnX1WNbcp',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )
