import inspect
import logging
from contextvars import Token
from datetime import datetime
from typing import Any, Dict, List, Literal, Mapping, Optional, Sequence, Union, cast

import llama_index_instrumentation as instrument
from llama_index.observability.otel.utils import _is_otel_supported_type, flatten_dict
from llama_index_instrumentation.base.event import BaseEvent
from llama_index_instrumentation.event_handlers import BaseEventHandler
from llama_index_instrumentation.span import SimpleSpan, active_span_id
from llama_index_instrumentation.span_handlers.simple import SimpleSpanHandler
from opentelemetry import context, propagate, trace
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
    SpanExporter,
)
from opentelemetry.trace import set_span_in_context
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr
from termcolor.termcolor import cprint

_logger = logging.getLogger(__name__)


class OTelEventAttributes(BaseModel):
    name: str
    attributes: Optional[
        Mapping[
            str,
            Union[
                str,
                bool,
                int,
                float,
                Sequence[str],
                Sequence[bool],
                Sequence[int],
                Sequence[float],
            ],
        ]
    ]


class OTelCompatibleSpanHandler(SimpleSpanHandler):
    """OpenTelemetry-compatible span handler."""

    _tracer: trace.Tracer = PrivateAttr()
    _tracer_provider: Optional[TracerProvider] = PrivateAttr(default=None)
    _events_by_span: Dict[str, List[OTelEventAttributes]] = PrivateAttr(
        default_factory=dict,
    )
    _context_tokens: Dict[str, Token[context.Context]] = PrivateAttr(
        default_factory=dict
    )
    _previous_contexts: Dict[str, context.Context] = PrivateAttr(default_factory=dict)
    all_spans: Dict[str, trace.Span] = Field(
        default_factory=dict, description="All the registered OpenTelemetry spans."
    )
    debug: bool = Field(
        default=False,
        description="Debug the start and end of span and the recording of events",
    )

    def __init__(
        self,
        tracer: trace.Tracer,
        debug: bool = False,
        open_spans: Optional[Dict[str, SimpleSpan]] = None,
        completed_spans: Optional[List[SimpleSpan]] = None,
        dropped_spans: Optional[List[SimpleSpan]] = None,
        current_span_ids: Optional[Dict[Any, str]] = None,
        tracer_provider: Optional[TracerProvider] = None,
    ):
        super().__init__(
            open_spans=open_spans or {},
            completed_spans=completed_spans or [],
            dropped_spans=dropped_spans or [],
            current_span_ids=cast(Dict[str, Any], current_span_ids or {}),
        )
        self._tracer = tracer
        self._tracer_provider = tracer_provider
        self._events_by_span = {}
        self._context_tokens = {}
        self._previous_contexts = {}
        self.debug = debug

    def close(self) -> None:
        """Flush and shut down the OTel tracer provider."""
        provider = self._tracer_provider
        if provider is None:
            # Fall back to the global tracer provider
            global_provider = trace.get_tracer_provider()
            if isinstance(global_provider, TracerProvider):
                provider = global_provider
        if provider is not None:
            try:
                provider.shutdown()
            except BaseException:
                _logger.warning("Error shutting down tracer provider", exc_info=True)

    @classmethod
    def class_name(cls) -> str:  # type: ignore
        """Class name."""
        return "OTelCompatibleSpanHandler"

    _PROPAGATION_KEY = "otel"

    def capture_propagation_context(self) -> Dict[str, Any]:
        """Serialize the current OTel trace context for cross-process propagation."""
        carrier: Dict[str, str] = {}
        propagate.inject(carrier)
        if carrier:
            return {self._PROPAGATION_KEY: carrier}
        return {}

    def restore_propagation_context(self, ctx: Dict[str, Any]) -> None:
        """Restore OTel trace context from a serialized carrier dict."""
        carrier = ctx.get(self._PROPAGATION_KEY)
        if carrier:
            restored = propagate.extract(carrier)
            context.attach(restored)

    def _get_parent_context(self, parent_span_id: Optional[str]) -> context.Context:
        ctx = context.get_current()
        current_span_context = trace.get_current_span(ctx).get_span_context()
        if (
            current_span_context.is_valid
            or parent_span_id is None
            or parent_span_id not in self.all_spans
        ):
            return ctx
        return set_span_in_context(span=self.all_spans[parent_span_id])

    def _add_events_to_span(self, id_: str, span: trace.Span) -> None:
        events = self._events_by_span.pop(id_, [])
        for event in events:
            span.add_event(name=event.name, attributes=event.attributes)

    def _detach_context_and_end_span(self, id_: str, span: trace.Span) -> None:
        token = self._context_tokens.pop(id_, None)
        previous_context = self._previous_contexts.pop(id_, None)
        try:
            if token is not None:
                token.var.reset(token)
        except ValueError as err:
            if "different Context" not in str(err):
                _logger.warning(
                    "Error detaching OTel context for %s", id_, exc_info=True
                )
            elif previous_context is not None and trace.get_current_span() is span:
                context.attach(previous_context)
        except BaseException:
            _logger.warning("Error detaching OTel context for %s", id_, exc_info=True)
        finally:
            span.end()

    def new_span(
        self,
        id_: str,
        bound_args: inspect.BoundArguments,
        instance: Optional[Any] = None,
        parent_span_id: Optional[str] = None,
        tags: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> SimpleSpan:
        span = super().new_span(
            id_, bound_args, instance, parent_span_id, tags, **kwargs
        )

        # Strip UUID suffix from span name for clean grouping
        span_name = id_.partition("-")[0]

        # Resolve parent context:
        # 1. Same-process parent found in all_spans → use it
        # 2. Otherwise → use ambient OTel context (set by restore_propagation_context
        #    for cross-process, or inherited naturally for same-process roots)
        ctx = self._get_parent_context(parent_span_id)

        otel_span = self._tracer.start_span(name=span_name, context=ctx)
        self.all_spans.update({id_: otel_span})

        current_context = context.get_current()
        token = context.attach(set_span_in_context(otel_span))
        self._context_tokens[id_] = token
        self._previous_contexts[id_] = current_context

        # Record instrument_tags as span attributes
        if tags is not None:
            for key, value in tags.items():
                if _is_otel_supported_type(value):
                    attr_key = key if "." in key else f"llamaindex.{key}"
                    otel_span.set_attribute(attr_key, value)

        if self.debug:
            cprint(
                f"Emitting span {span_name} at time: {datetime.now()}",
                color="yellow",
                attrs=["bold"],
            )
        return span

    def prepare_to_exit_span(
        self,
        id_: str,
        bound_args: inspect.BoundArguments,
        instance: Optional[Any] = None,
        result: Optional[Any] = None,
        **kwargs: Any,
    ) -> SimpleSpan:
        if self.debug:
            cprint(
                f"Preparing to end span {id_} at time: {datetime.now()}",
                color="blue",
                attrs=["bold"],
            )
        sp = super().prepare_to_exit_span(id_, bound_args, instance, result, **kwargs)
        span = self.all_spans.pop(id_, None)
        if span is None:
            _logger.warning("No OTel span found for %s in prepare_to_exit_span", id_)
            return sp

        self._add_events_to_span(id_, span)
        span.set_status(status=trace.StatusCode.OK)
        self._detach_context_and_end_span(id_, span)
        return sp

    def prepare_to_drop_span(
        self,
        id_: str,
        bound_args: inspect.BoundArguments,
        instance: Optional[Any] = None,
        err: Optional[BaseException] = None,
        **kwargs: Any,
    ) -> Optional[SimpleSpan]:
        if self.debug:
            cprint(
                f"Preparing to exit span {id_} with an error at time: {datetime.now()}",
                color="red",
                attrs=["bold"],
            )
        sp = super().prepare_to_drop_span(id_, bound_args, instance, err, **kwargs)
        span = self.all_spans.pop(id_, None)
        if span is None:
            _logger.warning("No OTel span found for %s in prepare_to_drop_span", id_)
            return sp

        self._add_events_to_span(id_, span)
        if err is not None:
            span.record_exception(err)
        span.set_status(status=trace.StatusCode.ERROR, description=err.__str__())
        self._detach_context_and_end_span(id_, span)
        return sp


class OTelCompatibleEventHandler(BaseEventHandler):
    """OpenTelemetry-compatible event handler."""

    span_handler: OTelCompatibleSpanHandler = Field(
        description="Span Handler associated with the event handler"
    )
    debug: bool = Field(
        default=False,
        description="Debug the start and end of span and the recording of events",
    )

    @classmethod
    def class_name(cls) -> str:
        """Class name."""
        return "OtelCompatibleEventHandler"

    def handle(self, event: BaseEvent, **kwargs: Any) -> None:
        """Handle events by pushing them to the correct span's bucket for later attachment to OpenTelemetry."""
        if self.debug:
            cprint(
                f"Registering a {event.class_name()} event at time: {datetime.now()}",
                color="green",
                attrs=["bold"],
            )

        # Prefer the span id the event was stamped with, falling back to the
        # ambient contextvar.
        #
        # Events dispatched from inside a streaming generator cannot rely on
        # the contextvar: the generator body runs in the *consumer's* context,
        # long after the coroutine that created it returned and reset
        # `active_span_id`. That is why the streaming wrappers in
        # `llama_index.core.llms.callbacks` capture `active_span_id.get()`
        # eagerly and pass it explicitly (`LLMChatInProgressEvent(...,
        # span_id=span_id)`). Reading only the contextvar here discards that
        # and silently drops every streamed event.
        current_span_id = event.span_id or active_span_id.get()
        if current_span_id is None:
            # The event is happening outside of any span - nothing to do
            return

        # Only buffer events for a span that is currently open. `all_spans`
        # holds a span between `new_span` and `prepare_to_exit_span`/
        # `prepare_to_drop_span`, and those flush the buffer with a `pop`.
        # Without this check, an event stamped with an already-ended span id
        # would create a bucket that nothing ever drains — an unbounded leak
        # in long-running processes.
        if current_span_id not in self.span_handler.all_spans:
            if self.debug:
                cprint(
                    f"Discarding a {event.class_name()} event for span "
                    f"{current_span_id}, which is not open",
                    color="red",
                    attrs=["bold"],
                )
            return

        try:
            event_data = event.model_dump()
        except TypeError:
            # Some events can be unserializable,
            # so we just convert to a string as a fallback
            event_data = {"event_data": str(event)}

        otel_event = OTelEventAttributes(
            name=event.class_name(), attributes=flatten_dict(event_data)
        )

        self.span_handler._events_by_span.setdefault(current_span_id, []).append(
            otel_event
        )


class LlamaIndexOpenTelemetry(BaseModel):
    """
    LlamaIndexOpenTelemetry is a configuration and integration class for OpenTelemetry tracing within LlamaIndex.
    This class manages the setup and registration of OpenTelemetry span and event handlers, configures the tracer provider,
    and exports trace data using the specified span exporter and processor. It supports both simple and batch span processors,
    and allows customization of the service name or resource, as well as the dispatcher name.

    Attributes:
        span_exporter (Optional[SpanExporter]): The OpenTelemetry span exporter. Defaults to ConsoleSpanExporter.
        span_processor (Literal["simple", "batch"]): The span processor type, either 'simple' or 'batch'. Defaults to 'batch'.
        service_name_or_resource (Union[str, Resource]): The service name or OpenTelemetry Resource. Defaults to a Resource with service name 'llamaindex.opentelemetry'.

    """

    model_config = ConfigDict(arbitrary_types_allowed=True)
    span_exporter: Optional[SpanExporter] = Field(
        default=ConsoleSpanExporter(),
        description="OpenTelemetry span exporter. Supports all SpanExporter-compatible interfaces, defaults to ConsoleSpanExporter.",
    )
    span_processor: Literal["simple", "batch"] = Field(
        default="batch",
        description="OpenTelemetry span processor. Can be either 'batch' (-> BatchSpanProcessor), 'simple' (-> SimpleSpanProcessor). Defaults to 'batch'",
    )
    extra_span_processors: List[SpanProcessor] = Field(
        default_factory=list,
        description="List of OpenTelemetry Span Processors to add to the tracer provider.",
    )
    tracer_provider: Optional[TracerProvider] = Field(
        default=None,
        description="Tracer Provider to inherint from the existing observability context. Defaults to None.",
    )
    service_name_or_resource: Union[str, Resource] = Field(
        default=Resource(attributes={SERVICE_NAME: "llamaindex.opentelemetry"}),
        description="Service name or resource for OpenTelemetry. Defaults to a Resource with 'llamaindex.opentelemetry' as service name.",
    )
    debug: bool = Field(
        default=False,
        description="Debug the start and end of span and the recording of events",
    )
    _tracer: Optional[trace.Tracer] = PrivateAttr(default=None)
    _tracer_provider_instance: Optional[TracerProvider] = PrivateAttr(default=None)

    def _start_otel(
        self,
    ) -> None:
        if isinstance(self.service_name_or_resource, str):
            self.service_name_or_resource = Resource(
                attributes={SERVICE_NAME: self.service_name_or_resource}
            )
        if self.tracer_provider is None:
            tracer_provider = TracerProvider(resource=self.service_name_or_resource)
        else:
            tracer_provider = self.tracer_provider
        assert self.span_exporter is not None, (
            "span_exporter has to be non-null to be used within simple or batch span processors"
        )
        span_processor: SpanProcessor
        if self.span_processor == "simple":
            span_processor = SimpleSpanProcessor(self.span_exporter)
        else:
            span_processor = BatchSpanProcessor(self.span_exporter)
        for extra_span_processor in self.extra_span_processors:
            tracer_provider.add_span_processor(extra_span_processor)
        tracer_provider.add_span_processor(span_processor)
        trace.set_tracer_provider(tracer_provider)
        self._tracer_provider_instance = tracer_provider
        self._tracer = trace.get_tracer("llamaindex.opentelemetry.tracer")

    def start_registering(
        self,
    ) -> None:
        """Starts LlamaIndex instrumentation."""
        self._start_otel()
        dispatcher = instrument.get_dispatcher()
        assert self._tracer is not None, (
            "The tracer has to be non-null to start observabiliy"
        )
        span_handler = OTelCompatibleSpanHandler(
            tracer=self._tracer,
            debug=self.debug,
            tracer_provider=self._tracer_provider_instance,
        )
        dispatcher.add_span_handler(span_handler)
        dispatcher.add_event_handler(
            OTelCompatibleEventHandler(span_handler=span_handler, debug=self.debug)
        )
