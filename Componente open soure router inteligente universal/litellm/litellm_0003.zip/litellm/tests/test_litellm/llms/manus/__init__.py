# Manus provider tests
