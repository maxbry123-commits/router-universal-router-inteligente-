"""Soniox audio transcription tests."""
