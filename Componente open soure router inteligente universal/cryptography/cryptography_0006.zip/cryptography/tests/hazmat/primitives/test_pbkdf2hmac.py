# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.


import typing

import pytest

from cryptography.exceptions import AlreadyFinalized, InvalidKey, _Reasons
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from ...doubles import DummyHashAlgorithm
from ...utils import raises_unsupported_algorithm


class TestPBKDF2HMAC:
    def test_already_finalized(self):
        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        kdf.derive(b"password")
        with pytest.raises(AlreadyFinalized):
            kdf.derive(b"password2")

        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        key = kdf.derive(b"password")
        with pytest.raises(AlreadyFinalized):
            kdf.verify(b"password", key)

        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        kdf.verify(b"password", key)
        with pytest.raises(AlreadyFinalized):
            kdf.verify(b"password", key)

    def test_unsupported_algorithm(self):
        with raises_unsupported_algorithm(_Reasons.UNSUPPORTED_HASH):
            PBKDF2HMAC(DummyHashAlgorithm(), 20, b"salt", 10)

    def test_invalid_key(self):
        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        key = kdf.derive(b"password")

        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        with pytest.raises(InvalidKey):
            kdf.verify(b"password2", key)

    def test_unicode_error_with_salt(self):
        with pytest.raises(TypeError):
            PBKDF2HMAC(hashes.SHA1(), 20, typing.cast(typing.Any, "salt"), 10)

    def test_unicode_error_with_key_material(self):
        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        with pytest.raises(TypeError):
            kdf.derive(typing.cast(typing.Any, "unicode here"))

    def test_buffer_protocol(self):
        kdf = PBKDF2HMAC(hashes.SHA1(), 10, b"salt", 10)
        data = bytearray(b"data")
        assert kdf.derive(data) == b"\xe9n\xaa\x81\xbbt\xa4\xf6\x08\xce"

    def test_derive_into(self):
        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        buf = bytearray(20)
        n = kdf.derive_into(b"password", buf)
        assert n == 20
        # Verify the output matches what derive would produce
        kdf2 = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        expected = kdf2.derive(b"password")
        assert buf == expected

    @pytest.mark.parametrize(("buflen", "outlen"), [(19, 20), (21, 20)])
    def test_derive_into_buffer_incorrect_size(self, buflen, outlen):
        kdf = PBKDF2HMAC(hashes.SHA1(), outlen, b"salt", 10)
        buf = bytearray(buflen)
        with pytest.raises(ValueError, match="buffer must be"):
            kdf.derive_into(b"password", buf)

    def test_derive_into_already_finalized(self):
        kdf = PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 10)
        buf = bytearray(20)
        kdf.derive_into(b"password", buf)
        with pytest.raises(AlreadyFinalized):
            kdf.derive_into(b"password2", buf)

    def test_zero_iterations(self):
        with pytest.raises(ValueError, match="iterations must be"):
            PBKDF2HMAC(hashes.SHA1(), 20, b"salt", 0)
