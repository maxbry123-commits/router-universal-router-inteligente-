from huggingface_hub.utils._runtime import is_google_colab, is_notebook


class TestRuntimeUtils:
    def test_is_notebook(self) -> None:
        """Test `is_notebook`."""
        assert not is_notebook()

    def test_is_google_colab(self) -> None:
        """Test `is_google_colab`."""
        assert not is_google_colab()
