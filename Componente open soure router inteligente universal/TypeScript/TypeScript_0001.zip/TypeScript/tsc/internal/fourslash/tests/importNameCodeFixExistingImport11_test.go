package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestImportNameCodeFixExistingImport11(t *testing.T) {
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `import [|{
    v1, v2,
    v3
}|] from "./module";
f1/*0*/();
// @Filename: module.ts
 export function f1() {}
 export var v1 = 5;
 export var v2 = 5;
 export var v3 = 5;`
	f, done := fourslash.NewFourslash(t, nil /*capabilities*/, content)
	defer done()
	f.VerifyImportFixAtPosition(t, []string{
		`{
    f1,
    v1, v2,
    v3
}`,
	}, nil /*preferences*/)
}
