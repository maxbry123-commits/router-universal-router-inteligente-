package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestDocCommentTemplateVariableStatements01(t *testing.T) {
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `/*a*/
var a = 10;

/*b*/
let b = "";

/*c*/
const c = 30;

/*d*/
let d = {
    foo: 10,
    bar: "20"
};

/*e*/
let e = function e(x, y, z) {
    return +(x + y + z);
};

/*f*/
let f = class F {
    constructor(a, b, c) {
        this.a = a;
        this.b = b || (this.c = c);
    }
}`
	capabilities := fourslash.GetDefaultCapabilities()
	capabilities.TextDocument.Completion.CompletionItem.SnippetSupport = new(false)
	f, done := fourslash.NewFourslash(t, capabilities, content)
	defer done()
	for _, varName := range []string{"a", "b", "c", "d"} {
		f.VerifyJSDocCompletion(t, varName, 3, `/** */`, nil)
	}
	f.VerifyJSDocCompletion(t, "e", 7, `/**
 * 
 * @param x
 * @param y
 * @param z
 * @returns
 */`, nil)
	f.VerifyJSDocCompletion(t, "f", 7, `/**
 * 
 * @param a
 * @param b
 * @param c
 */`, nil)
}
