package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestJsDocFunctionSignatures5(t *testing.T) {
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `// @strict: true
// @allowJs: true
// @Filename: Foo.js
/**
 * Filters a path based on a regexp or glob pattern.
 * @param {String} basePath The base path where the search will be performed.
 * @param {String} pattern A string defining a regexp of a glob pattern.
 * @param {String} type The search pattern type, can be a regexp or a glob.
 * @param {Object} options A object containing options to the search.
 * @return {Array} A list containing the filtered paths.
 */
function pathFilter(basePath, pattern, type, options){
//...
}
pathFilter(/**/'foo', 'bar', 'baz', {});`
	f, done := fourslash.NewFourslash(t, nil /*capabilities*/, content)
	defer done()
	f.VerifyBaselineSignatureHelp(t)
}
