//// [tests/cases/conformance/expressions/asOperator/asOperatorNames.ts] ////

//// [asOperatorNames.ts]
var a = 20;
var b = a as string;
var as = "hello";
var as1 = as as string;


//// [asOperatorNames.js]
"use strict";
var a = 20;
var b = a;
var as = "hello";
var as1 = as;
