//// [tests/cases/conformance/externalModules/umd7.ts] ////

//// [foo.d.ts]
declare function Thing(): number;
export = Thing;
export as namespace Foo;

//// [a.ts]
/// <reference path="foo.d.ts" />
let y: number = Foo();


//// [a.js]
"use strict";
/// <reference path="foo.d.ts" />
let y = Foo();
