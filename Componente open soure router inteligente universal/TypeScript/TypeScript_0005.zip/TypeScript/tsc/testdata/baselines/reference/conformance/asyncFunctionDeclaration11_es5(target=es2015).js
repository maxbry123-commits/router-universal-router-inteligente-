//// [tests/cases/conformance/async/es5/functionDeclarations/asyncFunctionDeclaration11_es5.ts] ////

//// [asyncFunctionDeclaration11_es5.ts]
async function await(): Promise<void> {
}

//// [asyncFunctionDeclaration11_es5.js]
"use strict";
function await() {
    return __awaiter(this, void 0, void 0, function* () {
    });
}
