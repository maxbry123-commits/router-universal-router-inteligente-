//// [tests/cases/conformance/es6/templates/templateStringMultiline1_ES6.ts] ////

//// [templateStringMultiline1_ES6.ts]
// newlines are <CR><LF>
`
\
`

//// [templateStringMultiline1_ES6.js]
"use strict";
// newlines are <CR><LF>
`
\
`;
