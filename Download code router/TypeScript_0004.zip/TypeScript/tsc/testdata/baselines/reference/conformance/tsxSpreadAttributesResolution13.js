//// [tests/cases/conformance/jsx/tsxSpreadAttributesResolution13.tsx] ////

//// [file.tsx]
/// <reference path="/.lib/react.d.ts" />

import React = require('react');

interface ComponentProps {
    property1: string;
    property2: number;
}

export default function Component(props: ComponentProps) {
    let condition1: boolean;
    if (condition1) {
        return (
            <ChildComponent {...props} />
        );
    }
    else {
        return (<ChildComponent {...props} property1="NewString" />);
    }
}

interface AnotherComponentProps {
    property1: string;
}

function ChildComponent({ property1 }: AnotherComponentProps) {
    return (
        <span>{property1}</span>
    );
}

//// [file.jsx]
"use strict";
/// <reference path="/.lib/react.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Component;
const React = require("react");
function Component(props) {
    let condition1;
    if (condition1) {
        return (<ChildComponent {...props}/>);
    }
    else {
        return (<ChildComponent {...props} property1="NewString"/>);
    }
}
function ChildComponent({ property1 }) {
    return (<span>{property1}</span>);
}
