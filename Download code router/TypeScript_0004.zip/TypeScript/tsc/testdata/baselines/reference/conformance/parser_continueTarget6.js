//// [tests/cases/conformance/parser/ecmascript5/Statements/ContinueStatements/parser_continueTarget6.ts] ////

//// [parser_continueTarget6.ts]
while (true) {
  continue target;
}

//// [parser_continueTarget6.js]
"use strict";
while (true) {
    continue target;
}
