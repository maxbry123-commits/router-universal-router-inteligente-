<script setup lang="ts">
import {
	AGENT_TASK_NAME_MAX_LENGTH,
	AGENT_TASK_OBJECTIVE_MAX_LENGTH,
	StrictTimeZoneSchema,
	type AgentTaskDto,
} from '@n8n/api-types';
import {
	N8nButton,
	N8nFormInput,
	N8nHeading,
	N8nIcon,
	N8nInput,
	N8nMarkdownEditor,
	N8nOption,
	N8nSelect,
	N8nSwitch2,
	N8nText,
	N8nTooltip,
} from '@n8n/design-system';
import type { IValidator, Validatable } from '@n8n/design-system';
import { useI18n, type BaseTextKey } from '@n8n/i18n';
import { useRootStore } from '@n8n/stores/useRootStore';
import { useSettingsStore } from '@n8n/stores/settings.store';
import { computed, onMounted, ref, watch } from 'vue';

import Modal from '@/app/components/Modal.vue';
import { useToast } from '@n8n/composables/useToast';
import { MODAL_CONFIRM } from '@/app/constants';
import { useUIStore } from '@/app/stores/ui.store';
import {
	createAgentTask,
	deleteAgentTask,
	runAgentTask,
	updateAgentTask,
} from '../composables/useAgentApi';
import { useAgentConfirmationModal } from '../composables/useAgentConfirmationModal';
import {
	buildCron,
	DEFAULT_SCHEDULE_PARTS,
	formatScheduleDateTime,
	formatTimeOfDay,
	getNextScheduleOccurrence,
	parseCron,
	type ScheduleFrequency,
	weekdayLabel,
} from '../utils/scheduleBuilder';

export type AgentTaskModalData = {
	projectId: string;
	agentId: string;
	task?: AgentTaskDto | null;
	isPublished: boolean;
	taskState?: {
		enabled: boolean;
	};
	onToggle?: (payload: { id: string; enabled: boolean }) => void;
	onSaved: () => void;
};

type FrequencyOption = ScheduleFrequency | 'custom';

const props = defineProps<{
	modalName: string;
	data: AgentTaskModalData;
}>();

const i18n = useI18n();
const rootStore = useRootStore();
const settingsStore = useSettingsStore();
const uiStore = useUIStore();
const toast = useToast();
const { openAgentConfirmationModal } = useAgentConfirmationModal();

const task = computed(() => props.data.task ?? null);
const isEditing = computed(() => Boolean(task.value));
// Editing a task on a published agent only changes the live schedule on the
// next publish (see AgentTaskService), so warn before the edit silently no-ops.
const showRepublishHint = computed(() => isEditing.value && props.data.isPublished);
const enabled = ref(props.data.taskState?.enabled ?? true);
const running = ref(false);
const deleting = ref(false);

const name = ref('');
const objective = ref('');
const frequency = ref<FrequencyOption>(DEFAULT_SCHEDULE_PARTS.frequency);
const minute = ref(DEFAULT_SCHEDULE_PARTS.minute);
const hour = ref(DEFAULT_SCHEDULE_PARTS.hour);
const dayOfWeek = ref(DEFAULT_SCHEDULE_PARTS.dayOfWeek);
const dayOfMonth = ref(DEFAULT_SCHEDULE_PARTS.dayOfMonth);
const customCron = ref('');
const timezone = ref(browserTimezone());
const timezoneOptions = ref<Array<{ value: string; label: string }>>([]);
// A task stored without a timezone follows the instance timezone. The selector has
// to show a concrete zone, so remember that the task was on the default and keep
// it there unless the user picks one — otherwise saving an unrelated edit would
// silently pin it, and a later instance timezone change would stop applying.
const followsInstanceTimezone = ref(false);
const saving = ref(false);
const errorMessage = ref('');
// Save is always clickable; clicking with invalid data reveals every field's
// error instead of silently no-op'ing behind a disabled button.
const saveAttempted = ref(false);
const nameValid = ref(false);
const objectiveTouched = ref(false);
// Non-custom frequencies always build a well-formed cron (see `cronExpression`
// below), so only the custom field's own validator can make this false.
const cronValid = ref(true);

/**
 * Zone a new task is authored in — the clock the user is actually reading. A host
 * that cannot determine its zone reports `Etc/Unknown`, which `Intl` itself then
 * refuses, so check against the same schema the API validates with and fall back
 * to the instance timezone rather than sending a value that cannot be saved.
 */
function browserTimezone(): string {
	const browserZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
	return StrictTimeZoneSchema.safeParse(browserZone).success ? browserZone : rootStore.timezone;
}

const cronExpression = computed(() => {
	const freq = frequency.value;
	if (freq === 'custom') return customCron.value.trim();
	return buildCron({
		frequency: freq,
		minute: minute.value,
		hour: hour.value,
		dayOfWeek: dayOfWeek.value,
		dayOfMonth: dayOfMonth.value,
	});
});

function applyTask() {
	const current = task.value;
	name.value = current?.name ?? '';
	objective.value = current?.objective ?? '';
	// A task saved before schedules carried their own timezone runs in the
	// instance timezone, so keep showing that instead of the viewer's zone.
	// Absent and null both mean "no zone stored", so treat them alike.
	followsInstanceTimezone.value = current !== null && !current.timezone;
	timezone.value = current ? (current.timezone ?? rootStore.timezone) : browserTimezone();

	const parts = current ? parseCron(current.cronExpression) : { ...DEFAULT_SCHEDULE_PARTS };
	if (parts) {
		frequency.value = parts.frequency;
		minute.value = parts.minute;
		hour.value = parts.hour;
		dayOfWeek.value = parts.dayOfWeek;
		dayOfMonth.value = parts.dayOfMonth;
		customCron.value = '';
	} else {
		frequency.value = 'custom';
		customCron.value = current?.cronExpression ?? '';
	}
}

applyTask();

// Snapshot of whether each field was already invalid when an existing task
// opened, so its error shows immediately instead of only after a touch/save.
// A pristine new-task field stays quiet until the user interacts with it.
const initialNameInvalid = isEditing.value && !name.value.trim();
const initialObjectiveInvalid = isEditing.value && !objective.value.trim();
const initialCronInvalid =
	isEditing.value && !getNextScheduleOccurrence(cronExpression.value, timezone.value);

const cronValidator: IValidator = {
	validate: (value: Validatable) =>
		getNextScheduleOccurrence(typeof value === 'string' ? value : '', timezone.value)
			? false
			: { message: i18n.baseText('agents.builder.tasks.validation.cronInvalid' as BaseTextKey) },
};

watch(frequency, (value) => {
	if (value !== 'custom') cronValid.value = true;
});

const frequencyOptions = computed<Array<{ label: string; value: FrequencyOption }>>(() => [
	{ value: 'hourly', label: i18n.baseText('agents.builder.tasks.schedule.frequency.hourly') },
	{ value: 'daily', label: i18n.baseText('agents.builder.tasks.schedule.frequency.daily') },
	{ value: 'weekly', label: i18n.baseText('agents.builder.tasks.schedule.frequency.weekly') },
	{ value: 'monthly', label: i18n.baseText('agents.builder.tasks.schedule.frequency.monthly') },
	{ value: 'custom', label: i18n.baseText('agents.builder.tasks.schedule.frequency.custom') },
]);

function onFrequencyChange(value: unknown) {
	const match = frequencyOptions.value.find((option) => option.value === value);
	if (match) frequency.value = match.value;
}

const dayOfWeekOptions = computed(() =>
	Array.from({ length: 7 }, (_, index) => ({ value: index, label: weekdayLabel(index) })),
);

const dayOfMonthOptions = computed(() =>
	Array.from({ length: 31 }, (_, index) => ({ value: index + 1, label: String(index + 1) })),
);

const showTime = computed(() => ['daily', 'weekly', 'monthly'].includes(frequency.value));

const selectedTime = computed({
	get: () => hour.value * 60 + minute.value,
	set: (value: number) => {
		hour.value = Math.floor(value / 60);
		minute.value = value % 60;
	},
});

const timeOptions = computed(() => {
	const steps = Array.from({ length: 48 }, (_, index) => index * 30);
	// Keep a non-30-minute time from an existing cron selectable instead of blank.
	const values = steps.includes(selectedTime.value)
		? steps
		: [...steps, selectedTime.value].sort((a, b) => a - b);
	return values.map((totalMinutes) => ({
		value: totalMinutes,
		label: formatTimeOfDay(Math.floor(totalMinutes / 60), totalMinutes % 60),
	}));
});

function onMinuteInput(value: string) {
	const parsed = Number(value);
	minute.value = Number.isFinite(parsed) ? Math.min(59, Math.max(0, Math.trunc(parsed))) : 0;
}

/**
 * Same timezone list the workflow settings offer. Kept renderable while it
 * loads (and if it fails) by always including the selected zone, since a
 * filterable select shows the raw value for an option it doesn't know.
 */
const timezoneSelectOptions = computed(() => {
	const options = timezoneOptions.value;
	if (options.some((option) => option.value === timezone.value)) return options;
	return [{ value: timezone.value, label: timezone.value }, ...options];
});

onMounted(async () => {
	try {
		const timezones = await settingsStore.getTimezones();
		timezoneOptions.value = Object.entries(timezones).map(([value, label]) => ({
			value,
			label: typeof label === 'string' ? label : value,
		}));
	} catch {
		// Selector keeps the current zone as its only option; saving still works.
	}
});

const nextOccurrenceText = computed(() => {
	const next = getNextScheduleOccurrence(cronExpression.value, timezone.value);
	if (!next) return '';
	return formatScheduleDateTime(next, timezone.value);
});

const objectiveError = computed(() => {
	if (!objective.value.trim()) {
		return i18n.baseText('agents.builder.tasks.validation.objectiveRequired');
	}
	if (objective.value.trim().length > AGENT_TASK_OBJECTIVE_MAX_LENGTH) {
		return i18n.baseText('agents.builder.tasks.validation.objectiveMaxLength' as BaseTextKey, {
			interpolate: { max: String(AGENT_TASK_OBJECTIVE_MAX_LENGTH) },
		});
	}
	return '';
});
const visibleObjectiveError = computed(() =>
	saveAttempted.value || initialObjectiveInvalid || objectiveTouched.value
		? objectiveError.value
		: '',
);

const canSave = computed(
	() => nameValid.value && !objectiveError.value && cronValid.value && !saving.value,
);

function onObjectiveInput(value: string) {
	objective.value = value;
	objectiveTouched.value = true;
}

function onNameInput(value: Validatable) {
	name.value = typeof value === 'string' ? value : '';
}

function onCronInput(value: Validatable) {
	customCron.value = typeof value === 'string' ? value : '';
}

function onTimezoneChange(value: unknown) {
	timezone.value = String(value);
	followsInstanceTimezone.value = false;
}

function closeModal() {
	uiStore.closeModal(props.modalName);
}

function onToggleEnabled(value: boolean) {
	const current = task.value;
	if (!current) return;
	enabled.value = value;
	props.data.onToggle?.({ id: current.id, enabled: value });
}

async function onRun() {
	const current = task.value;
	if (!current || running.value) return;
	running.value = true;
	try {
		await runAgentTask(
			rootStore.restApiContext,
			props.data.projectId,
			props.data.agentId,
			current.id,
		);
		toast.showMessage({
			title: i18n.baseText('agents.builder.tasks.executeStarted'),
			type: 'success',
		});
	} catch (error) {
		toast.showError(error, i18n.baseText('agents.builder.tasks.executeError'));
	} finally {
		running.value = false;
	}
}

async function onDelete() {
	const current = task.value;
	if (!current || deleting.value) return;
	const confirmed = await openAgentConfirmationModal({
		title: i18n.baseText('agents.builder.tasks.deleteConfirm.title'),
		description: i18n.baseText('agents.builder.tasks.deleteConfirm.description'),
		confirmButtonText: i18n.baseText('agents.builder.tasks.deleteConfirm.confirm'),
		cancelButtonText: i18n.baseText('agents.builder.tasks.cancel'),
	});
	if (confirmed !== MODAL_CONFIRM) return;

	deleting.value = true;
	errorMessage.value = '';
	try {
		await deleteAgentTask(
			rootStore.restApiContext,
			props.data.projectId,
			props.data.agentId,
			current.id,
		);
		props.data.onSaved();
		closeModal();
	} catch (error) {
		errorMessage.value =
			error instanceof Error && error.message
				? error.message
				: i18n.baseText('agents.builder.tasks.deleteError');
	} finally {
		deleting.value = false;
	}
}

async function onSave() {
	saveAttempted.value = true;
	if (!canSave.value) return;

	saving.value = true;
	errorMessage.value = '';

	const base = {
		name: name.value.trim(),
		objective: objective.value.trim(),
		cronExpression: cronExpression.value,
		timezone: followsInstanceTimezone.value ? null : timezone.value,
	};

	try {
		if (task.value) {
			await updateAgentTask(
				rootStore.restApiContext,
				props.data.projectId,
				props.data.agentId,
				task.value.id,
				base,
			);
		} else {
			// New tasks are enabled by default; the config ref carries the flag and
			// the task starts running once the agent is published.
			await createAgentTask(rootStore.restApiContext, props.data.projectId, props.data.agentId, {
				...base,
				enabled: true,
			});
		}
		props.data.onSaved();
		closeModal();
	} catch (error) {
		errorMessage.value =
			error instanceof Error && error.message
				? error.message
				: i18n.baseText('agents.builder.tasks.saveError');
	} finally {
		saving.value = false;
	}
}
</script>

<template>
	<Modal :name="modalName" width="860px" data-testid="agent-task-modal">
		<template #header>
			<div :class="$style.header">
				<N8nHeading tag="h2" size="large">
					{{
						i18n.baseText(
							isEditing ? 'agents.builder.tasks.edit.title' : 'agents.builder.tasks.create.title',
						)
					}}
				</N8nHeading>
				<div v-if="isEditing" :class="$style.headerActions">
					<N8nTooltip
						:content="
							props.data.isPublished
								? i18n.baseText('agents.builder.tasks.republishHint')
								: i18n.baseText('agents.builder.tasks.publishHint')
						"
						placement="top"
					>
						<N8nSwitch2
							:model-value="enabled"
							data-testid="agent-task-toggle"
							@update:model-value="(value) => onToggleEnabled(Boolean(value))"
						/>
					</N8nTooltip>
					<N8nTooltip :content="i18n.baseText('agents.builder.tasks.execute')" placement="top">
						<N8nButton
							variant="ghost"
							size="small"
							icon-only
							:loading="running"
							:aria-label="i18n.baseText('agents.builder.tasks.execute')"
							data-testid="agent-task-run"
							@click="onRun"
						>
							<template #icon><N8nIcon icon="play" :size="16" /></template>
						</N8nButton>
					</N8nTooltip>
				</div>
			</div>
		</template>

		<template #content>
			<div :class="$style.content">
				<div :class="$style.field">
					<N8nFormInput
						:model-value="name"
						:label="i18n.baseText('agents.builder.tasks.name.label')"
						name="task-name"
						required
						label-size="small"
						:placeholder="i18n.baseText('agents.builder.tasks.name.placeholder')"
						:validation-rules="[
							{ name: 'MAX_LENGTH', config: { maximum: AGENT_TASK_NAME_MAX_LENGTH } },
						]"
						:show-validation-warnings="saveAttempted || initialNameInvalid"
						data-testid="agent-task-name-input"
						@update:model-value="onNameInput"
						@validate="nameValid = $event"
					/>
				</div>

				<div :class="$style.field">
					<N8nText size="small" bold>
						{{ i18n.baseText('agents.builder.tasks.objective.label') }}
						<N8nText color="primary" bold size="small">*</N8nText>
					</N8nText>
					<N8nMarkdownEditor
						:class="$style.objectiveEditor"
						:model-value="objective"
						:placeholder="i18n.baseText('agents.builder.tasks.objective.placeholder')"
						max-height="100%"
						data-testid="agent-task-objective-input"
						@update:model-value="onObjectiveInput"
					/>
					<N8nText v-if="visibleObjectiveError" :class="$style.error" size="small">
						{{ visibleObjectiveError }}
					</N8nText>
				</div>

				<div :class="$style.field">
					<N8nText size="small" bold>
						{{ i18n.baseText('agents.builder.tasks.schedule.label') }}
						<N8nText color="primary" bold size="small">*</N8nText>
					</N8nText>
					<div :class="$style.scheduleRow">
						<N8nSelect
							:model-value="frequency"
							:class="$style.frequencySelect"
							data-testid="agent-task-frequency"
							@update:model-value="onFrequencyChange"
						>
							<N8nOption
								v-for="option in frequencyOptions"
								:key="option.value"
								:value="option.value"
								:label="option.label"
							/>
						</N8nSelect>

						<template v-if="frequency === 'weekly'">
							<N8nText size="small" color="text-light">
								{{ i18n.baseText('agents.builder.tasks.schedule.on') }}
							</N8nText>
							<N8nSelect
								:model-value="dayOfWeek"
								:class="$style.daySelect"
								data-testid="agent-task-day-of-week"
								@update:model-value="dayOfWeek = Number($event)"
							>
								<N8nOption
									v-for="day in dayOfWeekOptions"
									:key="day.value"
									:value="day.value"
									:label="day.label"
								/>
							</N8nSelect>
						</template>

						<template v-if="frequency === 'monthly'">
							<N8nText size="small" color="text-light">
								{{ i18n.baseText('agents.builder.tasks.schedule.onDay') }}
							</N8nText>
							<N8nSelect
								:model-value="dayOfMonth"
								:class="$style.daySelect"
								data-testid="agent-task-day-of-month"
								@update:model-value="dayOfMonth = Number($event)"
							>
								<N8nOption
									v-for="day in dayOfMonthOptions"
									:key="day.value"
									:value="day.value"
									:label="day.label"
								/>
							</N8nSelect>
						</template>

						<template v-if="showTime">
							<N8nText size="small" color="text-light">
								{{ i18n.baseText('agents.builder.tasks.schedule.at') }}
							</N8nText>
							<N8nSelect
								:model-value="selectedTime"
								:class="$style.timeSelect"
								data-testid="agent-task-time"
								@update:model-value="selectedTime = Number($event)"
							>
								<N8nOption
									v-for="option in timeOptions"
									:key="option.value"
									:value="option.value"
									:label="option.label"
								/>
							</N8nSelect>
						</template>

						<template v-if="frequency === 'hourly'">
							<N8nText size="small" color="text-light">
								{{ i18n.baseText('agents.builder.tasks.schedule.minuteLabel') }}
							</N8nText>
							<N8nInput
								type="number"
								:model-value="String(minute)"
								:class="$style.minuteInput"
								data-testid="agent-task-minute"
								@update:model-value="onMinuteInput"
							/>
						</template>

						<N8nFormInput
							v-if="frequency === 'custom'"
							:model-value="customCron"
							label=""
							name="task-cron"
							required
							:placeholder="i18n.baseText('agents.builder.tasks.schedule.cron.placeholder')"
							:validators="{ VALID_CRON: cronValidator }"
							:validation-rules="[{ name: 'VALID_CRON' }]"
							:show-validation-warnings="saveAttempted || initialCronInvalid"
							:class="$style.cronInput"
							data-testid="agent-task-schedule-cron"
							@update:model-value="onCronInput"
							@validate="cronValid = $event"
						/>

						<N8nText size="small" color="text-light">
							{{ i18n.baseText('agents.builder.tasks.schedule.in') }}
						</N8nText>
						<N8nSelect
							:model-value="timezone"
							:class="$style.timezoneSelect"
							:placeholder="i18n.baseText('agents.builder.tasks.schedule.timezone.placeholder')"
							filterable
							:limit-popper-width="true"
							data-testid="agent-task-timezone"
							@update:model-value="onTimezoneChange"
						>
							<N8nOption
								v-for="option in timezoneSelectOptions"
								:key="option.value"
								:value="option.value"
								:label="option.label"
							/>
						</N8nSelect>
					</div>
					<N8nText v-if="nextOccurrenceText" :class="$style.help" size="small">
						{{
							i18n.baseText('agents.builder.tasks.schedule.nextOccurrence', {
								interpolate: { occurrence: nextOccurrenceText },
							})
						}}
					</N8nText>
				</div>

				<N8nText
					v-if="showRepublishHint"
					:class="$style.help"
					size="small"
					data-testid="agent-task-republish-hint"
				>
					{{ i18n.baseText('agents.builder.tasks.republishHint') }}
				</N8nText>

				<N8nText v-if="errorMessage" :class="$style.error" size="small">
					{{ errorMessage }}
				</N8nText>
			</div>
		</template>

		<template #footer>
			<div :class="$style.footer">
				<N8nButton
					v-if="isEditing"
					variant="subtle"
					:loading="deleting"
					data-testid="agent-task-delete"
					@click="onDelete"
				>
					<template #icon><N8nIcon icon="trash-2" :size="16" /></template>
					{{ i18n.baseText('agents.builder.tasks.delete') }}
				</N8nButton>
				<div :class="$style.footerActions">
					<N8nButton variant="subtle" @click="closeModal">
						{{ i18n.baseText('agents.builder.tasks.cancel') }}
					</N8nButton>
					<N8nButton
						variant="solid"
						:disabled="saving"
						:loading="saving"
						data-testid="agent-task-save"
						@click="onSave"
					>
						{{ i18n.baseText('agents.builder.tasks.save') }}
					</N8nButton>
				</div>
			</div>
		</template>
	</Modal>
</template>

<style module>
.header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: var(--spacing--sm);
	padding-right: var(--spacing--xl);
}

.headerActions {
	display: flex;
	align-items: center;
	gap: var(--spacing--2xs);
}

.content {
	display: flex;
	flex-direction: column;
	gap: var(--spacing--sm);
}

.field {
	display: flex;
	flex-direction: column;
	gap: var(--spacing--2xs);
}

/* Matches the height the skills instructions editor fills inside its modal. */
.objectiveEditor {
	height: 400px;
}

.scheduleRow {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	gap: var(--spacing--2xs);
}

.frequencySelect {
	width: 12rem;
}

.daySelect {
	width: 10rem;
}

.minuteInput {
	width: 6rem;
}

.cronInput {
	flex: 1;
	min-width: 12rem;
}

.timeSelect {
	width: 8rem;
}

.timezoneSelect {
	width: 14rem;
}

.help {
	color: var(--color--text--tint-1);
}

.error {
	color: var(--color--danger);
}

.footer {
	display: flex;
	justify-content: space-between;
	gap: var(--spacing--2xs);
}

.footerActions {
	display: flex;
	gap: var(--spacing--2xs);
	margin-left: auto;
}
</style>
