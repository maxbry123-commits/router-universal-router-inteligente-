import type {
	AgentSessionLangSmithExportResponse,
	AgentSessionOrigin,
	AgentSessionStatus,
} from '@n8n/api-types';
import { makeRestApiRequest } from '@n8n/rest-api-client';
import type { IRestApiContext } from '@n8n/rest-api-client';

export interface AgentExecutionThread {
	id: string;
	agentId: string;
	agentName: string;
	parentThreadId: string | null;
	parentAgentId: string | null;
	projectId: string;
	/** Set when the session was invoked by a scheduled task; null for agent runs. */
	taskId: string | null;
	sessionNumber: number;
	title: string | null;
	emoji: string | null;
	totalPromptTokens: number;
	totalCompletionTokens: number;
	totalCost: number;
	totalDuration: number;
	createdAt: string;
	updatedAt: string;
	firstMessage?: string | null;
	/** Earliest non-null execution source for the thread (e.g. slack, telegram). */
	source?: string | null;
	failureSummary?: ThreadFailureSummary | null;
	status?: AgentSessionStatus | null;
}

export type AgentExecutionStatus = 'running' | 'success' | 'error' | 'cancelled' | 'interrupted';
export type AgentExecutionHitlStatus = 'suspended' | 'resumed';
export type AgentExecutionFailureKind = 'execution' | 'tool' | 'node' | 'workflow';
export type { AgentSessionOrigin, AgentSessionStatus };

export interface AgentSessionFilters {
	status: AgentSessionStatus | 'all';
	origin: AgentSessionOrigin | 'all';
	startDate: string | Date;
	endDate: string | Date;
}

export function defaultAgentSessionFilters(): AgentSessionFilters {
	return { status: 'all', origin: 'all', startDate: '', endDate: '' };
}

export interface AgentExecutionFailure {
	kind: AgentExecutionFailureKind;
	name: string | null;
	message: string | null;
	occurredAt: number;
}

export interface AgentExecutionFailureSummary {
	count: number;
	latest: AgentExecutionFailure;
}

export interface ThreadFailureSummary extends AgentExecutionFailureSummary {
	latest: AgentExecutionFailure & { executionId: string };
}

/**
 * Raw timeline event shape as persisted on the agent_execution row.
 * The display-side parser in `session-timeline.utils.ts` is the source of
 * truth for the discriminated union; this is intentionally loose so the
 * API surface doesn't need to track every event field.
 */
export type AgentExecutionTimelineEvent = Record<string, unknown> & { type: string };

/** Metadata of a file attached to the user turn; bytes come from the chat attachment download route. */
export interface AgentExecutionAttachment {
	id: string;
	fileName: string;
	mimeType: string;
	sizeBytes: number;
}

export interface AgentExecution {
	id: string;
	threadId: string;
	agentId: string;
	status: AgentExecutionStatus;
	createdAt: string;
	startedAt: string | null;
	stoppedAt: string | null;
	duration: number;
	userMessage: string | null;
	attachments: AgentExecutionAttachment[] | null;
	model: string | null;
	promptTokens: number | null;
	completionTokens: number | null;
	totalTokens: number | null;
	cost: number | null;
	timeline: AgentExecutionTimelineEvent[] | null;
	error: string | null;
	failureSummary: AgentExecutionFailureSummary | null;
	hitlStatus: AgentExecutionHitlStatus | null;
	source: string | null;
}

export interface ThreadDetail {
	thread: AgentExecutionThread;
	executions: AgentExecution[];
}

export interface ThreadsPage {
	threads: AgentExecutionThread[];
	nextCursor: string | null;
}

export const listThreads = async (
	context: IRestApiContext,
	projectId: string,
	agentId: string,
	options: { limit: number; cursor?: string; filters?: AgentSessionFilters },
): Promise<ThreadsPage> => {
	const params = new URLSearchParams({ limit: String(options.limit) });
	if (options.cursor) params.set('cursor', options.cursor);
	const { filters } = options;
	if (filters?.status && filters.status !== 'all') params.set('status', filters.status);
	if (filters?.origin && filters.origin !== 'all') params.set('origin', filters.origin);
	if (filters?.startDate) {
		params.set('updatedAfter', new Date(filters.startDate).toISOString());
	}
	if (filters?.endDate) {
		params.set('updatedBefore', new Date(filters.endDate).toISOString());
	}
	return await makeRestApiRequest<ThreadsPage>(
		context,
		'GET',
		`/projects/${projectId}/agents/v2/${agentId}/threads?${params.toString()}`,
	);
};

export const getThreadDetail = async (
	context: IRestApiContext,
	projectId: string,
	agentId: string,
	threadId: string,
): Promise<ThreadDetail> => {
	return await makeRestApiRequest<ThreadDetail>(
		context,
		'GET',
		`/projects/${projectId}/agents/v2/${agentId}/threads/${threadId}`,
	);
};

export const deleteThread = async (
	context: IRestApiContext,
	projectId: string,
	agentId: string,
	threadId: string,
): Promise<{ success: boolean }> => {
	return await makeRestApiRequest<{ success: boolean }>(
		context,
		'DELETE',
		`/projects/${projectId}/agents/v2/${agentId}/threads/${threadId}`,
	);
};

export const exportThreadToLangSmith = async (
	context: IRestApiContext,
	projectId: string,
	agentId: string,
	threadId: string,
): Promise<AgentSessionLangSmithExportResponse> => {
	return await makeRestApiRequest<AgentSessionLangSmithExportResponse>(
		context,
		'POST',
		`/projects/${projectId}/agents/v2/${agentId}/threads/${threadId}/langsmith-export`,
	);
};
