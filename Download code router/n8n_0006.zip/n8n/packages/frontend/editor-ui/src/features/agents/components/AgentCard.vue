<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import dateformat from 'dateformat';
import {
	N8nActionToggle,
	N8nBadge,
	N8nCard,
	N8nIcon,
	N8nText,
	N8nTooltip,
} from '@n8n/design-system';
import { useI18n, type BaseTextKey } from '@n8n/i18n';
import { useRootStore } from '@n8n/stores/useRootStore';
import { MODAL_CONFIRM } from '@/app/constants';
import TimeAgo from '@/app/components/TimeAgo.vue';
import { useToast } from '@n8n/composables/useToast';
import { useSettingsStore } from '@n8n/stores/settings.store';
import { useMcp } from '@/features/ai/mcpAccess/composables/useMcp';
import { useMCPStore } from '@/features/ai/mcpAccess/mcp.store';
import { deleteAgent } from '../composables/useAgentApi';
import { useAgentConfirmationModal } from '../composables/useAgentConfirmationModal';
import { useAgentPermissions } from '../composables/useAgentPermissions';
import { useAgentPublish } from '../composables/useAgentPublish';
import { removeProjectAgentFromListCache } from '../composables/useProjectAgentsList';
import type { AgentResource } from '../types';
import { useFavoritesStore } from '@/app/stores/favorites.store';

const props = defineProps<{
	agent: AgentResource;
	projectId: string;
}>();

const emit = defineEmits<{
	select: [agentId: string];
	published: [agent: AgentResource];
	unpublished: [agent: AgentResource];
	deleted: [agentId: string];
	'new-chat': [agentId: string, projectId: string];
}>();

const locale = useI18n();
const toast = useToast();
const rootStore = useRootStore();
const settingsStore = useSettingsStore();
const mcpStore = useMCPStore();
const mcp = useMcp();
const { openAgentConfirmationModal } = useAgentConfirmationModal();
const { publish, unpublish } = useAgentPublish();
const { canUpdate, canDelete, canPublish, canUnpublish } = useAgentPermissions(
	() => props.projectId,
);

const isPublished = computed(() => props.agent.activeVersionId !== null);

const isMcpEnabled = computed(
	() => settingsStore.isModuleActive('mcp') && !!settingsStore.moduleSettings.mcp?.mcpAccessEnabled,
);

// Optimistic state so the action label flips without refetching the list
// (same pattern as the workflow card's 3-dot menu).
const mcpToggleStatus = ref<boolean | null>(null);

const isAvailableInMCP = computed(
	() => mcpToggleStatus.value ?? props.agent.availableInMCP ?? false,
);

watch([() => props.agent, () => props.agent.availableInMCP], () => {
	mcpToggleStatus.value = null;
});

const showMcpIndicator = computed(() => isMcpEnabled.value && isAvailableInMCP.value);

const favoriteStore = useFavoritesStore();
const isFavorite = computed(() => favoriteStore.isFavorite(props.agent.id, 'agent'));

const actions = computed(() => {
	const items: Array<{ value: string; label: string; divided?: boolean }> = [
		{
			value: 'newChat',
			label: locale.baseText('agents.list.actions.newChat' as BaseTextKey),
		},
	];

	if (isPublished.value && canUnpublish.value) {
		items.push({
			value: 'unpublish',
			label: locale.baseText('agents.list.actions.unpublish'),
			divided: true,
		});
	} else if (!isPublished.value && canPublish.value) {
		items.push({
			value: 'publish',
			label: locale.baseText('agents.list.actions.publish'),
			divided: true,
		});
	}

	items.push({
		value: 'toggleFavorite',
		label: locale.baseText(isFavorite.value ? 'favorites.remove' : 'favorites.add'),
		divided: !isPublished.value ? !canPublish.value : !canUnpublish.value,
	});

	if (isMcpEnabled.value && canUpdate.value) {
		items.push({
			value: 'toggleMCPAccess',
			label: locale.baseText(
				isAvailableInMCP.value
					? 'agents.list.actions.disableMCPAccess'
					: 'agents.list.actions.enableMCPAccess',
			),
		});
	}

	if (canDelete.value) {
		items.push({
			value: 'delete',
			label: locale.baseText('agents.list.actions.delete'),
			divided: items.length > 0,
		});
	}

	return items;
});

const showActions = computed(() => actions.value.length > 0);

const formattedCreatedAtDate = computed(() => {
	const currentYear = new Date().getFullYear().toString();

	return dateformat(
		props.agent.createdAt,
		`d mmmm${String(props.agent.createdAt).startsWith(currentYear) ? '' : ', yyyy'}`,
	);
});

async function onAction(action: string) {
	if (action === 'newChat') {
		emit('new-chat', props.agent.id, props.projectId);
	} else if (action === 'publish') {
		const updated = await publish(props.projectId, props.agent.id);
		if (updated) emit('published', updated);
	} else if (action === 'unpublish') {
		const updated = await unpublish(props.projectId, props.agent.id, props.agent.name);
		if (updated) emit('unpublished', updated);
	} else if (action === 'toggleFavorite') {
		await favoriteStore.toggleFavorite(props.agent.id, 'agent');
	} else if (action === 'toggleMCPAccess') {
		await toggleMCPAccess(!isAvailableInMCP.value);
	} else if (action === 'delete') {
		const confirmed = await openAgentConfirmationModal({
			title: locale.baseText('agents.delete.modal.title', {
				interpolate: { name: props.agent.name },
			}),
			description: locale.baseText('agents.delete.modal.description', {
				interpolate: { name: props.agent.name },
			}),
			confirmButtonText: locale.baseText('agents.delete.modal.button.delete'),
			cancelButtonText: locale.baseText('generic.cancel'),
		});
		if (confirmed !== MODAL_CONFIRM) return;
		await deleteAgent(rootStore.restApiContext, props.projectId, props.agent.id);
		removeProjectAgentFromListCache(props.projectId, props.agent.id);
		favoriteStore.removeFavoriteLocally(props.agent.id, 'agent');
		emit('deleted', props.agent.id);
	}
}

async function toggleMCPAccess(enabled: boolean) {
	try {
		await mcpStore.toggleAgentMcpAccess(props.agent.id, enabled);
		mcpToggleStatus.value = enabled;
		if (enabled) {
			mcp.trackMcpAccessEnabledForAgent(props.agent.id);
		}
	} catch (error) {
		toast.showError(error, locale.baseText('agents.toggleMCP.error.title'));
	}
}
</script>

<template>
	<N8nCard :class="$style.cardLink" data-test-id="agent-card" @click="emit('select', agent.id)">
		<template #header>
			<N8nText tag="h2" bold :class="$style.cardHeading" data-test-id="agent-card-name">
				{{ agent.name }}
				<N8nBadge
					v-if="!canUpdate"
					:class="$style.readonlyBadge"
					theme="tertiary"
					bold
					data-test-id="agent-card-readonly-badge"
				>
					{{ locale.baseText('agents.list.readonly') }}
				</N8nBadge>
			</N8nText>
		</template>
		<div :class="$style.cardDescription">
			<span>
				{{ locale.baseText('agents.list.updated') }}
				<TimeAgo :date="String(agent.updatedAt)" /> |
			</span>
			<span> {{ locale.baseText('agents.list.created') }} {{ formattedCreatedAtDate }} </span>
			<span v-if="showMcpIndicator">|</span>
			<span v-if="showMcpIndicator" :class="$style.mcpIndicator" data-test-id="agent-card-mcp">
				<N8nTooltip placement="right" :content="locale.baseText('agents.list.availableInMCP')">
					<N8nIcon icon="mcp" size="medium" />
				</N8nTooltip>
			</span>
		</div>
		<template #append>
			<div :class="$style.cardActions" @click.stop>
				<div
					v-if="isPublished"
					:class="$style.publishIndicator"
					data-test-id="agent-card-publish-indicator"
				>
					<span :class="$style.publishIndicatorDot" />
					<N8nText size="small" color="text-base">
						{{ locale.baseText('agents.list.published') }}
					</N8nText>
				</div>
				<N8nActionToggle
					v-if="showActions"
					:actions="actions"
					theme="dark"
					data-test-id="agent-card-actions"
					@action="onAction"
				/>
			</div>
		</template>
	</N8nCard>
</template>

<style lang="scss" module>
.cardLink {
	transition: box-shadow 0.3s ease;
	cursor: pointer;
	padding: 0;
	align-items: stretch;

	&:hover {
		box-shadow: var(--shadow--card-hover);
	}
}

.cardHeading {
	display: flex;
	align-items: center;
	font-size: var(--font-size--sm);
	word-break: break-word;
	padding: var(--spacing--sm) 0 0 var(--spacing--sm);
}

.readonlyBadge {
	margin-left: var(--spacing--3xs);
}

.cardDescription {
	min-height: var(--spacing--xl);
	display: flex;
	align-items: center;
	padding: 0 0 var(--spacing--sm) var(--spacing--sm);
	font-size: var(--font-size--2xs);
	color: var(--color--text--tint-1);
	gap: var(--spacing--2xs);
}

.mcpIndicator {
	display: inline-flex;
	align-items: center;
}

.cardActions {
	display: flex;
	gap: var(--spacing--2xs);
	flex-direction: row;
	justify-content: center;
	align-items: center;
	align-self: stretch;
	padding: 0 var(--spacing--sm) 0 0;
	cursor: default;
}

.publishIndicator {
	display: flex;
	align-items: center;
	gap: var(--spacing--3xs);
	padding: var(--spacing--4xs) var(--spacing--2xs);
	border-radius: var(--spacing--4xs);
	border: var(--border);

	* {
		// This is needed to line height up with ownership badge
		line-height: calc(var(--font-size--sm) + 1px);
	}
}

.publishIndicatorDot {
	width: var(--spacing--2xs);
	height: var(--spacing--2xs);
	border-radius: 50%;
	background-color: var(--color--mint-600);
}

@include mixins.breakpoint('sm-and-down') {
	.cardLink {
		--card--padding: 0 var(--spacing--sm) var(--spacing--sm);
		--card--append--width: 100%;

		flex-direction: column;
	}

	.cardActions {
		width: 100%;
		padding: 0 var(--spacing--sm) var(--spacing--sm);
		justify-content: end;
	}
}
</style>
