/* eslint-disable import-x/no-extraneous-dependencies, @typescript-eslint/require-await, @typescript-eslint/no-unsafe-assignment -- test-only patterns: @vue/test-utils is a transitive devDep, async stubs, and any-based mock reads */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { mount, flushPromises } from '@vue/test-utils';
import { ref } from 'vue';
import type { AgentResource } from '../types';
import type { AgentVersion } from '../agent.types';

vi.mock('../composables/useAgentApi', () => ({
	publishAgent: vi.fn(),
	unpublishAgent: vi.fn(),
	revertAgentToPublished: vi.fn(),
}));

const agentPermissionsMock = {
	canCreate: ref(true),
	canUpdate: ref(true),
	canDelete: ref(true),
	canPublish: ref(true),
	canUnpublish: ref(true),
};

vi.mock('../composables/useAgentPermissions', () => ({
	useAgentPermissions: () => agentPermissionsMock,
}));

vi.mock('@n8n/stores/useRootStore', () => ({
	useRootStore: () => ({ restApiContext: {} }),
}));

vi.mock('@n8n/i18n', () => ({
	useI18n: () => ({ baseText: (key: string) => key }),
}));

vi.mock('@n8n/composables/useToast', () => {
	const showMessage = vi.fn();
	const showError = vi.fn();
	return { useToast: () => ({ showMessage, showError }) };
});

const openModalWithDataMock = vi.fn();
const closeModalMock = vi.fn();

vi.mock('@/app/stores/ui.store', () => ({
	useUIStore: () => ({
		openModalWithData: openModalWithDataMock,
		closeModal: closeModalMock,
	}),
}));

const STUBS = {
	N8nButton: {
		template:
			'<button :disabled="disabled || loading || undefined" @click="$emit(\'click\')"><slot /></button>',
		props: ['disabled', 'loading', 'variant'],
		emits: ['click'],
	},
	N8nIconButton: {
		template: '<button @click="$emit(\'click\')" />',
		props: ['icon', 'variant', 'ariaLabel'],
		emits: ['click'],
	},
	// N8nActionDropdown has no defineOptions name, Vue infers it as 'ActionDropdown' from filename
	ActionDropdown: {
		name: 'ActionDropdown',
		template:
			'<div><button v-for="item in items" :key="item.id" :data-action="item.id" :disabled="item.disabled || undefined" @click="$emit(\'select\', item.id)">{{ item.label }}</button></div>',
		props: ['items', 'placement', 'activatorIcon'],
		emits: ['select'],
	},
	N8nTooltip: {
		name: 'N8nTooltip',
		template:
			'<span data-testid="stub-tooltip" :data-disabled="disabled" :data-content="content"><slot /></span>',
		props: ['disabled', 'content'],
	},
};

const activeVersion: AgentVersion = {
	versionId: 'v1',
	schema: null,
	skills: null,
	author: 'Test User',
};

function createAgent(overrides: Partial<AgentResource> = {}): AgentResource {
	return {
		resourceType: 'agent',
		id: 'agent-1',
		name: 'My Agent',
		projectId: 'project-1',
		isCompiled: false,
		createdAt: '2026-01-01T00:00:00Z',
		updatedAt: '2026-01-01T00:00:00Z',
		versionId: 'v1',
		activeVersionId: null,
		tools: {},
		skills: {},
		activeVersion: null,
		...overrides,
	};
}

interface RenderProps {
	agent?: AgentResource | null;
	projectId?: string;
	agentId?: string;
	beforeRevertToPublished?: () => Promise<void> | void;
	configValidationStatus?: 'valid' | 'invalid' | null;
	beforePublish?: () => Promise<boolean>;
}

function getModalCallbacks() {
	const data = openModalWithDataMock.mock.lastCall?.[0]?.data as {
		onConfirm: () => Promise<void> | void;
		onCancel: () => Promise<void> | void;
	};

	return data;
}

// First mount eats the SFC transform cost for AgentPublishButton + deps,
// which has crept above the default 5 s budget on slower CI workers. Give
// the suite headroom; subsequent tests hit the cached module and finish fast.
vi.setConfig({ testTimeout: 30_000 });

describe('AgentPublishButton', () => {
	async function renderComponent(props: RenderProps = {}) {
		const { default: AgentPublishButton } = await import('../components/AgentPublishButton.vue');
		return mount(AgentPublishButton, {
			props: {
				agent: createAgent(),
				projectId: 'project-1',
				agentId: 'agent-1',
				...props,
			},
			global: { stubs: STUBS },
		});
	}

	beforeEach(() => {
		vi.clearAllMocks();
	});

	// Button states
	it('shows "Publish" and is enabled when agent is not published', async () => {
		const agent = createAgent({ activeVersionId: null });
		const wrapper = await renderComponent({ agent });
		const button = wrapper.find('[data-testid="publish-agent-button"]');
		expect(button.text()).toContain('agents.publish.button.publish');
		expect(button.attributes('disabled')).toBeUndefined();
	});

	it('shows "Published" and is disabled when latest version is published', async () => {
		const agent = createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		const button = wrapper.find('[data-testid="publish-agent-button"]');
		expect(button.text()).toContain('agents.publish.button.published');
		expect(button.attributes('disabled')).toBeDefined();
	});

	it('shows "Publish" and is enabled when there are unpublished changes', async () => {
		const agent = createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		const button = wrapper.find('[data-testid="publish-agent-button"]');
		expect(button.text()).toContain('agents.publish.button.publish');
		expect(button.attributes('disabled')).toBeUndefined();
	});

	// Publish button click
	it('calls publishAgent and emits published when Publish is clicked', async () => {
		const { publishAgent } = await import('../composables/useAgentApi');
		const updatedAgent = createAgent({ activeVersionId: 'v1', activeVersion });
		vi.mocked(publishAgent).mockResolvedValue(updatedAgent);

		const agent = createAgent({ activeVersionId: null });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-testid="publish-agent-button"]').trigger('click');
		await flushPromises();

		expect(publishAgent).toHaveBeenCalledWith({}, 'project-1', 'agent-1');
		expect(wrapper.emitted('published')?.[0]).toEqual([updatedAgent]);
	});

	it('calls publishAgent and emits published when republishing with pending changes', async () => {
		const { publishAgent } = await import('../composables/useAgentApi');
		const updatedAgent = createAgent({
			versionId: 'v2',
			activeVersionId: 'v2',
			activeVersion: { ...activeVersion, versionId: 'v2' },
		});
		vi.mocked(publishAgent).mockResolvedValue(updatedAgent);

		const agent = createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-testid="publish-agent-button"]').trigger('click');
		await flushPromises();

		expect(publishAgent).toHaveBeenCalledWith({}, 'project-1', 'agent-1');
		expect(wrapper.emitted('published')?.[0]).toEqual([updatedAgent]);
	});

	it('does nothing when the disabled Published button is clicked', async () => {
		const { publishAgent } = await import('../composables/useAgentApi');

		const agent = createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-testid="publish-agent-button"]').trigger('click');
		await flushPromises();

		expect(publishAgent).not.toHaveBeenCalled();
	});

	// Dropdown — publish action
	it('calls publishAgent via dropdown Publish action', async () => {
		const { publishAgent } = await import('../composables/useAgentApi');
		const updatedAgent = createAgent({ activeVersionId: 'v1', activeVersion });
		vi.mocked(publishAgent).mockResolvedValue(updatedAgent);

		const agent = createAgent({ activeVersionId: null });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-action="publish"]').trigger('click');
		await flushPromises();

		expect(publishAgent).toHaveBeenCalledWith({}, 'project-1', 'agent-1');
		expect(wrapper.emitted('published')?.[0]).toEqual([updatedAgent]);
	});

	it('calls revertAgentToPublished and emits reverted from the dropdown action', async () => {
		const { revertAgentToPublished } = await import('../composables/useAgentApi');
		const beforeRevertToPublished = vi.fn();
		const updatedAgent = createAgent({
			versionId: 'v1',
			activeVersionId: 'v1',
			activeVersion,
		});
		vi.mocked(revertAgentToPublished).mockResolvedValue(updatedAgent);

		const agent = createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent, beforeRevertToPublished });
		await wrapper.find('[data-action="revert-to-published"]').trigger('click');
		await getModalCallbacks().onConfirm();
		await flushPromises();

		expect(beforeRevertToPublished).toHaveBeenCalled();
		expect(revertAgentToPublished).toHaveBeenCalledWith({}, 'project-1', 'agent-1');
		expect(wrapper.emitted('reverted')?.[0]).toEqual([updatedAgent]);
	});

	it('does not show the revert action when the agent is not published', async () => {
		const wrapper = await renderComponent({ agent: createAgent({ activeVersionId: null }) });

		expect(wrapper.find('[data-action="revert-to-published"]').exists()).toBe(false);
	});

	it('disables the revert action when the draft is in sync with the published version', async () => {
		const { revertAgentToPublished } = await import('../composables/useAgentApi');
		const agent = createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });

		expect(
			wrapper.find('[data-action="revert-to-published"]').attributes('disabled'),
		).toBeDefined();

		await wrapper.find('[data-action="revert-to-published"]').trigger('click');
		await flushPromises();

		expect(revertAgentToPublished).not.toHaveBeenCalled();
	});

	it('does not revert when the confirmation modal is cancelled', async () => {
		const { revertAgentToPublished } = await import('../composables/useAgentApi');

		const agent = createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-action="revert-to-published"]').trigger('click');
		await getModalCallbacks().onCancel();
		await flushPromises();

		expect(revertAgentToPublished).not.toHaveBeenCalled();
		expect(wrapper.emitted('reverted')).toBeUndefined();
	});

	// Dropdown — unpublish action
	it('calls unpublishAgent and emits unpublished on confirmed unpublish', async () => {
		const { unpublishAgent } = await import('../composables/useAgentApi');
		const unpublishedAgent = createAgent({ activeVersionId: null });
		vi.mocked(unpublishAgent).mockResolvedValue(unpublishedAgent);

		const agent = createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-action="unpublish"]').trigger('click');
		await getModalCallbacks().onConfirm();
		await flushPromises();

		expect(openModalWithDataMock).toHaveBeenCalled();
		expect(unpublishAgent).toHaveBeenCalledWith({}, 'project-1', 'agent-1');
		expect(wrapper.emitted('unpublished')?.[0]).toEqual([unpublishedAgent]);
	});

	it('does not unpublish when confirm modal is cancelled', async () => {
		const { unpublishAgent } = await import('../composables/useAgentApi');

		const agent = createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion });
		const wrapper = await renderComponent({ agent });
		await wrapper.find('[data-action="unpublish"]').trigger('click');
		await getModalCallbacks().onCancel();
		await flushPromises();

		expect(unpublishAgent).not.toHaveBeenCalled();
		expect(wrapper.emitted('unpublished')).toBeUndefined();
	});

	// Indicator dot styling — guards against regressions like
	// using subtle text-color tokens that render an invisible dot.
	describe('indicator dot', () => {
		it('does not render the indicator when the agent is not published', async () => {
			const wrapper = await renderComponent({
				agent: createAgent({ activeVersionId: null }),
			});
			const button = wrapper.find('[data-testid="publish-agent-button"]');
			expect(button.find('span[class*="indicatorDot"]').exists()).toBe(false);
		});

		it('renders the published indicator when latest version is published', async () => {
			const wrapper = await renderComponent({
				agent: createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion }),
			});
			const dot = wrapper.find('[data-testid="publish-agent-button"] span[class*="indicatorDot"]');
			expect(dot.exists()).toBe(true);
			expect(dot.classes().some((c) => c.includes('indicatorPublished'))).toBe(true);
			expect(dot.classes().some((c) => c.includes('indicatorChanges'))).toBe(false);
		});

		it('renders the changes indicator when there are unpublished changes', async () => {
			const wrapper = await renderComponent({
				agent: createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion }),
			});
			const dot = wrapper.find('[data-testid="publish-agent-button"] span[class*="indicatorDot"]');
			expect(dot.exists()).toBe(true);
			expect(dot.classes().some((c) => c.includes('indicatorChanges'))).toBe(true);
			expect(dot.classes().some((c) => c.includes('indicatorPublished'))).toBe(false);
		});
	});

	// Configuration validation gating
	describe('configuration validation gating', () => {
		it('gates the Publish button on validation status', async () => {
			const unpublishedAgent = createAgent({ activeVersionId: null });

			const invalidWrapper = await renderComponent({
				agent: unpublishedAgent,
				configValidationStatus: 'invalid',
			});
			const invalidButton = invalidWrapper.find('[data-testid="publish-agent-button"]');
			expect(invalidButton.attributes('disabled')).toBeDefined();
			const invalidTooltip = invalidWrapper.find('[data-testid="stub-tooltip"]');
			expect(invalidTooltip.attributes('data-disabled')).toBe('false');
			expect(invalidTooltip.attributes('data-content')).toBe(
				'agents.publish.button.invalidConfigTooltip',
			);

			// An unknown (null) validation result is treated as not publishable.
			const nullWrapper = await renderComponent({
				agent: unpublishedAgent,
				configValidationStatus: null,
			});
			expect(
				nullWrapper.find('[data-testid="publish-agent-button"]').attributes('disabled'),
			).toBeDefined();

			const validWrapper = await renderComponent({
				agent: unpublishedAgent,
				configValidationStatus: 'valid',
			});
			expect(
				validWrapper.find('[data-testid="publish-agent-button"]').attributes('disabled'),
			).toBeUndefined();

			// Published with no pending changes — disabled regardless of validation,
			// and the invalid-config tooltip must not show for this other reason.
			const publishedAgent = createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion });
			const publishedWrapper = await renderComponent({
				agent: publishedAgent,
				configValidationStatus: 'invalid',
			});
			expect(
				publishedWrapper.find('[data-testid="publish-agent-button"]').attributes('disabled'),
			).toBeDefined();
			expect(
				publishedWrapper.find('[data-testid="stub-tooltip"]').attributes('data-disabled'),
			).toBe('true');
		});

		it('aborts the publish request when beforePublish resolves false', async () => {
			const { publishAgent } = await import('../composables/useAgentApi');
			const beforePublish = vi.fn().mockResolvedValue(false);
			const agent = createAgent({ activeVersionId: null });
			const wrapper = await renderComponent({
				agent,
				configValidationStatus: 'valid',
				beforePublish,
			});

			await wrapper.find('[data-testid="publish-agent-button"]').trigger('click');
			await flushPromises();

			expect(beforePublish).toHaveBeenCalled();
			expect(publishAgent).not.toHaveBeenCalled();
		});

		it('publishes when beforePublish resolves true', async () => {
			const { publishAgent } = await import('../composables/useAgentApi');
			const updatedAgent = createAgent({ activeVersionId: 'v1', activeVersion });
			vi.mocked(publishAgent).mockResolvedValue(updatedAgent);
			const beforePublish = vi.fn().mockResolvedValue(true);
			const agent = createAgent({ activeVersionId: null });
			const wrapper = await renderComponent({
				agent,
				configValidationStatus: 'valid',
				beforePublish,
			});

			await wrapper.find('[data-testid="publish-agent-button"]').trigger('click');
			await flushPromises();

			expect(beforePublish).toHaveBeenCalled();
			expect(publishAgent).toHaveBeenCalledWith({}, 'project-1', 'agent-1');
			expect(wrapper.emitted('published')?.[0]).toEqual([updatedAgent]);
		});
	});

	// Permission gating
	describe('permission gating', () => {
		beforeEach(() => {
			agentPermissionsMock.canUpdate.value = true;
			agentPermissionsMock.canPublish.value = true;
			agentPermissionsMock.canUnpublish.value = true;
		});

		it('disables Publish main button and dropdown item when canPublish is false', async () => {
			agentPermissionsMock.canPublish.value = false;
			const wrapper = await renderComponent({ agent: createAgent({ activeVersionId: null }) });

			expect(
				wrapper.find('[data-testid="publish-agent-button"]').attributes('disabled'),
			).toBeDefined();
			expect(wrapper.find('[data-action="publish"]').attributes('disabled')).toBeDefined();
		});

		it('disables Unpublish dropdown item when canUnpublish is false', async () => {
			agentPermissionsMock.canUnpublish.value = false;
			const wrapper = await renderComponent({
				agent: createAgent({ versionId: 'v1', activeVersionId: 'v1', activeVersion }),
			});

			expect(wrapper.find('[data-action="unpublish"]').attributes('disabled')).toBeDefined();
		});

		it('disables Revert dropdown item when canUpdate is false', async () => {
			agentPermissionsMock.canUpdate.value = false;
			const wrapper = await renderComponent({
				agent: createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion }),
			});

			expect(
				wrapper.find('[data-action="revert-to-published"]').attributes('disabled'),
			).toBeDefined();
		});

		it('does not call publishAgent when Publish is clicked without canPublish', async () => {
			const { publishAgent } = await import('../composables/useAgentApi');
			agentPermissionsMock.canPublish.value = false;
			const wrapper = await renderComponent({ agent: createAgent({ activeVersionId: null }) });

			await wrapper.find('[data-testid="publish-agent-button"]').trigger('click');
			await flushPromises();

			expect(publishAgent).not.toHaveBeenCalled();
		});

		it('keeps publish independent from unpublish — granting only canPublish enables Publish but disables Unpublish', async () => {
			agentPermissionsMock.canUnpublish.value = false;
			const wrapper = await renderComponent({
				agent: createAgent({ versionId: 'v2', activeVersionId: 'v1', activeVersion }),
			});

			expect(wrapper.find('[data-action="publish"]').attributes('disabled')).toBeUndefined();
			expect(wrapper.find('[data-action="unpublish"]').attributes('disabled')).toBeDefined();
		});
	});
});
