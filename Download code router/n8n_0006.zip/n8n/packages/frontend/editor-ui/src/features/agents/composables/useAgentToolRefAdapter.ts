import { v4 as uuidv4 } from 'uuid';
import type { INode, INodeCredentials, INodeTypeDescription } from 'n8n-workflow';

import type { IWorkflowDb } from '@/Interface';
import type { AgentJsonMcpServerConfig, AgentJsonToolRef, NodeToolConfig } from '../types';

/**
 * Two-way adapter between the agent's persisted tool shape (`AgentJsonToolRef`
 * with `type: 'node'`) and the richer `INode` shape that the NDV parameter
 * form and Chat Hub's ToolListItem component both operate on.
 *
 * The agent config stores node tools as a flat ref:
 *   { type: 'node', name, description, node: { nodeType, nodeTypeVersion,
 *     nodeParameters, credentials }, requireApproval }
 *
 * Rendering a row in the tools list only needs `INode.type`, `typeVersion`,
 * `name`, and — for the settings/config panel — `parameters` and
 * `credentials`.
 */

function pickLatestVersion(version: number | number[]): number {
	if (Array.isArray(version)) {
		return [...version].sort((a, b) => b - a)[0] ?? 1;
	}
	return version;
}

/**
 * Convert the config's credential map to `INodeCredentials` for rendering,
 * carrying the n8n Connect managed marker through.
 */
function toINodeCredentials(
	credentials: NodeToolConfig['credentials'],
): INodeCredentials | undefined {
	if (!credentials) return undefined;
	const out: INodeCredentials = {};
	for (const [credType, value] of Object.entries(credentials)) {
		out[credType] =
			'__aiGatewayManaged' in value
				? { id: null, name: value.name, __aiGatewayManaged: true }
				: { id: value.id, name: value.name };
	}
	return out;
}

/**
 * Convert `INodeCredentials` back to the config shape. Drops entries whose
 * credential is not yet persisted (null id), except n8n Connect managed slots.
 */
function toConfigCredentials(
	credentials: INodeCredentials | undefined,
): NodeToolConfig['credentials'] {
	if (!credentials) return undefined;
	const out: NonNullable<NodeToolConfig['credentials']> = {};
	for (const [credType, value] of Object.entries(credentials)) {
		if (value.__aiGatewayManaged) {
			out[credType] = { id: null, name: value.name, __aiGatewayManaged: true };
			continue;
		}
		if (value.id === null) continue;
		out[credType] = { id: value.id, name: value.name };
	}
	return Object.keys(out).length > 0 ? out : undefined;
}

/** Shape a node-type `AgentJsonToolRef` as an `INode` for list rendering. */
export function toolRefToNode(ref: AgentJsonToolRef): INode | null {
	if (ref.type !== 'node' || !ref.node) return null;

	return {
		id: uuidv4(),
		name: ref.name ?? ref.node.nodeType,
		type: ref.node.nodeType,
		typeVersion: ref.node.nodeTypeVersion,
		parameters: (ref.node.nodeParameters ?? {}) as INode['parameters'],
		credentials: toINodeCredentials(ref.node.credentials),
		position: [0, 0],
	};
}

/** Build a new `AgentJsonToolRef` for a node type the user just connected. */
export function nodeTypeToNewToolRef(
	nodeType: INodeTypeDescription,
): Extract<AgentJsonToolRef, { type: 'node' }> {
	const version = pickLatestVersion(nodeType.version);
	return {
		type: 'node',
		// Display name may carry the " Tool" suffix the variant adds — strip it
		// so the sidebar + config modal show the service name, not "Slack Tool".
		name: nodeType.displayName.replace(/ Tool$/, ''),
		node: {
			// Keep the Tool-variant name as stored in the node-types store. The
			// backend resolver tolerates both forms, and the form render relies on
			// the variant description's AI codex to enable the $fromAI override.
			nodeType: nodeType.name,
			nodeTypeVersion: version,
			nodeParameters: {},
		},
	};
}

/**
 * Merge edits made to an `INode` back into the original ref (preserving extra
 * fields).
 */
export function updateToolRefFromNode(original: AgentJsonToolRef, node: INode): AgentJsonToolRef {
	if (original.type !== 'node' || !original.node) return original;

	return {
		...original,
		name: node.name,
		node: {
			...original.node,
			nodeType: node.type,
			nodeTypeVersion: node.typeVersion,
			nodeParameters: node.parameters as Record<string, unknown>,
			credentials: toConfigCredentials(node.credentials),
		},
	};
}

/**
 * Build a new `AgentJsonToolRef` of type `workflow` from the user's chosen
 * workflow. The id is the stable lookup key; the name remains display data and
 * the fallback for legacy refs.
 */
export function workflowToNewToolRef(
	workflow: IWorkflowDb,
): Extract<AgentJsonToolRef, { type: 'workflow' }> {
	return {
		type: 'workflow',
		workflowId: workflow.id,
		workflow: workflow.name,
		name: workflow.name,
		description: workflow.description ?? '',
		allOutputs: false,
	};
}

/**
 * Collect the display names of every tool in the list, optionally excluding
 * the one currently being edited. Feeds the config form's name-uniqueness
 * check from both the sidebar gear path and the tools-modal connect / gear
 * paths so they stay in sync.
 */
export function getExistingToolNames(
	tools: AgentJsonToolRef[],
	exclude?: AgentJsonToolRef,
): string[] {
	return tools
		.filter((t) => t !== exclude && t.type !== 'custom' && Boolean(t.name))
		.map((t) => (t as Extract<AgentJsonToolRef, { type: 'workflow' | 'node' }>).name!);
}

export function getExistingMcpServerNames(
	mcpServers: AgentJsonMcpServerConfig[],
	exclude?: AgentJsonMcpServerConfig,
): string[] {
	return mcpServers.filter((s) => s.name !== exclude?.name && Boolean(s.name)).map((s) => s.name);
}

/** Merge edits from the workflow config form back into the ref. */
export function updateWorkflowToolRef(
	original: AgentJsonToolRef,
	edits: {
		name: string;
		description: string;
		allOutputs: boolean;
		workflow: string;
		workflowId?: string;
		inputs?: Extract<AgentJsonToolRef, { type: 'workflow' }>['inputs'];
	},
): AgentJsonToolRef {
	if (original.type !== 'workflow') return original;
	const next: Extract<AgentJsonToolRef, { type: 'workflow' }> = {
		...original,
		name: edits.name,
		description: edits.description,
		allOutputs: edits.allOutputs,
		workflow: edits.workflow,
		...(edits.workflowId !== undefined ? { workflowId: edits.workflowId } : {}),
	};
	if ('inputs' in edits) {
		if (edits.inputs && Object.keys(edits.inputs).length > 0) {
			next.inputs = edits.inputs;
		} else {
			delete next.inputs;
		}
	}
	return next;
}
