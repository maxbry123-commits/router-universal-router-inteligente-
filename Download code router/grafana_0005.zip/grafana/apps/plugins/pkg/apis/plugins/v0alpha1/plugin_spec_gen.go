// Code generated - EDITING IS FUTILE. DO NOT EDIT.

package v0alpha1

// +k8s:openapi-gen=true
type PluginSpec struct {
	Id       string  `json:"id"`
	Version  string  `json:"version"`
	Url      *string `json:"url,omitempty"`
	ParentId *string `json:"parentId,omitempty"`
}

// NewPluginSpec creates a new PluginSpec object.
func NewPluginSpec() *PluginSpec {
	return &PluginSpec{}
}

// OpenAPIModelName returns the OpenAPI model name for PluginSpec.
func (PluginSpec) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.PluginSpec"
}
