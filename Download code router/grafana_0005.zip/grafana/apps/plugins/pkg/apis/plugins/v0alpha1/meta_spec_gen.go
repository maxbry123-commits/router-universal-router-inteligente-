// Code generated - EDITING IS FUTILE. DO NOT EDIT.

package v0alpha1

// JSON configuration schema for Grafana plugins
// Converted from: https://github.com/grafana/grafana/blob/main/docs/sources/developers/plugins/plugin.schema.json
// +k8s:openapi-gen=true
type MetaJSONData struct {
	// Unique name of the plugin
	Id string `json:"id"`
	// Plugin type
	Type MetaJSONDataType `json:"type"`
	// Human-readable name of the plugin
	Name string `json:"name"`
	// Metadata for the plugin
	Info MetaInfo `json:"info"`
	// Dependency information
	Dependencies MetaDependencies `json:"dependencies"`
	// Optional fields
	Alerting           *bool                   `json:"alerting,omitempty"`
	Annotations        *bool                   `json:"annotations,omitempty"`
	AutoEnabled        *bool                   `json:"autoEnabled,omitempty"`
	Backend            *bool                   `json:"backend,omitempty"`
	BuildMode          *string                 `json:"buildMode,omitempty"`
	BuiltIn            *bool                   `json:"builtIn,omitempty"`
	Category           *string                 `json:"category,omitempty"`
	EnterpriseFeatures *MetaEnterpriseFeatures `json:"enterpriseFeatures,omitempty"`
	Executable         *string                 `json:"executable,omitempty"`
	HideFromList       *bool                   `json:"hideFromList,omitempty"`
	// +listType=atomic
	Includes                  []MetaInclude     `json:"includes,omitempty"`
	Logs                      *bool             `json:"logs,omitempty"`
	Metrics                   *bool             `json:"metrics,omitempty"`
	MultiValueFilterOperators *bool             `json:"multiValueFilterOperators,omitempty"`
	PascalName                *string           `json:"pascalName,omitempty"`
	Preload                   *bool             `json:"preload,omitempty"`
	QueryOptions              *MetaQueryOptions `json:"queryOptions,omitempty"`
	// +listType=atomic
	Routes        []MetaRoute        `json:"routes,omitempty"`
	SkipDataQuery *bool              `json:"skipDataQuery,omitempty"`
	State         *MetaJSONDataState `json:"state,omitempty"`
	Streaming     *bool              `json:"streaming,omitempty"`
	Suggestions   *bool              `json:"suggestions,omitempty"`
	Tracing       *bool              `json:"tracing,omitempty"`
	Iam           *MetaIAM           `json:"iam,omitempty"`
	// +listType=atomic
	Roles      []MetaRole      `json:"roles,omitempty"`
	Extensions *MetaExtensions `json:"extensions,omitempty"`
	// +listType=atomic
	Languages []string `json:"languages,omitempty"`
}

// NewMetaJSONData creates a new MetaJSONData object.
func NewMetaJSONData() *MetaJSONData {
	return &MetaJSONData{
		Info:         *NewMetaInfo(),
		Dependencies: *NewMetaDependencies(),
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaJSONData.
func (MetaJSONData) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaJSONData"
}

// +k8s:openapi-gen=true
type MetaInfo struct {
	// Required fields
	// +listType=set
	Keywords []string              `json:"keywords"`
	Logos    MetaV0alpha1InfoLogos `json:"logos"`
	Updated  string                `json:"updated"`
	Version  string                `json:"version"`
	// Optional fields
	Author      *MetaV0alpha1InfoAuthor `json:"author,omitempty"`
	Description *string                 `json:"description,omitempty"`
	Build       *MetaV0alpha1InfoBuild  `json:"build,omitempty"`
	// +listType=atomic
	Links []MetaV0alpha1InfoLinks `json:"links,omitempty"`
	// +listType=atomic
	Screenshots []MetaV0alpha1InfoScreenshots `json:"screenshots,omitempty"`
}

// NewMetaInfo creates a new MetaInfo object.
func NewMetaInfo() *MetaInfo {
	return &MetaInfo{
		Keywords: []string{},
		Logos:    *NewMetaV0alpha1InfoLogos(),
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaInfo.
func (MetaInfo) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaInfo"
}

// +k8s:openapi-gen=true
type MetaDependencies struct {
	// Required field
	GrafanaDependency string `json:"grafanaDependency"`
	// Optional fields
	GrafanaVersion *string `json:"grafanaVersion,omitempty"`
	// +listType=set
	// +listMapKey=id
	Plugins    []MetaV0alpha1DependenciesPlugins   `json:"plugins,omitempty"`
	Extensions *MetaV0alpha1DependenciesExtensions `json:"extensions,omitempty"`
}

// NewMetaDependencies creates a new MetaDependencies object.
func NewMetaDependencies() *MetaDependencies {
	return &MetaDependencies{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaDependencies.
func (MetaDependencies) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaDependencies"
}

// +k8s:openapi-gen=true
type MetaEnterpriseFeatures struct {
	// Allow additional properties
	HealthDiagnosticsErrors *bool `json:"healthDiagnosticsErrors,omitempty"`
}

// NewMetaEnterpriseFeatures creates a new MetaEnterpriseFeatures object.
func NewMetaEnterpriseFeatures() *MetaEnterpriseFeatures {
	return &MetaEnterpriseFeatures{
		HealthDiagnosticsErrors: (func(input bool) *bool { return &input })(false),
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaEnterpriseFeatures.
func (MetaEnterpriseFeatures) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaEnterpriseFeatures"
}

// +k8s:openapi-gen=true
type MetaInclude struct {
	Uid        *string          `json:"uid,omitempty"`
	Type       *MetaIncludeType `json:"type,omitempty"`
	Name       *string          `json:"name,omitempty"`
	Component  *string          `json:"component,omitempty"`
	Role       *MetaIncludeRole `json:"role,omitempty"`
	Action     *string          `json:"action,omitempty"`
	Path       *string          `json:"path,omitempty"`
	AddToNav   *bool            `json:"addToNav,omitempty"`
	DefaultNav *bool            `json:"defaultNav,omitempty"`
	Icon       *string          `json:"icon,omitempty"`
}

// NewMetaInclude creates a new MetaInclude object.
func NewMetaInclude() *MetaInclude {
	return &MetaInclude{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaInclude.
func (MetaInclude) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaInclude"
}

// +k8s:openapi-gen=true
type MetaQueryOptions struct {
	MaxDataPoints *bool `json:"maxDataPoints,omitempty"`
	MinInterval   *bool `json:"minInterval,omitempty"`
	CacheTimeout  *bool `json:"cacheTimeout,omitempty"`
}

// NewMetaQueryOptions creates a new MetaQueryOptions object.
func NewMetaQueryOptions() *MetaQueryOptions {
	return &MetaQueryOptions{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaQueryOptions.
func (MetaQueryOptions) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaQueryOptions"
}

// +k8s:openapi-gen=true
type MetaRoute struct {
	Path        *string `json:"path,omitempty"`
	Method      *string `json:"method,omitempty"`
	Url         *string `json:"url,omitempty"`
	ReqSignedIn *bool   `json:"reqSignedIn,omitempty"`
	ReqRole     *string `json:"reqRole,omitempty"`
	ReqAction   *string `json:"reqAction,omitempty"`
	// +listType=atomic
	Headers      []MetaV0alpha1RouteHeaders     `json:"headers,omitempty"`
	Body         map[string]interface{}         `json:"body,omitempty"`
	TokenAuth    *MetaV0alpha1RouteTokenAuth    `json:"tokenAuth,omitempty"`
	JwtTokenAuth *MetaV0alpha1RouteJwtTokenAuth `json:"jwtTokenAuth,omitempty"`
	// +listType=atomic
	UrlParams []MetaV0alpha1RouteUrlParams `json:"urlParams,omitempty"`
}

// NewMetaRoute creates a new MetaRoute object.
func NewMetaRoute() *MetaRoute {
	return &MetaRoute{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaRoute.
func (MetaRoute) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaRoute"
}

// +k8s:openapi-gen=true
type MetaIAM struct {
	// +listType=atomic
	Permissions []MetaV0alpha1IAMPermissions `json:"permissions,omitempty"`
}

// NewMetaIAM creates a new MetaIAM object.
func NewMetaIAM() *MetaIAM {
	return &MetaIAM{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaIAM.
func (MetaIAM) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaIAM"
}

// +k8s:openapi-gen=true
type MetaRole struct {
	Role *MetaV0alpha1RoleRole `json:"role,omitempty"`
	// +listType=set
	Grants []string `json:"grants,omitempty"`
}

// NewMetaRole creates a new MetaRole object.
func NewMetaRole() *MetaRole {
	return &MetaRole{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaRole.
func (MetaRole) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaRole"
}

// +k8s:openapi-gen=true
type MetaExtensions struct {
	// +listType=atomic
	AddedComponents []MetaV0alpha1ExtensionsAddedComponents `json:"addedComponents,omitempty"`
	// +listType=atomic
	AddedLinks []MetaV0alpha1ExtensionsAddedLinks `json:"addedLinks,omitempty"`
	// +listType=atomic
	AddedFunctions []MetaV0alpha1ExtensionsAddedFunctions `json:"addedFunctions,omitempty"`
	// +listType=set
	// +listMapKey=id
	ExposedComponents []MetaV0alpha1ExtensionsExposedComponents `json:"exposedComponents,omitempty"`
	// +listType=set
	// +listMapKey=id
	ExtensionPoints []MetaV0alpha1ExtensionsExtensionPoints `json:"extensionPoints,omitempty"`
}

// NewMetaExtensions creates a new MetaExtensions object.
func NewMetaExtensions() *MetaExtensions {
	return &MetaExtensions{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaExtensions.
func (MetaExtensions) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaExtensions"
}

// +k8s:openapi-gen=true
type MetaSpec struct {
	PluginJson   MetaJSONData              `json:"pluginJson"`
	Class        MetaSpecClass             `json:"class"`
	Module       MetaV0alpha1SpecModule    `json:"module"`
	BaseURL      string                    `json:"baseURL"`
	Signature    MetaV0alpha1SpecSignature `json:"signature"`
	Translations map[string]string         `json:"translations,omitempty"`
	// +listType=atomic
	Children []string `json:"children,omitempty"`
	// +listType=atomic
	AliasIds []string `json:"aliasIds,omitempty"`
}

// NewMetaSpec creates a new MetaSpec object.
func NewMetaSpec() *MetaSpec {
	return &MetaSpec{
		PluginJson: *NewMetaJSONData(),
		Module:     *NewMetaV0alpha1SpecModule(),
		Signature:  *NewMetaV0alpha1SpecSignature(),
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaSpec.
func (MetaSpec) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaSpec"
}

// +k8s:openapi-gen=true
type MetaV0alpha1InfoLogos struct {
	Small string `json:"small"`
	Large string `json:"large"`
}

// NewMetaV0alpha1InfoLogos creates a new MetaV0alpha1InfoLogos object.
func NewMetaV0alpha1InfoLogos() *MetaV0alpha1InfoLogos {
	return &MetaV0alpha1InfoLogos{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1InfoLogos.
func (MetaV0alpha1InfoLogos) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1InfoLogos"
}

// +k8s:openapi-gen=true
type MetaV0alpha1InfoAuthor struct {
	Name  *string `json:"name,omitempty"`
	Email *string `json:"email,omitempty"`
	Url   *string `json:"url,omitempty"`
}

// NewMetaV0alpha1InfoAuthor creates a new MetaV0alpha1InfoAuthor object.
func NewMetaV0alpha1InfoAuthor() *MetaV0alpha1InfoAuthor {
	return &MetaV0alpha1InfoAuthor{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1InfoAuthor.
func (MetaV0alpha1InfoAuthor) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1InfoAuthor"
}

// +k8s:openapi-gen=true
type MetaV0alpha1InfoBuild struct {
	Time   *float64 `json:"time,omitempty"`
	Repo   *string  `json:"repo,omitempty"`
	Branch *string  `json:"branch,omitempty"`
	Hash   *string  `json:"hash,omitempty"`
	// Quoted to avoid conflict with CUE 'number' type
	Number *float64 `json:"number,omitempty"`
	Pr     *float64 `json:"pr,omitempty"`
	Build  *float64 `json:"build,omitempty"`
}

// NewMetaV0alpha1InfoBuild creates a new MetaV0alpha1InfoBuild object.
func NewMetaV0alpha1InfoBuild() *MetaV0alpha1InfoBuild {
	return &MetaV0alpha1InfoBuild{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1InfoBuild.
func (MetaV0alpha1InfoBuild) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1InfoBuild"
}

// +k8s:openapi-gen=true
type MetaV0alpha1InfoLinks struct {
	Name   *string                      `json:"name,omitempty"`
	Url    *string                      `json:"url,omitempty"`
	Target *MetaV0alpha1InfoLinksTarget `json:"target,omitempty"`
}

// NewMetaV0alpha1InfoLinks creates a new MetaV0alpha1InfoLinks object.
func NewMetaV0alpha1InfoLinks() *MetaV0alpha1InfoLinks {
	return &MetaV0alpha1InfoLinks{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1InfoLinks.
func (MetaV0alpha1InfoLinks) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1InfoLinks"
}

// +k8s:openapi-gen=true
type MetaV0alpha1InfoScreenshots struct {
	Name *string `json:"name,omitempty"`
	Path *string `json:"path,omitempty"`
}

// NewMetaV0alpha1InfoScreenshots creates a new MetaV0alpha1InfoScreenshots object.
func NewMetaV0alpha1InfoScreenshots() *MetaV0alpha1InfoScreenshots {
	return &MetaV0alpha1InfoScreenshots{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1InfoScreenshots.
func (MetaV0alpha1InfoScreenshots) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1InfoScreenshots"
}

// +k8s:openapi-gen=true
type MetaV0alpha1DependenciesPlugins struct {
	Id   string                              `json:"id"`
	Type MetaV0alpha1DependenciesPluginsType `json:"type"`
	Name string                              `json:"name"`
}

// NewMetaV0alpha1DependenciesPlugins creates a new MetaV0alpha1DependenciesPlugins object.
func NewMetaV0alpha1DependenciesPlugins() *MetaV0alpha1DependenciesPlugins {
	return &MetaV0alpha1DependenciesPlugins{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1DependenciesPlugins.
func (MetaV0alpha1DependenciesPlugins) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1DependenciesPlugins"
}

// +k8s:openapi-gen=true
type MetaV0alpha1DependenciesExtensions struct {
	// +listType=set
	ExposedComponents []string `json:"exposedComponents,omitempty"`
}

// NewMetaV0alpha1DependenciesExtensions creates a new MetaV0alpha1DependenciesExtensions object.
func NewMetaV0alpha1DependenciesExtensions() *MetaV0alpha1DependenciesExtensions {
	return &MetaV0alpha1DependenciesExtensions{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1DependenciesExtensions.
func (MetaV0alpha1DependenciesExtensions) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1DependenciesExtensions"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RouteHeaders struct {
	Name    string `json:"name"`
	Content string `json:"content"`
}

// NewMetaV0alpha1RouteHeaders creates a new MetaV0alpha1RouteHeaders object.
func NewMetaV0alpha1RouteHeaders() *MetaV0alpha1RouteHeaders {
	return &MetaV0alpha1RouteHeaders{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RouteHeaders.
func (MetaV0alpha1RouteHeaders) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RouteHeaders"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RouteTokenAuthParams struct {
	// Allow additional properties
	GrantType *string `json:"grant_type,omitempty"`
	// Allow additional properties
	ClientId *string `json:"client_id,omitempty"`
	// Allow additional properties
	ClientSecret *string `json:"client_secret,omitempty"`
	// Allow additional properties
	Resource *string `json:"resource,omitempty"`
}

// NewMetaV0alpha1RouteTokenAuthParams creates a new MetaV0alpha1RouteTokenAuthParams object.
func NewMetaV0alpha1RouteTokenAuthParams() *MetaV0alpha1RouteTokenAuthParams {
	return &MetaV0alpha1RouteTokenAuthParams{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RouteTokenAuthParams.
func (MetaV0alpha1RouteTokenAuthParams) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RouteTokenAuthParams"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RouteTokenAuth struct {
	Url *string `json:"url,omitempty"`
	// +listType=set
	Scopes []string                          `json:"scopes,omitempty"`
	Params *MetaV0alpha1RouteTokenAuthParams `json:"params,omitempty"`
}

// NewMetaV0alpha1RouteTokenAuth creates a new MetaV0alpha1RouteTokenAuth object.
func NewMetaV0alpha1RouteTokenAuth() *MetaV0alpha1RouteTokenAuth {
	return &MetaV0alpha1RouteTokenAuth{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RouteTokenAuth.
func (MetaV0alpha1RouteTokenAuth) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RouteTokenAuth"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RouteJwtTokenAuthParams struct {
	// Allow additional properties
	TokenUri *string `json:"token_uri,omitempty"`
	// Allow additional properties
	ClientEmail *string `json:"client_email,omitempty"`
	// Allow additional properties
	PrivateKey *string `json:"private_key,omitempty"`
}

// NewMetaV0alpha1RouteJwtTokenAuthParams creates a new MetaV0alpha1RouteJwtTokenAuthParams object.
func NewMetaV0alpha1RouteJwtTokenAuthParams() *MetaV0alpha1RouteJwtTokenAuthParams {
	return &MetaV0alpha1RouteJwtTokenAuthParams{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RouteJwtTokenAuthParams.
func (MetaV0alpha1RouteJwtTokenAuthParams) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RouteJwtTokenAuthParams"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RouteJwtTokenAuth struct {
	Url *string `json:"url,omitempty"`
	// +listType=set
	Scopes []string                             `json:"scopes,omitempty"`
	Params *MetaV0alpha1RouteJwtTokenAuthParams `json:"params,omitempty"`
}

// NewMetaV0alpha1RouteJwtTokenAuth creates a new MetaV0alpha1RouteJwtTokenAuth object.
func NewMetaV0alpha1RouteJwtTokenAuth() *MetaV0alpha1RouteJwtTokenAuth {
	return &MetaV0alpha1RouteJwtTokenAuth{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RouteJwtTokenAuth.
func (MetaV0alpha1RouteJwtTokenAuth) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RouteJwtTokenAuth"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RouteUrlParams struct {
	Name    *string `json:"name,omitempty"`
	Content *string `json:"content,omitempty"`
}

// NewMetaV0alpha1RouteUrlParams creates a new MetaV0alpha1RouteUrlParams object.
func NewMetaV0alpha1RouteUrlParams() *MetaV0alpha1RouteUrlParams {
	return &MetaV0alpha1RouteUrlParams{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RouteUrlParams.
func (MetaV0alpha1RouteUrlParams) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RouteUrlParams"
}

// +k8s:openapi-gen=true
type MetaV0alpha1IAMPermissions struct {
	Action *string `json:"action,omitempty"`
	Scope  *string `json:"scope,omitempty"`
}

// NewMetaV0alpha1IAMPermissions creates a new MetaV0alpha1IAMPermissions object.
func NewMetaV0alpha1IAMPermissions() *MetaV0alpha1IAMPermissions {
	return &MetaV0alpha1IAMPermissions{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1IAMPermissions.
func (MetaV0alpha1IAMPermissions) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1IAMPermissions"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RoleRolePermissions struct {
	Action *string `json:"action,omitempty"`
	Scope  *string `json:"scope,omitempty"`
}

// NewMetaV0alpha1RoleRolePermissions creates a new MetaV0alpha1RoleRolePermissions object.
func NewMetaV0alpha1RoleRolePermissions() *MetaV0alpha1RoleRolePermissions {
	return &MetaV0alpha1RoleRolePermissions{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RoleRolePermissions.
func (MetaV0alpha1RoleRolePermissions) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RoleRolePermissions"
}

// +k8s:openapi-gen=true
type MetaV0alpha1RoleRole struct {
	Name        *string `json:"name,omitempty"`
	Description *string `json:"description,omitempty"`
	// +listType=atomic
	Permissions []MetaV0alpha1RoleRolePermissions `json:"permissions,omitempty"`
}

// NewMetaV0alpha1RoleRole creates a new MetaV0alpha1RoleRole object.
func NewMetaV0alpha1RoleRole() *MetaV0alpha1RoleRole {
	return &MetaV0alpha1RoleRole{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1RoleRole.
func (MetaV0alpha1RoleRole) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1RoleRole"
}

// +k8s:openapi-gen=true
type MetaV0alpha1ExtensionsAddedComponents struct {
	// +listType=set
	Targets     []string `json:"targets"`
	Title       string   `json:"title"`
	Description *string  `json:"description,omitempty"`
}

// NewMetaV0alpha1ExtensionsAddedComponents creates a new MetaV0alpha1ExtensionsAddedComponents object.
func NewMetaV0alpha1ExtensionsAddedComponents() *MetaV0alpha1ExtensionsAddedComponents {
	return &MetaV0alpha1ExtensionsAddedComponents{
		Targets: []string{},
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1ExtensionsAddedComponents.
func (MetaV0alpha1ExtensionsAddedComponents) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1ExtensionsAddedComponents"
}

// +k8s:openapi-gen=true
type MetaV0alpha1ExtensionsAddedLinks struct {
	// +listType=set
	Targets     []string `json:"targets"`
	Title       string   `json:"title"`
	Description *string  `json:"description,omitempty"`
}

// NewMetaV0alpha1ExtensionsAddedLinks creates a new MetaV0alpha1ExtensionsAddedLinks object.
func NewMetaV0alpha1ExtensionsAddedLinks() *MetaV0alpha1ExtensionsAddedLinks {
	return &MetaV0alpha1ExtensionsAddedLinks{
		Targets: []string{},
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1ExtensionsAddedLinks.
func (MetaV0alpha1ExtensionsAddedLinks) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1ExtensionsAddedLinks"
}

// +k8s:openapi-gen=true
type MetaV0alpha1ExtensionsAddedFunctions struct {
	// +listType=set
	Targets     []string `json:"targets"`
	Title       string   `json:"title"`
	Description *string  `json:"description,omitempty"`
}

// NewMetaV0alpha1ExtensionsAddedFunctions creates a new MetaV0alpha1ExtensionsAddedFunctions object.
func NewMetaV0alpha1ExtensionsAddedFunctions() *MetaV0alpha1ExtensionsAddedFunctions {
	return &MetaV0alpha1ExtensionsAddedFunctions{
		Targets: []string{},
	}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1ExtensionsAddedFunctions.
func (MetaV0alpha1ExtensionsAddedFunctions) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1ExtensionsAddedFunctions"
}

// +k8s:openapi-gen=true
type MetaV0alpha1ExtensionsExposedComponents struct {
	Id          string  `json:"id"`
	Title       *string `json:"title,omitempty"`
	Description *string `json:"description,omitempty"`
}

// NewMetaV0alpha1ExtensionsExposedComponents creates a new MetaV0alpha1ExtensionsExposedComponents object.
func NewMetaV0alpha1ExtensionsExposedComponents() *MetaV0alpha1ExtensionsExposedComponents {
	return &MetaV0alpha1ExtensionsExposedComponents{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1ExtensionsExposedComponents.
func (MetaV0alpha1ExtensionsExposedComponents) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1ExtensionsExposedComponents"
}

// +k8s:openapi-gen=true
type MetaV0alpha1ExtensionsExtensionPoints struct {
	Id          string  `json:"id"`
	Title       *string `json:"title,omitempty"`
	Description *string `json:"description,omitempty"`
}

// NewMetaV0alpha1ExtensionsExtensionPoints creates a new MetaV0alpha1ExtensionsExtensionPoints object.
func NewMetaV0alpha1ExtensionsExtensionPoints() *MetaV0alpha1ExtensionsExtensionPoints {
	return &MetaV0alpha1ExtensionsExtensionPoints{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1ExtensionsExtensionPoints.
func (MetaV0alpha1ExtensionsExtensionPoints) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1ExtensionsExtensionPoints"
}

// +k8s:openapi-gen=true
type MetaV0alpha1SpecModule struct {
	Path            string                                `json:"path"`
	Hash            *string                               `json:"hash,omitempty"`
	LoadingStrategy MetaV0alpha1SpecModuleLoadingStrategy `json:"loadingStrategy"`
}

// NewMetaV0alpha1SpecModule creates a new MetaV0alpha1SpecModule object.
func NewMetaV0alpha1SpecModule() *MetaV0alpha1SpecModule {
	return &MetaV0alpha1SpecModule{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1SpecModule.
func (MetaV0alpha1SpecModule) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1SpecModule"
}

// +k8s:openapi-gen=true
type MetaV0alpha1SpecSignature struct {
	Status MetaV0alpha1SpecSignatureStatus `json:"status"`
	Type   *MetaV0alpha1SpecSignatureType  `json:"type,omitempty"`
	Org    *string                         `json:"org,omitempty"`
}

// NewMetaV0alpha1SpecSignature creates a new MetaV0alpha1SpecSignature object.
func NewMetaV0alpha1SpecSignature() *MetaV0alpha1SpecSignature {
	return &MetaV0alpha1SpecSignature{}
}

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1SpecSignature.
func (MetaV0alpha1SpecSignature) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1SpecSignature"
}

// +k8s:openapi-gen=true
type MetaJSONDataType string

const (
	MetaJSONDataTypeApp        MetaJSONDataType = "app"
	MetaJSONDataTypeDatasource MetaJSONDataType = "datasource"
	MetaJSONDataTypePanel      MetaJSONDataType = "panel"
	MetaJSONDataTypeRenderer   MetaJSONDataType = "renderer"
)

// OpenAPIModelName returns the OpenAPI model name for MetaJSONDataType.
func (MetaJSONDataType) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaJSONDataType"
}

// +k8s:openapi-gen=true
type MetaJSONDataState string

const (
	MetaJSONDataStateAlpha      MetaJSONDataState = "alpha"
	MetaJSONDataStateBeta       MetaJSONDataState = "beta"
	MetaJSONDataStateStable     MetaJSONDataState = "stable"
	MetaJSONDataStateDeprecated MetaJSONDataState = "deprecated"
)

// OpenAPIModelName returns the OpenAPI model name for MetaJSONDataState.
func (MetaJSONDataState) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaJSONDataState"
}

// +k8s:openapi-gen=true
type MetaIncludeType string

const (
	MetaIncludeTypeDashboard  MetaIncludeType = "dashboard"
	MetaIncludeTypePage       MetaIncludeType = "page"
	MetaIncludeTypePanel      MetaIncludeType = "panel"
	MetaIncludeTypeDatasource MetaIncludeType = "datasource"
)

// OpenAPIModelName returns the OpenAPI model name for MetaIncludeType.
func (MetaIncludeType) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaIncludeType"
}

// +k8s:openapi-gen=true
type MetaIncludeRole string

const (
	MetaIncludeRoleAdmin  MetaIncludeRole = "Admin"
	MetaIncludeRoleEditor MetaIncludeRole = "Editor"
	MetaIncludeRoleViewer MetaIncludeRole = "Viewer"
	MetaIncludeRoleNone   MetaIncludeRole = "None"
)

// OpenAPIModelName returns the OpenAPI model name for MetaIncludeRole.
func (MetaIncludeRole) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaIncludeRole"
}

// +k8s:openapi-gen=true
type MetaSpecClass string

const (
	MetaSpecClassCore     MetaSpecClass = "core"
	MetaSpecClassExternal MetaSpecClass = "external"
)

// OpenAPIModelName returns the OpenAPI model name for MetaSpecClass.
func (MetaSpecClass) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaSpecClass"
}

// +k8s:openapi-gen=true
type MetaV0alpha1InfoLinksTarget string

const (
	MetaV0alpha1InfoLinksTargetBlank  MetaV0alpha1InfoLinksTarget = "_blank"
	MetaV0alpha1InfoLinksTargetSelf   MetaV0alpha1InfoLinksTarget = "_self"
	MetaV0alpha1InfoLinksTargetParent MetaV0alpha1InfoLinksTarget = "_parent"
	MetaV0alpha1InfoLinksTargetTop    MetaV0alpha1InfoLinksTarget = "_top"
)

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1InfoLinksTarget.
func (MetaV0alpha1InfoLinksTarget) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1InfoLinksTarget"
}

// +k8s:openapi-gen=true
type MetaV0alpha1DependenciesPluginsType string

const (
	MetaV0alpha1DependenciesPluginsTypeApp        MetaV0alpha1DependenciesPluginsType = "app"
	MetaV0alpha1DependenciesPluginsTypeDatasource MetaV0alpha1DependenciesPluginsType = "datasource"
	MetaV0alpha1DependenciesPluginsTypePanel      MetaV0alpha1DependenciesPluginsType = "panel"
)

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1DependenciesPluginsType.
func (MetaV0alpha1DependenciesPluginsType) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1DependenciesPluginsType"
}

// +k8s:openapi-gen=true
type MetaV0alpha1SpecModuleLoadingStrategy string

const (
	MetaV0alpha1SpecModuleLoadingStrategyFetch  MetaV0alpha1SpecModuleLoadingStrategy = "fetch"
	MetaV0alpha1SpecModuleLoadingStrategyScript MetaV0alpha1SpecModuleLoadingStrategy = "script"
)

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1SpecModuleLoadingStrategy.
func (MetaV0alpha1SpecModuleLoadingStrategy) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1SpecModuleLoadingStrategy"
}

// +k8s:openapi-gen=true
type MetaV0alpha1SpecSignatureStatus string

const (
	MetaV0alpha1SpecSignatureStatusInternal MetaV0alpha1SpecSignatureStatus = "internal"
	MetaV0alpha1SpecSignatureStatusValid    MetaV0alpha1SpecSignatureStatus = "valid"
	MetaV0alpha1SpecSignatureStatusInvalid  MetaV0alpha1SpecSignatureStatus = "invalid"
	MetaV0alpha1SpecSignatureStatusModified MetaV0alpha1SpecSignatureStatus = "modified"
	MetaV0alpha1SpecSignatureStatusUnsigned MetaV0alpha1SpecSignatureStatus = "unsigned"
)

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1SpecSignatureStatus.
func (MetaV0alpha1SpecSignatureStatus) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1SpecSignatureStatus"
}

// +k8s:openapi-gen=true
type MetaV0alpha1SpecSignatureType string

const (
	MetaV0alpha1SpecSignatureTypeGrafana     MetaV0alpha1SpecSignatureType = "grafana"
	MetaV0alpha1SpecSignatureTypeCommercial  MetaV0alpha1SpecSignatureType = "commercial"
	MetaV0alpha1SpecSignatureTypeCommunity   MetaV0alpha1SpecSignatureType = "community"
	MetaV0alpha1SpecSignatureTypePrivate     MetaV0alpha1SpecSignatureType = "private"
	MetaV0alpha1SpecSignatureTypePrivateGlob MetaV0alpha1SpecSignatureType = "private-glob"
)

// OpenAPIModelName returns the OpenAPI model name for MetaV0alpha1SpecSignatureType.
func (MetaV0alpha1SpecSignatureType) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.plugins.pkg.apis.plugins.v0alpha1.MetaV0alpha1SpecSignatureType"
}
