package meta

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/grafana/grafana-app-sdk/logging"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	pluginsv0alpha1 "github.com/grafana/grafana/apps/plugins/pkg/apis/plugins/v0alpha1"
)

func TestCatalogProvider_GetMeta(t *testing.T) {
	ctx := context.Background()

	t.Run("successfully fetches plugin metadata", func(t *testing.T) {
		expectedMeta := pluginsv0alpha1.MetaJSONData{
			Id:   "test-plugin",
			Name: "Test Plugin",
			Type: pluginsv0alpha1.MetaJSONDataTypeDatasource,
		}

		childJSON := pluginsv0alpha1.MetaJSONData{
			Id:   "test-child-plugin",
			Name: "Test Child Plugin",
			Type: pluginsv0alpha1.MetaJSONDataTypePanel,
		}

		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			assert.Equal(t, http.MethodGet, r.Method)
			assert.Equal(t, "/api/plugins/test-plugin/versions/1.0.0", r.URL.Path)
			assert.Equal(t, "application/json", r.Header.Get("Accept"))
			assert.Equal(t, "grafana-plugins-app", r.Header.Get("User-Agent"))

			response := grafanaComPluginVersionMeta{
				PluginSlug:          "test-plugin",
				Version:             "1.0.0",
				JSON:                grafanaComPluginVersionMetaJSON{MetaJSONData: expectedMeta},
				SignatureType:       "grafana",
				SignedByOrg:         "grafana",
				CDNURL:              "https://cdn.grafana.com/plugins/test-plugin/1.0.0",
				CreatePluginVersion: "4.15.0",
				Manifest: grafanaComPluginManifest{
					Files: map[string]string{
						"module.js":                   "deadbeef",
						"test-child-plugin/module.js": "beefcafe",
					},
				},
				Children: []grafanaComChildPluginVersion{
					{
						Slug: "test-child-plugin",
						Path: "test-child-plugin",
						JSON: grafanaComPluginVersionMetaJSON{MetaJSONData: childJSON},
					},
				},
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})
		require.NoError(t, err)
		require.NotNil(t, result)
		// The plugin.json has no version, so it falls back to the gcom version.
		expectedWithVersion := expectedMeta
		expectedWithVersion.Info.Version = "1.0.0"
		assert.Equal(t, expectedWithVersion, result.Meta.PluginJson)
		assert.Equal(t, pluginsv0alpha1.MetaSpecClassExternal, result.Meta.Class)
		assert.Equal(t, pluginsv0alpha1.MetaV0alpha1SpecSignatureStatusValid, result.Meta.Signature.Status)
		assert.Equal(t, pluginsv0alpha1.MetaV0alpha1SpecSignatureTypeGrafana, *result.Meta.Signature.Type)
		assert.Equal(t, "grafana", *result.Meta.Signature.Org)
		assert.Equal(t, result.Meta.Module.Path, "https://cdn.grafana.com/plugins/test-plugin/1.0.0/module.js")
		// The manifest stores a raw hex hash; the meta exposes it in SRI format.
		assert.Equal(t, "sha256-3q2+7w==", *result.Meta.Module.Hash)
		assert.Equal(t, pluginsv0alpha1.MetaV0alpha1SpecModuleLoadingStrategyScript, result.Meta.Module.LoadingStrategy)
		assert.Equal(t, "https://cdn.grafana.com/plugins/test-plugin/1.0.0", result.Meta.BaseURL)
		assert.Equal(t, []string{"test-child-plugin"}, result.Meta.Children)
		assert.Equal(t, defaultCatalogTTL, result.TTL)

		t.Run("fetches child plugin from parent", func(t *testing.T) {
			parentID := "test-plugin"
			childResult, err := provider.GetMeta(ctx, PluginRef{
				ID:       "test-child-plugin",
				Version:  "1.0.0",
				ParentID: &parentID,
			})

			require.NoError(t, err)
			require.NotNil(t, childResult)
			// Child plugin should have its own JSON data, with the version
			// inherited from the parent (its own plugin.json has none).
			expectedChild := childJSON
			expectedChild.Info.Version = "1.0.0"
			assert.Equal(t, expectedChild, childResult.Meta.PluginJson)
			assert.Equal(t, pluginsv0alpha1.MetaSpecClassExternal, childResult.Meta.Class)

			// Child inherits signature from parent
			assert.Equal(t, result.Meta.Signature.Status, childResult.Meta.Signature.Status)
			assert.Equal(t, *result.Meta.Signature.Type, *childResult.Meta.Signature.Type)
			assert.Equal(t, *result.Meta.Signature.Org, *childResult.Meta.Signature.Org)

			// Child has its own module path based on child path
			assert.Equal(t, "https://cdn.grafana.com/plugins/test-plugin/1.0.0/test-child-plugin/module.js", childResult.Meta.Module.Path)
			assert.Equal(t, "sha256-vu/K/g==", *childResult.Meta.Module.Hash)

			// BaseURL should be constructed from parent CDNURL + child path
			assert.Equal(t, "https://cdn.grafana.com/plugins/test-plugin/1.0.0/test-child-plugin", childResult.Meta.BaseURL)

			assert.Equal(t, defaultCatalogTTL, childResult.TTL)
		})
	})

	t.Run("successfully fetches plugin with aliasIDs", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			assert.Equal(t, "/api/plugins/grafana-postgresql-datasource/versions/5.0.0", r.URL.Path)

			response := grafanaComPluginVersionMeta{
				PluginSlug: "grafana-postgresql-datasource",
				Version:    "5.0.0",
				JSON: grafanaComPluginVersionMetaJSON{
					MetaJSONData: pluginsv0alpha1.MetaJSONData{
						Id:   "grafana-postgresql-datasource",
						Name: "PostgreSQL",
						Type: pluginsv0alpha1.MetaJSONDataTypeDatasource,
					},
					AliasIDs: []string{"postgres"},
				},
				SignatureType:       "grafana",
				SignedByOrg:         "grafana",
				CDNURL:              "https://cdn.grafana.com/plugins/grafana-postgresql-datasource/5.0.0",
				CreatePluginVersion: "4.15.0",
				Manifest: grafanaComPluginManifest{
					Files: map[string]string{
						"module.js": "deadbeef",
					},
				},
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "grafana-postgresql-datasource", Version: "5.0.0"})
		require.NoError(t, err)
		require.NotNil(t, result)
		assert.Equal(t, "grafana-postgresql-datasource", result.Meta.PluginJson.Id)
		assert.Equal(t, []string{"postgres"}, result.Meta.AliasIds)
	})

	t.Run("returns ErrMetaNotFound for 404 status", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusNotFound)
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "nonexistent-plugin", Version: "1.0.0"})

		assert.Error(t, err)
		assert.True(t, errors.Is(err, ErrMetaNotFound))
		assert.Nil(t, result)
	})

	t.Run("returns error for non-200 status codes", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusInternalServerError)
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unexpected status code 500")
		assert.Nil(t, result)
	})

	t.Run("returns error for invalid JSON response", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte("invalid json"))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to decode response")
		assert.Nil(t, result)
	})

	t.Run("returns error for invalid API URL", func(t *testing.T) {
		provider := NewCatalogProvider(&logging.NoOpLogger{}, "://invalid-url", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "invalid grafana.com API URL")
		assert.Nil(t, result)
	})

	t.Run("uses custom TTL when provided", func(t *testing.T) {
		customTTL := 2 * time.Hour
		expectedMeta := pluginsv0alpha1.MetaJSONData{
			Id:   "test-plugin",
			Name: "Test Plugin",
			Type: pluginsv0alpha1.MetaJSONDataTypeDatasource,
		}

		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			response := grafanaComPluginVersionMeta{
				PluginSlug: "test-plugin",
				Version:    "1.0.0",
				JSON:       grafanaComPluginVersionMetaJSON{MetaJSONData: expectedMeta},
				CDNURL:     "https://cdn.grafana.com",
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProviderWithTTL(&logging.NoOpLogger{}, server.URL+"/api/plugins", "", customTTL)
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		require.NoError(t, err)
		require.NotNil(t, result)
		assert.Equal(t, customTTL, result.TTL)
	})

	t.Run("handles context cancellation", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			time.Sleep(100 * time.Millisecond)
			w.WriteHeader(http.StatusOK)
		}))
		defer server.Close()

		ctx, cancel := context.WithCancel(context.Background())
		cancel()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		assert.Error(t, err)
		assert.Nil(t, result)
	})

	t.Run("sends gcom token in Authorization header", func(t *testing.T) {
		expectedToken := "test-gcom-token-12345" //nolint:gosec // G101: test token value
		expectedMeta := pluginsv0alpha1.MetaJSONData{
			Id:   "test-plugin",
			Name: "Test Plugin",
			Type: pluginsv0alpha1.MetaJSONDataTypeDatasource,
		}

		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			assert.Equal(t, http.MethodGet, r.Method)
			assert.Equal(t, "/api/plugins/test-plugin/versions/1.0.0", r.URL.Path)
			assert.Equal(t, "application/json", r.Header.Get("Accept"))
			assert.Equal(t, "grafana-plugins-app", r.Header.Get("User-Agent"))
			assert.Equal(t, "Bearer "+expectedToken, r.Header.Get("Authorization"))

			response := grafanaComPluginVersionMeta{
				PluginSlug: "test-plugin",
				Version:    "1.0.0",
				JSON:       grafanaComPluginVersionMetaJSON{MetaJSONData: expectedMeta},
				CDNURL:     "https://cdn.grafana.com",
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", expectedToken)
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		require.NoError(t, err)
		require.NotNil(t, result)
		// The plugin.json has no version, so it falls back to the gcom version.
		expectedWithVersion := expectedMeta
		expectedWithVersion.Info.Version = "1.0.0"
		assert.Equal(t, expectedWithVersion, result.Meta.PluginJson)
		assert.Equal(t, defaultCatalogTTL, result.TTL)
	})

	t.Run("handles missing module hash gracefully", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			response := grafanaComPluginVersionMeta{
				PluginSlug: "test-plugin",
				Version:    "1.0.0",
				JSON:       grafanaComPluginVersionMetaJSON{MetaJSONData: pluginsv0alpha1.MetaJSONData{Id: "test-plugin"}},
				CDNURL:     "https://cdn.grafana.com",
				Manifest: grafanaComPluginManifest{
					Files: map[string]string{},
				},
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		require.NoError(t, err)
		require.NotNil(t, result.Meta.Module)
		assert.Nil(t, result.Meta.Module.Hash)
	})

	t.Run("calculates loading strategy correctly", func(t *testing.T) {
		testCases := []struct {
			name                string
			createPluginVersion string
			expectScript        bool
		}{
			{"version < 4.15.0 uses fetch", "4.14.0", false},
			{"version >= 4.15.0 uses script", "4.15.0", true},
			{"version > 4.15.0 uses script", "5.0.0", true},
			{"invalid version uses fetch", "invalid", false},
			{"empty version uses fetch", "", false},
		}

		for _, tc := range testCases {
			t.Run(tc.name, func(t *testing.T) {
				server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
					response := grafanaComPluginVersionMeta{
						PluginSlug:          "test-plugin",
						Version:             "1.0.0",
						JSON:                grafanaComPluginVersionMetaJSON{MetaJSONData: pluginsv0alpha1.MetaJSONData{Id: "test-plugin"}},
						CDNURL:              "https://cdn.grafana.com",
						CreatePluginVersion: tc.createPluginVersion,
						Manifest: grafanaComPluginManifest{
							Files: map[string]string{
								"module.js": "deadbeef",
							},
						},
					}

					w.Header().Set("Content-Type", "application/json")
					w.WriteHeader(http.StatusOK)
					require.NoError(t, json.NewEncoder(w).Encode(response))
				}))
				defer server.Close()

				provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
				result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

				require.NoError(t, err)
				require.NotNil(t, result.Meta.Module)
				if tc.expectScript {
					assert.Equal(t, pluginsv0alpha1.MetaV0alpha1SpecModuleLoadingStrategyScript, result.Meta.Module.LoadingStrategy)
				} else {
					assert.Equal(t, pluginsv0alpha1.MetaV0alpha1SpecModuleLoadingStrategyFetch, result.Meta.Module.LoadingStrategy)
				}
			})
		}
	})

	t.Run("handles empty children list", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			response := grafanaComPluginVersionMeta{
				PluginSlug: "test-plugin",
				Version:    "1.0.0",
				JSON:       grafanaComPluginVersionMetaJSON{MetaJSONData: pluginsv0alpha1.MetaJSONData{Id: "test-plugin"}},
				CDNURL:     "https://cdn.grafana.com",
				Children:   []grafanaComChildPluginVersion{},
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		require.NoError(t, err)
		assert.Empty(t, result.Meta.Children)
	})

	t.Run("handles missing translations gracefully", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			response := grafanaComPluginVersionMeta{
				PluginSlug: "test-plugin",
				Version:    "1.0.0",
				JSON:       grafanaComPluginVersionMetaJSON{MetaJSONData: pluginsv0alpha1.MetaJSONData{Id: "test-plugin", Languages: []string{"en", "fr"}}},
				CDNURL:     "https://cdn.grafana.com",
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		result, err := provider.GetMeta(ctx, PluginRef{ID: "test-plugin", Version: "1.0.0"})

		require.NoError(t, err)
		assert.Empty(t, result.Meta.Translations)
	})

	t.Run("returns ErrMetaNotFound when child not found in parent", func(t *testing.T) {
		parentID := "parent-plugin"
		childID := "nonexistent-child"

		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			response := grafanaComPluginVersionMeta{
				PluginSlug: parentID,
				Version:    "1.0.0",
				JSON:       grafanaComPluginVersionMetaJSON{MetaJSONData: pluginsv0alpha1.MetaJSONData{Id: parentID}},
				CDNURL:     "https://cdn.grafana.com",
				Children: []grafanaComChildPluginVersion{
					{Slug: "other-child", JSON: grafanaComPluginVersionMetaJSON{MetaJSONData: pluginsv0alpha1.MetaJSONData{Id: "other-child"}}},
				},
			}

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			require.NoError(t, json.NewEncoder(w).Encode(response))
		}))
		defer server.Close()

		provider := NewCatalogProvider(&logging.NoOpLogger{}, server.URL+"/api/plugins", "")
		parentIDPtr := parentID
		result, err := provider.GetMeta(ctx, PluginRef{
			ID:       childID,
			Version:  "1.0.0",
			ParentID: &parentIDPtr,
		})

		assert.Error(t, err)
		assert.True(t, errors.Is(err, ErrMetaNotFound))
		assert.Nil(t, result)
	})
}

func TestNewCatalogProvider(t *testing.T) {
	t.Run("creates provider with default TTL", func(t *testing.T) {
		provider := NewCatalogProvider(&logging.NoOpLogger{}, "https://grafana.com/api/plugins", "")
		assert.Equal(t, defaultCatalogTTL, provider.ttl)
		assert.NotNil(t, provider.httpClient)
		assert.Equal(t, "https://grafana.com/api/plugins", provider.grafanaComAPIURL)
	})

	t.Run("uses default URL when empty", func(t *testing.T) {
		provider := NewCatalogProvider(&logging.NoOpLogger{}, "", "")
		assert.Equal(t, "https://grafana.com/api/plugins", provider.grafanaComAPIURL)
	})
}

func TestNewCatalogProviderWithTTL(t *testing.T) {
	t.Run("creates provider with custom TTL", func(t *testing.T) {
		customTTL := 2 * time.Hour
		provider := NewCatalogProviderWithTTL(&logging.NoOpLogger{}, "https://grafana.com/api/plugins", "", customTTL)
		assert.Equal(t, customTTL, provider.ttl)
	})

	t.Run("accepts zero TTL", func(t *testing.T) {
		provider := NewCatalogProviderWithTTL(&logging.NoOpLogger{}, "https://grafana.com/api/plugins", "", 0)
		assert.Equal(t, time.Duration(0), provider.ttl)
	})

	t.Run("uses default URL when empty", func(t *testing.T) {
		provider := NewCatalogProviderWithTTL(&logging.NoOpLogger{}, "", "", defaultCatalogTTL)
		assert.Equal(t, "https://grafana.com/api/plugins", provider.grafanaComAPIURL)
	})
}
