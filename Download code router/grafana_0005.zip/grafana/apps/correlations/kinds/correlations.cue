package kinds

correlationsv0alpha1: {
	kind:       "Correlation" // note: must be uppercase
	pluralName: "Correlations"
	mutation: {
		operations: [
			"CREATE",
			"UPDATE",
		]
	}
	schema: {
		spec: {
			type:         CorrelationType
			source:       DataSourceRef
			target?:      DataSourceRef | null // null is for PATCH/edit when we want to clear the value
			description?: string
			label:        string
			config:       ConfigSpec
		}
	}
	selectableFields: [
		"spec.source.name",
		"spec.source.group",
		"spec.target.name",
		"spec.target.group",
	]
}

DataSourceRef: {
	group: string // same as pluginId
	name:  string // same as grafana uid
}

// there was a deprecated field here called type, we will need to move that for conversion and provisioning
ConfigSpec: {
	field:  string
	target: TargetSpec
	transformations?: [...TransformationSpec]
}

TargetSpec: {
	...
}

TransformationSpec: {
	type:        "regex" | "logfmt"
	expression?: string
	field?:      string
	mapValue?:   string
}

CorrelationType: "query" | "external"
