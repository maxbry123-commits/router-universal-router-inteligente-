// Code generated - EDITING IS FUTILE. DO NOT EDIT.

package v0alpha1

// +k8s:openapi-gen=true
type AnnotationstatusOperatorState struct {
	// lastEvaluation is the ResourceVersion last evaluated
	LastEvaluation string `json:"lastEvaluation"`
	// state describes the state of the lastEvaluation.
	// It is limited to three possible states for machine evaluation.
	State AnnotationStatusOperatorStateState `json:"state"`
	// descriptiveState is an optional more descriptive state field which has no requirements on format
	DescriptiveState *string `json:"descriptiveState,omitempty"`
	// details contains any extra information that is operator-specific
	Details map[string]interface{} `json:"details,omitempty"`
}

// NewAnnotationstatusOperatorState creates a new AnnotationstatusOperatorState object.
func NewAnnotationstatusOperatorState() *AnnotationstatusOperatorState {
	return &AnnotationstatusOperatorState{}
}

// OpenAPIModelName returns the OpenAPI model name for AnnotationstatusOperatorState.
func (AnnotationstatusOperatorState) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.annotation.pkg.apis.annotation.v0alpha1.AnnotationstatusOperatorState"
}

// +k8s:openapi-gen=true
type AnnotationStatus struct {
	// operatorStates is a map of operator ID to operator state evaluations.
	// Any operator which consumes this kind SHOULD add its state evaluation information to this field.
	OperatorStates map[string]AnnotationstatusOperatorState `json:"operatorStates,omitempty"`
	// additionalFields is reserved for future use
	AdditionalFields map[string]interface{} `json:"additionalFields,omitempty"`
}

// NewAnnotationStatus creates a new AnnotationStatus object.
func NewAnnotationStatus() *AnnotationStatus {
	return &AnnotationStatus{}
}

// OpenAPIModelName returns the OpenAPI model name for AnnotationStatus.
func (AnnotationStatus) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.annotation.pkg.apis.annotation.v0alpha1.AnnotationStatus"
}

// +k8s:openapi-gen=true
type AnnotationStatusOperatorStateState string

const (
	AnnotationStatusOperatorStateStateSuccess    AnnotationStatusOperatorStateState = "success"
	AnnotationStatusOperatorStateStateInProgress AnnotationStatusOperatorStateState = "in_progress"
	AnnotationStatusOperatorStateStateFailed     AnnotationStatusOperatorStateState = "failed"
)

// OpenAPIModelName returns the OpenAPI model name for AnnotationStatusOperatorStateState.
func (AnnotationStatusOperatorStateState) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.annotation.pkg.apis.annotation.v0alpha1.AnnotationStatusOperatorStateState"
}
