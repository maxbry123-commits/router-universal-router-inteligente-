"""Tests for xAI search tool integrations (XSearchTool, FileSearchTool, grok profiles)."""

from __future__ import annotations as _annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

import pytest

from pydantic_ai import (
    Agent,
    FileSearchTool,
    ModelRequest,
    ModelResponse,
    NativeToolCallPart,
    NativeToolReturnPart,
    TextPart,
    ThinkingPart,
    UserPromptPart,
    XSearchTool,
)
from pydantic_ai.capabilities import NativeTool
from pydantic_ai.messages import PartStartEvent, RequestUsage
from pydantic_ai.profiles import ModelProfile
from pydantic_ai.profiles.grok import grok_model_profile
from pydantic_ai.usage import RunUsage

from ..._inline_snapshot import snapshot
from ...conftest import IsDatetime, IsNow, IsStr, try_import
from ..mock_xai import (
    MockXai,
    create_collections_search_response,
    create_mixed_tools_response,
    create_response,
    create_usage,
    create_x_search_response,
    get_mock_chat_create_kwargs,
)

with try_import() as imports_successful:
    from xai_sdk import chat as chat_types
    from xai_sdk.proto import chat_pb2, sample_pb2, usage_pb2

    from pydantic_ai.models.xai import XaiModel, XaiModelSettings
    from pydantic_ai.providers.xai import XaiProvider
    from tests.models.xai_proto_cassettes import XaiProtoCassetteClient


pytestmark = [
    pytest.mark.skipif(not imports_successful(), reason='xai_sdk not installed'),
    pytest.mark.anyio,
    pytest.mark.vcr,
]

XAI_NON_REASONING_MODEL = 'grok-4-fast-non-reasoning'
XAI_REASONING_MODEL = 'grok-4-fast-reasoning'


# =============================================================================
# Grok model profile tests
# =============================================================================


@pytest.mark.parametrize(
    'model_name,expected_thinking,expected_always_enabled',
    [
        ('grok-4.3', True, False),
        ('grok-4.3-latest', True, False),
        # `grok-latest` is the floating alias for the newest Grok (currently 4.3), so it mirrors its efforts.
        ('grok-latest', True, False),
        ('grok-4-fast-reasoning', True, False),
        ('grok-4-fast-non-reasoning', True, False),
        ('grok-4-1-fast-non-reasoning', True, False),
        # `grok-4.20`'s effort knob controls agent count, not thinking depth, so unified thinking is unsupported.
        ('grok-4.20', False, False),
        ('grok-4.20-multi-agent', False, False),
        ('grok-4.20-reasoning', False, False),
        # `grok-code-fast-1` redirects to `grok-build-0.1`, not Grok 4.3, so they get no reasoning effort.
        ('grok-code-fast-1', False, False),
        ('grok-build-0.1', False, False),
        ('grok-3', True, False),
        ('grok-3-mini', True, True),
        ('grok-3-mini-fast', True, True),
        ('grok-3-fast', False, False),
        ('grok-4-1-reasoning', False, False),
    ],
    ids=[
        'grok-4.3',
        'grok-4.3-latest',
        'grok-latest',
        'grok-4-fast-reasoning',
        'grok-4-fast-non-reasoning',
        'grok-4-1-fast-non-reasoning',
        'grok-4.20',
        'grok-4.20-multi-agent',
        'grok-4.20-reasoning',
        'grok-code-fast-1',
        'grok-build-0.1',
        'grok-3',
        'grok-3-mini',
        'grok-3-mini-fast',
        'grok-3-fast',
        'grok-4-1-reasoning',
    ],
)
def test_grok_model_profile_thinking(model_name: str, expected_thinking: bool, expected_always_enabled: bool) -> None:
    profile = grok_model_profile(model_name)
    assert profile is not None
    assert profile.get('supports_thinking', False) == expected_thinking
    # Only models whose `reasoning_effort` set lacks `'none'` (the grok-3-mini family) are always-on;
    # Grok 4.3 and its redirect slugs accept `'none'`, so `thinking=False` disables reasoning there.
    assert profile.get('thinking_always_enabled', False) == expected_always_enabled


async def test_grok_4_reasoning_model_forwards_reasoning_effort(allow_model_requests: None) -> None:
    """Retired grok-4 reasoning slugs redirect to grok-4.3 and accept `reasoning_effort`."""
    response = create_response(content='ok')
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    settings: XaiModelSettings = {'thinking': 'high'}
    agent = Agent(m, model_settings=settings)

    await agent.run('hi')

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert len(kwargs) == 1
    assert kwargs[0]['reasoning_effort'] == 'high'


async def test_xai_thinking_false_with_non_always_on_profile_is_dropped(allow_model_requests: None) -> None:
    """Defensive guard: no `reasoning_effort` is emitted when `thinking=False` survives the gate
    (only possible under a profile with `supports_thinking=True` and `thinking_always_enabled=False`).
    The profile here exposes no `reasoning_effort` values, so `_map_reasoning_effort` returns `None`
    and the parameter is omitted rather than forwarded."""
    response = create_response(content='ok')
    mock_client = MockXai.create_mock([response])
    custom_profile = ModelProfile(supports_thinking=True, thinking_always_enabled=False)
    m = XaiModel('grok-3-mini', provider=XaiProvider(xai_client=mock_client), profile=custom_profile)
    settings: XaiModelSettings = {'thinking': False}
    agent = Agent(m, model_settings=settings)

    await agent.run('hi')

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert len(kwargs) == 1
    assert 'reasoning_effort' not in kwargs[0]


def test_grok_model_profile_builtin_tools() -> None:
    grok4_profile = grok_model_profile('grok-4-fast-non-reasoning')
    assert grok4_profile is not None
    assert isinstance(grok4_profile, dict)
    assert grok4_profile.get('grok_supports_builtin_tools', False) is True

    # `grok-3` redirects to Grok 4.3, so it's builtin-capable despite not matching the `grok-4`/`code` patterns.
    grok3_profile = grok_model_profile('grok-3')
    assert grok3_profile is not None
    assert isinstance(grok3_profile, dict)
    assert grok3_profile.get('grok_supports_builtin_tools', False) is True

    # `grok-build-0.1` is a coding model (the `grok-code-fast-1` redirect target) and supports builtin tools.
    grok_build_profile = grok_model_profile('grok-build-0.1')
    assert grok_build_profile is not None
    assert isinstance(grok_build_profile, dict)
    assert grok_build_profile.get('grok_supports_builtin_tools', False) is True

    grok3_mini_profile = grok_model_profile('grok-3-mini')
    assert grok3_mini_profile is not None
    assert isinstance(grok3_mini_profile, dict)
    assert grok3_mini_profile.get('grok_supports_builtin_tools', False) is False


# =============================================================================
# XSearchTool validation tests
# =============================================================================


def test_x_search_tool_validation():
    """Test XSearchTool validation rules."""
    with pytest.raises(ValueError, match='Cannot specify both allowed_x_handles and excluded_x_handles'):
        XSearchTool(allowed_x_handles=['foo'], excluded_x_handles=['bar'])

    handles = [f'h{i}' for i in range(1, 21)]
    assert XSearchTool(allowed_x_handles=handles).allowed_x_handles == handles
    assert XSearchTool(excluded_x_handles=handles).excluded_x_handles == handles

    handles = [f'h{i}' for i in range(1, 22)]
    with pytest.raises(ValueError, match='allowed_x_handles cannot contain more than 20 handles'):
        XSearchTool(allowed_x_handles=handles)

    with pytest.raises(ValueError, match='excluded_x_handles cannot contain more than 20 handles'):
        XSearchTool(excluded_x_handles=handles)

    tool = XSearchTool(allowed_x_handles=['handle1', 'handle2'])
    assert tool.allowed_x_handles == ['handle1', 'handle2']
    assert tool.excluded_x_handles is None

    tool = XSearchTool(excluded_x_handles=['spam1', 'spam2'])
    assert tool.excluded_x_handles == ['spam1', 'spam2']
    assert tool.allowed_x_handles is None

    tool = XSearchTool()
    assert tool.allowed_x_handles is None
    assert tool.excluded_x_handles is None

    tool = XSearchTool(from_date=datetime(2024, 6, 1), to_date=datetime(2024, 12, 31))
    assert tool.from_date == datetime(2024, 6, 1)
    assert tool.to_date == datetime(2024, 12, 31)


# =============================================================================
# XSearchTool → x_search VCR tests
# =============================================================================


async def test_xai_builtin_x_search_tool(allow_model_requests: None, xai_provider: XaiProvider):
    """Test xAI's built-in x_search tool (non-streaming, recorded via proto cassette)."""
    m = XaiModel(XAI_REASONING_MODEL, provider=xai_provider)
    agent = Agent(
        m,
        capabilities=[NativeTool(XSearchTool())],
        model_settings=XaiModelSettings(
            xai_include_encrypted_content=True,
            xai_include_x_search_output=True,
        ),
    )

    result = await agent.run('What are the latest posts about PydanticAI on X? Reply with just the key topic.')
    assert result.output == snapshot('PydanticAI v1.80 updates for AI agent development')

    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='What are the latest posts about PydanticAI on X? Reply with just the key topic.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='',
                        signature=IsStr(),
                        provider_name='xai',
                    ),
                    NativeToolCallPart(
                        tool_name='x_search',
                        args={'query': 'PydanticAI', 'limit': 10, 'mode': 'Latest'},
                        tool_call_id=IsStr(),
                        provider_name='xai',
                        provider_details={'function_name': 'x_keyword_search'},
                    ),
                    ThinkingPart(
                        content='',
                        signature=IsStr(),
                        provider_name='xai',
                    ),
                    NativeToolReturnPart(
                        tool_name='x_search',
                        content={
                            'citations': [
                                'https://x.com/i/status/2042562199843987834',
                                'https://x.com/i/status/2042535641490096426',
                                'https://x.com/i/status/2042981439357227193',
                                'https://x.com/i/status/2042935940440822230',
                                'https://x.com/i/status/2043733929694232605',
                                'https://x.com/i/status/2043307387835342915',
                                'https://x.com/i/status/2042600007912820765',
                                'https://x.com/i/status/2043737344478527731',
                                'https://x.com/i/status/2043307391111024980',
                                'https://x.com/i/status/2043548524416217320',
                                'https://x.com/i/status/2042444002595889482',
                                'https://x.com/i/status/2042149152801620346',
                                'https://x.com/i/status/2042935942454087800',
                            ]
                        },
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                        provider_name='xai',
                    ),
                    ThinkingPart(
                        content='',
                        signature=IsStr(),
                        provider_name='xai',
                    ),
                    TextPart(content='PydanticAI v1.80 updates for AI agent development'),
                ],
                usage=RequestUsage(
                    input_tokens=5821,
                    cache_read_tokens=2692,
                    output_tokens=586,
                    output_reasoning_tokens=524,
                    details={'reasoning_tokens': 524, 'server_side_tools_x_search': 1},
                    cost=Decimal('0.0010534'),
                ),
                model_name='grok-4-fast-reasoning',
                timestamp=IsDatetime(),
                provider_name='xai',
                provider_url='https://api.x.ai/v1',
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_xai_builtin_x_search_tool_stream(allow_model_requests: None, xai_provider: XaiProvider):
    """Test xAI's built-in x_search tool with streaming (recorded via proto cassette)."""
    m = XaiModel(XAI_REASONING_MODEL, provider=xai_provider)
    agent = Agent(
        m,
        capabilities=[NativeTool(XSearchTool())],
        model_settings=XaiModelSettings(
            xai_include_encrypted_content=True,
            xai_include_x_search_output=True,
        ),
    )

    event_parts: list[Any] = []
    async with agent.iter(
        user_prompt='Search X for the latest PydanticAI updates. Reply with just the key topic.'
    ) as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node) or Agent.is_call_tools_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        event_parts.append(event)

    assert agent_run.result is not None
    messages = agent_run.result.all_messages()
    assert messages == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='Search X for the latest PydanticAI updates. Reply with just the key topic.',
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsNow(tz=timezone.utc),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ThinkingPart(
                        content='',
                        signature=IsStr(),
                        provider_name='xai',
                    ),
                    NativeToolCallPart(
                        tool_name='x_search',
                        args={'query': 'PydanticAI', 'limit': 10, 'mode': 'Latest'},
                        tool_call_id=IsStr(),
                        provider_name='xai',
                        provider_details={'function_name': 'x_keyword_search'},
                    ),
                    NativeToolReturnPart(
                        tool_name='x_search',
                        content={
                            'citations': [
                                'https://x.com/i/status/2042935942454087800',
                                'https://x.com/i/status/2042444002595889482',
                                'https://x.com/i/status/2042981439357227193',
                                'https://x.com/i/status/2042149152801620346',
                                'https://x.com/i/status/2043307391111024980',
                                'https://x.com/i/status/2042562199843987834',
                                'https://x.com/i/status/2043307387835342915',
                                'https://x.com/i/status/2043548524416217320',
                                'https://x.com/i/status/2043733929694232605',
                                'https://x.com/i/status/2042935940440822230',
                                'https://x.com/i/status/2043737344478527731',
                                'https://x.com/i/status/2042535641490096426',
                                'https://x.com/i/status/2042600007912820765',
                            ]
                        },
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                        provider_name='xai',
                    ),
                    TextPart(content='PydanticAI v1.80: Tool call retry fixes and capability ordering primitives'),
                ],
                usage=RequestUsage(
                    input_tokens=5828,
                    cache_read_tokens=2701,
                    output_tokens=664,
                    output_reasoning_tokens=598,
                    details={'reasoning_tokens': 598, 'server_side_tools_x_search': 1},
                    cost=Decimal('0.00109245'),
                ),
                model_name='grok-4-fast-reasoning',
                timestamp=IsDatetime(),
                provider_name='xai',
                provider_url='https://api.x.ai/v1',
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_xai_x_search_streaming_citations_no_duplicate_part_start_event(allow_model_requests: None):
    """Regression: streaming x_search citation backfill must not emit a duplicate `PartStartEvent`.

    xAI returns x_search results as top-level `response.citations` that only arrive with the
    final stream chunk, so we backfill them onto the already-emitted `NativeToolReturnPart`.
    The fix mutates the part in place rather than re-calling `_parts_manager.handle_part`,
    which would have emitted a second `PartStartEvent` at the same index. This test exercises
    that path with mocked stream chunks (citation arrives only on the final chunk) and asserts:
    1. the final return part's `content` ends up populated with the citations, and
    2. exactly one `PartStartEvent` is emitted for the x_search return part vendor id.
    """
    tool_call_id = 'x_search_stream_001'
    citations = ['https://x.com/i/status/1', 'https://x.com/i/status/2']

    def _build_x_search_tool_call(status: chat_pb2.ToolCallStatus) -> chat_pb2.ToolCall:
        return chat_pb2.ToolCall(
            id=tool_call_id,
            type=chat_pb2.ToolCallType.TOOL_CALL_TYPE_X_SEARCH_TOOL,
            status=status,
            function=chat_pb2.FunctionCall(name='x_keyword_search', arguments='{"query":"PydanticAI"}'),
        )

    def _build_chunk(
        *,
        role: chat_pb2.MessageRole,
        tool_calls: list[chat_pb2.ToolCall] | None = None,
        content: str = '',
        finish_reason: str | None = None,
    ) -> chat_types.Chunk:
        proto = chat_pb2.GetChatCompletionChunk(id='grok-stream')
        proto.created.GetCurrentTime()
        output_chunk = chat_pb2.CompletionOutputChunk(
            index=0,
            delta=chat_pb2.Delta(role=role, tool_calls=tool_calls or [], content=content),
        )
        if finish_reason == 'stop':
            output_chunk.finish_reason = sample_pb2.FinishReason.REASON_STOP
        elif finish_reason == 'tool_calls':
            output_chunk.finish_reason = sample_pb2.FinishReason.REASON_TOOL_CALLS
        proto.outputs.append(output_chunk)
        return chat_types.Chunk(proto, index=None)

    def _build_response(
        *,
        tool_calls: list[chat_pb2.ToolCall] | None = None,
        content: str = '',
        finish_reason: str = 'stop',
        with_citations: bool = False,
    ) -> chat_types.Response:
        proto = chat_pb2.GetChatCompletionResponse(id='grok-stream')
        proto.created.GetCurrentTime()
        proto.outputs.append(
            chat_pb2.CompletionOutput(
                index=0,
                finish_reason=sample_pb2.FinishReason.REASON_STOP
                if finish_reason == 'stop'
                else sample_pb2.FinishReason.REASON_TOOL_CALLS,
                message=chat_pb2.CompletionMessage(
                    role=chat_pb2.MessageRole.ROLE_ASSISTANT, content=content, tool_calls=tool_calls or []
                ),
            )
        )
        if with_citations:
            proto.citations.extend(citations)
        return chat_types.Response(proto, index=None)

    completed_call = _build_x_search_tool_call(chat_pb2.ToolCallStatus.TOOL_CALL_STATUS_COMPLETED)

    stream = [
        # Assistant emits the x_search call.
        (
            _build_response(tool_calls=[completed_call], finish_reason='tool_calls'),
            _build_chunk(
                role=chat_pb2.MessageRole.ROLE_ASSISTANT,
                tool_calls=[completed_call],
                finish_reason='tool_calls',
            ),
        ),
        # ROLE_TOOL message marks the tool result. Note: no `content` and no `citations` yet.
        (
            _build_response(tool_calls=[completed_call], finish_reason='tool_calls'),
            _build_chunk(role=chat_pb2.MessageRole.ROLE_TOOL, tool_calls=[completed_call]),
        ),
        # Final chunk: assistant reply + citations populated on the accumulated response.
        (
            _build_response(content='done', with_citations=True),
            _build_chunk(role=chat_pb2.MessageRole.ROLE_ASSISTANT, content='done', finish_reason='stop'),
        ),
    ]

    mock_client = MockXai.create_mock_stream([stream])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(XSearchTool())])

    events: list[Any] = []
    async with agent.iter(user_prompt='find PydanticAI posts') as agent_run:
        async for node in agent_run:
            if Agent.is_model_request_node(node):
                async with node.stream(agent_run.ctx) as request_stream:
                    async for event in request_stream:
                        events.append(event)

    assert agent_run.result is not None
    parts = agent_run.result.all_messages()[1].parts
    return_parts = [p for p in parts if isinstance(p, NativeToolReturnPart) and p.tool_name == XSearchTool.kind]
    assert len(return_parts) == 1
    assert return_parts[0].content == {'citations': citations}

    # Locate the return part by index in the final parts list, then verify exactly one
    # `PartStartEvent` was emitted for that index.
    return_part_index = parts.index(return_parts[0])
    start_events_at_return_index = [
        e
        for e in events
        if isinstance(e, PartStartEvent) and e.index == return_part_index and isinstance(e.part, NativeToolReturnPart)
    ]
    assert len(start_events_at_return_index) == 1


# =============================================================================
# XSearchTool → x_search mock tests (SDK parameter verification)
# =============================================================================


async def test_xai_builtin_x_search_tool_with_handles(allow_model_requests: None):
    """Test that XSearchTool handle filtering params are sent to the xAI SDK."""
    response = create_x_search_response(
        query='AI updates',
        content={'results': [{'text': 'AI news from @OpenAI'}]},
        assistant_text='Found filtered posts.',
    )
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(
        m,
        capabilities=[NativeTool(XSearchTool(allowed_x_handles=['OpenAI', 'AnthropicAI']))],
    )

    await agent.run('What are OpenAI and Anthropic tweeting about?')

    assert get_mock_chat_create_kwargs(mock_client) == snapshot(
        [
            {
                'model': XAI_NON_REASONING_MODEL,
                'messages': [
                    {'content': [{'text': 'What are OpenAI and Anthropic tweeting about?'}], 'role': 'ROLE_USER'}
                ],
                'tools': [
                    {
                        'x_search': {
                            'allowed_x_handles': ['OpenAI', 'AnthropicAI'],
                            'enable_image_understanding': False,
                            'enable_video_understanding': False,
                        }
                    }
                ],
                'tool_choice': 'auto',
                'response_format': None,
                'use_encrypted_content': False,
                'include': [],
            }
        ]
    )


async def test_xai_builtin_x_search_tool_with_date_range(allow_model_requests: None):
    """Test that XSearchTool date params are sent to the xAI SDK."""
    response = create_x_search_response(
        query='PydanticAI release',
        content={'results': []},
        assistant_text='No posts found in date range.',
    )
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(
        m,
        capabilities=[
            NativeTool(
                XSearchTool(
                    from_date=datetime(2024, 1, 1),
                    to_date=datetime(2024, 12, 31),
                )
            )
        ],
    )

    await agent.run('Any PydanticAI posts in 2024?')

    assert get_mock_chat_create_kwargs(mock_client) == snapshot(
        [
            {
                'model': XAI_NON_REASONING_MODEL,
                'messages': [{'content': [{'text': 'Any PydanticAI posts in 2024?'}], 'role': 'ROLE_USER'}],
                'tools': [
                    {
                        'x_search': {
                            'from_date': '2024-01-01T00:00:00Z',
                            'to_date': '2024-12-31T00:00:00Z',
                            'enable_image_understanding': False,
                            'enable_video_understanding': False,
                        }
                    }
                ],
                'tool_choice': 'auto',
                'response_format': None,
                'use_encrypted_content': False,
                'include': [],
            }
        ]
    )


async def test_xai_x_search_tool_type_in_response(allow_model_requests: None):
    """Test handling of x_search tool type in responses (without agent-side XSearchTool)."""
    x_search_tool_call = chat_pb2.ToolCall(
        id='x_search_001',
        type=chat_pb2.ToolCallType.TOOL_CALL_TYPE_X_SEARCH_TOOL,
        status=chat_pb2.ToolCallStatus.TOOL_CALL_STATUS_COMPLETED,
        function=chat_pb2.FunctionCall(
            name='x_search',
            arguments='{"query": "test"}',
        ),
    )

    response = create_mixed_tools_response([x_search_tool_call], text_content='Search results here')
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m)

    result = await agent.run('Search for something')

    assert result.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='Search for something', timestamp=IsNow(tz=timezone.utc))],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    NativeToolCallPart(
                        tool_name='x_search',
                        args={'query': 'test'},
                        tool_call_id=IsStr(),
                        provider_name='xai',
                        provider_details={'function_name': 'x_search'},
                    ),
                    TextPart(content='Search results here'),
                ],
                usage=RequestUsage(cost=Decimal('0.00')),
                model_name=XAI_NON_REASONING_MODEL,
                timestamp=IsDatetime(),
                provider_name='xai',
                provider_url='https://api.x.ai/v1',
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_xai_x_search_builtin_tool_call_in_history(allow_model_requests: None):
    """Test that XSearchTool NativeToolCallPart in history is properly mapped back to xAI."""
    response1 = create_x_search_response(query='pydantic updates', assistant_text='Found posts about PydanticAI.')
    response2 = create_response(content='The posts were about PydanticAI releases.')

    mock_client = MockXai.create_mock([response1, response2])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(XSearchTool())])

    result1 = await agent.run('Search for pydantic updates')
    result2 = await agent.run('What were the posts about?', message_history=result1.new_messages())

    assert get_mock_chat_create_kwargs(mock_client) == snapshot(
        [
            {
                'model': XAI_NON_REASONING_MODEL,
                'messages': [{'content': [{'text': 'Search for pydantic updates'}], 'role': 'ROLE_USER'}],
                'tools': [{'x_search': {'enable_image_understanding': False, 'enable_video_understanding': False}}],
                'tool_choice': 'auto',
                'response_format': None,
                'use_encrypted_content': False,
                'include': [],
            },
            {
                'model': XAI_NON_REASONING_MODEL,
                'messages': [
                    {'content': [{'text': 'Search for pydantic updates'}], 'role': 'ROLE_USER'},
                    {
                        'content': [{'text': ''}],
                        'role': 'ROLE_ASSISTANT',
                        'tool_calls': [
                            {
                                'id': 'x_search_001',
                                'type': 'TOOL_CALL_TYPE_X_SEARCH_TOOL',
                                'status': 'TOOL_CALL_STATUS_COMPLETED',
                                'function': {'name': 'x_keyword_search', 'arguments': '{"query":"pydantic updates"}'},
                            }
                        ],
                    },
                    {
                        'content': [{'text': 'Found posts about PydanticAI.'}],
                        'role': 'ROLE_ASSISTANT',
                    },
                    {'content': [{'text': 'What were the posts about?'}], 'role': 'ROLE_USER'},
                ],
                'tools': [{'x_search': {'enable_image_understanding': False, 'enable_video_understanding': False}}],
                'tool_choice': 'auto',
                'response_format': None,
                'use_encrypted_content': False,
                'include': [],
            },
        ]
    )

    assert result2.output == 'The posts were about PydanticAI releases.'


async def test_xai_x_search_function_name_round_trip(allow_model_requests: None):
    """Test that the xAI-specific function name (e.g. 'x_keyword_search') survives the round-trip.

    The xAI API uses function names like 'x_keyword_search' or 'collections_search' that differ
    from PydanticAI's normalized tool_name ('x_search', 'file_search'). The original function name
    must be preserved in provider_details and sent back when replaying history.
    """
    response1 = create_x_search_response(query='test query', assistant_text='Found results.')
    response2 = create_response(content='Follow-up answer.')

    mock_client = MockXai.create_mock([response1, response2])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(XSearchTool())])

    result1 = await agent.run('Search for something')

    # Verify provider_details stores the original function name
    call_parts = [p for p in result1.all_messages()[1].parts if isinstance(p, NativeToolCallPart)]
    assert len(call_parts) == 1
    assert call_parts[0].tool_name == 'x_search'
    assert call_parts[0].provider_details == snapshot({'function_name': 'x_keyword_search'})

    # Verify round-trip: the original function name is sent back in history
    result2 = await agent.run('Follow up', message_history=result1.new_messages())
    kwargs = get_mock_chat_create_kwargs(mock_client)
    history_tool_calls = kwargs[1]['messages'][1]['tool_calls']
    assert history_tool_calls[0]['function']['name'] == 'x_keyword_search'

    assert result2.output == 'Follow-up answer.'


async def test_xai_x_search_include_option(allow_model_requests: None):
    """Test that xai_include_x_search_output maps correctly."""
    response = create_response(content='test', usage=create_usage(prompt_tokens=10, completion_tokens=5))
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m)

    settings: XaiModelSettings = {
        'xai_include_x_search_output': True,
    }
    await agent.run('Hello', model_settings=settings)

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert kwargs[0]['include'] == [chat_pb2.IncludeOption.INCLUDE_OPTION_X_SEARCH_CALL_OUTPUT]


async def test_xai_x_search_usage_mapping(allow_model_requests: None):
    """Test that SERVER_SIDE_TOOL_X_SEARCH maps to x_search in usage."""
    mock_usage = create_usage(
        prompt_tokens=50,
        completion_tokens=30,
        server_side_tools_used=[usage_pb2.SERVER_SIDE_TOOL_X_SEARCH],
    )
    response = create_response(content='Found it', usage=mock_usage)
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m)

    result = await agent.run('Search X')
    assert result.usage == snapshot(
        RunUsage(
            input_tokens=50,
            output_tokens=30,
            details={'server_side_tools_x_search': 1},
            requests=1,
            cost=Decimal('0.000025'),
        )
    )


# =============================================================================
# FileSearchTool → collections_search tests
# =============================================================================


async def test_xai_builtin_file_search_tool(
    allow_model_requests: None,
    xai_provider: XaiProvider,
    monkeypatch: pytest.MonkeyPatch,
):
    """End-to-end `FileSearchTool` -> xAI `collections_search` round-trip (recorded via proto cassette).

    Creates a real collection, uploads a test document, runs an agent query, and cleans up.
    All four interactions (create, upload_document, chat.sample, delete) are captured for offline replay.

    Re-recording requires `XAI_MANAGEMENT_KEY` in addition to `XAI_API_KEY` — the SDK reads it from env
    when creating the management gRPC channel used by `client.collections.*`.
    """
    import asyncio
    from datetime import timedelta
    from uuid import uuid4

    from xai_sdk.aio.collections import Client as _AioCollectionsClient
    from xai_sdk.poll_timer import PollTimer
    from xai_sdk.proto import collections_pb2

    # xai-sdk (through 1.11.0) raises on unknown DocumentStatus values. The xAI backend has added a
    # status beyond the ones the SDK recognizes, so patch polling to treat unknown statuses as
    # "still processing" during recording. Replay path never calls into the real SDK, so this patch
    # is a no-op offline.
    async def _tolerant_wait_for_indexing(  # pragma: no cover
        self: _AioCollectionsClient,
        collection_id: str,
        file_id: str,
        poll_interval: timedelta,
        timeout: timedelta,
    ) -> collections_pb2.DocumentMetadata:
        timer = PollTimer(timeout, poll_interval)
        while True:
            doc = await self.get_document(file_id, collection_id)
            if doc.status == collections_pb2.DocumentStatus.DOCUMENT_STATUS_PROCESSED:
                return doc
            if doc.status == collections_pb2.DocumentStatus.DOCUMENT_STATUS_FAILED:
                raise ValueError(f'Document indexing failed: {doc.error_message}')
            await asyncio.sleep(timer.sleep_interval_or_raise())

    monkeypatch.setattr(_AioCollectionsClient, '_wait_for_indexing', _tolerant_wait_for_indexing)

    paragraph = (
        'Zorblax Research Memo 7742. '
        'The Zorblax Protocol is a fictional encryption scheme invented by the Zorblax Research Collective '
        'in the year 2187. Its defining property is the use of heptapod-prime key rotation, which cycles '
        'every 7919 milliseconds across the primary substrate. The Zorblax Protocol was adopted as the '
        'galactic standard by the Outer Rim Treaty of 2193. Researchers cite three principal inventors: '
        'Dr. Mira Calyx, Dr. Taren Ko, and Dr. Silas Rhen. '
    )
    doc_text = ('\n\n'.join([f'Section {i}. {paragraph}' for i in range(1, 11)])).encode('utf-8')

    client = xai_provider.client
    collection = await client.collections.create(
        name=f'pydantic-ai-test-{uuid4().hex[:8]}',
        chunk_configuration={
            'chars_configuration': {'max_chunk_size_chars': 256, 'chunk_overlap_chars': 32},
        },
    )
    try:
        await client.collections.upload_document(
            collection_id=collection.collection_id,
            name='zorblax-memo-7742.txt',
            data=doc_text,
            wait_for_indexing=True,
            timeout=timedelta(seconds=180),
        )
        if not isinstance(client, XaiProtoCassetteClient):  # pragma: no cover
            # PROCESSED status doesn't guarantee the live search index is fully propagated; give it a moment.
            await asyncio.sleep(5)

        m = XaiModel(XAI_NON_REASONING_MODEL, provider=xai_provider)
        agent = Agent(
            m,
            capabilities=[
                NativeTool(
                    FileSearchTool(
                        file_store_ids=[collection.collection_id],
                        max_num_results=1,
                        instructions='Prioritize exact factual matches from the uploaded research memo.',
                        retrieval_mode='semantic',
                    )
                )
            ],
            model_settings=XaiModelSettings(xai_include_collections_search_output=True),
        )

        result = await agent.run(
            'Using the uploaded Zorblax Research Memo, in what year was the Zorblax Protocol invented '
            'and who are its three principal inventors?'
        )
        assert result.all_messages() == snapshot(
            [
                ModelRequest(
                    parts=[
                        UserPromptPart(
                            content='Using the uploaded Zorblax Research Memo, in what year was the Zorblax Protocol invented and who are its three principal inventors?',
                            timestamp=IsDatetime(),
                        )
                    ],
                    timestamp=IsDatetime(),
                    run_id=IsStr(),
                    conversation_id=IsStr(),
                ),
                ModelResponse(
                    parts=[
                        NativeToolCallPart(
                            tool_name='file_search',
                            args={
                                'search_request': '{"query": "Zorblax Protocol invented year principal inventors", "limit": 10, "retrieval_mode": "semantic"}'
                            },
                            tool_call_id=IsStr(),
                            provider_name='xai',
                            provider_details={'function_name': 'collections_search'},
                        ),
                        NativeToolReturnPart(
                            tool_name='file_search',
                            content={
                                'search_matches': [
                                    {
                                        'file_id': 'file_e9ef3a06-160e-4a51-a3e2-762cd070cc32',
                                        'chunk_id': 'file_e9ef3a06-160e-4a51-a3e2-762cd070cc32_5',
                                        'chunk_content': 'ary substrate. The Zorblax Protocol was adopted as the galactic standard by the Outer Rim Treaty of 2193. Researchers cite three principal inventors: Dr. Mira Calyx, Dr. Taren Ko, and Dr. Silas Rhen. \\n\\nSection 10. Zorblax Research Memo 7742. The Zorblax Protocol is a fictional encryption scheme invented by the Zorblax Research Collective in the year 2187. Its defining property is the use of heptapod-prime key rotation, which cycles every 7919 milliseconds across the primary substrate. The Zorblax Protocol was adopted as the galactic standard by the Outer Rim Treaty of 2193. Researchers cite three principal inventors: Dr. Mira Calyx, Dr. Taren Ko, and Dr. Silas Rhen. "}]',
                                        'score': 0.7739996314048767,
                                        'collection_ids': ['collection_744aab7b-44f2-41ab-a982-9c49d1690c2f'],
                                    }
                                ]
                            },
                            tool_call_id=IsStr(),
                            timestamp=IsDatetime(),
                            provider_name='xai',
                        ),
                        TextPart(
                            content="""\
**2187**, by **Dr. Mira Calyx, Dr. Taren Ko, and Dr. Silas Rhen**. \n\

This is stated directly in the uploaded Zorblax Research Memo (Section 10), which describes the Zorblax Protocol as a fictional encryption scheme invented by the Zorblax Research Collective in 2187, with those three researchers cited as the principal inventors.\
"""
                        ),
                    ],
                    usage=RequestUsage(
                        input_tokens=2417,
                        cache_read_tokens=1152,
                        output_tokens=120,
                        details={'server_side_tools_file_search': 1},
                        cost=Decimal('0.0003706'),
                    ),
                    model_name='grok-4-fast-non-reasoning',
                    timestamp=IsDatetime(),
                    provider_name='xai',
                    provider_url='https://api.x.ai/v1',
                    provider_response_id=IsStr(),
                    finish_reason='stop',
                    run_id=IsStr(),
                    conversation_id=IsStr(),
                ),
            ]
        )
    finally:
        await client.collections.delete(collection.collection_id)


async def test_xai_file_search_sends_collection_ids(allow_model_requests: None):
    """Test that FileSearchTool passes collection_ids to the xAI SDK."""
    response = create_response(content='result', usage=create_usage(prompt_tokens=10, completion_tokens=5))
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(
        m,
        capabilities=[NativeTool(FileSearchTool(file_store_ids=['col-1', 'col-2']))],
    )

    await agent.run('Search my docs')

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert len(kwargs) == 1
    tools = kwargs[0]['tools']
    assert tools is not None
    assert len(tools) == 1
    tool_dict = tools[0]
    assert 'collections_search' in tool_dict


async def test_xai_file_search_options_forwarded(allow_model_requests: None):
    """FileSearchTool option fields are forwarded to xAI's collections search payload."""
    response = create_response(content='result', usage=create_usage(prompt_tokens=10, completion_tokens=5))
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(
        m,
        capabilities=[
            NativeTool(
                FileSearchTool(
                    file_store_ids=['col-1', 'col-2'],
                    max_num_results=5,
                    instructions='Focus on recent documents.',
                    retrieval_mode='hybrid',
                )
            )
        ],
    )

    await agent.run('Search my docs')

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert kwargs[0]['tools'] == snapshot(
        [
            {
                'collections_search': {
                    'collection_ids': ['col-1', 'col-2'],
                    'limit': 5,
                    'instructions': 'Focus on recent documents.',
                    'hybrid_retrieval': {},
                }
            }
        ]
    )


async def test_xai_file_search_options_omitted_when_none(allow_model_requests: None):
    """Unset FileSearchTool options are omitted from the outgoing collections search payload."""
    response = create_response(content='result', usage=create_usage(prompt_tokens=10, completion_tokens=5))
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(
        m,
        capabilities=[NativeTool(FileSearchTool(file_store_ids=['col-1']))],
    )

    await agent.run('Search my docs')

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert kwargs[0]['tools'] == snapshot(
        [
            {
                'collections_search': {
                    'collection_ids': ['col-1'],
                }
            }
        ]
    )


async def test_xai_file_search_include_option(allow_model_requests: None):
    """Test that xai_include_collections_search_output maps correctly."""
    response = create_response(content='test', usage=create_usage(prompt_tokens=10, completion_tokens=5))
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m)

    settings: XaiModelSettings = {
        'xai_include_collections_search_output': True,
    }
    await agent.run('Hello', model_settings=settings)

    kwargs = get_mock_chat_create_kwargs(mock_client)
    assert kwargs[0]['include'] == [chat_pb2.IncludeOption.INCLUDE_OPTION_COLLECTIONS_SEARCH_CALL_OUTPUT]


async def test_xai_file_search_builtin_tool_call_in_history(allow_model_requests: None):
    """Test that FileSearchTool NativeToolCallPart in history is properly mapped back to xAI."""
    response1 = create_collections_search_response(query='quarterly report', assistant_text='Found relevant documents.')
    response2 = create_response(content='The report showed 15% revenue increase.')

    mock_client = MockXai.create_mock([response1, response2])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m, capabilities=[NativeTool(FileSearchTool(file_store_ids=['col-abc']))])

    result1 = await agent.run('Search my documents for quarterly report')
    result2 = await agent.run('What did it say?', message_history=result1.new_messages())

    assert get_mock_chat_create_kwargs(mock_client) == snapshot(
        [
            {
                'model': XAI_NON_REASONING_MODEL,
                'messages': [{'content': [{'text': 'Search my documents for quarterly report'}], 'role': 'ROLE_USER'}],
                'tools': [{'collections_search': {'collection_ids': ['col-abc']}}],
                'tool_choice': 'auto',
                'response_format': None,
                'use_encrypted_content': False,
                'include': [],
            },
            {
                'model': XAI_NON_REASONING_MODEL,
                'messages': [
                    {'content': [{'text': 'Search my documents for quarterly report'}], 'role': 'ROLE_USER'},
                    {
                        'content': [{'text': ''}],
                        'role': 'ROLE_ASSISTANT',
                        'tool_calls': [
                            {
                                'id': 'collections_search_001',
                                'type': 'TOOL_CALL_TYPE_COLLECTIONS_SEARCH_TOOL',
                                'status': 'TOOL_CALL_STATUS_COMPLETED',
                                'function': {
                                    'name': 'collections_search',
                                    'arguments': '{"query":"quarterly report"}',
                                },
                            }
                        ],
                    },
                    {
                        'content': [{'text': 'Found relevant documents.'}],
                        'role': 'ROLE_ASSISTANT',
                    },
                    {'content': [{'text': 'What did it say?'}], 'role': 'ROLE_USER'},
                ],
                'tools': [{'collections_search': {'collection_ids': ['col-abc']}}],
                'tool_choice': 'auto',
                'response_format': None,
                'use_encrypted_content': False,
                'include': [],
            },
        ]
    )

    assert result2.output == 'The report showed 15% revenue increase.'


async def test_xai_file_search_usage_mapping(allow_model_requests: None):
    """Test that SERVER_SIDE_TOOL_COLLECTIONS_SEARCH maps to file_search in usage."""
    mock_usage = create_usage(
        prompt_tokens=50,
        completion_tokens=30,
        server_side_tools_used=[usage_pb2.SERVER_SIDE_TOOL_COLLECTIONS_SEARCH],
    )
    response = create_response(content='Found it', usage=mock_usage)
    mock_client = MockXai.create_mock([response])
    m = XaiModel(XAI_NON_REASONING_MODEL, provider=XaiProvider(xai_client=mock_client))
    agent = Agent(m)

    result = await agent.run('Search collections')
    assert result.usage == snapshot(
        RunUsage(
            input_tokens=50,
            output_tokens=30,
            details={'server_side_tools_file_search': 1},
            requests=1,
            cost=Decimal('0.000025'),
        )
    )
