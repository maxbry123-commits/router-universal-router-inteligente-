"""Tests for Anthropic models."""
