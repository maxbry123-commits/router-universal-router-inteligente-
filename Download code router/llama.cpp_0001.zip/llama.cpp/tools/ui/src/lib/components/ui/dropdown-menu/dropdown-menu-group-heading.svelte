<script lang="ts">
	import { cn } from '$lib/components/ui/utils.js';
	import { DropdownMenu as DropdownMenuPrimitive } from 'bits-ui';
	import type { ComponentProps } from 'svelte';

	let {
		class: className,
		inset,
		ref = $bindable(null),
		...restProps
	}: ComponentProps<typeof DropdownMenuPrimitive.GroupHeading> & {
		inset?: boolean;
	} = $props();
</script>

<DropdownMenuPrimitive.GroupHeading
	bind:ref
	class={cn('px-2 py-1.5 text-sm font-semibold data-[inset]:pl-8', className)}
	data-inset={inset}
	data-slot="dropdown-menu-group-heading"
	{...restProps}
/>
