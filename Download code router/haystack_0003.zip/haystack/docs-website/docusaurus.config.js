// SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
//
// SPDX-License-Identifier: Apache-2.0

// @ts-check

import {themes as prismThemes} from 'prism-react-renderer';
import versions from './versions.json' with { type: 'json' };

// Keep the total number of built versions constant to keep memory/build time reasonable
// Build the current version (docs/), the unstable version (e.g. 3.x-unstable, only present during the release process)
// and fill the remaining slots with the most recent stable versions (e.g. 3.x)
const MAX_TOTAL_VERSIONS = 6;
const unstableVersions = versions.filter(v => v.endsWith('-unstable'));
const activeVersions = [
  'current',
  ...unstableVersions,
  ...versions.filter(v => !v.endsWith('-unstable')),
].slice(0, MAX_TOTAL_VERSIONS);

// This runs in Node.js - Don't use client-side code here (browser APIs, JSX...)

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Haystack Documentation',
  tagline: 'Haystack Docs',
  favicon: 'img/favicon.ico',

  // Set the production url of your site here
  url: 'https://docs.haystack.deepset.ai',
  baseUrl: '/',

  onBrokenLinks: 'throw',
  onBrokenAnchors: 'throw',
  onDuplicateRoutes: 'throw',

  future: {
    faster: true,
    v4: true,
  },

  markdown: {
    mdx1Compat: {
      comments: true,
    },
    hooks: {
      onBrokenMarkdownLinks: 'throw',
    },
  },

  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  headTags: [
    {
      tagName: "script",
      attributes: {},
      innerHTML: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WCKQG9T');`,
    }
  ],

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          onlyIncludeVersions: activeVersions,
          sidebarPath: './sidebars.js',
           // Exclude internal templates from the docs build
           exclude: ['**/_templates/**'],
          editUrl:
            'https://github.com/deepset-ai/haystack/tree/main/docs-website/',
          // Use beforeDefaultRemarkPlugins to ensure our plugin runs before Webpack processes links
          beforeDefaultRemarkPlugins: [require('./src/remark/versionedReferenceLinks')],
          versions: {
            current: {
              label: '3.2-unstable',
              path: 'next',
              banner: 'unreleased',
            },
          },
          lastVersion: '3.1',
        },
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      }),
    ],
  ],

  plugins: [
    function gtmNoscriptPlugin() {
      return {
        name: "gtm-noscript",
        injectHtmlTags() {
          return {
            preBodyHtmlTags: [
              `<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WCKQG9T" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>`,
            ],
          };
        },
      };
    },
    [
      '@docusaurus/plugin-ideal-image',
      {
        quality: 70,
        max: 1030,
        min: 640,
        steps: 2,
        disableInDev: false,
      },
    ],
    [
      '@docusaurus/plugin-content-docs',
      {
        id: 'reference',
        onlyIncludeVersions: activeVersions,
        path: 'reference',
        routeBasePath: 'reference',
        sidebarPath: './reference-sidebars.js',
        editUrl: 'https://github.com/deepset-ai/haystack/tree/main/docs-website/',
        // Use beforeDefaultRemarkPlugins to ensure our plugin runs before Webpack processes links
        beforeDefaultRemarkPlugins: [require('./src/remark/versionedReferenceLinks')],
        showLastUpdateAuthor: false,
        showLastUpdateTime: false,
        exclude: ['**/_templates/**'],
        versions: {
          current: {
            label: '3.2-unstable',
            path: 'next',
            banner: 'unreleased',
          },
        },
        lastVersion: '3.1',
      },
    ],
    [
      'docusaurus-plugin-generate-llms-txt',
      {
        // defaults to "llms.txt", but set explicitly for clarity
        outputFile: 'llms.txt',
      },
    ],
    // Local plugin to teach Webpack how to handle `.txt` files like `llms.txt`
    require.resolve('./plugins/txtLoaderPlugin'),
    [
      '@docusaurus/plugin-client-redirects',
      {
        redirects: [
          {
            from: '/docs',
            to: '/docs/intro',
          },
          {
            from: '/docs/get_started',
            to: '/docs/get-started',
          },
          {
            from: '/docs/document_store',
            to: '/docs/document-store',
          },
          {
            from: '/docs/components_overview',
            to: '/docs/components',
          },
          {
            from: '/docs/nodes_overview',
            to: '/docs/components',
          },
          {
            from: '/docs/retriever',
            to: '/docs/retrievers',
          },
          {
            from: '/docs/ranker',
            to: '/docs/rankers',
          },
          {
            from: '/docs/pipeline',
            to: '/docs/pipelines',
          },
          {
            from: '/docs/prompt_node',
            to: '/docs/promptbuilder',
          },
          {
            from: '/docs/join_documents',
            to: '/docs/documentjoiner',
          },
          {
            from: '/docs/dynamicchatpromptbuilder',
            to: '/docs/chatpromptbuilder',
          },
          {
            from: '/docs/dynamicpromptbuilder',
            to: '/docs/promptbuilder',
          },
          {
            from: '/docs/generators-vs-chat-generators',
            to: '/docs/choosing-the-right-generator#generators-vs-chatgenerators',
          },
          // Components removed or renamed in Haystack 3.0
          {
            from: '/docs/openaigenerator',
            to: '/docs/openaichatgenerator',
          },
          {
            from: '/docs/azureopenaigenerator',
            to: '/docs/azureopenaichatgenerator',
          },
          {
            from: '/docs/huggingfaceapigenerator',
            to: '/docs/huggingfaceapichatgenerator',
          },
          {
            from: '/docs/huggingfacelocalgenerator',
            to: '/docs/transformerschatgenerator',
          },
          {
            from: '/docs/huggingfacelocalchatgenerator',
            to: '/docs/transformerschatgenerator',
          },
          {
            from: '/docs/dalleimagegenerator',
            to: '/docs/openaiimagegenerator',
          },
          {
            from: '/docs/extractivereader',
            to: '/docs/transformersextractivereader',
          },
          {
            from: '/docs/namedentityextractor',
            to: '/docs/transformersnamedentityextractor',
          },
          {
            from: '/docs/transformerssimilarityranker',
            to: '/docs/sentencetransformerssimilarityranker',
          },
          {
            from: '/docs/toolinvoker',
            to: '/docs/agent',
          },
          {
            from: '/docs/asyncpipeline',
            to: '/docs/pipelines',
          },
          {
            from: '/docs/function-calling',
            to: '/docs/tool',
          },
        ],
      },
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      image: 'img/haystack-ogimage.png',
      docs: {
        sidebar: {
          autoCollapseCategories: true,
        },
      },
      navbar: {
        title: 'Haystack Documentation',
        logo: {
          alt: 'Haystack Logo',
          src: 'img/logo.svg',
        },
        items: [
          {
            type: 'docsVersionDropdown',
            position: 'left',
            dropdownActiveClassDisabled: true,
            dropdownItemsAfter: [
              {
                type: 'html',
                value: '<hr style="margin: 0.3rem 0;">',
              },
              {
                href: '/docs/faq#where-can-i-find-tutorials-and-documentation-for-haystack-1x',
                label: '1.x archived documentation',
              },
              {
                href: '/docs/faq#where-can-i-find-documentation-for-older-haystack-versions',
                label: '2.x archived documentation',
              },
            ],
          },
          {
            type: 'doc',
            docId: 'intro',
            label: 'Docs',
            position: 'left',
          },
          {
            type: 'doc',
            docsPluginId: 'reference',
            docId: 'api-index',
            label: 'API Reference',
            position: 'left',
          },
          {
            href: 'https://github.com/deepset-ai/haystack/blob/main/docs-website/CONTRIBUTING.md',
            label: 'Contribute',
            position: 'right',
          },
          {
            href: 'https://github.com/deepset-ai/haystack/tree/main/docs-website',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Community',
            items: [
              {
                html: '<div class="footer-social-icons-container"><div class="footer-social-row"><a href="https://discord.com/invite/haystack" target="_blank" rel="noopener noreferrer" class="footer__link-item" aria-label="Discord"><img src="/img/discord.svg" alt="Discord" class="footer-social-icon" /></a><a href="https://github.com/deepset-ai/haystack" target="_blank" rel="noopener noreferrer" class="footer__link-item" aria-label="GitHub"><img src="/img/github.svg" alt="GitHub" class="footer-social-icon" /></a><a href="https://x.com/haystack_ai" target="_blank" rel="noopener noreferrer" class="footer__link-item" aria-label="X"><img src="/img/x.svg" alt="X" class="footer-social-icon" /></a></div><div class="footer-social-row"><a href="https://www.linkedin.com/company/deepset-ai/" target="_blank" rel="noopener noreferrer" class="footer__link-item" aria-label="LinkedIn"><img src="/img/linkedin.svg" alt="LinkedIn" class="footer-social-icon" /></a><a href="https://www.youtube.com/channel/UC5dfn9m310oyt-cbeegfvZw" target="_blank" rel="noopener noreferrer" class="footer__link-item" aria-label="YouTube"><img src="/img/youtube.svg" alt="YouTube" class="footer-social-icon" /></a></div></div>'
              },
            ],
          },
          {
            title: 'Learn',
            items: [
              { label: 'Tutorials',   href: 'https://haystack.deepset.ai/tutorials' },
              { label: 'Cookbooks', href: 'https://haystack.deepset.ai/cookbook' },
            ],
          },
          {
            title: 'More',
            items: [
              { label: 'Integrations',   href: 'https://haystack.deepset.ai/integrations' },
              { label: 'Platform - Try Free', href: 'https://landing.deepset.ai/deepset-studio-signup' },
              { label: 'Enterprise Support', href: 'https://landing.deepset.ai/deepset-studio-signup' },
            ],
          },
          {
            title: 'Company',
            items: [
              { label: 'About',   href: 'https://deepset.ai/about' },
              { label: 'Careers', href: 'https://deepset.ai/careers' },
              { label: 'Blog',    href: 'https://deepset.ai/blog' },
            ],
          },
          {
            title: 'Legal',
            items: [
              { label: 'Privacy Policy', href: 'https://www.deepset.ai/privacy-policy' },
              { label: 'Imprint', href: 'https://www.deepset.ai/imprint' },
            ],
          },
        ],
        copyright: `© ${new Date().getFullYear()} deepset GmbH. All rights reserved.`,
      },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
        additionalLanguages: ['python', 'bash', 'docker'],
      },
    }),
};

export default config;
