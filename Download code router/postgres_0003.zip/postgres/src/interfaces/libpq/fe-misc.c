/*-------------------------------------------------------------------------
 *
 *	 FILE
 *		fe-misc.c
 *
 *	 DESCRIPTION
 *		 miscellaneous useful functions
 *
 * The communication routines here are analogous to the ones in
 * backend/libpq/pqcomm.c and backend/libpq/pqformat.c, but operate
 * in the considerably different environment of the frontend libpq.
 * In particular, we work with a bare nonblock-mode socket, rather than
 * a stdio stream, so that we can avoid unwanted blocking of the application.
 *
 * XXX: MOVE DEBUG PRINTOUT TO HIGHER LEVEL.  As is, block and restart
 * will cause repeat printouts.
 *
 * We must speak the same transmitted data representations as the backend
 * routines.
 *
 *
 * Portions Copyright (c) 1996-2026, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * IDENTIFICATION
 *	  src/interfaces/libpq/fe-misc.c
 *
 *-------------------------------------------------------------------------
 */

#include "postgres_fe.h"

#include <signal.h>
#include <time.h>

#ifdef WIN32
#include "win32.h"
#else
#include <unistd.h>
#include <sys/select.h>
#include <sys/time.h>
#endif

#ifdef HAVE_POLL_H
#include <poll.h>
#endif

#include "libpq-fe.h"
#include "libpq-int.h"
#include "mb/pg_wchar.h"
#include "pg_config_paths.h"
#include "port/pg_bswap.h"

static int	pqPutMsgBytes(const void *buf, size_t len, PGconn *conn);
static int	pqSendSome(PGconn *conn, int len);
static int	pqSocketCheck(PGconn *conn, int forRead, int forWrite,
						  pg_usec_time_t end_time);
static int	pqReadData_internal(PGconn *conn);
static int	pqDrainPending(PGconn *conn);

/*
 * PQlibVersion: return the libpq version number
 */
int
PQlibVersion(void)
{
	return PG_VERSION_NUM;
}


/*
 * pqGetc: read 1 character from the connection
 *
 *	All these routines return 0 on success, EOF on error.
 *	Note that for the Get routines, EOF only means there is not enough
 *	data in the buffer, not that there is necessarily a hard error.
 */
int
pqGetc(char *result, PGconn *conn)
{
	if (conn->inCursor >= conn->inEnd)
		return EOF;

	*result = conn->inBuffer[conn->inCursor++];

	return 0;
}


/*
 * pqPutc: write 1 char to the current message
 */
int
pqPutc(char c, PGconn *conn)
{
	if (pqPutMsgBytes(&c, 1, conn))
		return EOF;

	return 0;
}


/*
 * pqGets[_append]:
 * read a null-terminated string from the connection,
 * and store it in an expansible PQExpBuffer.
 * If we run out of memory, all of the string is still read,
 * but the excess characters are silently discarded.
 */
static int
pqGets_internal(PQExpBuffer buf, PGconn *conn, bool resetbuffer)
{
	/* Copy conn data to locals for faster search loop */
	char	   *inBuffer = conn->inBuffer;
	int			inCursor = conn->inCursor;
	int			inEnd = conn->inEnd;
	int			slen;

	while (inCursor < inEnd && inBuffer[inCursor])
		inCursor++;

	if (inCursor >= inEnd)
		return EOF;

	slen = inCursor - conn->inCursor;

	if (resetbuffer)
		resetPQExpBuffer(buf);

	appendBinaryPQExpBuffer(buf, inBuffer + conn->inCursor, slen);

	conn->inCursor = ++inCursor;

	return 0;
}

int
pqGets(PQExpBuffer buf, PGconn *conn)
{
	return pqGets_internal(buf, conn, true);
}

int
pqGets_append(PQExpBuffer buf, PGconn *conn)
{
	return pqGets_internal(buf, conn, false);
}


/*
 * pqPuts: write a null-terminated string to the current message
 */
int
pqPuts(const char *s, PGconn *conn)
{
	if (pqPutMsgBytes(s, strlen(s) + 1, conn))
		return EOF;

	return 0;
}

/*
 * pqGetnchar:
 *	read exactly len bytes in buffer s, no null termination
 */
int
pqGetnchar(void *s, size_t len, PGconn *conn)
{
	if (len > (size_t) (conn->inEnd - conn->inCursor))
		return EOF;

	memcpy(s, conn->inBuffer + conn->inCursor, len);
	/* no terminating null */

	conn->inCursor += len;

	return 0;
}

/*
 * pqSkipnchar:
 *	skip over len bytes in input buffer.
 *
 * Note: this is primarily useful for its debug output, which should
 * be exactly the same as for pqGetnchar.  We assume the data in question
 * will actually be used, but just isn't getting copied anywhere as yet.
 */
int
pqSkipnchar(size_t len, PGconn *conn)
{
	if (len > (size_t) (conn->inEnd - conn->inCursor))
		return EOF;

	conn->inCursor += len;

	return 0;
}

/*
 * pqPutnchar:
 *	write exactly len bytes to the current message
 */
int
pqPutnchar(const void *s, size_t len, PGconn *conn)
{
	if (pqPutMsgBytes(s, len, conn))
		return EOF;

	return 0;
}

/*
 * pqGetInt
 *	read a 2 or 4 byte integer and convert from network byte order
 *	to local byte order
 */
int
pqGetInt(int *result, size_t bytes, PGconn *conn)
{
	uint16		tmp2;
	uint32		tmp4;

	switch (bytes)
	{
		case 2:
			if (conn->inCursor + 2 > conn->inEnd)
				return EOF;
			memcpy(&tmp2, conn->inBuffer + conn->inCursor, 2);
			conn->inCursor += 2;
			*result = (int) pg_ntoh16(tmp2);
			break;
		case 4:
			if (conn->inCursor + 4 > conn->inEnd)
				return EOF;
			memcpy(&tmp4, conn->inBuffer + conn->inCursor, 4);
			conn->inCursor += 4;
			*result = (int) pg_ntoh32(tmp4);
			break;
		default:
			pqInternalNotice(&conn->noticeHooks,
							 "integer of size %zu not supported by pqGetInt",
							 bytes);
			return EOF;
	}

	return 0;
}

/*
 * pqPutInt
 * write an integer of 2 or 4 bytes, converting from host byte order
 * to network byte order.
 */
int
pqPutInt(int value, size_t bytes, PGconn *conn)
{
	uint16		tmp2;
	uint32		tmp4;

	switch (bytes)
	{
		case 2:
			tmp2 = pg_hton16((uint16) value);
			if (pqPutMsgBytes((const char *) &tmp2, 2, conn))
				return EOF;
			break;
		case 4:
			tmp4 = pg_hton32((uint32) value);
			if (pqPutMsgBytes((const char *) &tmp4, 4, conn))
				return EOF;
			break;
		default:
			pqInternalNotice(&conn->noticeHooks,
							 "integer of size %zu not supported by pqPutInt",
							 bytes);
			return EOF;
	}

	return 0;
}

/*
 * Make sure conn's output buffer can hold bytes_needed bytes (caller must
 * include already-stored data into the value!)
 *
 * Returns 0 on success, EOF if failed to enlarge buffer
 */
int
pqCheckOutBufferSpace(size_t bytes_needed, PGconn *conn)
{
	int			newsize = conn->outBufSize;
	char	   *newbuf;

	/* Quick exit if we have enough space */
	if (bytes_needed <= (size_t) newsize)
		return 0;

	/*
	 * If we need to enlarge the buffer, we first try to double it in size; if
	 * that doesn't work, enlarge in multiples of 8K.  This avoids thrashing
	 * the malloc pool by repeated small enlargements.
	 *
	 * Note: tests for newsize > 0 are to catch integer overflow.
	 */
	do
	{
		newsize *= 2;
	} while (newsize > 0 && bytes_needed > (size_t) newsize);

	if (newsize > 0 && bytes_needed <= (size_t) newsize)
	{
		newbuf = realloc(conn->outBuffer, newsize);
		if (newbuf)
		{
			/* realloc succeeded */
			conn->outBuffer = newbuf;
			conn->outBufSize = newsize;
			return 0;
		}
	}

	newsize = conn->outBufSize;
	do
	{
		newsize += 8192;
	} while (newsize > 0 && bytes_needed > (size_t) newsize);

	if (newsize > 0 && bytes_needed <= (size_t) newsize)
	{
		newbuf = realloc(conn->outBuffer, newsize);
		if (newbuf)
		{
			/* realloc succeeded */
			conn->outBuffer = newbuf;
			conn->outBufSize = newsize;
			return 0;
		}
	}

	/* realloc failed. Probably out of memory */
	appendPQExpBufferStr(&conn->errorMessage,
						 "cannot allocate memory for output buffer\n");
	return EOF;
}

/*
 * Make sure conn's input buffer can hold bytes_needed bytes (caller must
 * include already-stored data into the value!)
 *
 * Returns 0 on success, EOF if failed to enlarge buffer
 */
int
pqCheckInBufferSpace(size_t bytes_needed, PGconn *conn)
{
	int			newsize = conn->inBufSize;
	char	   *newbuf;

	/* Quick exit if we have enough space */
	if (bytes_needed <= (size_t) newsize)
		return 0;

	/*
	 * Before concluding that we need to enlarge the buffer, left-justify
	 * whatever is in it and recheck.  The caller's value of bytes_needed
	 * includes any data to the left of inStart, but we can delete that in
	 * preference to enlarging the buffer.  It's slightly ugly to have this
	 * function do this, but it's better than making callers worry about it.
	 */
	bytes_needed -= conn->inStart;

	if (conn->inStart < conn->inEnd)
	{
		if (conn->inStart > 0)
		{
			memmove(conn->inBuffer, conn->inBuffer + conn->inStart,
					conn->inEnd - conn->inStart);
			conn->inEnd -= conn->inStart;
			conn->inCursor -= conn->inStart;
			conn->inStart = 0;
		}
	}
	else
	{
		/* buffer is logically empty, reset it */
		conn->inStart = conn->inCursor = conn->inEnd = 0;
	}

	/* Recheck whether we have enough space */
	if (bytes_needed <= (size_t) newsize)
		return 0;

	/*
	 * If we need to enlarge the buffer, we first try to double it in size; if
	 * that doesn't work, enlarge in multiples of 8K.  This avoids thrashing
	 * the malloc pool by repeated small enlargements.
	 *
	 * Note: tests for newsize > 0 are to catch integer overflow.
	 */
	do
	{
		newsize *= 2;
	} while (newsize > 0 && bytes_needed > (size_t) newsize);

	if (newsize > 0 && bytes_needed <= (size_t) newsize)
	{
		newbuf = realloc(conn->inBuffer, newsize);
		if (newbuf)
		{
			/* realloc succeeded */
			conn->inBuffer = newbuf;
			conn->inBufSize = newsize;
			return 0;
		}
	}

	newsize = conn->inBufSize;
	do
	{
		newsize += 8192;
	} while (newsize > 0 && bytes_needed > (size_t) newsize);

	if (newsize > 0 && bytes_needed <= (size_t) newsize)
	{
		newbuf = realloc(conn->inBuffer, newsize);
		if (newbuf)
		{
			/* realloc succeeded */
			conn->inBuffer = newbuf;
			conn->inBufSize = newsize;
			return 0;
		}
	}

	/* realloc failed. Probably out of memory */
	appendPQExpBufferStr(&conn->errorMessage,
						 "cannot allocate memory for input buffer\n");
	return EOF;
}

/*
 * pqParseDone: after a server-to-client message has successfully
 * been parsed, advance conn->inStart to account for it.
 */
void
pqParseDone(PGconn *conn, int newInStart)
{
	/* trace server-to-client message */
	if (conn->Pfdebug)
		pqTraceOutputMessage(conn, conn->inBuffer + conn->inStart, false);

	/* Mark message as done */
	conn->inStart = newInStart;
}

/*
 * pqPutMsgStart: begin construction of a message to the server
 *
 * msg_type is the message type byte, or 0 for a message without type byte
 * (only startup messages have no type byte)
 *
 * Returns 0 on success, EOF on error
 *
 * The idea here is that we construct the message in conn->outBuffer,
 * beginning just past any data already in outBuffer (ie, at
 * outBuffer+outCount).  We enlarge the buffer as needed to hold the message.
 * When the message is complete, we fill in the length word (if needed) and
 * then advance outCount past the message, making it eligible to send.
 *
 * The state variable conn->outMsgStart points to the incomplete message's
 * length word: it is either outCount or outCount+1 depending on whether
 * there is a type byte.  The state variable conn->outMsgEnd is the end of
 * the data collected so far.
 */
int
pqPutMsgStart(char msg_type, PGconn *conn)
{
	int			lenPos;
	int			endPos;

	/* allow room for message type byte */
	if (msg_type)
		endPos = conn->outCount + 1;
	else
		endPos = conn->outCount;

	/* do we want a length word? */
	lenPos = endPos;
	/* allow room for message length */
	endPos += 4;

	/* make sure there is room for message header */
	if (pqCheckOutBufferSpace(endPos, conn))
		return EOF;
	/* okay, save the message type byte if any */
	if (msg_type)
		conn->outBuffer[conn->outCount] = msg_type;
	/* set up the message pointers */
	conn->outMsgStart = lenPos;
	conn->outMsgEnd = endPos;
	/* length word, if needed, will be filled in by pqPutMsgEnd */

	return 0;
}

/*
 * pqPutMsgBytes: add bytes to a partially-constructed message
 *
 * Returns 0 on success, EOF on error
 */
static int
pqPutMsgBytes(const void *buf, size_t len, PGconn *conn)
{
	/* make sure there is room for it */
	if (pqCheckOutBufferSpace(conn->outMsgEnd + len, conn))
		return EOF;
	/* okay, save the data */
	memcpy(conn->outBuffer + conn->outMsgEnd, buf, len);
	conn->outMsgEnd += len;
	/* no Pfdebug call here, caller should do it */
	return 0;
}

/*
 * pqPutMsgEnd: finish constructing a message and possibly send it
 *
 * Returns 0 on success, EOF on error
 *
 * We don't actually send anything here unless we've accumulated at least
 * 8K worth of data (the typical size of a pipe buffer on Unix systems).
 * This avoids sending small partial packets.  The caller must use pqFlush
 * when it's important to flush all the data out to the server.
 */
int
pqPutMsgEnd(PGconn *conn)
{
	/* Fill in length word if needed */
	if (conn->outMsgStart >= 0)
	{
		uint32		msgLen = conn->outMsgEnd - conn->outMsgStart;

		msgLen = pg_hton32(msgLen);
		memcpy(conn->outBuffer + conn->outMsgStart, &msgLen, 4);
	}

	/* trace client-to-server message */
	if (conn->Pfdebug)
	{
		if (conn->outCount < conn->outMsgStart)
			pqTraceOutputMessage(conn, conn->outBuffer + conn->outCount, true);
		else
			pqTraceOutputNoTypeByteMessage(conn,
										   conn->outBuffer + conn->outMsgStart);
	}

	/* Make message eligible to send */
	conn->outCount = conn->outMsgEnd;

	/* If appropriate, try to push out some data */
	if (conn->outCount >= 8192)
	{
		int			toSend = conn->outCount;

		/*
		 * On Unix-pipe connections, it seems profitable to prefer sending
		 * pipe-buffer-sized packets not randomly-sized ones, so retain the
		 * last partial-8K chunk in our buffer for now.  On TCP connections,
		 * the advantage of that is far less clear.  Moreover, it flat out
		 * isn't safe when using SSL or GSSAPI, because those code paths have
		 * API stipulations that if they fail to send all the data that was
		 * offered in the previous write attempt, we mustn't offer less data
		 * in this write attempt.  The previous write attempt might've been
		 * pqFlush attempting to send everything in the buffer, so we mustn't
		 * offer less now.  (Presently, we won't try to use SSL or GSSAPI on
		 * Unix connections, so those checks are just Asserts.  They'll have
		 * to become part of the regular if-test if we ever change that.)
		 */
		if (conn->raddr.addr.ss_family == AF_UNIX)
		{
#ifdef USE_SSL
			Assert(!conn->ssl_in_use);
#endif
#ifdef ENABLE_GSS
			Assert(!conn->gssenc);
#endif
			toSend -= toSend % 8192;
		}

		if (pqSendSome(conn, toSend) < 0)
			return EOF;
		/* in nonblock mode, don't complain if unable to send it all */
	}

	return 0;
}

/* ----------
 * pqReadData: read more data, if any is available
 *
 * Upon a successful return, callers may assume that either 1) all available
 * bytes have been consumed from the socket, or 2) the socket is still marked
 * readable by the OS.  (In other words: after a successful pqReadData, it's
 * safe to tell a client to poll for readable bytes on the socket without any
 * further draining of the SSL/GSS transport buffers.)
 *
 * Possible return values:
 *	 1: successfully loaded at least one more byte
 *	 0: no data is presently available, but no error detected
 *	-1: error detected (including EOF = connection closure);
 *		conn->errorMessage set
 * NOTE: callers must not assume that pointers or indexes into conn->inBuffer
 * remain valid across this call!
 * ----------
 */
int
pqReadData(PGconn *conn)
{
	int			available;

	if (conn->sock == PGINVALID_SOCKET)
	{
		libpq_append_conn_error(conn, "connection not open");
		return -1;
	}

	available = pqReadData_internal(conn);
	if (available < 0)
		return -1;
	else if (available > 0)
	{
		/*
		 * Make sure there are no bytes stuck in layers between conn->inBuffer
		 * and the socket, to make it safe for clients to poll on PQsocket().
		 */
		if (pqDrainPending(conn))
			return -1;
	}
	else
	{
		/*
		 * If we're not returning any bytes from the underlying transport,
		 * that must imply there aren't any in the transport buffer...
		 */
		Assert(pqsecure_bytes_pending(conn) == 0);
	}

	return available;
}

/*
 * Workhorse for pqReadData().  It's kept separate from the pqDrainPending()
 * logic to avoid adding to this function's goto complexity.
 */
static int
pqReadData_internal(PGconn *conn)
{
	int			someread = 0;
	ssize_t		nread;

	/* Left-justify any data in the buffer to make room */
	if (conn->inStart < conn->inEnd)
	{
		if (conn->inStart > 0)
		{
			memmove(conn->inBuffer, conn->inBuffer + conn->inStart,
					conn->inEnd - conn->inStart);
			conn->inEnd -= conn->inStart;
			conn->inCursor -= conn->inStart;
			conn->inStart = 0;
		}
	}
	else
	{
		/* buffer is logically empty, reset it */
		conn->inStart = conn->inCursor = conn->inEnd = 0;
	}

	/*
	 * If the buffer is fairly full, enlarge it. We need to be able to enlarge
	 * the buffer in case a single message exceeds the initial buffer size. We
	 * enlarge before filling the buffer entirely so as to avoid asking the
	 * kernel for a partial packet. The magic constant here should be large
	 * enough for a TCP packet or Unix pipe bufferload.  8K is the usual pipe
	 * buffer size, so...
	 */
	if (conn->inBufSize - conn->inEnd < 8192)
	{
		if (pqCheckInBufferSpace(conn->inEnd + (size_t) 8192, conn))
		{
			/*
			 * We don't insist that the enlarge worked, but we need some room
			 */
			if (conn->inBufSize - conn->inEnd < 100)
				return -1;		/* errorMessage already set */
		}
	}

	/* OK, try to read some data */
retry3:
	nread = pqsecure_read(conn, conn->inBuffer + conn->inEnd,
						  conn->inBufSize - conn->inEnd);
	if (nread < 0)
	{
		switch (SOCK_ERRNO)
		{
			case EINTR:
				goto retry3;

				/* Some systems return EAGAIN/EWOULDBLOCK for no data */
#ifdef EAGAIN
			case EAGAIN:
				return someread;
#endif
#if defined(EWOULDBLOCK) && (!defined(EAGAIN) || (EWOULDBLOCK != EAGAIN))
			case EWOULDBLOCK:
				return someread;
#endif

				/* We might get ECONNRESET etc here if connection failed */
			case ALL_CONNECTION_FAILURE_ERRNOS:
				goto definitelyFailed;

			default:
				/* pqsecure_read set the error message for us */
				return -1;
		}
	}
	if (nread > 0)
	{
		conn->inEnd += nread;

		/*
		 * Hack to deal with the fact that some kernels will only give us back
		 * 1 packet per recv() call, even if we asked for more and there is
		 * more available.  If it looks like we are reading a long message,
		 * loop back to recv() again immediately, until we run out of data or
		 * buffer space.  Without this, the block-and-restart behavior of
		 * libpq's higher levels leads to O(N^2) performance on long messages.
		 *
		 * Since we left-justified the data above, conn->inEnd gives the
		 * amount of data already read in the current message.  We consider
		 * the message "long" once we have acquired 32k ...
		 */
		if (conn->inEnd > 32768 &&
			(conn->inBufSize - conn->inEnd) >= 8192)
		{
			someread = 1;
			goto retry3;
		}
		return 1;
	}

	if (someread)
		return 1;				/* got a zero read after successful tries */

	/*
	 * A return value of 0 could mean just that no data is now available, or
	 * it could mean EOF --- that is, the server has closed the connection.
	 * Since we have the socket in nonblock mode, the only way to tell the
	 * difference is to see if select() is saying that the file is ready.
	 * Grumble.  Fortunately, we don't expect this path to be taken much,
	 * since in normal practice we should not be trying to read data unless
	 * the file selected for reading already.
	 *
	 * In SSL mode it's even worse: SSL_read() could say WANT_READ and then
	 * data could arrive before we make the pqReadReady() test, but the second
	 * SSL_read() could still say WANT_READ because the data received was not
	 * a complete SSL record.  So we must play dumb and assume there is more
	 * data, relying on the SSL layer to detect true EOF.
	 */

#ifdef USE_SSL
	if (conn->ssl_in_use)
		return 0;
#endif

	switch (pqReadReady(conn))
	{
		case 0:
			/* definitely no data available */
			return 0;
		case 1:
			/* ready for read */
			break;
		default:
			/* we override pqReadReady's message with something more useful */
			goto definitelyEOF;
	}

	/*
	 * Still not sure that it's EOF, because some data could have just
	 * arrived.
	 */
retry4:
	nread = pqsecure_read(conn, conn->inBuffer + conn->inEnd,
						  conn->inBufSize - conn->inEnd);
	if (nread < 0)
	{
		switch (SOCK_ERRNO)
		{
			case EINTR:
				goto retry4;

				/* Some systems return EAGAIN/EWOULDBLOCK for no data */
#ifdef EAGAIN
			case EAGAIN:
				return 0;
#endif
#if defined(EWOULDBLOCK) && (!defined(EAGAIN) || (EWOULDBLOCK != EAGAIN))
			case EWOULDBLOCK:
				return 0;
#endif

				/* We might get ECONNRESET etc here if connection failed */
			case ALL_CONNECTION_FAILURE_ERRNOS:
				goto definitelyFailed;

			default:
				/* pqsecure_read set the error message for us */
				return -1;
		}
	}
	if (nread > 0)
	{
		conn->inEnd += nread;
		return 1;
	}

	/*
	 * OK, we are getting a zero read even though select() says ready. This
	 * means the connection has been closed.  Cope.
	 */
definitelyEOF:
	libpq_append_conn_error(conn, "server closed the connection unexpectedly\n"
							"\tThis probably means the server terminated abnormally\n"
							"\tbefore or while processing the request.");

	/* Come here if lower-level code already set a suitable errorMessage */
definitelyFailed:
	/* Do *not* drop any already-read data; caller still wants it */
	pqDropConnection(conn, false);
	conn->status = CONNECTION_BAD;	/* No more connection to backend */
	return -1;
}

/*---
 * Drain any transport data that is already buffered in userspace and add it
 * to conn->inBuffer, enlarging inBuffer if necessary.  The drain fails if
 * inBuffer cannot be made to hold all available transport data.
 *
 * We assume that the underlying secure transport implementation does not
 * attempt to read any more data from the socket while draining the transport
 * buffer.  After a successful return, pqsecure_bytes_pending() must be zero.
 *
 * This operation is necessary to prevent deadlock, due to a layering
 * violation designed into our asynchronous client API: pqReadData() and all
 * the parsing routines above it receive data from the SSL/GSS transport
 * buffer, but clients poll on the raw PQsocket() handle.  So data can be
 * "lost" in the intermediate layer if we don't take it out here.
 *
 * To illustrate what we're trying to prevent, say that the server is sending
 * two messages at once in response to a query (Aaaa and Bb), the libpq buffer
 * is five characters in size, and TLS records max out at three-character
 * payloads.  Here's what would happen if pqReadData() didn't call
 * pqDrainPending():
 *
 *   Client    libpq      SSL      Socket
 *     |         |         |         |
 *     |      [     ]    [   ]     [   ]    [1] Buffers are empty, client is
 *     x --------------------------> |          polling on socket
 *     |         |         |         |
 *     |      [     ]    [   ]     [xxx]    [2] First record is received; poll
 *     | <-------------------------- |          signals read-ready
 *     |         |         |         |
 *     x ---> [     ]    [   ]     [xxx]    [3] Client calls PQconsumeInput()
 *     |         |         |         |
 *     |      [     ] -> [   ]     [xxx]    [4] libpq calls pqReadData() to fill
 *     |         |         |         |          the receive buffer
 *     |      [     ]    [Aaa] <-- [   ]    [5] SSL pulls payload off the wire
 *     |         |         |         |          and decrypts it
 *     |      [Aaa  ] <- [   ]     [   ]    [6] pqsecure_read() takes all data
 *     |         |         |         |
 *     | <--- [Aaa  ]    [   ]     [   ]    [7] PQconsumeInput() returns with a
 *     x --------------------------> |          partial message, PQisBusy() is
 *     |         |         |         |          still true, client polls again
 *     |      [Aaa  ]    [   ]     [xxx]    [8] Second record is received; poll
 *     | <-------------------------- |          signals read-ready
 *     |         |         |         |
 *     x ---> [Aaa  ]    [   ]     [xxx]    [9] Client calls PQconsumeInput()
 *     |         |         |         |
 *     |      [Aaa  ] -> [   ]     [xxx]   [10] libpq calls pqReadData() to fill
 *     |         |         |         |          the receive buffer
 *     |      [Aaa  ]    [aBb] <-- [   ]   [11] SSL decrypts
 *     |         |         |         |
 *     |      [AaaaB] <- [b  ]     [   ]   [12] pqsecure_read() fills its
 *     |         |         |         |          buffer, taking only two bytes
 *     | <--- [AaaaB]    [b  ]     [   ]   [13] PQconsumeInput() returns with a
 *     |         |         |         |          complete message buffered;
 *     |         |         |         |          PQisBusy() is false
 *     x ---> [AaaaB]    [b  ]     [   ]   [14] Client calls PQgetResult()
 *     |         |         |         |
 *     | <--- [B    ]    [b  ]     [   ]   [15] Aaaa is returned; PQisBusy() is
 *     x --------------------------> |          true and client polls again
 *     .         |         |         .
 *     .      [B    ]    [b  ]       .     [16] No packets, and client hangs.
 *     .         |         |         .
 *
 * The pqDrainPending() call fixes the above scenario at step [13].  Before
 * returning to the Client, it first expands the libpq buffer and moves the
 * remaining data from the SSL buffer to the libpq buffer.
 *
 * The function returns 0 on success and -1 on error.  Success means that
 * there was no data pending or it was successfully drained to conn->inBuffer.
 * On error, conn->errorMessage is set.
 */
static int
pqDrainPending(PGconn *conn)
{
	ssize_t		bytes_pending;
	ssize_t		nread;

	bytes_pending = pqsecure_bytes_pending(conn);
	if (bytes_pending <= 0)
		return bytes_pending;

	/* Expand the input buffer if necessary. */
	if (pqCheckInBufferSpace(conn->inEnd + (size_t) bytes_pending, conn))
		return -1;				/* errorMessage already set */

	nread = pqsecure_read(conn, conn->inBuffer + conn->inEnd,
						  bytes_pending);

	/*
	 * When there are bytes pending, pqsecure_read() is not supposed to fail
	 * or do a short read, but let's check anyway to be safe.
	 */
	if (nread < 0)
		return -1;
	conn->inEnd += nread;
	if (nread != bytes_pending)
	{
		libpq_append_conn_error(conn,
								"drained only %zd of %zd pending bytes in transport buffer",
								nread, bytes_pending);
		return -1;
	}
	return 0;
}

/*
 * pqSendSome: send data waiting in the output buffer.
 *
 * len is how much to try to send (typically equal to outCount, but may
 * be less).
 *
 * Return 0 on success, -1 on failure and 1 when not all data could be sent
 * because the socket would block and the connection is non-blocking.
 *
 * Note that this is also responsible for consuming data from the socket
 * (putting it in conn->inBuffer) in any situation where we can't send
 * all the specified data immediately.
 *
 * If a socket-level write failure occurs, conn->write_failed is set and the
 * error message is saved in conn->write_err_msg, but we clear the output
 * buffer and return zero anyway; this is because callers should soldier on
 * until we have read what we can from the server and checked for an error
 * message.  write_err_msg should be reported only when we are unable to
 * obtain a server error first.  Much of that behavior is implemented at
 * lower levels, but this function deals with some edge cases.
 */
static int
pqSendSome(PGconn *conn, int len)
{
	char	   *ptr = conn->outBuffer;
	int			remaining = conn->outCount;
	int			result = 0;

	/*
	 * If we already had a write failure, we will never again try to send data
	 * on that connection.  Even if the kernel would let us, we've probably
	 * lost message boundary sync with the server.  conn->write_failed
	 * therefore persists until the connection is reset, and we just discard
	 * all data presented to be written.  However, as long as we still have a
	 * valid socket, we should continue to absorb data from the backend, so
	 * that we can collect any final error messages.
	 */
	if (conn->write_failed)
	{
		/* conn->write_err_msg should be set up already */
		conn->outCount = 0;
		/* Absorb input data if any, and detect socket closure */
		if (conn->sock != PGINVALID_SOCKET)
		{
			if (pqReadData(conn) < 0)
				return -1;
		}
		return 0;
	}

	if (conn->sock == PGINVALID_SOCKET)
	{
		conn->write_failed = true;
		/* Store error message in conn->write_err_msg, if possible */
		/* (strdup failure is OK, we'll cope later) */
		conn->write_err_msg = strdup(libpq_gettext("connection not open\n"));
		/* Discard queued data; no chance it'll ever be sent */
		conn->outCount = 0;
		return 0;
	}

	/* while there's still data to send */
	while (len > 0)
	{
		ssize_t		sent;

#ifndef WIN32
		sent = pqsecure_write(conn, ptr, len);
#else

		/*
		 * Windows can fail on large sends, per KB article Q201213. The
		 * failure-point appears to be different in different versions of
		 * Windows, but 64k should always be safe.
		 */
		sent = pqsecure_write(conn, ptr, Min(len, 65536));
#endif

		if (sent < 0)
		{
			/* Anything except EAGAIN/EWOULDBLOCK/EINTR is trouble */
			switch (SOCK_ERRNO)
			{
#ifdef EAGAIN
				case EAGAIN:
					break;
#endif
#if defined(EWOULDBLOCK) && (!defined(EAGAIN) || (EWOULDBLOCK != EAGAIN))
				case EWOULDBLOCK:
					break;
#endif
				case EINTR:
					continue;

				default:
					/* Discard queued data; no chance it'll ever be sent */
					conn->outCount = 0;

					/* Absorb input data if any, and detect socket closure */
					if (conn->sock != PGINVALID_SOCKET)
					{
						if (pqReadData(conn) < 0)
							return -1;
					}

					/*
					 * Lower-level code should already have filled
					 * conn->write_err_msg (and set conn->write_failed) or
					 * conn->errorMessage.  In the former case, we pretend
					 * there's no problem; the write_failed condition will be
					 * dealt with later.  Otherwise, report the error now.
					 */
					if (conn->write_failed)
						return 0;
					else
						return -1;
			}
		}
		else
		{
			ptr += sent;
			len -= sent;
			remaining -= sent;
		}

		if (len > 0)
		{
			/*
			 * We didn't send it all, wait till we can send more.
			 *
			 * There are scenarios in which we can't send data because the
			 * communications channel is full, but we cannot expect the server
			 * to clear the channel eventually because it's blocked trying to
			 * send data to us.  (This can happen when we are sending a large
			 * amount of COPY data, and the server has generated lots of
			 * NOTICE responses.)  To avoid a deadlock situation, we must be
			 * prepared to accept and buffer incoming data before we try
			 * again.  Furthermore, it is possible that such incoming data
			 * might not arrive until after we've gone to sleep.  Therefore,
			 * we wait for either read ready or write ready.
			 *
			 * In non-blocking mode, we don't wait here directly, but return 1
			 * to indicate that data is still pending.  The caller should wait
			 * for both read and write ready conditions, and call
			 * PQconsumeInput() on read ready, but just in case it doesn't, we
			 * call pqReadData() ourselves before returning.  That's not
			 * enough if the data has not arrived yet, but it's the best we
			 * can do, and works pretty well in practice.  (The documentation
			 * used to say that you only need to wait for write-ready, so
			 * there are still plenty of applications like that out there.)
			 *
			 * Note that errors here don't result in write_failed becoming
			 * set.
			 */
			if (pqReadData(conn) < 0)
			{
				result = -1;	/* error message already set up */
				break;
			}

			if (pqIsnonblocking(conn))
			{
				result = 1;
				break;
			}

			if (pqWait(true, true, conn))
			{
				result = -1;
				break;
			}
		}
	}

	/* shift the remaining contents of the buffer */
	if (remaining > 0)
		memmove(conn->outBuffer, ptr, remaining);
	conn->outCount = remaining;

	return result;
}


/*
 * pqFlush: send any data waiting in the output buffer
 *
 * Return 0 on success, -1 on failure and 1 when not all data could be sent
 * because the socket would block and the connection is non-blocking.
 * (See pqSendSome comments about how failure should be handled.)
 */
int
pqFlush(PGconn *conn)
{
	if (conn->outCount > 0)
	{
		if (conn->Pfdebug)
			fflush(conn->Pfdebug);

		return pqSendSome(conn, conn->outCount);
	}

	return 0;
}


/*
 * pqWait: wait until we can read or write the connection socket
 *
 * JAB: If SSL enabled and used and forRead, buffered bytes short-circuit the
 * call to select().
 *
 * We also stop waiting and return if the kernel flags an exception condition
 * on the socket.  The actual error condition will be detected and reported
 * when the caller tries to read or write the socket.
 */
int
pqWait(int forRead, int forWrite, PGconn *conn)
{
	return pqWaitTimed(forRead, forWrite, conn, -1);
}

/*
 * pqWaitTimed: wait, but not past end_time.
 *
 * Returns -1 on failure, 0 if the socket is readable/writable, 1 if it timed out.
 *
 * The timeout is specified by end_time, which is the int64 number of
 * microseconds since the Unix epoch (that is, time_t times 1 million).
 * Timeout is infinite if end_time is -1.  Timeout is immediate (no blocking)
 * if end_time is 0 (or indeed, any time before now).
 */
int
pqWaitTimed(int forRead, int forWrite, PGconn *conn, pg_usec_time_t end_time)
{
	int			result;

	result = pqSocketCheck(conn, forRead, forWrite, end_time);

	if (result < 0)
		return -1;				/* errorMessage is already set */

	if (result == 0)
	{
		libpq_append_conn_error(conn, "timeout expired");
		return 1;
	}

	return 0;
}

/*
 * pqReadReady: is select() saying the file is ready to read?
 * Returns -1 on failure, 0 if not ready, 1 if ready.
 */
int
pqReadReady(PGconn *conn)
{
	return pqSocketCheck(conn, 1, 0, 0);
}

/*
 * pqWriteReady: is select() saying the file is ready to write?
 * Returns -1 on failure, 0 if not ready, 1 if ready.
 */
int
pqWriteReady(PGconn *conn)
{
	return pqSocketCheck(conn, 0, 1, 0);
}

/*
 * Checks a socket, using poll or select, for data to be read, written,
 * or both.  Returns >0 if one or more conditions are met, 0 if it timed
 * out, -1 if an error occurred.
 *
 * If an altsock is set for asynchronous authentication, that will be used in
 * preference to the "server" socket. Otherwise, if SSL is in use, the SSL
 * buffer is checked prior to checking the socket for read data directly.
 */
static int
pqSocketCheck(PGconn *conn, int forRead, int forWrite, pg_usec_time_t end_time)
{
	int			result;
	pgsocket	sock;

	if (!conn)
		return -1;

	if (conn->altsock != PGINVALID_SOCKET)
		sock = conn->altsock;
	else
	{
		sock = conn->sock;
		if (sock == PGINVALID_SOCKET)
		{
			libpq_append_conn_error(conn, "invalid socket");
			return -1;
		}

		/* Check for SSL/GSS library buffering read bytes */
		if (forRead && pqsecure_bytes_pending(conn) != 0)
		{
			/* short-circuit the select */
			return 1;
		}
	}

	/* We will retry as long as we get EINTR */
	do
		result = PQsocketPoll(sock, forRead, forWrite, end_time);
	while (result < 0 && SOCK_ERRNO == EINTR);

	if (result < 0)
	{
		char		sebuf[PG_STRERROR_R_BUFLEN];

		libpq_append_conn_error(conn, "%s() failed: %s", "select",
								SOCK_STRERROR(SOCK_ERRNO, sebuf, sizeof(sebuf)));
	}

	return result;
}


/*
 * Check a file descriptor for read and/or write data, possibly waiting.
 * If neither forRead nor forWrite are set, immediately return a timeout
 * condition (without waiting).  Return >0 if condition is met, 0
 * if a timeout occurred, -1 if an error or interrupt occurred.
 *
 * The timeout is specified by end_time, which is the int64 number of
 * microseconds since the Unix epoch (that is, time_t times 1 million).
 * Timeout is infinite if end_time is -1.  Timeout is immediate (no blocking)
 * if end_time is 0 (or indeed, any time before now).
 */
int
PQsocketPoll(int sock, int forRead, int forWrite, pg_usec_time_t end_time)
{
	/* We use poll(2) if available, otherwise select(2) */
#ifdef HAVE_POLL
	struct pollfd input_fd;
	int			timeout_ms;

	if (!forRead && !forWrite)
		return 0;

	input_fd.fd = sock;
	input_fd.events = POLLERR;
	input_fd.revents = 0;

	if (forRead)
		input_fd.events |= POLLIN;
	if (forWrite)
		input_fd.events |= POLLOUT;

	/* Compute appropriate timeout interval */
	if (end_time == -1)
		timeout_ms = -1;
	else if (end_time == 0)
		timeout_ms = 0;
	else
	{
		pg_usec_time_t now = PQgetCurrentTimeUSec();

		if (end_time > now)
			timeout_ms = (end_time - now) / 1000;
		else
			timeout_ms = 0;
	}

	return poll(&input_fd, 1, timeout_ms);
#else							/* !HAVE_POLL */

	fd_set		input_mask;
	fd_set		output_mask;
	fd_set		except_mask;
	struct timeval timeout;
	struct timeval *ptr_timeout;

	if (!forRead && !forWrite)
		return 0;

	FD_ZERO(&input_mask);
	FD_ZERO(&output_mask);
	FD_ZERO(&except_mask);
	if (forRead)
		FD_SET(sock, &input_mask);

	if (forWrite)
		FD_SET(sock, &output_mask);
	FD_SET(sock, &except_mask);

	/* Compute appropriate timeout interval */
	if (end_time == -1)
		ptr_timeout = NULL;
	else if (end_time == 0)
	{
		timeout.tv_sec = 0;
		timeout.tv_usec = 0;
		ptr_timeout = &timeout;
	}
	else
	{
		pg_usec_time_t now = PQgetCurrentTimeUSec();

		if (end_time > now)
		{
			timeout.tv_sec = (end_time - now) / 1000000;
			timeout.tv_usec = (end_time - now) % 1000000;
		}
		else
		{
			timeout.tv_sec = 0;
			timeout.tv_usec = 0;
		}
		ptr_timeout = &timeout;
	}

	return select(sock + 1, &input_mask, &output_mask,
				  &except_mask, ptr_timeout);
#endif							/* HAVE_POLL */
}

/*
 * PQgetCurrentTimeUSec: get current time with microsecond precision
 *
 * This provides a platform-independent way of producing a reference
 * value for PQsocketPoll's timeout parameter.
 */
pg_usec_time_t
PQgetCurrentTimeUSec(void)
{
	struct timeval tval;

	gettimeofday(&tval, NULL);
	return (pg_usec_time_t) tval.tv_sec * 1000000 + tval.tv_usec;
}


/*
 * A couple of "miscellaneous" multibyte related functions. They used
 * to be in fe-print.c but that file is doomed.
 */

/*
 * Like pg_encoding_mblen().  Use this in callers that want the
 * dynamically-linked libpq's stance on encodings, even if that means
 * different behavior in different startups of the executable.
 */
int
PQmblen(const char *s, int encoding)
{
	return pg_encoding_mblen(encoding, s);
}

/*
 * Like pg_encoding_mblen_bounded().  Use this in callers that want the
 * dynamically-linked libpq's stance on encodings, even if that means
 * different behavior in different startups of the executable.
 */
int
PQmblenBounded(const char *s, int encoding)
{
	return strnlen(s, pg_encoding_mblen(encoding, s));
}

/*
 * Returns the display length of the character beginning at s, using the
 * specified encoding.
 */
int
PQdsplen(const char *s, int encoding)
{
	return pg_encoding_dsplen(encoding, s);
}

/*
 * Get encoding id from environment variable PGCLIENTENCODING.
 */
int
PQenv2encoding(void)
{
	char	   *str;
	int			encoding = PG_SQL_ASCII;

	str = getenv("PGCLIENTENCODING");
	if (str && *str != '\0')
	{
		encoding = pg_char_to_encoding(str);
		if (encoding < 0)
			encoding = PG_SQL_ASCII;
	}
	return encoding;
}


#ifdef ENABLE_NLS

static void
libpq_binddomain(void)
{
	/*
	 * At least on Windows, there are gettext implementations that fail if
	 * multiple threads call bindtextdomain() concurrently.  Use a mutex and
	 * flag variable to ensure that we call it just once per process.  It is
	 * not known that similar bugs exist on non-Windows platforms, but we
	 * might as well do it the same way everywhere.
	 */
	static volatile bool already_bound = false;
	static pthread_mutex_t binddomain_mutex = PTHREAD_MUTEX_INITIALIZER;

	if (!already_bound)
	{
		/* bindtextdomain() does not preserve errno */
#ifdef WIN32
		int			save_errno = GetLastError();
#else
		int			save_errno = errno;
#endif

		(void) pthread_mutex_lock(&binddomain_mutex);

		if (!already_bound)
		{
			const char *ldir;

			/*
			 * No relocatable lookup here because the calling executable could
			 * be anywhere
			 */
			ldir = getenv("PGLOCALEDIR");
			if (!ldir)
				ldir = LOCALEDIR;
			bindtextdomain(PG_TEXTDOMAIN("libpq"), ldir);
			already_bound = true;
		}

		(void) pthread_mutex_unlock(&binddomain_mutex);

#ifdef WIN32
		SetLastError(save_errno);
#else
		errno = save_errno;
#endif
	}
}

char *
libpq_gettext(const char *msgid)
{
	libpq_binddomain();
	return dgettext(PG_TEXTDOMAIN("libpq"), msgid);
}

char *
libpq_ngettext(const char *msgid, const char *msgid_plural, unsigned long n)
{
	libpq_binddomain();
	return dngettext(PG_TEXTDOMAIN("libpq"), msgid, msgid_plural, n);
}

#endif							/* ENABLE_NLS */


/*
 * Append a formatted string to the given buffer, after translating it.  A
 * newline is automatically appended; the format should not end with a
 * newline.
 */
void
libpq_append_error(PQExpBuffer errorMessage, const char *fmt, ...)
{
	int			save_errno = errno;
	bool		done;
	va_list		args;

	Assert(fmt[strlen(fmt) - 1] != '\n');

	if (PQExpBufferBroken(errorMessage))
		return;					/* already failed */

	/* Loop in case we have to retry after enlarging the buffer. */
	do
	{
		errno = save_errno;
		va_start(args, fmt);
		done = appendPQExpBufferVA(errorMessage, libpq_gettext(fmt), args);
		va_end(args);
	} while (!done);

	appendPQExpBufferChar(errorMessage, '\n');
}

/*
 * Append a formatted string to the error message buffer of the given
 * connection, after translating it.  A newline is automatically appended; the
 * format should not end with a newline.
 */
void
libpq_append_conn_error(PGconn *conn, const char *fmt, ...)
{
	int			save_errno = errno;
	bool		done;
	va_list		args;

	Assert(fmt[strlen(fmt) - 1] != '\n');

	if (PQExpBufferBroken(&conn->errorMessage))
		return;					/* already failed */

	/* Loop in case we have to retry after enlarging the buffer. */
	do
	{
		errno = save_errno;
		va_start(args, fmt);
		done = appendPQExpBufferVA(&conn->errorMessage, libpq_gettext(fmt), args);
		va_end(args);
	} while (!done);

	appendPQExpBufferChar(&conn->errorMessage, '\n');
}

/*
 * For 19beta only, some protocol errors will have additional information
 * appended to help with the "grease" campaign.
 */
void
libpq_append_grease_info(PGconn *conn)
{
	/* translator: %s is a URL */
	libpq_append_conn_error(conn,
							"\tThis indicates a bug in either the server being contacted\n"
							"\tor a proxy handling the connection. Please consider\n"
							"\treporting this to the maintainers of that software.\n"
							"\tFor more information, including instructions on how to\n"
							"\twork around this issue for now, visit\n"
							"\t\t%s",
							"https://wiki.postgresql.org/wiki/Grease");
}
