//! `POST /api/read-page` — reconstruct a single wiki page in full from its
//! chunks, keyed by `slug`.
//!
//! Search returns chunk-level hits; this route reassembles a whole page: fetch
//! every chunk for the slug, order them by `chunk_id`, and join their
//! documents. Scalar page metadata is read from the head chunk, while array
//! metadata that may be distributed is unioned across every chunk. Like the
//! other wiki routes it proxies to the FE through
//! the Foundation Chroma client, which enforces auth, quota,
//! metering, and billing.

use crate::routes::links::page_url;
use crate::routes::{caller_token, whoami::whoami_and_authorize};
use crate::wiki::page::{meta_int, meta_str};
use crate::wiki::WikiClientError;
use crate::{auth::AuthzAction, errors::ServerError, server::FoundationApiServer};
use axum::{extract::State, http::HeaderMap, Json};
use chroma::client::ChromaHttpClientError;
use chroma::types::{Key, SearchPayload, SearchResponse};
use chroma::ChromaCollection;
use chroma_error::{ChromaError, ChromaValidationError, ErrorCodes};
use chroma_types::{
    Metadata, MetadataComparison, MetadataExpression, MetadataValue, PrimitiveOperator, Where,
};
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use validator::Validate;

/// Request body for `POST /api/read-page`.
#[derive(Debug, Deserialize, Validate)]
pub struct ReadPageRequest {
    /// Slug of the wiki page to reconstruct in full. Empty string is the wiki root.
    pub slug: String,
}

/// A full wiki page reconstructed from its chunks, returned by the `read_page`
/// tool and `POST /api/read-page`. Carries only the fields the agent needs.
///
/// `url` is a redirect link (built from the tenant UUID and slug) that the
/// configured web origin resolves to the page.
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct FoundationPage {
    pub slug: String,
    pub title: String,
    pub categories: Vec<String>,
    pub source_ids: Vec<String>,
    pub version: u32,
    pub updated_at: Option<i64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_written_by: Option<String>,
    pub content: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
}

/// Errors raised while reconstructing a wiki page (after validation).
#[derive(Debug, thiserror::Error)]
pub enum ReadPageError {
    /// `frontend_ingress_url` is unset, so the wiki client was never built.
    #[error("wiki read is not configured")]
    RouteDisabled,
    /// The caller's request carried no usable `x-chroma-token`.
    #[error("missing or invalid x-chroma-token header")]
    MissingToken,
    /// Resolving the wiki collection through the proxy failed.
    #[error(transparent)]
    Resolve(#[from] WikiClientError),
    /// The proxied `/search` call to the FE failed.
    #[error("chroma search failed: {0}")]
    Query(ChromaHttpClientError),
    /// No chunks exist for the requested page slug.
    #[error("page not found")]
    PageNotFound,
    /// Stored page metadata has the wrong type. Treat this as data loss instead
    /// of silently replacing metadata that the route could not decode.
    #[error("page '{slug}' has non-array '{key}' metadata")]
    MalformedArrayMetadata { slug: String, key: &'static str },
}

impl ChromaError for ReadPageError {
    fn code(&self) -> ErrorCodes {
        match self {
            ReadPageError::RouteDisabled => ErrorCodes::Internal,
            ReadPageError::MissingToken => ErrorCodes::InvalidArgument,
            ReadPageError::Resolve(err) => err.code(),
            ReadPageError::Query(_) => ErrorCodes::Internal,
            ReadPageError::PageNotFound => ErrorCodes::NotFound,
            ReadPageError::MalformedArrayMetadata { .. } => ErrorCodes::DataLoss,
        }
    }
}

/// `POST /api/read-page` handler. Reconstructs a single wiki page in full from
/// its chunks, keyed by `slug`. Returns 404 when the page does not exist.
pub async fn foundation_read_page(
    headers: HeaderMap,
    State(server): State<FoundationApiServer>,
    Json(request): Json<ReadPageRequest>,
) -> Result<Json<FoundationPage>, ServerError> {
    let identity =
        whoami_and_authorize(&*server.auth, &headers, AuthzAction::ViewFoundation).await?;
    let tenant = identity.tenant;

    let _guard =
        server.scorecard_request(&["op:foundation_read_page", &format!("tenant:{tenant}")])?;

    request.validate().map_err(ChromaValidationError::from)?;

    let page = run_read_page(&server, &headers, &tenant, &request.slug)
        .await?
        .ok_or(ReadPageError::PageNotFound)?;
    Ok(Json(page))
}

/// Resolves the wiki collection and reconstructs the full page for `slug`,
/// returning `None` when no such page exists. Stamps the page's `url` from the
/// configured `foundation_ui_origin` (left `None` when the origin is unset).
pub(crate) async fn run_read_page(
    server: &FoundationApiServer,
    headers: &HeaderMap,
    tenant: &str,
    slug: &str,
) -> Result<Option<FoundationPage>, ReadPageError> {
    let wiki_client = server
        .foundation_chroma_client
        .as_ref()
        .ok_or(ReadPageError::RouteDisabled)?;
    let token = caller_token(headers).ok_or(ReadPageError::MissingToken)?;
    let collection = wiki_client.wiki_collection(tenant, token).await?;

    read_page_from_collection(
        &collection,
        tenant,
        server.config.foundation.foundation_ui_origin.as_deref(),
        slug,
    )
    .await
}

/// Reconstructs the full page for `slug` from an already-resolved wiki
/// `collection`, stamping the page's `url` from `ui_origin` (left `None` when
/// the origin is unset). Callers that resolve the collection once and reuse it
/// across many reads (e.g. the agent's `read_page` tool) go through this;
/// [`run_read_page`] resolves the collection per call and then delegates here.
pub(crate) async fn read_page_from_collection(
    collection: &ChromaCollection,
    tenant: &str,
    ui_origin: Option<&str>,
    slug: &str,
) -> Result<Option<FoundationPage>, ReadPageError> {
    let mut page = read_full_page(collection, slug).await?;
    if let Some(page) = &mut page {
        page.url = page_url(ui_origin, tenant, &page.slug);
    }
    Ok(page)
}

/// Reconstructs a single page by fetching all chunks for `slug`, ordering them
/// by `chunk_id`, and joining their documents. Returns `None` when the slug has
/// no chunks.
///
/// This is a filter-only `search` (no rank) rather than a `get`: the two go
/// through different authorization paths on the FE, and the MCP token is
/// granted the `search` capability — `get` comes back 403.
async fn read_full_page(
    collection: &ChromaCollection,
    slug: &str,
) -> Result<Option<FoundationPage>, ReadPageError> {
    let where_slug = Where::Metadata(MetadataExpression {
        key: "slug".to_string(),
        comparison: MetadataComparison::Primitive(
            PrimitiveOperator::Equal,
            MetadataValue::Str(slug.to_string()),
        ),
    });

    // No rank and no limit: this is a pure metadata filter that returns every
    // chunk of the page, which `assemble_page` then orders by `chunk_id`.
    let payload = SearchPayload::default()
        .r#where(where_slug)
        .limit(None, 0)
        .select([Key::Document, Key::Metadata]);

    let response = collection
        .search(vec![payload])
        .await
        .map_err(ReadPageError::Query)?;

    assemble_page(slug, chunks_from_response(response))
}

/// Flattens a single-payload [`SearchResponse`] into `(document, metadata)`
/// chunk pairs. The per-field outer `Vec` is indexed by payload; we send exactly
/// one payload, so we read row 0. Chunks whose metadata is absent are dropped
/// (assembly keys everything off metadata). Pure (no I/O) so it is unit-testable.
fn chunks_from_response(response: SearchResponse) -> Vec<(String, Metadata)> {
    let documents = response
        .documents
        .into_iter()
        .next()
        .flatten()
        .unwrap_or_default();
    let metadatas = response
        .metadatas
        .into_iter()
        .next()
        .flatten()
        .unwrap_or_default();

    documents
        .into_iter()
        .zip(metadatas)
        .filter_map(|(doc, meta)| Some((doc.unwrap_or_default(), meta?)))
        .collect()
}

/// Orders the chunks of a single page by `chunk_id`, joins their documents into
/// the full markdown, reads scalar per-page metadata off the head chunk, and
/// safely unions preserved array metadata across all chunks. Pure (no I/O) so
/// the ordering/join behaviour is unit-testable. Returns `None` when there are
/// no chunks.
fn assemble_page(
    slug: &str,
    mut chunks: Vec<(String, Metadata)>,
) -> Result<Option<FoundationPage>, ReadPageError> {
    if chunks.is_empty() {
        return Ok(None);
    }

    chunks.sort_by_key(|(_, meta)| meta_int(meta, "chunk_id").unwrap_or(0));

    let categories = page_string_array(slug, &chunks, "categories")?;
    let source_ids = page_string_array(slug, &chunks, "source_ids")?;
    let content: String = chunks.iter().map(|(doc, _)| doc.as_str()).collect();
    let head = &chunks[0].1;

    Ok(Some(FoundationPage {
        slug: slug.to_string(),
        title: meta_str(head, "title").unwrap_or_else(|| slug.to_string()),
        categories,
        source_ids,
        version: meta_int(head, "version")
            .and_then(|version| u32::try_from(version).ok())
            .unwrap_or(0),
        updated_at: meta_int(head, "updated_at"),
        last_written_by: meta_str(head, "last_written_by"),
        content,
        url: None,
    }))
}

/// Reads optional page-level array metadata across every chunk. Missing fields
/// are the canonical representation of an empty array, while values found on
/// any chunk are retained and deduplicated. A wrong-typed value fails the read
/// so a later full-page rewrite cannot silently discard undecodable metadata.
fn page_string_array(
    slug: &str,
    chunks: &[(String, Metadata)],
    key: &'static str,
) -> Result<Vec<String>, ReadPageError> {
    let mut values = Vec::new();
    let mut seen = HashSet::new();
    for (_, metadata) in chunks {
        match metadata.get(key) {
            None => {}
            Some(MetadataValue::StringArray(chunk_values)) => {
                for value in chunk_values {
                    if seen.insert(value.clone()) {
                        values.push(value.clone());
                    }
                }
            }
            Some(_) => {
                return Err(ReadPageError::MalformedArrayMetadata {
                    slug: slug.to_string(),
                    key,
                });
            }
        }
    }
    Ok(values)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn chunk_meta(chunk_id: i64) -> Metadata {
        let mut meta = Metadata::new();
        meta.insert("chunk_id".to_string(), MetadataValue::Int(chunk_id));
        meta.insert(
            "title".to_string(),
            MetadataValue::Str("My Page".to_string()),
        );
        meta.insert("updated_at".to_string(), MetadataValue::Int(1700));
        meta.insert(
            "last_written_by".to_string(),
            MetadataValue::Str("00000000-0000-0000-0000-000000000001".to_string()),
        );
        meta.insert(
            "categories".to_string(),
            MetadataValue::StringArray(vec!["eng".to_string()]),
        );
        meta.insert(
            "source_ids".to_string(),
            MetadataValue::StringArray(vec!["slack_master:abc".to_string()]),
        );
        meta.insert("version".to_string(), MetadataValue::Int(7));
        meta
    }

    #[test]
    fn assemble_page_orders_chunks_and_joins_content() {
        // Deliberately out of order: assembly must sort by chunk_id before join.
        let chunks = vec![
            ("world".to_string(), chunk_meta(1)),
            ("hello ".to_string(), chunk_meta(0)),
        ];

        let page = assemble_page("my-page", chunks)
            .expect("valid metadata")
            .expect("page");

        assert_eq!(page.slug, "my-page");
        assert_eq!(page.title, "My Page");
        assert_eq!(page.categories, vec!["eng".to_string()]);
        assert_eq!(page.source_ids, vec!["slack_master:abc".to_string()]);
        assert_eq!(page.version, 7);
        assert_eq!(page.updated_at, Some(1700));
        assert_eq!(
            page.last_written_by,
            Some("00000000-0000-0000-0000-000000000001".to_string())
        );
        // Chunks are joined with no separator.
        assert_eq!(page.content, "hello world");
    }

    #[test]
    fn assemble_page_falls_back_to_slug_when_title_missing() {
        let mut meta = Metadata::new();
        meta.insert("chunk_id".to_string(), MetadataValue::Int(0));
        let page = assemble_page("orphan", vec![("body".to_string(), meta)])
            .expect("valid metadata")
            .expect("page");

        assert_eq!(page.title, "orphan");
        assert!(page.categories.is_empty());
        assert!(page.source_ids.is_empty());
        assert_eq!(page.version, 0);
        assert_eq!(page.updated_at, None);
        assert_eq!(page.last_written_by, None);
    }

    #[test]
    fn assemble_page_returns_none_without_chunks() {
        assert!(assemble_page("empty", Vec::new())
            .expect("valid metadata")
            .is_none());
    }

    #[test]
    fn assemble_page_rejects_malformed_preserved_array_metadata() {
        for key in ["source_ids", "categories"] {
            let head = chunk_meta(0);
            let mut malformed = chunk_meta(1);
            malformed.insert(
                key.to_string(),
                MetadataValue::Str("not-an-array".to_string()),
            );

            let err = assemble_page(
                "broken",
                vec![("head".to_string(), head), ("body".to_string(), malformed)],
            )
            .expect_err("malformed page metadata should fail the read");

            assert!(matches!(
                err,
                ReadPageError::MalformedArrayMetadata {
                    ref slug,
                    key: malformed_key,
                } if slug == "broken" && malformed_key == key
            ));
            assert_eq!(err.code(), ErrorCodes::DataLoss);
        }
    }

    #[test]
    fn assemble_page_recovers_preserved_metadata_from_non_head_chunks() {
        let mut head = chunk_meta(0);
        head.remove("source_ids");
        head.remove("categories");

        let page = assemble_page(
            "recoverable",
            vec![
                ("head".to_string(), head),
                ("body".to_string(), chunk_meta(1)),
            ],
        )
        .expect("valid metadata")
        .expect("page");

        assert_eq!(page.source_ids, vec!["slack_master:abc".to_string()]);
        assert_eq!(page.categories, vec!["eng".to_string()]);
    }

    #[test]
    fn chunks_from_response_reads_row_zero_and_drops_metaless_chunks() {
        let response = SearchResponse {
            ids: vec![vec!["a-0".to_string(), "a-1".to_string()]],
            documents: vec![Some(vec![
                Some("first".to_string()),
                Some("second".to_string()),
            ])],
            embeddings: vec![None],
            // Second chunk has no metadata, so it is dropped.
            metadatas: vec![Some(vec![Some(chunk_meta(0)), None])],
            scores: vec![None],
            select: vec![vec![]],
        };

        let chunks = chunks_from_response(response);
        assert_eq!(chunks.len(), 1);
        assert_eq!(chunks[0].0, "first");
    }

    #[test]
    fn chunks_from_response_empty_yields_no_chunks() {
        let response = SearchResponse {
            ids: vec![],
            documents: vec![],
            embeddings: vec![],
            metadatas: vec![],
            scores: vec![],
            select: vec![],
        };
        assert!(chunks_from_response(response).is_empty());
    }

    #[test]
    fn read_page_request_allows_root_slug() {
        let valid: ReadPageRequest =
            serde_json::from_value(serde_json::json!({ "slug": "my-page" })).expect("deserialize");
        assert!(valid.validate().is_ok());

        let root: ReadPageRequest =
            serde_json::from_value(serde_json::json!({ "slug": "" })).expect("deserialize");
        assert!(root.validate().is_ok());
    }

    #[test]
    fn read_page_error_maps_to_http_codes() {
        assert_eq!(ReadPageError::PageNotFound.code(), ErrorCodes::NotFound);
        assert_eq!(
            ReadPageError::MissingToken.code(),
            ErrorCodes::InvalidArgument
        );
        assert_eq!(ReadPageError::RouteDisabled.code(), ErrorCodes::Internal);
    }
}
