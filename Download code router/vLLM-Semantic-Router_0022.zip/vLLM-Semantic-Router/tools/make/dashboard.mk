# ========================== dashboard.mk ==========================
# = Everything For Dashboard, include Frontend and Backend          =
# ========================== dashboard.mk ==========================

DASHBOARD_DIR := dashboard
DASHBOARD_FRONTEND_DIR := $(DASHBOARD_DIR)/frontend
DASHBOARD_BACKEND_DIR := $(DASHBOARD_DIR)/backend
DASHBOARD_WIZMAP_DIR := $(DASHBOARD_DIR)/wizmap
DASHBOARD_WASM_DIR := src/semantic-router/cmd/wasm

##@ Dashboard

## Install and Development

dashboard-install: ## Install dashboard dependencies (frontend npm + backend go mod)
	@$(LOG_TARGET)
	@echo "Installing frontend dependencies..."
	cd $(DASHBOARD_FRONTEND_DIR) && npm install
	@echo "Installing Knowledge Map dependencies..."
	cd $(DASHBOARD_WIZMAP_DIR) && npm install
	@echo "Tidying backend dependencies..."
	cd $(DASHBOARD_BACKEND_DIR) && go mod tidy
	@echo "dashboard dependencies installed"

dashboard-build-wasm: ## Build dashboard DSL compiler WASM assets
	@$(LOG_TARGET)
	@echo "Building dashboard WASM assets..."
	@$(MAKE) -C $(DASHBOARD_WASM_DIR) build
	@echo "dashboard WASM assets completed"

dashboard-dev-frontend: dashboard-install dashboard-build-wasm ## Start dashboard frontend in dev mode
	@$(LOG_TARGET)
	cd $(DASHBOARD_FRONTEND_DIR) && npm run dev

dashboard-dev-backend: ## Start dashboard backend in dev mode
	@$(LOG_TARGET)
	cd $(DASHBOARD_BACKEND_DIR) && go run main.go


## Build

dashboard-build-frontend: dashboard-install dashboard-build-wasm ## Build dashboard frontend for production
	@$(LOG_TARGET)
	cd $(DASHBOARD_FRONTEND_DIR) && npm run build
	cd $(DASHBOARD_WIZMAP_DIR) && npm run build:embedded
	@echo "dashboard/frontend build completed"

dashboard-build-backend: ## Build dashboard backend binary
	@$(LOG_TARGET)
	@echo "Building dashboard backend..."
	@PROJECT_VERSION=$$(sed -n 's/^version = "\(.*\)"/\1/p' src/vllm-sr/pyproject.toml | head -n1); \
		GIT_REVISION=$$(git rev-parse --short=7 HEAD 2>/dev/null || echo local); \
		if [ -z "$${DASHBOARD_VERSION:-}" ]; then \
			DASHBOARD_VERSION="$${PROJECT_VERSION}-dev.$${GIT_REVISION}"; \
			if [ -n "$$(git status --porcelain -- dashboard/backend dashboard/frontend src/vllm-sr/pyproject.toml 2>/dev/null)" ]; then DASHBOARD_VERSION="$${DASHBOARD_VERSION}.dirty"; fi; \
		fi; \
		cd $(DASHBOARD_BACKEND_DIR) && go build \
			-ldflags "-X github.com/vllm-project/semantic-router/dashboard/backend/handlers.dashboardStatusVersion=$$DASHBOARD_VERSION" \
			-o bin/dashboard-server ./main.go
	@echo "dashboard/backend build completed"

dashboard-build: dashboard-build-frontend dashboard-build-backend ## Build dashboard (frontend + backend)
	@$(LOG_TARGET)
	@echo "dashboard build completed (frontend + backend)"

## Lint and Type Check

dashboard-lint: ## Lint dashboard frontend and backend
	@$(LOG_TARGET)
	@echo "Running ESLint for dashboard frontend..."
	cd $(DASHBOARD_FRONTEND_DIR) && npm install 2>/dev/null && npm run lint
	@echo "dashboard/frontend lint passed"
	@echo "Running golangci-lint for dashboard backend..."
	@cd $(DASHBOARD_BACKEND_DIR) && \
		export GOROOT=$$(dirname $$(dirname $$(readlink -f $$(which go)))) && \
		export GOPATH=$$(go env GOPATH 2>/dev/null || echo "$$HOME/go") && \
		export PATH="$$GOPATH/bin:$$PATH" && \
		golangci-lint run ./... --config ../../tools/linter/go/.golangci.yml
	@echo "dashboard/backend lint passed"

dashboard-lint-fix: ## Auto-fix lint issues in dashboard (frontend + backend)
	@$(LOG_TARGET)
	@echo "Running ESLint fix for dashboard frontend..."
	cd $(DASHBOARD_FRONTEND_DIR) && npm install 2>/dev/null && npm run lint -- --fix || true
	@echo "dashboard/frontend lint fix applied"
	@echo "Running golangci-lint fix for dashboard backend..."
	@cd $(DASHBOARD_BACKEND_DIR) && \
		export GOROOT=$$(dirname $$(dirname $$(readlink -f $$(which go)))) && \
		export GOPATH=$$(go env GOPATH 2>/dev/null || echo "$$HOME/go") && \
		export PATH="$$GOPATH/bin:$$PATH" && \
		golangci-lint run ./... --fix --config ../../tools/linter/go/.golangci.yml
	@echo "dashboard/backend lint fix applied"

dashboard-type-check: ## Run TypeScript type checking for dashboard frontend
	@$(LOG_TARGET)
	cd $(DASHBOARD_FRONTEND_DIR) && npm install 2>/dev/null && npm run type-check
	cd $(DASHBOARD_WIZMAP_DIR) && npm install 2>/dev/null && npm run build >/dev/null
	@echo "dashboard/frontend type-check passed"

dashboard-test-frontend: ## Run dashboard frontend unit tests
	@$(LOG_TARGET)
	cd $(DASHBOARD_FRONTEND_DIR) && npm install 2>/dev/null && npm run test:unit
	@echo "dashboard/frontend unit tests passed"

dashboard-test-e2e-evaluation: ## Run Evaluation browser acceptance in Chromium
	@$(LOG_TARGET)
	cd $(DASHBOARD_FRONTEND_DIR) && \
		npm install 2>/dev/null && \
		npx playwright install --with-deps chromium && \
		npm run test:e2e:evaluation
	@echo "dashboard/frontend Evaluation browser acceptance passed"

dashboard-go-mod-tidy: ## Check go mod tidy for dashboard backend
	@$(LOG_TARGET)
	@echo "Checking dashboard/backend..."
	@cd $(DASHBOARD_BACKEND_DIR) && go mod tidy && \
		if ! git diff --exit-code go.mod go.sum 2>/dev/null; then \
			echo "ERROR: go.mod or go.sum files are not tidy in dashboard/backend. Please run 'go mod tidy' in dashboard/backend directory and commit the changes."; \
			git diff go.mod go.sum; \
			exit 1; \
		fi
	@echo "dashboard/backend go mod tidy check passed"

dashboard-test-backend: ## Run dashboard backend Go tests (run from repo root: make dashboard-test-backend)
	@$(LOG_TARGET)
	cd $(DASHBOARD_BACKEND_DIR) && \
		VLLM_SR_EVALUATION_TEST_PYTHON="$${VLLM_SR_EVALUATION_TEST_PYTHON:-python3}" go test ./...

dashboard-evaluation-catalog-check: ## Check generated Evaluation catalog mirrors
	@python3 tools/ci/sync_evaluation_catalogs.py --check

dashboard-check: dashboard-evaluation-catalog-check dashboard-lint dashboard-type-check dashboard-test-frontend dashboard-test-backend dashboard-go-mod-tidy ## Run all dashboard checks (catalogs, lint, type-check, frontend + backend tests, go mod tidy)
	@$(LOG_TARGET)
	@echo "All dashboard checks passed"

## Clean

dashboard-clean: ## Clean dashboard build artifacts (frontend dist + backend bin)
	@$(LOG_TARGET)
	rm -rf $(DASHBOARD_FRONTEND_DIR)/dist
	rm -rf $(DASHBOARD_FRONTEND_DIR)/node_modules
	rm -rf $(DASHBOARD_WIZMAP_DIR)/dist
	rm -rf $(DASHBOARD_WIZMAP_DIR)/node_modules
	rm -f $(DASHBOARD_FRONTEND_DIR)/public/signal-compiler.wasm
	rm -f $(DASHBOARD_FRONTEND_DIR)/public/wasm_exec.js
	rm -rf $(DASHBOARD_BACKEND_DIR)/bin
	@echo "dashboard cleaned"

.PHONY: dashboard-install dashboard-dev-frontend dashboard-dev-backend \
	dashboard-build dashboard-build-wasm dashboard-build-frontend dashboard-build-backend \
	dashboard-test-backend dashboard-test-frontend dashboard-test-e2e-evaluation \
	dashboard-evaluation-catalog-check \
	dashboard-lint dashboard-lint-fix dashboard-type-check dashboard-go-mod-tidy \
	dashboard-check dashboard-clean
