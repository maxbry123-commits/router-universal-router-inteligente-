# Copied and adapted from: https://github.com/hao-ai-lab/FastVideo

# SPDX-License-Identifier: Apache-2.0
"""
Base class for composed pipelines.

This module defines the base class for pipelines that are composed of multiple stages.
"""

import os
from abc import ABC, abstractmethod
from typing import Any, Callable, Iterator, Literal, cast

import torch
from tqdm import tqdm

from sglang.multimodal_gen.runtime.disaggregation.roles import (
    RoleType,
    filter_modules_for_role,
)
from sglang.multimodal_gen.runtime.loader.component_loaders.component_loader import (
    PipelineComponentLoader,
)
from sglang.multimodal_gen.runtime.loader.utils import _normalize_component_type
from sglang.multimodal_gen.runtime.managers.memory_managers.component_loading_order import (
    ComponentLoadSpec,
    order_component_load_specs,
)
from sglang.multimodal_gen.runtime.managers.memory_managers.component_manager import (
    ComponentResidencyManager,
    ComponentResidencyStrategy,
    get_global_component_residency_manager,
)
from sglang.multimodal_gen.runtime.pipelines_core.executors.pipeline_executor import (
    PipelineExecutor,
)
from sglang.multimodal_gen.runtime.pipelines_core.schedule_batch import OutputBatch, Req
from sglang.multimodal_gen.runtime.pipelines_core.stages import (
    DecodingStage,
    DenoisingStage,
    ImageEncodingStage,
    ImageVAEEncodingStage,
    InputValidationStage,
    LatentPreparationStage,
    PipelineStage,
    TextEncodingStage,
    TimestepPreparationStage,
)
from sglang.multimodal_gen.runtime.pipelines_core.stages.progressive_resolution.denoising import (
    ProgressiveDenoisingStage,
    ProgressiveDenoisingStageRouter,
)
from sglang.multimodal_gen.runtime.platforms import current_platform
from sglang.multimodal_gen.runtime.server_args import ServerArgs
from sglang.multimodal_gen.runtime.utils.hf_diffusers_utils import (
    maybe_download_model,
    prepare_diffusers_component_path_for_loading,
    verify_model_config_and_directory,
)
from sglang.multimodal_gen.runtime.utils.logging_utils import init_logger

logger = init_logger(__name__)


class ComposedPipelineBase(ABC):
    """
    Base class for pipelines composed of multiple stages.

    This class provides the framework for creating pipelines by composing multiple
    stages together. Each stage is responsible for a specific part of the diffusion
    process, and the pipeline orchestrates the execution of these stages.
    """

    is_video_pipeline: bool = False  # To be overridden by video pipelines
    # should contains only the modules to be loaded
    _required_config_modules: list[str] = []
    _unfiltered_required_config_modules: tuple[str, ...] = ()
    _extra_config_module_map: dict[str, str] = {}
    server_args: ServerArgs | None = None
    modules: dict[str, Any] = {}
    executor: PipelineExecutor | None = None

    # the name of the pipeline it associated with, in diffusers
    pipeline_name: str
    default_model_subfolder: str | None = None

    def is_lora_effective(self):
        return False

    def is_lora_set(self):
        return False

    def __init__(
        self,
        model_path: str,
        server_args: ServerArgs,
        required_config_modules: list[str] | None = None,
        loaded_modules: dict[str, torch.nn.Module] | None = None,
        executor: PipelineExecutor | None = None,
    ):
        """
        Initialize the pipeline. After __init__, the pipeline should be ready to
        use. The pipeline should be stateless and not hold any batch state.
        """
        self.server_args = server_args
        self._disagg_role = server_args.disagg_role
        self.validate_disagg_role(self._disagg_role)

        self.model_path: str = model_path
        self._stages: list[PipelineStage] = []
        self._stage_name_mapping: dict[str, PipelineStage] = {}
        self.component_residency_strategies: dict[str, ComponentResidencyStrategy] = {}
        self.executor = executor or self.build_executor(server_args=server_args)
        self.component_residency_manager: ComponentResidencyManager | None = None

        base_required_config_modules = (
            required_config_modules
            if required_config_modules is not None
            else self._required_config_modules
        )
        if base_required_config_modules is None:
            raise NotImplementedError("Subclass must set _required_config_modules")
        self._unfiltered_required_config_modules = tuple(base_required_config_modules)
        self._required_config_modules = list(self._unfiltered_required_config_modules)
        self._extra_config_module_map = dict(self._extra_config_module_map)

        # Filter modules based on disaggregation role
        if self._disagg_role != RoleType.MONOLITHIC:
            original_modules = list(self._required_config_modules)
            task_name = self.server_args.pipeline_config.task_type.name.lower()
            self._required_config_modules = filter_modules_for_role(
                self._required_config_modules,
                self._disagg_role,
                extra_allowed_modules=self._get_extra_allowed_modules_for_role(
                    self._disagg_role, task_name
                ),
                structural_component_names=self._extra_config_module_map,
            )
            skipped = set(original_modules) - set(self._required_config_modules)
            if skipped:
                logger.info(
                    "Disagg role=%s: skipping modules %s",
                    self._disagg_role.value,
                    sorted(skipped),
                )

        # [module_name, gpu memory usage]
        self.memory_usages: dict[str, float] = {}
        # Load modules directly in initialization
        logger.info("Loading pipeline modules...")
        self.modules = self.load_modules(server_args, loaded_modules)

        self.__post_init__()

    def build_executor(self, server_args: ServerArgs):
        # TODO
        from sglang.multimodal_gen.runtime.pipelines_core.executors.parallel_executor import (
            ParallelExecutor,
        )

        # return SyncExecutor(server_args=server_args)
        return ParallelExecutor(server_args=server_args)

    def __post_init__(self) -> None:
        assert self.server_args is not None, "server_args must be set"
        self.initialize_pipeline(self.server_args)

        logger.info("Creating pipeline stages...")
        self.create_pipeline_stages(self.server_args)

    def get_module(self, module_name: str, default_value: Any = None) -> Any:
        return self.modules.get(module_name, default_value)

    def add_module(self, module_name: str, module: Any):
        self.modules[module_name] = module

    def _load_config(self) -> dict[str, Any]:
        model_subfolder = self.server_args.model_subfolder
        if model_subfolder is None and not os.path.isfile(
            os.path.join(self.model_path, "model_index.json")
        ):
            model_subfolder = self.default_model_subfolder

        if model_subfolder is None:
            model_path = maybe_download_model(
                self.model_path,
                force_diffusers_model=True,
                revision=self.server_args.revision,
            )
        else:
            model_subfolder = os.path.normpath(model_subfolder)
            if (
                os.path.isabs(model_subfolder)
                or model_subfolder == ".."
                or model_subfolder.startswith(f"..{os.sep}")
            ):
                raise ValueError(
                    f"model_subfolder must stay inside the model repository: {model_subfolder!r}"
                )
            model_root = maybe_download_model(
                self.model_path,
                allow_patterns=[f"{model_subfolder}/**"],
                revision=self.server_args.revision,
            )
            model_path = os.path.join(model_root, model_subfolder)

        self.model_path = model_path
        logger.info("Model path: %s", model_path)
        config = verify_model_config_and_directory(model_path)
        return cast(dict[str, Any], config)

    @property
    def required_config_modules(self) -> list[str]:
        """
        List of modules that are required by the pipeline. The names should match
        the diffusers directory and model_index.json file. These modules will be
        loaded using the PipelineComponentLoader and made available in the
        modules dictionary. Access these modules using the get_module method.

        class ConcretePipeline(ComposedPipelineBase):
            _required_config_modules = ["vae", "text_encoder", "transformer", "scheduler", "tokenizer"]


            @property
            def required_config_modules(self):
                return self._required_config_modules
        """
        return self._required_config_modules

    @property
    def stages(self) -> list[PipelineStage]:
        """
        List of stages in the pipeline.
        """
        return self._stages

    @abstractmethod
    def create_pipeline_stages(self, server_args: ServerArgs):
        """
        Create the inference pipeline stages.
        """
        raise NotImplementedError

    def initialize_pipeline(self, server_args: ServerArgs):
        """
        Initialize the pipeline.
        """
        return

    def validate_disagg_role(self, role: RoleType) -> None:
        """Validate whether the requested disaggregation role is supported."""
        return

    def _get_extra_allowed_modules_for_role(
        self, role: RoleType, task_name: str
    ) -> set[str]:
        role_to_pipeline_modules: dict[RoleType, dict[str, set[str]]] = {
            RoleType.ENCODER: {
                "Flux2Pipeline": {"vae"},
                "Flux2KleinPipeline": {"vae"},
                "QwenImageEditPipeline": {"vae"},
                "QwenImageEditPlusPipeline": {"vae"},
                "QwenImageLayeredPipeline": {"vae", "transformer"},
                "LongCatImageEditPipeline": {"vae"},
                "GlmImagePipeline": {"vae", "transformer"},
                "WanImageToVideoPipeline": {"vae"},
                "WanImageToVideoDmdPipeline": {"vae"},
                "MOVA": {"video_vae", "audio_vae"},
                "MOVAPipeline": {"video_vae", "audio_vae"},
            },
            RoleType.DENOISER: {},
            RoleType.DECODER: {},
        }
        extra_allowed_modules = set(
            role_to_pipeline_modules.get(role, {}).get(self.pipeline_name, set())
        )
        if (
            role == RoleType.DENOISER
            and self.pipeline_name == "GlmImagePipeline"
            and getattr(self.server_args, "srt_encoder_url", None) is not None
        ):
            extra_allowed_modules.update({"text_encoder", "tokenizer", "vae"})

        if role == RoleType.DENOISER and task_name == "ti2v":
            if self.pipeline_name in {
                "WanImageToVideoPipeline",
                "WanImageToVideoDmdPipeline",
            }:
                extra_allowed_modules.add("vae")
            elif self.pipeline_name == "LTX2Pipeline":
                extra_allowed_modules.update({"vae", "audio_vae"})

        return extra_allowed_modules

    # --- Config-name → pipeline_config attribute mapping ---
    _CONFIG_ATTR_MAP: dict[str, str] = {
        "vae": "vae_config",
        "video_vae": "vae_config",
        "audio_vae": "audio_vae_config",
    }

    def _init_skipped_component_configs(
        self,
        full_model_index: dict[str, Any],
        server_args: ServerArgs,
    ) -> None:
        """Read HF JSON configs for skipped components and run
        update_model_arch + post_init so pipeline_config is fully
        initialized without loading weights.
        """
        from sglang.multimodal_gen.runtime.utils.hf_diffusers_utils import (
            get_diffusers_component_config,
        )

        loaded_components = set(self.required_config_modules)
        loaded_structural_components = {
            self._extra_config_module_map.get(name, name)
            for name in self.required_config_modules
        }
        skipped_components: list[tuple[str, str]] = []
        seen_component_keys = loaded_components | loaded_structural_components
        for component_name in self._unfiltered_required_config_modules:
            structural_name = self._extra_config_module_map.get(
                component_name, component_name
            )
            if (
                component_name in seen_component_keys
                or structural_name in seen_component_keys
                or (
                    component_name not in full_model_index
                    and structural_name not in full_model_index
                )
            ):
                continue
            skipped_components.append((component_name, structural_name))
            seen_component_keys.update((component_name, structural_name))
        for structural_name in full_model_index:
            if structural_name not in seen_component_keys:
                skipped_components.append((structural_name, structural_name))

        for component_name, structural_name in skipped_components:
            cfg_attr = self._CONFIG_ATTR_MAP.get(
                _normalize_component_type(structural_name)
            )
            if cfg_attr is None:
                continue  # not a config we need to patch

            pipeline_cfg = getattr(server_args.pipeline_config, cfg_attr, None)
            if pipeline_cfg is None:
                continue

            try:
                component_path = self._resolve_component_path(
                    server_args, component_name, structural_name
                )
                hf_config = get_diffusers_component_config(
                    component_path=component_path
                )
                hf_config.pop("_class_name", None)
                hf_config.pop("_diffusers_version", None)
                pipeline_cfg.update_model_arch(hf_config)
                if hasattr(pipeline_cfg, "post_init"):
                    pipeline_cfg.post_init()
                logger.info(
                    "Disagg role=%s: initialized %s config from HF JSON "
                    "(spatial_compression_ratio=%s)",
                    self._disagg_role.value,
                    component_name,
                    getattr(
                        getattr(pipeline_cfg, "arch_config", None),
                        "spatial_compression_ratio",
                        "N/A",
                    ),
                )
            except Exception as e:
                logger.warning(
                    "Disagg role=%s: failed to read HF config for skipped "
                    "component %s: %s",
                    self._disagg_role.value,
                    component_name,
                    e,
                )

    def _resolve_component_path(
        self, server_args: ServerArgs, module_name: str, load_module_name: str
    ) -> str:
        override_path = server_args.component_paths.get(module_name)
        if override_path is not None:
            component_model_path = prepare_diffusers_component_path_for_loading(
                override_path
            )
        else:
            component_model_path = os.path.join(self.model_path, load_module_name)

        logger.debug("Resolved component path: %s", component_model_path)
        return component_model_path

    @staticmethod
    def _validate_direct_gpu_component_selection(
        model_index: dict[str, Any], server_args: ServerArgs
    ) -> None:
        unavailable = sorted(
            component_name
            for component_name in server_args.component_direct_gpu_weight_loading
            if component_name not in model_index or model_index[component_name] is None
        )
        if unavailable:
            raise ValueError(
                "--component-direct-gpu-weight-loading selects component(s) "
                "that are not available in this pipeline: "
                f"{', '.join(unavailable)}"
            )

    def load_modules(
        self,
        server_args: ServerArgs,
        loaded_modules: dict[str, torch.nn.Module] | None = None,
    ) -> dict[str, Any]:
        """
        Load the modules from the config.
        loaded_modules: Optional[Dict[str, torch.nn.Module]] = None,
        If provided, loaded_modules will be used instead of loading from config/pretrained weights.
        """

        model_index = self._load_config()
        logger.info("Loading pipeline modules from config: %s", model_index)

        # remove keys that are not pipeline modules
        model_index.pop("_class_name")
        model_index.pop("_diffusers_version")
        if (
            "boundary_ratio" in model_index
            and model_index["boundary_ratio"] is not None
        ):
            has_transformer = (
                "transformer" in model_index
                or "transformer_2" in model_index
                or "transformer" in self.required_config_modules
                or "transformer_2" in self.required_config_modules
            )
            if has_transformer:
                logger.info(
                    "MoE pipeline detected. Adding transformer_2 to self.required_config_modules..."
                )
                if "transformer_2" not in self.required_config_modules:
                    # Re-apply disagg role filter: only add transformer_2 if the
                    # role actually needs denoising modules.
                    from sglang.multimodal_gen.runtime.disaggregation.roles import (
                        get_module_role,
                    )

                    module_role = get_module_role("transformer_2")
                    if (
                        self._disagg_role == RoleType.MONOLITHIC
                        or module_role is None
                        or module_role == self._disagg_role
                    ):
                        self.required_config_modules.append("transformer_2")
                    else:
                        logger.info(
                            "Disagg role=%s: skipping dynamically added module transformer_2",
                            self._disagg_role.value,
                        )
            else:
                logger.info(
                    "Boundary ratio found in model_index.json without transformers; "
                    "using it for pipeline config only."
                )
            logger.info(
                "Setting boundary ratio to %s",
                model_index["boundary_ratio"],
            )
            server_args.pipeline_config.dit_config.boundary_ratio = model_index[
                "boundary_ratio"
            ]

        model_index.pop("boundary_ratio", None)
        # used by Wan2.2 ti2v
        model_index.pop("expand_timesteps", None)
        self._validate_direct_gpu_component_selection(model_index, server_args)

        # some sanity checks
        assert (
            len(model_index) > 1
        ), "model_index.json must contain at least one pipeline module"

        # In disagg mode, read HF config for skipped components (e.g., VAE)
        # so that update_model_arch + post_init can derive pipeline_config.
        if self._disagg_role != RoleType.MONOLITHIC:
            self._init_skipped_component_configs(model_index, server_args)

        declared_modules = model_index
        model_index = {
            required_module: model_index[required_module]
            for required_module in self.required_config_modules
            if required_module in model_index
        }

        for module_name in self.required_config_modules:
            if (
                module_name not in model_index
                and module_name in self._extra_config_module_map
            ):
                extra_module_value = self._extra_config_module_map[module_name]
                logger.warning(
                    "model_index.json does not contain a %s module, but found {%s: %s} in _extra_config_module_map, adding to model_index.",
                    module_name,
                    module_name,
                    extra_module_value,
                )
                if extra_module_value in declared_modules:
                    logger.info(
                        "Using module %s for %s", extra_module_value, module_name
                    )
                    model_index[module_name] = declared_modules[extra_module_value]
                    continue
                else:
                    raise ValueError(
                        f"Required module key: {module_name} value: "
                        f"{declared_modules.get(module_name)} was not found in "
                        f"declared modules {declared_modules.keys()}"
                    )

        # all the component models used by the pipeline
        required_modules = self.required_config_modules
        logger.info("Loading required components: %s", required_modules)

        loaded_components = {}
        component_load_specs: list[ComponentLoadSpec] = []

        # enqueue only real weight loads (e.g., scheduler, tokenizer is excluded); skipped/provided modules keep old handling
        for index, (module_name, component_spec) in enumerate(model_index.items()):
            # Diffusers uses JSON null for unavailable optional components.
            # Check before unpacking the normal [library, architecture] pair.
            if component_spec is None:
                logger.warning(
                    "Module %s in model_index.json has null value, removing from required_config_modules",
                    module_name,
                )
                if module_name in self.required_config_modules:
                    self.required_config_modules.remove(module_name)
                continue
            if (
                not isinstance(component_spec, (list, tuple))
                or len(component_spec) != 2
            ):
                raise ValueError(
                    f"Module {module_name!r} in model_index.json must be null or "
                    f"a [library, architecture] pair, got {component_spec!r}"
                )
            transformers_or_diffusers, architecture = component_spec
            if transformers_or_diffusers is None:
                logger.warning(
                    "Module %s in model_index.json has null value, removing from required_config_modules",
                    module_name,
                )
                if module_name in self.required_config_modules:
                    self.required_config_modules.remove(module_name)
                continue
            if module_name not in required_modules:
                logger.info("Skipping module %s", module_name)
                continue
            if loaded_modules is not None and module_name in loaded_modules:
                logger.info("Using module %s already provided", module_name)
                loaded_components[module_name] = loaded_modules[module_name]
                continue

            if module_name in self._extra_config_module_map:
                load_module_name = self._extra_config_module_map[module_name]
            else:
                load_module_name = module_name
            component_model_path = self._resolve_component_path(
                server_args, module_name, load_module_name
            )
            # collect loading specs
            component_load_specs.append(
                ComponentLoadSpec(
                    module_name=module_name,
                    load_module_name=load_module_name,
                    component_model_path=component_model_path,
                    transformers_or_diffusers=transformers_or_diffusers,
                    architecture=architecture,
                    index=index,
                )
            )

        # reorder loading order to avoid OOM
        component_load_specs: ComponentLoadSpec = order_component_load_specs(
            component_load_specs
        )
        logger.info(
            "Memory-aware component load order: %s",
            [spec.module_name for spec in component_load_specs],
        )

        for spec in tqdm(
            iterable=component_load_specs, desc="Loading required modules"
        ):
            module_name: str = spec.module_name
            load_module_name: str = spec.load_module_name
            transformers_or_diffusers: str = spec.transformers_or_diffusers
            architecture: str = spec.architecture
            component_model_path: str = spec.component_model_path

            attn_backend, matched_backend_key = (
                server_args.resolve_component_attention_backend(
                    module_name, load_module_name
                )
            )
            if attn_backend is not None:
                logger.info(
                    "Using %s backend for component: %s",
                    attn_backend.name.lower(),
                    matched_backend_key,
                )
            module, memory_usage = PipelineComponentLoader.load_component(
                component_name=module_name,
                component_type=load_module_name,
                component_model_path=component_model_path,
                transformers_or_diffusers=transformers_or_diffusers,
                server_args=server_args,
                component_architecture=architecture,
                component_attn_backend=attn_backend,
                component_attn_name=matched_backend_key or module_name,
            )

            self.memory_usages[module_name] = memory_usage

            if module_name in loaded_components:
                logger.warning("Overwriting module %s", module_name)
            loaded_components[module_name] = module

        # Check if all required modules were loaded
        for module_name in required_modules:
            if (
                module_name not in loaded_components
                or loaded_components[module_name] is None
            ):
                raise ValueError(
                    f"Required module: {module_name} was not found in loaded modules: {list(loaded_components.keys())}"
                )

        logger.debug(
            "Memory usage of loaded modules (GiB): %s. avail mem: %s GB",
            self.memory_usages,
            round(current_platform.get_available_gpu_memory(), 2),
        )
        total_consumed_gb = sum(
            usage
            for usage in self.memory_usages.values()
            if isinstance(usage, (int, float))
        )
        available_after_gb = current_platform.get_available_gpu_memory()
        logger.debug(
            "Module load summary: required_modules=%s loaded_modules=%s "
            "memory_usages_gb=%s total_consumed_gb=%.2f "
            "available_after_gb=%.2f",
            list(required_modules),
            list(loaded_components.keys()),
            self.memory_usages,
            total_consumed_gb,
            available_after_gb,
        )

        return loaded_components

    @staticmethod
    def _infer_stage_name(stage: PipelineStage) -> str:
        return stage.__class__.__name__

    def _should_add_stage_for_role(
        self,
        role_affinity: RoleType,
        stage_name: str,
    ) -> bool:
        if self._disagg_role == RoleType.MONOLITHIC:
            return True
        if role_affinity == self._disagg_role:
            return True

        logger.info(
            "Disagg role=%s: skipping stage %s (affinity=%s)",
            self._disagg_role.value,
            stage_name,
            role_affinity.value,
        )
        return False

    def _profile_stage_name(self, stage: PipelineStage, stage_name: str) -> str:
        class_name = stage.__class__.__name__
        if any(existing.__class__.__name__ == class_name for existing in self._stages):
            return stage_name
        return class_name

    def add_stage(
        self, stage: PipelineStage, stage_name: str | None = None
    ) -> "ComposedPipelineBase":

        assert self.modules is not None, "No modules are registered"
        if stage_name is None:
            stage_name = self._infer_stage_name(stage)

        # Filter stages based on disaggregation role
        if not self._should_add_stage_for_role(stage.role_affinity, stage_name):
            return self

        if stage_name in self._stage_name_mapping:
            raise ValueError(f"Duplicate stage name detected: {stage_name}")

        stage.set_registered_stage_name(stage_name)
        stage.set_profile_stage_name(self._profile_stage_name(stage, stage_name))
        self._stages.append(stage)
        self._stage_name_mapping[stage_name] = stage
        return self

    def add_stage_factory(
        self,
        role_affinity: RoleType,
        stage_factory: Callable[[], PipelineStage],
        stage_name: str,
    ) -> "ComposedPipelineBase":
        assert self.modules is not None, "No modules are registered"
        if not self._should_add_stage_for_role(role_affinity, stage_name):
            return self
        return self.add_stage(stage_factory(), stage_name)

    def add_stages(
        self, stages: list[PipelineStage | tuple[PipelineStage, str]]
    ) -> "ComposedPipelineBase":

        for item in stages:
            if isinstance(item, tuple):
                stage, name = item
                self.add_stage(stage, name)
            else:
                self.add_stage(item)
        return self

    def add_stage_if(
        self,
        condition: bool | Callable[[], bool],
        stage: PipelineStage,
    ) -> "ComposedPipelineBase":
        should_add = condition() if callable(condition) else condition
        if should_add:
            self.add_stage(stage)
        return self

    def get_stage(self, stage_name: str) -> PipelineStage | None:
        """Get a stage by name."""
        return self._stage_name_mapping.get(stage_name)

    def add_standard_text_encoding_stage(
        self,
        text_encoder_key: str | list[str] = "text_encoder",
        tokenizer_key: str | list[str] = "tokenizer",
        stage_name: str | None = None,
    ) -> "ComposedPipelineBase":
        text_encoder_keys = (
            [text_encoder_key]
            if isinstance(text_encoder_key, str)
            else text_encoder_key
        )
        tokenizer_keys = (
            [tokenizer_key] if isinstance(tokenizer_key, str) else tokenizer_key
        )
        return self.add_stage(
            TextEncodingStage(
                text_encoders=[self.get_module(key) for key in text_encoder_keys],
                tokenizers=[self.get_module(key) for key in tokenizer_keys],
            ),
            stage_name,
        )

    def add_standard_timestep_preparation_stage(
        self,
        scheduler_key: str = "scheduler",
        prepare_extra_kwargs: list[Callable] | None = None,
    ) -> "ComposedPipelineBase":
        return self.add_stage(
            TimestepPreparationStage(
                scheduler=self.get_module(scheduler_key),
                prepare_extra_set_timesteps_kwargs=list(prepare_extra_kwargs or []),
            ),
        )

    def add_standard_latent_preparation_stage(
        self,
        scheduler_key: str = "scheduler",
        transformer_key: str = "transformer",
    ) -> "ComposedPipelineBase":
        return self.add_stage(
            LatentPreparationStage(
                scheduler=self.get_module(scheduler_key),
                transformer=self.get_module(transformer_key),
            ),
        )

    def add_standard_denoising_stage(
        self,
        transformer_key: str = "transformer",
        transformer_2_key: str | None = "transformer_2",
        scheduler_key: str = "scheduler",
        vae_key: str | None = "vae",
        stage_name: str = "denoising_stage",
    ) -> "ComposedPipelineBase":

        def create_stage() -> PipelineStage:
            kwargs = {
                "transformer": self.get_module(transformer_key),
                "scheduler": self.get_module(scheduler_key),
            }

            if transformer_2_key:
                transformer_2 = self.get_module(transformer_2_key, None)
                if transformer_2 is not None:
                    kwargs["transformer_2"] = transformer_2

            if vae_key:
                vae = self.get_module(vae_key, None)
                if vae is not None:
                    kwargs["vae"] = vae
                    kwargs["pipeline"] = self

            return DenoisingStage(**kwargs)

        return self.add_stage_factory(
            RoleType.DENOISER,
            create_stage,
            stage_name,
        )

    def add_progressive_denoising_stage(
        self,
        progressive_stage_cls: type[ProgressiveDenoisingStage],
        transformer_key: str = "transformer",
        transformer_2_key: str | None = "transformer_2",
        scheduler_key: str = "scheduler",
        vae_key: str | None = "vae",
        stage_name: str = "denoising_stage",
    ) -> "ComposedPipelineBase":

        def create_stage() -> PipelineStage:
            kwargs = {
                "transformer": self.get_module(transformer_key),
                "scheduler": self.get_module(scheduler_key),
                "pipeline": self,
            }

            if transformer_2_key:
                transformer_2 = self.get_module(transformer_2_key, None)
                if transformer_2 is not None:
                    kwargs["transformer_2"] = transformer_2

            if vae_key:
                kwargs["vae"] = self.get_module(vae_key, None)

            return ProgressiveDenoisingStageRouter(
                standard_stage=DenoisingStage(**kwargs),
                progressive_stage_factory=lambda: progressive_stage_cls(**kwargs),
            )

        return self.add_stage_factory(
            RoleType.DENOISER,
            create_stage,
            stage_name,
        )

    def add_standard_decoding_stage(
        self,
        vae_key: str = "vae",
        stage_name: str = "decoding_stage",
    ) -> "ComposedPipelineBase":

        def create_stage() -> PipelineStage:
            return DecodingStage(
                vae=self.get_module(vae_key),
                pipeline=self,
                component_name=vae_key,
            )

        return self.add_stage_factory(
            RoleType.DECODER,
            create_stage,
            stage_name,
        )

    def add_standard_t2i_stages(
        self,
        include_input_validation: bool = True,
        text_encoder_key: str | list[str] = "text_encoder",
        tokenizer_key: str | list[str] = "tokenizer",
        text_encoding_stage_name: str | None = None,
        prepare_extra_timestep_kwargs: list[Callable] | None = None,
        progressive_denoising_stage_cls: type[ProgressiveDenoisingStage] | None = None,
    ) -> "ComposedPipelineBase":

        if include_input_validation:
            self.add_stage(InputValidationStage())

        self.add_standard_text_encoding_stage(
            text_encoder_key=text_encoder_key,
            tokenizer_key=tokenizer_key,
            stage_name=text_encoding_stage_name,
        )

        self.add_standard_latent_preparation_stage()
        self.add_standard_timestep_preparation_stage(
            prepare_extra_kwargs=prepare_extra_timestep_kwargs
        )
        if progressive_denoising_stage_cls is None:
            self.add_standard_denoising_stage()
        else:
            self.add_progressive_denoising_stage(progressive_denoising_stage_cls)
        self.add_standard_decoding_stage()

        return self

    def add_standard_ti2i_stages(
        self,
        *,
        include_input_validation: bool = True,
        vae_image_processor: Any | None = None,
        prompt_encoding: Literal["text", "image_encoding"] = "text",
        text_encoder_key: str = "text_encoder",
        tokenizer_key: str = "tokenizer",
        image_processor_key: str = "processor",
        prompt_text_encoder_key: str = "text_encoder",
        image_vae_key: str = "vae",
        image_vae_stage_kwargs: dict[str, Any] | None = None,
        prepare_extra_timestep_kwargs: list[Callable] | None = None,
        progressive_denoising_stage_cls: type[ProgressiveDenoisingStage] | None = None,
    ) -> "ComposedPipelineBase":
        if include_input_validation:
            self.add_stage(
                InputValidationStage(vae_image_processor=vae_image_processor)
            )

        if prompt_encoding == "text":
            self.add_standard_text_encoding_stage(
                text_encoder_key=text_encoder_key,
                tokenizer_key=tokenizer_key,
            )
        elif prompt_encoding == "image_encoding":
            self.add_stage(
                ImageEncodingStage(
                    image_processor=self.get_module(image_processor_key),
                    text_encoder=self.get_module(prompt_text_encoder_key),
                ),
            )
        else:
            raise ValueError(f"Unknown prompt_encoding: {prompt_encoding}")

        self.add_stage(
            ImageVAEEncodingStage(
                vae=self.get_module(image_vae_key),
                **{
                    "component_name": image_vae_key,
                    **(image_vae_stage_kwargs or {}),
                },
            ),
        )

        self.add_standard_latent_preparation_stage()

        self.add_standard_timestep_preparation_stage(
            prepare_extra_kwargs=prepare_extra_timestep_kwargs
        )
        if progressive_denoising_stage_cls is None:
            self.add_standard_denoising_stage()
        else:
            self.add_progressive_denoising_stage(progressive_denoising_stage_cls)
        self.add_standard_decoding_stage()
        return self

    def add_standard_ti2v_stages(
        self,
        *,
        include_input_validation: bool = True,
        vae_image_processor: Any | None = None,
        text_encoder_key: str = "text_encoder",
        tokenizer_key: str = "tokenizer",
        image_encoder_key: str = "image_encoder",
        image_processor_key: str = "image_processor",
        image_vae_key: str = "vae",
        image_vae_stage_kwargs: dict[str, Any] | None = None,
        image_vae_encoding_position: Literal[
            "before_timestep", "after_latent"
        ] = "before_timestep",
        prepare_extra_timestep_kwargs: list[Callable] | None = None,
        denoising_stage_factory: Callable[[], PipelineStage] | None = None,
        denoising_stage_name: str = "denoising_stage",
    ) -> "ComposedPipelineBase":
        if include_input_validation:
            self.add_stage(
                InputValidationStage(vae_image_processor=vae_image_processor)
            )

        self.add_standard_text_encoding_stage(
            text_encoder_key=text_encoder_key,
            tokenizer_key=tokenizer_key,
        )

        image_encoder = self.get_module(image_encoder_key, None)
        image_processor = self.get_module(image_processor_key, None)
        self.add_stage_if(
            image_encoder is not None and image_processor is not None,
            ImageEncodingStage(
                image_encoder=image_encoder,
                image_processor=image_processor,
            ),
        )

        if image_vae_encoding_position == "before_timestep":
            self.add_stage(
                ImageVAEEncodingStage(
                    vae=self.get_module(image_vae_key),
                    **{
                        "component_name": image_vae_key,
                        **(image_vae_stage_kwargs or {}),
                    },
                )
            )

        self.add_standard_latent_preparation_stage()
        self.add_standard_timestep_preparation_stage(
            prepare_extra_kwargs=prepare_extra_timestep_kwargs
        )
        if image_vae_encoding_position == "after_latent":
            self.add_stage(
                ImageVAEEncodingStage(
                    vae=self.get_module(image_vae_key),
                    **{
                        "component_name": image_vae_key,
                        **(image_vae_stage_kwargs or {}),
                    },
                )
            )
        elif image_vae_encoding_position != "before_timestep":
            raise ValueError(
                f"Unknown image_vae_encoding_position: {image_vae_encoding_position}"
            )

        if denoising_stage_factory is None:
            self.add_standard_denoising_stage()
        else:
            self.add_stage_factory(
                RoleType.DENOISER,
                denoising_stage_factory,
                denoising_stage_name,
            )

        self.add_standard_decoding_stage()
        return self

    # TODO(will): don't hardcode no_grad
    @torch.no_grad()
    def forward(
        self,
        batch: Req,
        server_args: ServerArgs,
    ) -> OutputBatch:
        """
        Generate a video or image using the pipeline.

        Args:
            batch: The batch to generate from.
            server_args: The inference arguments.
        Returns:
            Req: The batch with the generated video or image.
        """

        if self.is_lora_set() and not self.is_lora_effective():
            logger.warning(
                "LoRA adapter is set, but not effective. Please make sure the LoRA weights are merged"
            )

        # Execute each stage
        if not batch.is_warmup and not batch.suppress_logs:
            stage_logger = (
                logger.debug
                if server_args.pipeline_config.task_type.is_action_gen()
                else logger.info
            )
            stage_logger(
                "Running pipeline stages: %s",
                list(self._stage_name_mapping.keys()),
                main_process_only=True,
            )

        self.component_residency_manager = get_global_component_residency_manager(
            self, server_args
        )
        self.executor.component_residency_manager = self.component_residency_manager

        return self.executor.execute_with_profiling(self.stages, batch, server_args)

    @torch.no_grad()
    def forward_batch(
        self,
        batches: list[Req],
        server_args: ServerArgs,
    ):
        if len(batches) == 1:
            return [self.forward(batches[0], server_args)]

        if self.is_lora_set() and not self.is_lora_effective():
            logger.warning(
                "LoRA adapter is set, but not effective. Please make sure the LoRA weights are merged"
            )

        if not batches[0].is_warmup and not batches[0].suppress_logs:
            stage_logger = (
                logger.debug
                if server_args.pipeline_config.task_type.is_action_gen()
                else logger.info
            )
            stage_logger(
                "Running grouped pipeline stages: %s",
                list(self._stage_name_mapping.keys()),
                main_process_only=True,
            )

        self.component_residency_manager = get_global_component_residency_manager(
            self, server_args
        )
        self.executor.component_residency_manager = self.component_residency_manager
        return self.executor.execute_group_with_profiling(
            self.stages, batches, server_args
        )

    @torch.no_grad()
    def forward_batch_sequentially(
        self,
        batches: list[Req],
        server_args: ServerArgs,
    ) -> Iterator[OutputBatch]:
        """Yield grouped outputs as each terminal-stage invocation completes."""
        if len(batches) == 1 and (
            not server_args.pipeline_config.supports_sequential_multi_output_inference()
            or max(1, int(batches[0].num_outputs_per_prompt or 1)) == 1
        ):
            yield self.forward(batches[0], server_args)
            return

        self.component_residency_manager = get_global_component_residency_manager(
            self, server_args
        )
        self.executor.component_residency_manager = self.component_residency_manager
        yield from self.executor.execute_group_sequentially_with_profiling(
            self.stages,
            batches,
            server_args,
        )
